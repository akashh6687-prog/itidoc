const STORAGE_KEY = "attendance-tracker-state-v4";
const PORTAL_APP_NAME = "attendance";
const LEGACY_STORAGE_KEYS = [
  "attendance-tracker-state-v3",
  "attendance-tracker-state-v2",
  "attendance-tracker-state-v1",
];
const DEFAULT_MONTH_KEYS = new Set(window.DEFAULT_ATTENDANCE_DATA.months.map((month) => month.key));
const DEFAULT_RECORDS = buildDefaultRecordMap(window.DEFAULT_ATTENDANCE_DATA);
const MONTH_NAMES = [
  "",
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const MONTH_ABBREVIATIONS = [
  "",
  "JAN",
  "FEB",
  "MAR",
  "APR",
  "MAY",
  "JUN",
  "JUL",
  "AUG",
  "SEP",
  "OCT",
  "NOV",
  "DEC",
];
const MONTH_TAB_LABELS = [
  "",
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];
const { downloadExcelDocument } = window.OfficeExport;

document.documentElement.classList.toggle("is-embedded", window.parent !== window);
document.body.classList.toggle("is-embedded", window.parent !== window);

const state = {
  data: loadState(),
  selectedMonthKey: null,
};
let portalSharedState = null;

const refs = {
  institutionName: document.getElementById("institutionName"),
  subtitleLine: document.getElementById("subtitleLine"),
  programLine: document.getElementById("programLine"),
  snapshotStats: document.getElementById("snapshotStats"),
  topTrainees: document.getElementById("topTrainees"),
  lowestTrainees: document.getElementById("lowestTrainees"),
  monthTabs: document.getElementById("monthTabs"),
  attendanceSheet: document.getElementById("attendanceSheet"),
  addMonthButton: document.getElementById("addMonthButton"),
  removeMonthButton: document.getElementById("removeMonthButton"),
  addTraineeButton: document.getElementById("addTraineeButton"),
  removeTraineeButton: document.getElementById("removeTraineeButton"),
  downloadExcelButton: document.getElementById("downloadExcelButton"),
  printButton: document.getElementById("printButton"),
  addMonthDialog: document.getElementById("addMonthDialog"),
  addMonthForm: document.getElementById("addMonthForm"),
  closeDialogButton: document.getElementById("closeDialogButton"),
  cancelDialogButton: document.getElementById("cancelDialogButton"),
  newMonthName: document.getElementById("newMonthName"),
  newMonthYear: document.getElementById("newMonthYear"),
  defaultPossibleDays: document.getElementById("defaultPossibleDays"),
  addTraineeDialog: document.getElementById("addTraineeDialog"),
  addTraineeForm: document.getElementById("addTraineeForm"),
  addTraineeTitle: document.getElementById("addTraineeTitle"),
  closeAddTraineeButton: document.getElementById("closeAddTraineeButton"),
  cancelAddTraineeButton: document.getElementById("cancelAddTraineeButton"),
  traineeAdmissionNo: document.getElementById("traineeAdmissionNo"),
  traineeName: document.getElementById("traineeName"),
  traineePossibleDays: document.getElementById("traineePossibleDays"),
  removeTraineeDialog: document.getElementById("removeTraineeDialog"),
  removeTraineeForm: document.getElementById("removeTraineeForm"),
  removeTraineeTitle: document.getElementById("removeTraineeTitle"),
  closeRemoveTraineeButton: document.getElementById("closeRemoveTraineeButton"),
  cancelRemoveTraineeButton: document.getElementById("cancelRemoveTraineeButton"),
  removeTraineeSelect: document.getElementById("removeTraineeSelect"),
};

initialize();

function initialize() {
  normalizeState(state.data);
  state.selectedMonthKey = state.data.months.at(-1)?.key ?? null;

  seedNextMonth();
  attachEvents();
  render();
}

function loadState() {
  const stored = readStoredPayload(STORAGE_KEY);
  if (stored) {
    return stored;
  }

  for (const legacyKey of LEGACY_STORAGE_KEYS) {
    const legacyPayload = readStoredPayload(legacyKey);
    if (legacyPayload) {
      return legacyPayload;
    }
  }

  return structuredClone(window.DEFAULT_ATTENDANCE_DATA);
}

function readStoredPayload(key) {
  const raw = localStorage.getItem(key);
  if (!raw) {
    return null;
  }

  try {
    return JSON.parse(raw);
  } catch (error) {
    console.warn(`Could not read saved state for ${key}.`, error);
    return null;
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.data));
}

function normalizeState(data) {
  const masterStudents = new Map(
    (data.students ?? []).map((student) => [
      String(student.admissionNo),
      {
        name: (student.name ?? "").trim(),
      },
    ]),
  );

  data.months = [...(data.months ?? [])]
    .map((month) => {
      const key = month.key ?? `${String(month.year).padStart(4, "0")}-${String(month.month).padStart(2, "0")}`;
      const [yearText, monthText] = key.split("-");
      const year = month.year ?? Number(yearText);
      const monthNumber = month.month ?? Number(monthText);
      const records = (month.records ?? [])
        .map((record) => {
          const admissionNo = String(record.admissionNo ?? "").trim();
          const knownStudent = masterStudents.get(admissionNo);
          return {
            admissionNo,
            name: (record.name ?? knownStudent?.name ?? "").trim(),
            present: toNumberOrNull(record.present),
            possible: toNumberOrNull(record.possible),
            sfDays: toNumberOrNull(record.sfDays),
          };
        })
        .filter((record) => record.admissionNo && record.name);

      return {
        ...month,
        key,
        year,
        month: monthNumber,
        label: month.label ?? `${MONTH_NAMES[monthNumber]} ${year}`,
        isCustom: month.isCustom ?? !DEFAULT_MONTH_KEYS.has(key),
        records,
      };
    })
    .sort((left, right) => left.key.localeCompare(right.key));
}

function attachEvents() {
  refs.addMonthButton.addEventListener("click", () => {
    refs.addMonthDialog.showModal();
  });

  refs.removeMonthButton.addEventListener("click", removeSelectedMonth);
  refs.addTraineeButton.addEventListener("click", openAddTraineeDialog);
  refs.removeTraineeButton.addEventListener("click", openRemoveTraineeDialog);
  refs.downloadExcelButton.addEventListener("click", downloadAttendanceExcel);
  refs.printButton.addEventListener("click", () => {
    window.print();
  });

  refs.closeDialogButton.addEventListener("click", closeAddMonthDialog);
  refs.cancelDialogButton.addEventListener("click", closeAddMonthDialog);
  refs.addMonthForm.addEventListener("submit", (event) => {
    event.preventDefault();
    createMonth();
  });

  refs.closeAddTraineeButton.addEventListener("click", closeAddTraineeDialog);
  refs.cancelAddTraineeButton.addEventListener("click", closeAddTraineeDialog);
  refs.addTraineeForm.addEventListener("submit", (event) => {
    event.preventDefault();
    addTraineeToSelectedMonth();
  });

  refs.closeRemoveTraineeButton.addEventListener("click", closeRemoveTraineeDialog);
  refs.cancelRemoveTraineeButton.addEventListener("click", closeRemoveTraineeDialog);
  refs.removeTraineeForm.addEventListener("submit", (event) => {
    event.preventDefault();
    removeTraineeFromSelectedMonth();
  });

  refs.monthTabs.addEventListener("click", (event) => {
    const button = event.target.closest("[data-month-key]");
    if (!button) {
      return;
    }

    state.selectedMonthKey = button.dataset.monthKey;
    render();
  });

  refs.attendanceSheet.addEventListener("input", (event) => {
    const input = event.target.closest(".sheet-input");
    if (!input) {
      return;
    }

    const { monthKey, admissionNo, field } = input.dataset;
    const month = state.data.months.find((item) => item.key === monthKey);
    const record = month?.records.find((item) => item.admissionNo === admissionNo);
    if (!record) {
      return;
    }

    record[field] = toNumberOrNull(input.value);
    saveState();
    render();
  });
}

function applyPortalSharedData(payload) {
  if (!payload || typeof payload !== "object") {
    return;
  }

  portalSharedState = payload;
  const institution = String(payload.itiName || payload.institution || state.data.meta.institution || "").trim();
  const programSource = String(
    payload.tradeNameLong
    || payload.tradeLong
    || payload.tradeNameShort
    || payload.tradeName
    || ""
  ).trim();

  if (institution) {
    state.data.meta.institution = institution;
  }

  if (programSource) {
    state.data.meta.program = programSource.toUpperCase().startsWith("TRADE")
      ? programSource
      : `TRADE : ${programSource}`;
  }

  const rosterEntries = Array.isArray(payload.rosterEntries)
    ? payload.rosterEntries
      .map((entry) => ({
        admissionNo: String(entry?.admNo || "").trim(),
        name: String(entry?.name || "").trim(),
      }))
      .filter((entry) => entry.admissionNo || entry.name)
    : [];

  if (rosterEntries.length && isPortalRosterSyncEnabled()) {
    syncRosterFromPortal(rosterEntries);
  }

  normalizeState(state.data);
  if (!state.data.months.some((month) => month.key === state.selectedMonthKey)) {
    state.selectedMonthKey = state.data.months.at(-1)?.key ?? null;
  }
  saveState();
  render();
  notifyPortalApplied();
}

function syncRosterFromPortal(rosterEntries) {
  setPortalRosterMode("portal");
  state.data.students = rosterEntries.map((entry, index) => ({
    slNo: index + 1,
    admissionNo: entry.admissionNo,
    name: entry.name,
  }));

  state.data.months = state.data.months.map((month) => {
    const commonPossible = getCommonPossibleValue(month);
    const recordByAdmission = new Map(
      (month.records ?? []).map((record) => [normalizePortalMatchToken(record.admissionNo), record])
    );
    const recordByName = new Map(
      (month.records ?? []).map((record) => [normalizePortalMatchToken(record.name), record])
    );

    return {
      ...month,
      records: rosterEntries.map((entry) => {
        const admissionKey = normalizePortalMatchToken(entry.admissionNo);
        const nameKey = normalizePortalMatchToken(entry.name);
        const match =
          (admissionKey ? recordByAdmission.get(admissionKey) : null)
          || (nameKey ? recordByName.get(nameKey) : null)
          || null;

        return {
          admissionNo: entry.admissionNo,
          name: entry.name,
          present: match?.present ?? null,
          possible: match?.possible ?? commonPossible,
          sfDays: match?.sfDays ?? null,
        };
      }),
    };
  });
}

function lockPortalManagedControls(selectedMonth) {
  const usingCustomRoster = !isPortalRosterSyncEnabled();
  refs.addTraineeButton.disabled = !selectedMonth;
  refs.removeTraineeButton.disabled = !selectedMonth || selectedMonth.rows.length === 0;
  refs.addTraineeButton.title = usingCustomRoster ? "Attendance-specific roster is active for this tab." : "";
  refs.removeTraineeButton.title = usingCustomRoster ? "Attendance-specific roster is active for this tab." : "";
}

function notifyPortalReady() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage({ type: "portal:ready", app: PORTAL_APP_NAME }, "*");
  reportPortalHeight();
}

function notifyPortalApplied() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:applied", app: PORTAL_APP_NAME, height: getPortalHeight() },
    "*",
  );
}

function reportPortalHeight() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:height", app: PORTAL_APP_NAME, height: getPortalHeight() },
    "*",
  );
}

function getPortalHeight() {
  const shell = document.querySelector(".app-shell");
  const bodyStyles = window.getComputedStyle(document.body);
  const bodyMargins =
    (Number.parseFloat(bodyStyles.marginTop) || 0)
    + (Number.parseFloat(bodyStyles.marginBottom) || 0);
  const contentHeight = shell
    ? Math.max(shell.scrollHeight || 0, shell.offsetHeight || 0)
    : Math.max(
      document.documentElement?.scrollHeight || 0,
      document.body?.scrollHeight || 0,
      document.documentElement?.offsetHeight || 0,
      document.body?.offsetHeight || 0,
    );

  return contentHeight + bodyMargins;
}

function render() {
  refs.institutionName.textContent = state.data.meta.institution || "";
  refs.subtitleLine.textContent = state.data.meta.subtitle || "";
  refs.programLine.textContent = state.data.meta.program || "";

  const computedMonths = computeMonthSummaries();
  const selectedMonth = computedMonths.find((month) => month.key === state.selectedMonthKey) ?? computedMonths.at(-1) ?? null;
  state.selectedMonthKey = selectedMonth?.key ?? null;

  refs.removeMonthButton.disabled = state.data.months.length <= 1;
  refs.addTraineeButton.disabled = !selectedMonth;
  refs.removeTraineeButton.disabled = !selectedMonth || selectedMonth.rows.length === 0;

  renderSnapshot(selectedMonth, computedMonths.length);
  renderMonthTabs();
  renderSheet(selectedMonth);
  lockPortalManagedControls(selectedMonth);
  reportPortalHeight();
}

function computeMonthSummaries() {
  const runningTotals = new Map();
  const divergenceMap = new Map();

  return state.data.months.map((month) => {
    const rows = month.records.map((record, index) => {
      const previous = runningTotals.get(record.admissionNo) ?? {
        cumulativePresent: 0,
        cumulativePossible: 0,
      };
      const hadDiverged = divergenceMap.get(record.admissionNo) ?? false;
      const defaultRecord = DEFAULT_RECORDS.get(month.key)?.get(record.admissionNo) ?? null;

      const present = toNumberOrNull(record.present);
      const possible = toNumberOrNull(record.possible);
      const sfDays = toNumberOrNull(record.sfDays);
      const hasMonthlyInput = present != null && possible != null;
      const creditedPresent = hasMonthlyInput ? roundToHalf(present + (sfDays ?? 0)) : null;
      const matchesDefaultInputs =
        !month.isCustom &&
        defaultRecord != null &&
        valuesMatch(present, defaultRecord.present) &&
        valuesMatch(possible, defaultRecord.possible) &&
        valuesMatch(sfDays, defaultRecord.sfDays);

      let displayPresentWithSf;
      let monthlyPercentage;
      let cumulativePresent;
      let cumulativePossible;
      let cumulativePercentage;
      let remark;

      if (!hadDiverged && matchesDefaultInputs) {
        displayPresentWithSf = defaultRecord.sheetPresentWithSf;
        monthlyPercentage = defaultRecord.sheetMonthlyPercentage;
        cumulativePresent = defaultRecord.sheetCumulativePresent ?? previous.cumulativePresent;
        cumulativePossible = defaultRecord.sheetCumulativePossible ?? previous.cumulativePossible;
        cumulativePercentage = defaultRecord.sheetCumulativePercentage;
        remark = defaultRecord.sheetRemark ?? "";
      } else {
        displayPresentWithSf = hasMonthlyInput && (sfDays ?? 0) > 0 ? creditedPresent : null;
        monthlyPercentage = hasMonthlyInput && possible > 0 ? roundToTwo((present / possible) * 100) : null;
        cumulativePresent = hasMonthlyInput
          ? roundToHalf(previous.cumulativePresent + creditedPresent)
          : previous.cumulativePresent;
        cumulativePossible = hasMonthlyInput
          ? roundToHalf(previous.cumulativePossible + possible)
          : previous.cumulativePossible;
        cumulativePercentage = cumulativePossible > 0 ? roundToTwo((cumulativePresent / cumulativePossible) * 100) : null;
        remark = (sfDays ?? 0) > 0 ? "SF" : "";
        divergenceMap.set(record.admissionNo, true);
      }

      const printedCumulativePercentage = getPrintedPercentageValue(cumulativePercentage);
      const isUnder80 = printedCumulativePercentage != null && printedCumulativePercentage <= 79;
      if (isUnder80) {
        remark = "under 80%";
      } else if (remark === "under 80%") {
        remark = "";
      }

      const rowSummary = {
        slNo: index + 1,
        admissionNo: record.admissionNo,
        name: record.name,
        present,
        possible,
        sfDays,
        displayPresentWithSf,
        monthlyPercentage,
        cumulativePresent,
        cumulativePossible,
        cumulativePercentage,
        remark,
        isUnder80,
      };

      runningTotals.set(record.admissionNo, {
        cumulativePresent,
        cumulativePossible,
      });

      if (!hadDiverged && matchesDefaultInputs) {
        divergenceMap.set(record.admissionNo, false);
      }

      return rowSummary;
    });

    const cumulativeRows = rows.filter((row) => row.cumulativePercentage != null);
    const classAverage = cumulativeRows.length
      ? roundToTwo(cumulativeRows.reduce((sum, row) => sum + row.cumulativePercentage, 0) / cumulativeRows.length)
      : null;
    const under80Count = rows.filter((row) => row.isUnder80).length;
    const topTrainees = [...cumulativeRows]
      .sort((left, right) => {
        if (right.cumulativePercentage !== left.cumulativePercentage) {
          return right.cumulativePercentage - left.cumulativePercentage;
        }
        return right.cumulativePresent - left.cumulativePresent;
      })
      .slice(0, 3);
    const lowestTrainees = [...cumulativeRows]
      .sort((left, right) => {
        if (left.cumulativePercentage !== right.cumulativePercentage) {
          return left.cumulativePercentage - right.cumulativePercentage;
        }
        return left.cumulativePresent - right.cumulativePresent;
      })
      .slice(0, 3);

    return {
      ...month,
      rows,
      classAverage,
      under80Count,
      topTrainees,
      lowestTrainees,
      sheetMonthLabel: `${MONTH_ABBREVIATIONS[month.month]}-${month.year}`,
    };
  });
}

function renderSnapshot(selectedMonth, monthCount) {
  if (!selectedMonth) {
    refs.snapshotStats.innerHTML = "";
    refs.topTrainees.innerHTML = "";
    refs.lowestTrainees.innerHTML = "";
    return;
  }

  const summaryItems = [
    {
      label: "Selected Month",
      value: selectedMonth.label,
    },
    {
      label: "Class Average",
      value: selectedMonth.classAverage == null ? "--" : `${formatSummaryPercentage(selectedMonth.classAverage)}%`,
    },
    {
      label: "Below 80%",
      value: String(selectedMonth.under80Count),
    },
    {
      label: "Months",
      value: String(monthCount),
    },
  ];

  refs.snapshotStats.innerHTML = summaryItems
    .map(
      (item) => `
        <div class="snapshot-pill">
          <span>${item.label}</span>
          <strong>${item.value}</strong>
        </div>
      `,
    )
    .join("");

  refs.topTrainees.innerHTML = renderTraineeCards(selectedMonth.topTrainees, "Top");
  refs.lowestTrainees.innerHTML = renderTraineeCards(selectedMonth.lowestTrainees, "Low");
}

function renderTraineeCards(trainees, prefix) {
  if (!trainees.length) {
    return `<article class="trainee-card empty-card">No data yet</article>`;
  }

  return trainees
    .map(
      (trainee, index) => `
        <article class="trainee-card compact-card">
          <div class="trainee-rank">${prefix} ${index + 1}</div>
          <div class="trainee-name">${escapeHtml(trainee.name)}</div>
          <div class="trainee-meta">Adm No ${escapeHtml(trainee.admissionNo)}</div>
          <div class="trainee-score">${formatSummaryPercentage(trainee.cumulativePercentage)}%</div>
        </article>
      `,
    )
    .join("");
}

function renderMonthTabs() {
  refs.monthTabs.innerHTML = state.data.months
    .map((month) => {
      const classes = ["month-chip"];
      if (month.key === state.selectedMonthKey) {
        classes.push("active");
      }

      return `<button class="${classes.join(" ")}" type="button" data-month-key="${month.key}">${shortMonthLabel(month)}</button>`;
    })
    .join("");
}

function renderSheet(selectedMonth) {
  if (!selectedMonth) {
    refs.attendanceSheet.innerHTML = "";
    return;
  }

  refs.attendanceSheet.innerHTML = `
    <table class="register-sheet">
      <colgroup>
        <col class="sl-col" />
        <col class="adm-col" />
        <col class="name-col" />
        <col class="narrow-col" />
        <col class="narrow-col" />
        <col class="mid-col" />
        <col class="narrow-col" />
        <col class="narrow-col" />
        <col class="mid-col" />
        <col class="mid-col" />
        <col class="narrow-col" />
        <col class="remark-col" />
      </colgroup>
      <thead>
        <tr>
          <th colspan="12" class="sheet-title">${escapeHtml(state.data.meta.institution || "")}</th>
        </tr>
        <tr>
          <th colspan="12" class="sheet-subtitle">${escapeHtml(state.data.meta.subtitle || "")}</th>
        </tr>
        <tr>
          <th colspan="9" class="sheet-program">${escapeHtml(state.data.meta.program || "")}</th>
          <th colspan="3" class="sheet-month">${selectedMonth.sheetMonthLabel}</th>
        </tr>
        <tr class="header-row">
          <th class="header-basic">SL NO</th>
          <th class="header-basic">ADM<br />NO</th>
          <th class="header-basic header-name">NAME</th>
          <th class="vertical-header"><span class="rotated-label">PRESENT</span></th>
          <th class="vertical-header"><span class="rotated-label">SF day(s)</span></th>
          <th class="vertical-header"><span class="rotated-label">PRESENT WITH SF</span></th>
          <th class="vertical-header"><span class="rotated-label">POSSIBLE</span></th>
          <th class="vertical-header"><span class="rotated-label">PERCENTAGE</span></th>
          <th class="vertical-header"><span class="rotated-label">CUMULATIVE PRESENT</span></th>
          <th class="vertical-header"><span class="rotated-label">CUMULATIVE POSSIBLE</span></th>
          <th class="vertical-header"><span class="rotated-label">PERCENTAGE</span></th>
          <th class="header-basic">REMARKS</th>
        </tr>
      </thead>
      <tbody>
        ${selectedMonth.rows
          .map(
            (row) => `
              <tr class="data-row ${row.isUnder80 ? "under-80-row" : ""}">
                <td class="sheet-number">${row.slNo}</td>
                <td class="sheet-number">${escapeHtml(row.admissionNo)}</td>
                <td class="sheet-name">${escapeHtml(row.name)}</td>
                <td>${renderInputCell("present", selectedMonth.key, row.admissionNo, row.present)}</td>
                <td>${renderInputCell("sfDays", selectedMonth.key, row.admissionNo, row.sfDays)}</td>
                <td class="sheet-number">${formatSheetValue(row.displayPresentWithSf)}</td>
                <td>${renderInputCell("possible", selectedMonth.key, row.admissionNo, row.possible)}</td>
                <td class="sheet-number">${formatSheetPercentage(row.monthlyPercentage)}</td>
                <td class="sheet-number">${formatSheetValue(row.cumulativePresent)}</td>
                <td class="sheet-number">${formatSheetValue(row.cumulativePossible)}</td>
                <td class="sheet-number">${formatSheetPercentage(row.cumulativePercentage)}</td>
                <td class="remarks-cell">${escapeHtml(row.remark)}</td>
              </tr>
            `,
          )
          .join("")}
        <tr class="signature-row">
          <td colspan="4">SIGNATURE OF INSTRUCTOR</td>
          <td colspan="4">GI</td>
          <td colspan="4">PRINCIPAL</td>
        </tr>
      </tbody>
    </table>
  `;
}

function renderInputCell(field, monthKey, admissionNo, value) {
  const safeValue = value == null ? "" : String(value);
  return `<input class="sheet-input" type="number" min="0" step="0.5" value="${safeValue}" data-month-key="${monthKey}" data-admission-no="${admissionNo}" data-field="${field}" />`;
}

function downloadAttendanceExcel() {
  const sheet = refs.attendanceSheet.querySelector(".register-sheet");
  const selectedMonth = getSelectedMonthData();
  if (!sheet || !selectedMonth) {
    return;
  }

  downloadExcelDocument({
    filename: `attendance-${sanitizeFilename(selectedMonth.label)}.xls`,
    title: `Attendance ${selectedMonth.label}`,
    worksheetName: "Attendance",
    pageOrientation: "landscape",
    sources: sheet,
    extraStyles: `
      .register-sheet {
        margin: 0 auto;
      }
    `,
  });
}

function createMonth() {
  const monthNumber = Number(refs.newMonthName.value);
  const year = Number(refs.newMonthYear.value);
  const key = `${String(year).padStart(4, "0")}-${String(monthNumber).padStart(2, "0")}`;

  if (state.data.months.some((month) => month.key === key)) {
    window.alert("That month already exists.");
    return;
  }

  const sourceMonth = state.data.months.find((month) => month.key === state.selectedMonthKey) ?? state.data.months.at(-1);
  const commonPossible = toNumberOrNull(refs.defaultPossibleDays.value) ?? getCommonPossibleValue(sourceMonth);
  const roster = (sourceMonth?.records ?? []).map((record) => ({
    admissionNo: record.admissionNo,
    name: record.name,
    present: null,
    possible: commonPossible,
    sfDays: null,
  }));

  state.data.months.push({
    key,
    year,
    month: monthNumber,
    label: `${MONTH_NAMES[monthNumber]} ${year}`,
    isCustom: true,
    records: roster,
  });

  normalizeState(state.data);
  state.selectedMonthKey = key;
  saveState();
  render();
  closeAddMonthDialog();
}

function removeSelectedMonth() {
  if (state.data.months.length <= 1) {
    window.alert("At least one month should remain.");
    return;
  }

  const selectedMonth = state.data.months.find((month) => month.key === state.selectedMonthKey);
  if (!selectedMonth) {
    return;
  }

  if (!window.confirm(`Remove ${selectedMonth.label}?`)) {
    return;
  }

  const index = state.data.months.findIndex((month) => month.key === selectedMonth.key);
  state.data.months.splice(index, 1);
  const fallbackMonth = state.data.months[Math.max(0, index - 1)] ?? state.data.months[0] ?? null;
  state.selectedMonthKey = fallbackMonth?.key ?? null;
  saveState();
  render();
}

function openAddTraineeDialog() {
  const selectedMonth = getSelectedMonthData();
  if (!selectedMonth) {
    return;
  }

  refs.addTraineeTitle.textContent = `Add Trainee to ${selectedMonth.label}`;
  refs.traineePossibleDays.value = formatDialogValue(getCommonPossibleValue(selectedMonth));
  refs.addTraineeDialog.showModal();
}

function closeAddTraineeDialog() {
  refs.addTraineeDialog.close();
  refs.addTraineeForm.reset();
}

function addTraineeToSelectedMonth() {
  const selectedMonth = getSelectedMonthData();
  if (!selectedMonth) {
    return;
  }

  const admissionNo = refs.traineeAdmissionNo.value.trim();
  const name = refs.traineeName.value.trim();
  const possible = toNumberOrNull(refs.traineePossibleDays.value);

  if (!admissionNo || !name) {
    window.alert("Admission number and trainee name are required.");
    return;
  }

  if (selectedMonth.records.some((record) => record.admissionNo === admissionNo)) {
    window.alert("That admission number already exists in this month.");
    return;
  }

  selectedMonth.records.push({
    admissionNo,
    name,
    present: null,
    possible,
    sfDays: null,
  });

  setPortalRosterMode("custom");
  saveState();
  render();
  closeAddTraineeDialog();
}

function openRemoveTraineeDialog() {
  const selectedMonth = getSelectedMonthData();
  if (!selectedMonth || selectedMonth.records.length === 0) {
    return;
  }

  refs.removeTraineeTitle.textContent = `Remove Trainee from ${selectedMonth.label}`;
  refs.removeTraineeSelect.innerHTML = selectedMonth.records
    .map(
      (record) =>
        `<option value="${escapeHtml(record.admissionNo)}">${escapeHtml(record.admissionNo)} - ${escapeHtml(record.name)}</option>`,
    )
    .join("");
  refs.removeTraineeDialog.showModal();
}

function closeRemoveTraineeDialog() {
  refs.removeTraineeDialog.close();
  refs.removeTraineeForm.reset();
  refs.removeTraineeSelect.innerHTML = "";
}

function removeTraineeFromSelectedMonth() {
  const selectedMonth = getSelectedMonthData();
  if (!selectedMonth) {
    return;
  }

  const admissionNo = refs.removeTraineeSelect.value;
  if (!admissionNo) {
    return;
  }

  const index = selectedMonth.records.findIndex((record) => record.admissionNo === admissionNo);
  if (index === -1) {
    return;
  }

  selectedMonth.records.splice(index, 1);
  setPortalRosterMode("custom");
  saveState();
  render();
  closeRemoveTraineeDialog();
}

function closeAddMonthDialog() {
  refs.addMonthDialog.close();
  refs.addMonthForm.reset();
  seedNextMonth();
}

function seedNextMonth() {
  const nextMonth = getNextMonthSeed();
  refs.newMonthName.value = String(nextMonth.month);
  refs.newMonthYear.value = String(nextMonth.year);
}

function getNextMonthSeed() {
  const lastMonth = state.data.months.at(-1);
  if (!lastMonth) {
    const now = new Date();
    return {
      year: now.getFullYear(),
      month: now.getMonth() + 1,
    };
  }

  const next = new Date(lastMonth.year, lastMonth.month - 1, 1);
  next.setMonth(next.getMonth() + 1);
  return {
    year: next.getFullYear(),
    month: next.getMonth() + 1,
  };
}

function getSelectedMonthData() {
  return state.data.months.find((month) => month.key === state.selectedMonthKey) ?? null;
}

function isPortalRosterSyncEnabled() {
  return state.data.meta?.portalRosterMode !== "custom";
}

function setPortalRosterMode(mode) {
  state.data.meta = state.data.meta && typeof state.data.meta === "object"
    ? state.data.meta
    : {};
  state.data.meta.portalRosterMode = mode;
}

function getCommonPossibleValue(month) {
  const values = (month?.records ?? [])
    .map((record) => toNumberOrNull(record.possible))
    .filter((value) => value != null);
  if (!values.length) {
    return null;
  }

  const counts = new Map();
  for (const value of values) {
    const key = String(value);
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }

  const [bestKey] = [...counts.entries()].sort((left, right) => right[1] - left[1])[0];
  return Number(bestKey);
}

function buildDefaultRecordMap(data) {
  return new Map(
    data.months.map((month) => [
      month.key,
      new Map(month.records.map((record) => [String(record.admissionNo), record])),
    ]),
  );
}

function valuesMatch(left, right) {
  const normalizedLeft = left == null ? null : Number(left);
  const normalizedRight = right == null ? null : Number(right);
  return normalizedLeft === normalizedRight;
}

function shortMonthLabel(month) {
  return `${MONTH_TAB_LABELS[month.month]} ${month.year}`;
}

function formatSheetValue(value) {
  if (value == null || Number.isNaN(value)) {
    return "";
  }

  return Number.isInteger(value) ? String(value) : value.toFixed(1).replace(/\.0$/, "");
}

function formatSheetPercentage(value) {
  const printedValue = getPrintedPercentageValue(value);
  if (printedValue == null) {
    return "";
  }

  return String(printedValue);
}

function formatSummaryPercentage(value) {
  if (value == null || Number.isNaN(value)) {
    return "--";
  }

  return value.toFixed(1).replace(/\.0$/, "");
}

function getPrintedPercentageValue(value) {
  if (value == null || Number.isNaN(value)) {
    return null;
  }

  return Math.round(value);
}

function formatDialogValue(value) {
  return value == null ? "" : String(value);
}

function sanitizeFilename(value) {
  return String(value || "")
    .trim()
    .replace(/[<>:"/\\|?*]+/g, "-")
    .replace(/\s+/g, "-")
    .toLowerCase();
}

function roundToTwo(value) {
  return Math.round(value * 100) / 100;
}

function roundToHalf(value) {
  return Math.round(value * 2) / 2;
}

function normalizePortalMatchToken(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function toNumberOrNull(value) {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

window.addEventListener("message", (event) => {
  if (event.data?.type !== "portal-shared-update" || event.data?.app !== PORTAL_APP_NAME) {
    return;
  }

  applyPortalSharedData(event.data.payload);
});

window.addEventListener("load", () => {
  if (window.parent !== window) {
    notifyPortalReady();
  }
});

window.addEventListener("resize", reportPortalHeight);

if (typeof ResizeObserver === "function") {
  const portalObserver = new ResizeObserver(() => {
    reportPortalHeight();
  });
  portalObserver.observe(document.querySelector(".app-shell") || document.body);
}
