const appData = window.APP_DATA;
const { downloadExcelDocument } = window.OfficeExport;
const storageKey = "annex-ii-site-state-v2";
const PLANNER_OUTCOME_STORAGE_KEY = "iti-planner-outcome-index-v1";
const PER_OUTCOME_META_KEYS = new Set(["dateOfAssessment", "learningOutcome"]);

const workbookName = document.querySelector("#workbookName");
const traineeCount = document.querySelector("#traineeCount");
const componentCount = document.querySelector("#componentCount");
const mainTabs = document.querySelector("#mainTabs");
const detailsPanel = document.querySelector("#detailsPanel");
const marksPanel = document.querySelector("#marksPanel");
const annexPanel = document.querySelector("#annexPanel");
const annex3Panel = document.querySelector("#annex3Panel");
const toerPanel = document.querySelector("#toerPanel");

const tabs = [
  { id: "marks", label: "Mark Entry" },
  { id: "annex", label: "Annex II Format" },
  { id: "annex3", label: "Annex 3" },
  { id: "toer", label: "TOER" },
];

const annex3Template = [
  {
    groupNo: 1,
    parameter: "SAFETY CONCIOUSNESS",
    annex2Index: 0,
    rows: [
      { name: "DRESS CODE", max: 2, locked: true },
      { name: "USE PPE", max: 3, locked: true },
      { name: "APPLY/PRACTICE SAFETY", max: 10 },
    ],
  },
  {
    groupNo: 2,
    parameter: "WORKPLACE HYGIENE & ECONOMICAL USE OF MATERIALS",
    annex2Index: 1,
    rows: [
      { name: "MAINTAIN PERSONAL & WORKPLACE CLEANLINESS", max: 3 },
      { name: "DISPOSE SCRAP AS PER STANDARD PRACTICE", max: 2 },
      { name: "SELECT APPROPRIATE MATERIAL & MINIMIZE WASTAGE", max: 5 },
    ],
  },
  {
    groupNo: 3,
    parameter: "ATTENDANCE / PUNCTUALITY",
    annex2Index: 2,
    rows: [
      { name: "INITIATIVE", max: 3 },
      { name: "ACCOUNTABILITY", max: 3 },
      { name: "PARTICIPATE IN WORK", max: 4 },
    ],
  },
  {
    groupNo: 4,
    parameter: "ABILITY TO FOLLOW MANUALS / WRITTEN INSTRUCTIONS",
    annex2Index: 3,
    rows: [
      { name: "SELECT RIGHT MANUAL", max: 1 },
      { name: "SEARCH FOR APPROPRIATE TOPIC", max: 2 },
      { name: "READ & INTERPRET MANUAL", max: 2 },
    ],
  },
  {
    groupNo: 5,
    parameter: "APPLICATION OF KNOWLEDGE",
    annex2Index: 4,
    rows: [
      { name: "PLAN THE WORK", max: 4 },
      { name: "SELECT APPROPRIATE TOOLS & EQUIPMENT", max: 3 },
      { name: "REVIEW THE WORK", max: 3 },
    ],
  },
  {
    groupNo: 6,
    parameter: "SKILLS TO HANDLE TOOLS & EQUIPMENT",
    annex2Index: 5,
    rows: [
      { name: "HANDLE & USE TOOLS & EQUIPMENT", max: 4 },
      { name: "MAINTAIN SAFETY IN HANDLING", max: 3 },
      { name: "CARE & MAINTAIN", max: 3 },
    ],
  },
  {
    groupNo: 7,
    parameter: "SPEED IN DOING WORK",
    annex2Index: 6,
    rows: [
      { name: "PROPERLY SEQUENCE THE WORK", max: 3 },
      { name: "USE APPROPRIATE TECHNIQUE", max: 5 },
      { name: "REVIEW THE WORK DURING EXECUTION", max: 2 },
    ],
  },
  {
    groupNo: 8,
    parameter: "QUALITY IN WORKMANSHIP",
    annex2Index: 7,
    rows: [
      { name: "ACHIEVE WORK WITH HIGH ACCURACY", max: 7 },
      { name: "CONFORM TO REQUIREMENT", max: 3 },
      { name: "SATISFY THE PURPOSE", max: 5 },
    ],
  },
  {
    groupNo: 9,
    parameter: "VIVA",
    annex2Index: 8,
    rows: [
      { name: "RESPONSE WITH CLARITY", max: 5 },
      { name: "TECHNICAL UNDERSTANDING", max: 7 },
      { name: "CONSCIOUS TOWARDS JOB ROLE", max: 3 },
    ],
  },
];

let activeTab = "marks";
let state = loadState();
let selectedAnnex3Index = 0;

document.documentElement.classList.toggle("is-embedded", window.parent !== window);
document.body.classList.toggle("is-embedded", window.parent !== window);

initialize();

function initialize() {
  refreshPlannerOutcomeOptions({ persist: false });
  workbookName.textContent = appData.workbookName;
  traineeCount.textContent = String(state.trainees.length);
  componentCount.textContent = String(state.components.length);

  renderTabs();
  renderPanels();
  window.addEventListener("resize", syncAnnexScale);
}

function renderTabs() {
  mainTabs.innerHTML = "";

  tabs.forEach((tab) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `tab-button${tab.id === activeTab ? " is-active" : ""}`;
    button.textContent = tab.label;
    button.addEventListener("click", () => {
      activeTab = tab.id;
      renderTabs();
      renderPanels();
    });
    mainTabs.appendChild(button);
  });
}

function renderPanels() {
  detailsPanel.classList.add("hidden");
  detailsPanel.innerHTML = "";
  marksPanel.classList.toggle("hidden", activeTab !== "marks");
  annexPanel.classList.toggle("hidden", activeTab !== "annex");
  annex3Panel.classList.toggle("hidden", activeTab !== "annex3");
  toerPanel.classList.toggle("hidden", activeTab !== "toer");

  renderMarksPanel();
  renderAnnexPanel();
  renderAnnex3Panel();
  renderToerPanel();
  lockOutcomeManagedFields();
}

function renderAnnexPanel() {
  annexPanel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 2</p>
        <h2 class="panel-title">Annex II exact-style marks sheet</h2>
      </div>
      <div class="panel-actions">
        <p class="panel-note">Component marks are generated automatically from the total mark entry tab.</p>
        <button type="button" class="print-button" id="downloadAnnex2ExcelBtn">Download Excel</button>
        <button type="button" class="print-button" id="downloadAnnex2PdfBtn">Download A4 Landscape PDF</button>
      </div>
    </div>

    <div class="annex-paper" id="annexPrintArea">
      <div class="annex-fit-stage" id="annexFitStage">
        <div class="annex-fit-content" id="annexFitContent">
      <table class="annex-table" id="annexTable">
        <colgroup>
          <col style="width: 90px;" />
          <col style="width: 220px;" />
          <col style="width: 210px;" />
          ${state.components.map(() => '<col style="width: 70px;" />').join("")}
          <col style="width: 90px;" />
          <col style="width: 68px;" />
        </colgroup>
        <tbody>
          <tr class="title-row">
            <td colspan="14">${escapeHtml(state.meta.title)}</td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.assessorLabel)}</td>
            <td colspan="5" class="annex-value"><input class="annex-inline-input" data-meta-key="assessor" value="${escapeAttribute(state.meta.assessor)}" /></td>
            <td colspan="3" class="annex-label">${escapeHtml(appData.meta.yearLabel)}</td>
            <td colspan="4" class="annex-value"><input class="annex-inline-input" data-meta-key="yearEnrolment" value="${escapeAttribute(state.meta.yearEnrolment)}" /></td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.itiLabel)}</td>
            <td colspan="5" class="annex-value"><input class="annex-inline-input" data-meta-key="itiName" value="${escapeAttribute(state.meta.itiName)}" /></td>
            <td colspan="3" class="annex-label">${escapeHtml(appData.meta.dateLabel)}</td>
            <td colspan="4" class="annex-value"><input class="annex-inline-input" data-meta-key="dateOfAssessment" value="${escapeAttribute(state.meta.dateOfAssessment)}" /></td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.industryLabel)}</td>
            <td colspan="5" class="annex-value"><input class="annex-inline-input" data-meta-key="industryName" value="${escapeAttribute(state.meta.industryName)}" /></td>
            <td colspan="3" class="annex-label">${escapeHtml(appData.meta.locationLabel)}</td>
            <td colspan="4" class="annex-value"><input class="annex-inline-input" data-meta-key="assessmentLocation" value="${escapeAttribute(state.meta.assessmentLocation)}" /></td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.tradeLabel)}</td>
            <td colspan="2" class="annex-value"><input class="annex-inline-input" data-meta-key="tradeName" value="${escapeAttribute(state.meta.tradeName)}" /></td>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.examLabel)}</td>
            <td colspan="2" class="annex-value"><input class="annex-inline-input" data-meta-key="examination" value="${escapeAttribute(state.meta.examination)}" /></td>
            <td colspan="3" class="annex-label">${escapeHtml(appData.meta.durationLabel)}</td>
            <td colspan="3" class="annex-value"><input class="annex-inline-input" data-meta-key="durationOfTrade" value="${escapeAttribute(state.meta.durationOfTrade)}" /></td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.learningOutcomeLabel)}</td>
            <td colspan="12" class="annex-value"><input class="annex-inline-input" data-meta-key="learningOutcome" value="${escapeAttribute(state.meta.learningOutcome)}" /></td>
          </tr>
          <tr>
            <td rowspan="2" class="head-small">Adm No</td>
            <td colspan="2" class="head-small">MAXIMUM MARKS (TOTAL 100 MARKS)</td>
            ${state.components.map((component) => `<td class="head-small">${escapeHtml(String(component.maxMark))}</td>`).join("")}
            <td rowspan="2" class="head-small">Total Internal Assessment Marks</td>
            <td rowspan="2" class="head-small">Result (Y/N)</td>
          </tr>
          <tr>
            <td class="head-small">CANDIDATE NAME</td>
            <td class="head-small">FATHER'S/MOTHER'S NAME</td>
            ${state.components.map((component) => `<td><div class="vertical-text">${escapeHtml(component.name)}</div></td>`).join("")}
          </tr>
          ${state.trainees.map(renderAnnexRow).join("")}
          <tr class="signature-row">
            <td colspan="3"><div class="signature-designation">${escapeHtml(state.meta.instructorLeft)}</div></td>
            <td colspan="4"><div class="signature-designation"><input class="annex-inline-input" data-meta-key="instructorMiddle" value="${escapeAttribute(state.meta.instructorMiddle)}" /></div></td>
            <td colspan="7"><div class="signature-designation"><input class="annex-inline-input" data-meta-key="principal" value="${escapeAttribute(state.meta.principal)}" /></div></td>
          </tr>
        </tbody>
      </table>
        </div>
      </div>
    </div>
  `;

  annexPanel.querySelectorAll("[data-meta-key]").forEach((field) => {
    field.addEventListener("input", handleMetaInput);
  });

  annexPanel.querySelectorAll("[data-mark-index]").forEach((field) => {
    field.addEventListener("input", handleMarkInput);
  });

  const downloadButton = annexPanel.querySelector("#downloadAnnex2PdfBtn");
  if (downloadButton) {
    downloadButton.addEventListener("click", async () => {
      await downloadAnnex2Pdf();
    });
  }

  const downloadExcelButton = annexPanel.querySelector("#downloadAnnex2ExcelBtn");
  if (downloadExcelButton) {
    downloadExcelButton.addEventListener("click", () => {
      downloadAnnex2Excel();
    });
  }

  syncAnnexScale();
}

function renderMarksPanel() {
  marksPanel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 1</p>
        <h2 class="panel-title">Total mark entry</h2>
      </div>
      <p class="panel-note">Choose the learning outcome here, then enter total marks out of 100. The trainee roster is synced from Common Details.</p>
    </div>

    <div class="marks-toolbar">
      <div class="field-group">
        <label for="learningOutcomeSelect">Learning outcome</label>
        <select id="learningOutcomeSelect" data-outcome-select>
          ${state.outcomeOptions.map((option) => `
            <option value="${escapeAttribute(option.key)}"${option.key === state.selectedOutcomeKey ? " selected" : ""}>${escapeHtml(option.label)}</option>
          `).join("")}
        </select>
      </div>
      <div class="field-group">
        <label for="dateOfAssessmentEntry">Date of assessment</label>
        <input
          id="dateOfAssessmentEntry"
          type="text"
          placeholder="DD-MM-YYYY"
          data-meta-key="dateOfAssessment"
          value="${escapeAttribute(state.meta.dateOfAssessment)}"
        />
      </div>
      <div class="marks-outcome-note">
        <strong>Outcome-wise saving</strong>
        <span>${escapeHtml(getOutcomeSourceNote())}</span>
      </div>
    </div>

    <div class="table-wrap">
      <table class="trainee-table">
        <thead>
          <tr>
            <th>SL</th>
            <th>Adm No</th>
            <th>Name</th>
            <th>Total Mark / 100</th>
            <th>Result</th>
            <th>Custom TOER Time</th>
            <th>Starting Time</th>
            <th>Finishing Time</th>
          </tr>
        </thead>
        <tbody>
          ${state.trainees.map((trainee, index) => renderMarkEntryRow(trainee, index)).join("")}
        </tbody>
      </table>
    </div>
  `;

  marksPanel.querySelectorAll("[data-total-index]").forEach((field) => {
    field.addEventListener("input", handleTotalMarkInput);
  });

  marksPanel.querySelectorAll("[data-meta-key]").forEach((field) => {
    field.addEventListener("input", handleMetaInput);
  });

  marksPanel.querySelectorAll("[data-outcome-select]").forEach((field) => {
    field.addEventListener("change", handleOutcomeSelect);
  });

  marksPanel.querySelectorAll("[data-toer-override-index]").forEach((field) => {
    field.addEventListener("change", handleToerOverrideToggle);
  });

  marksPanel.querySelectorAll("[data-toer-time-index]").forEach((field) => {
    field.addEventListener("input", handleToerTimeInput);
    field.addEventListener("change", handleToerTimeInput);
  });
}

function renderAnnex3Panel() {
  const trainee = state.trainees[selectedAnnex3Index] || state.trainees[0];
  if (!trainee) {
    annex3Panel.innerHTML = "";
    return;
  }

  const groups = buildAnnex3Groups(trainee);
  const grandTotal = groups.reduce((sum, group) => sum + group.total, 0);

  annex3Panel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 3</p>
        <h2 class="panel-title">Annex III detailed assessment sheet</h2>
      </div>
      <div class="panel-actions">
        <p class="panel-note">Each Annex II division is split into detailed component marks here.</p>
        <button type="button" class="print-button" id="downloadAnnex3ExcelBtn">Download Current Excel</button>
        <button type="button" class="print-button" id="downloadAnnex3Btn">Download Current PDF</button>
        <button type="button" class="print-button" id="downloadAllAnnex3Btn">Download Combined PDF</button>
      </div>
    </div>

    <div class="annex3-select-row">
      <div class="field-group">
        <label for="annex3TraineeSelect">Select trainee</label>
        <select id="annex3TraineeSelect">
          ${state.trainees.map((item, index) => `<option value="${index}"${index === selectedAnnex3Index ? " selected" : ""}>${escapeHtml(item.admNo)} - ${escapeHtml(item.name)}</option>`).join("")}
        </select>
      </div>
    </div>

    <div class="annex3-paper">
      <table class="annex3-table">
        <tbody>
          <tr>
            <td colspan="6" class="annex3-title">ANNEXURE - III</td>
          </tr>
          <tr>
            <td colspan="3" class="annex3-label">Name & Address of the Assessor</td>
            <td colspan="3" class="annex3-value">${escapeHtml(state.meta.assessor)}</td>
          </tr>
          <tr>
            <td colspan="3" class="annex3-label">Name & Address of I T I</td>
            <td colspan="3" class="annex3-value">${escapeHtml(state.meta.itiName)}</td>
          </tr>
          <tr>
            <td colspan="3" class="annex3-label">Subject Name</td>
            <td colspan="3" class="annex3-value">Trade Practical</td>
          </tr>
          <tr>
            <td colspan="3" class="annex3-label">Trade Name</td>
            <td colspan="3" class="annex3-value">${escapeHtml(state.meta.tradeName)}</td>
          </tr>
          <tr>
            <td colspan="2" class="annex3-label">Learning Outcome</td>
            <td colspan="4" class="annex3-value">${escapeHtml(state.meta.learningOutcome)}</td>
          </tr>
          <tr>
            <td class="annex3-subhead">Adm.No</td>
            <td colspan="2" class="annex3-subhead">Name of The Candidate</td>
            <td class="annex3-subhead">Academic Span</td>
            <td colspan="2" class="annex3-subhead">Date of Assessment</td>
          </tr>
          <tr>
            <td>${escapeHtml(trainee.admNo)}</td>
            <td colspan="2">${escapeHtml(trainee.name)}</td>
            <td>${escapeHtml(state.meta.yearEnrolment.replaceAll("-2027", "- 2027"))}</td>
            <td colspan="2">${escapeHtml(state.meta.dateOfAssessment)}</td>
          </tr>
          <tr>
            <td class="annex3-subhead">Sl No</td>
            <td class="annex3-subhead">ASSESSMENT PARAMETERS</td>
            <td colspan="2" class="annex3-subhead">COMPONENT OF ASSESSMENT PARAMETERS</td>
            <td class="annex3-subhead">MAX.MARKS BREAK-UP</td>
            <td class="annex3-subhead">MARKS AWARDED</td>
          </tr>
          ${groups.map(renderAnnex3Group).join("")}
          <tr class="annex3-grand">
            <td colspan="4" class="annex3-label">GRAND TOTAL</td>
            <td>100</td>
            <td>${grandTotal}</td>
          </tr>
          <tr class="annex3-sign-space">
            <td colspan="2"></td>
            <td colspan="2"></td>
            <td colspan="2"></td>
          </tr>
          <tr class="annex3-sign-label">
            <td colspan="2" class="annex3-label">Signature of the Candidate</td>
            <td colspan="2" class="annex3-label">Group Instructor</td>
            <td colspan="2" class="annex3-label">Signature, Name & Designation of Accessor</td>
          </tr>
        </tbody>
      </table>
    </div>
  `;

  const select = annex3Panel.querySelector("#annex3TraineeSelect");
  if (select) {
    select.addEventListener("change", (event) => {
      selectedAnnex3Index = Number(event.target.value);
      renderAnnex3Panel();
    });
  }

  const downloadCurrent = annex3Panel.querySelector("#downloadAnnex3Btn");
  if (downloadCurrent) {
    downloadCurrent.addEventListener("click", async () => {
      await downloadAnnex3PdfForCurrent();
    });
  }

  const downloadCurrentExcel = annex3Panel.querySelector("#downloadAnnex3ExcelBtn");
  if (downloadCurrentExcel) {
    downloadCurrentExcel.addEventListener("click", () => {
      downloadAnnex3Excel();
    });
  }

  const downloadAll = annex3Panel.querySelector("#downloadAllAnnex3Btn");
  if (downloadAll) {
    downloadAll.addEventListener("click", async () => {
      await downloadCombinedAnnex3Pdf();
    });
  }
}

function renderToerPanel() {
  toerPanel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 4</p>
        <h2 class="panel-title">Trainer's Observation & Evidence Report</h2>
      </div>
      <div class="panel-actions">
        <p class="panel-note">Performance is calculated automatically from each trainee's total mark percentage.</p>
        <button type="button" class="print-button" id="downloadToerExcelBtn">Download Excel</button>
        <button type="button" class="print-button" id="downloadToerPdfBtn">Download Landscape PDF</button>
      </div>
    </div>

    <div class="toer-controls">
      <div class="toer-meta-grid">
        ${renderToerField("trainerAddress", "Trainer Name & Address")}
        ${renderToerField("unit", "Unit")}
        ${renderToerField("year", "Year")}
        ${renderToerField("shift", "Shift")}
        ${renderToerTimeField("defaultStartTime", "Default Starting Time")}
        ${renderToerTimeField("defaultEndTime", "Default Finishing Time")}
      </div>

      <div class="toer-evidence">
        <strong>Evidence Report Available</strong>
        ${renderEvidenceCheckbox("video", "Video")}
        ${renderEvidenceCheckbox("photo", "Photo")}
        ${renderEvidenceCheckbox("record", "Record")}
        ${renderEvidenceCheckbox("physical", "Physical")}
        ${renderEvidenceCheckbox("chart", "Chart Sheet")}
        <label>
          <span>Any Other</span>
          <input class="toer-other-input" data-toer-key="anyOther" value="${escapeAttribute(state.toer.anyOther)}" />
        </label>
      </div>
    </div>

    <div class="toer-paper">
      <table class="toer-table">
        <colgroup>
          <col style="width:58px;" />
          <col style="width:220px;" />
          <col style="width:110px;" />
          <col style="width:110px;" />
          <col style="width:58px;" />
          <col style="width:58px;" />
          <col style="width:58px;" />
          <col style="width:58px;" />
          <col style="width:78px;" />
          <col style="width:78px;" />
          <col style="width:78px;" />
          <col style="width:84px;" />
          <col style="width:78px;" />
          <col style="width:100px;" />
          <col style="width:92px;" />
        </colgroup>
        <tbody>
          <tr>
            <td colspan="15" class="toer-title">TRAINER'S OBSERVATION & EVIDENCE REPORT</td>
          </tr>
          <tr>
            <td colspan="4" class="toer-label">Name of Institute: ${escapeHtml(formatInstituteForToer(state.meta.itiName))}</td>
            <td colspan="11" class="toer-label">Trade: ${escapeHtml(formatTradeForToer(state.meta.tradeName))}</td>
          </tr>
          <tr>
            <td colspan="4" class="toer-label">Name & Address of the Trainer: ${escapeHtml(state.toer.trainerAddress)}</td>
            <td colspan="11" class="toer-label">Unit: ${escapeHtml(state.toer.unit)}&nbsp;&nbsp;&nbsp;&nbsp;Year: ${escapeHtml(state.toer.year)}</td>
          </tr>
          <tr>
            <td colspan="4"></td>
            <td colspan="11" class="toer-label">Shift : ${escapeHtml(state.toer.shift)}</td>
          </tr>
          <tr>
            <td colspan="3" class="toer-label">No. & Name of Learning Outcome:</td>
            <td colspan="12" class="toer-value">${escapeHtml(state.meta.learningOutcome)}</td>
          </tr>
          <tr>
            <td rowspan="2" class="toer-subhead">Sl. No.</td>
            <td rowspan="2" class="toer-subhead">Name of Trainee</td>
            <td rowspan="2" class="toer-subhead">Starting Time</td>
            <td rowspan="2" class="toer-subhead">Finishing Time</td>
            <td colspan="4" class="toer-subhead">Overall Performance</td>
            <td colspan="6" class="toer-subhead">Evidences available Remarks</td>
            <td rowspan="2" class="toer-subhead">Remarks</td>
          </tr>
          <tr>
            <td class="toer-subhead">VG</td>
            <td class="toer-subhead">G</td>
            <td class="toer-subhead">M</td>
            <td class="toer-subhead">P</td>
            <td class="toer-subhead">Video<br/>Y/N</td>
            <td class="toer-subhead">Photo<br/>Y/N</td>
            <td class="toer-subhead">Record<br/>Y/N</td>
            <td class="toer-subhead">Physical<br/>Y/N</td>
            <td class="toer-subhead">Chart<br/>Y/N</td>
            <td class="toer-subhead">Any other</td>
          </tr>
          ${state.trainees.map(renderToerRow).join("")}
          <tr class="toer-sign-space">
            <td colspan="4"></td>
            <td colspan="4"></td>
            <td colspan="5"></td>
            <td colspan="2"></td>
          </tr>
          <tr class="toer-sign-note">
            <td colspan="4" class="toer-label">VG- above 90%, G- 75-90 %, M- 60-75 %, P- Below 60%</td>
            <td colspan="4" class="toer-label">SIGN.OF VP/PRINCIPAL</td>
            <td colspan="5" class="toer-label">SIGN OF GI</td>
            <td colspan="2" class="toer-label">SIGN. OF TRAINER</td>
          </tr>
        </tbody>
      </table>
    </div>
  `;

  const downloadButton = toerPanel.querySelector("#downloadToerPdfBtn");
  if (downloadButton) {
    downloadButton.addEventListener("click", async () => {
      await downloadToerPdf();
    });
  }

  const downloadExcelButton = toerPanel.querySelector("#downloadToerExcelBtn");
  if (downloadExcelButton) {
    downloadExcelButton.addEventListener("click", () => {
      downloadToerExcel();
    });
  }

  toerPanel.querySelectorAll("[data-toer-key]").forEach((field) => {
    field.addEventListener("input", handleToerMetaInput);
    field.addEventListener("change", handleToerMetaInput);
  });

  toerPanel.querySelectorAll("[data-toer-time-key]").forEach((field) => {
    field.addEventListener("input", handleToerDefaultTimeInput);
    field.addEventListener("change", handleToerDefaultTimeInput);
  });
}

function renderAnnexRow(trainee, traineeIndex) {
  const total = getTraineeTotal(trainee);
  const result = getResult(total);

  return `
    <tr class="marks-row">
      <td>${escapeHtml(trainee.admNo)}</td>
      <td class="name-cell">${escapeHtml(trainee.name)}</td>
      <td class="name-cell">${escapeHtml(trainee.fatherName)}</td>
      ${trainee.marks.map((mark, componentIndex) => `
        <td>
          <input
            class="marks-input"
            type="number"
            step="1"
            min="0"
            max="${escapeAttribute(String(state.components[componentIndex].maxMark))}"
            value="${escapeAttribute(formatMark(mark))}"
            data-mark-index="${traineeIndex}"
            data-component-index="${componentIndex}"
            readonly
          />
        </td>
      `).join("")}
      <td class="total-cell" data-total-index="${traineeIndex}">${formatMark(total)}</td>
      <td class="result-cell" data-result-index="${traineeIndex}">${escapeHtml(result)}</td>
    </tr>
  `;
}

function handleMetaInput(event) {
  const key = event.target.dataset.metaKey;
  state.meta[key] = event.target.value;
  persistState();
  syncMetaFields(key, event.target.value, event.target);
  if (!annexPanel.contains(event.target)) {
    renderAnnexPanel();
  }
  if (PER_OUTCOME_META_KEYS.has(key) && !marksPanel.contains(event.target)) {
    renderMarksPanel();
  }
  renderAnnex3Panel();
  renderToerPanel();
}

function handleMarkInput(event) {
  event.preventDefault();
}

function handleTotalMarkInput(event) {
  const traineeIndex = Number(event.target.dataset.totalIndex);
  const total = clampWholeNumber(event.target.value, 0, 100);
  state.trainees[traineeIndex].marks = splitTotalIntoComponents(total);
  persistState();
  const resultCell = marksPanel.querySelector(`[data-mark-result-index="${traineeIndex}"]`);
  if (resultCell) {
    resultCell.textContent = getResult(total);
  }
  renderAnnexPanel();
  renderAnnex3Panel();
  renderToerPanel();
}

function handleOutcomeSelect(event) {
  const nextKey = String(event.target.value || "").trim();
  if (!nextKey || nextKey === state.selectedOutcomeKey) {
    return;
  }

  activateOutcomeRecord(nextKey);
  persistState();
  renderPanels();
}

function handleToerMetaInput(event) {
  const key = event.target.dataset.toerKey;
  const isCheckbox = event.target.type === "checkbox";

  if (["video", "photo", "record", "physical", "chart"].includes(key)) {
    state.toer.evidence[key] = event.target.checked;
  } else {
    state.toer[key] = isCheckbox ? event.target.checked : event.target.value;
  }

  persistState();
  renderMarksPanel();
  renderToerPanel();
}

function handleToerOverrideToggle(event) {
  const index = Number(event.target.dataset.toerOverrideIndex);
  const override = state.toer.overrides[index] || createToerOverride();
  override.useCustomTime = event.target.checked;

  if (!override.useCustomTime) {
    override.startTime = "";
    override.endTime = "";
  } else {
    override.startTime ||= state.toer.defaultStartTime;
    override.endTime ||= state.toer.defaultEndTime;
  }

  state.toer.overrides[index] = override;
  persistState();
  renderMarksPanel();
  renderToerPanel();
}

function handleToerTimeInput(event) {
  const index = Number(event.target.dataset.toerTimeIndex);
  const field = event.target.dataset.timeField;
  const override = state.toer.overrides[index] || createToerOverride();
  override[field] = readTimeControlValue(event.target);
  state.toer.overrides[index] = override;
  persistState();

  if (event.type === "change") {
    renderToerPanel();
  }
}

function handleToerDefaultTimeInput(event) {
  const key = event.target.dataset.toerTimeKey;
  state.toer[key] = readTimeControlValue(event.target);
  persistState();

  if (event.type === "change") {
    renderMarksPanel();
    renderToerPanel();
  }
}

function loadState() {
  const fallbackMeta = normalizeMeta(appData.meta);
  const fallbackTrainees = normalizeTrainees(appData.trainees);
  const fallback = structuredClone({
    meta: fallbackMeta,
    components: appData.components,
    trainees: fallbackTrainees,
    toer: createDefaultToerState(fallbackTrainees, fallbackMeta),
  });

  const raw = localStorage.getItem(storageKey);
  if (!raw) {
    return buildStateFromParsed({}, fallback);
  }

  try {
    return buildStateFromParsed(JSON.parse(raw), fallback);
  } catch {
    return buildStateFromParsed({}, fallback);
  }
}

function persistState() {
  syncCurrentOutcomeRecord();
  localStorage.setItem(
    storageKey,
    JSON.stringify({
      meta: state.meta,
      components: state.components,
      trainees: state.trainees,
      toer: state.toer,
      outcomeOptions: state.outcomeOptions,
      outcomeSourceLabel: state.outcomeSourceLabel,
      selectedOutcomeKey: state.selectedOutcomeKey,
      outcomeRecords: state.outcomeRecords,
    }),
  );
  traineeCount.textContent = String(state.trainees.length);
}

function buildStateFromParsed(parsed, fallback) {
  const baseMeta = { ...fallback.meta, ...(parsed?.meta || {}) };
  const baseTrainees = Array.isArray(parsed?.trainees)
    ? normalizeTrainees(parsed.trainees)
    : cloneTrainees(fallback.trainees);
  const baseToer = normalizeToerState(parsed?.toer, baseTrainees, baseMeta);
  const plannerOutcomePayload = getPlannerOutcomePayload({
    tradeName: baseMeta.tradeName,
    trainingYear: baseToer.year,
    institution: baseMeta.itiName,
    fallbackLabel: baseMeta.learningOutcome,
  });
  const outcomeRecords = {};
  const rawRecords =
    parsed?.outcomeRecords && typeof parsed.outcomeRecords === "object"
      ? parsed.outcomeRecords
      : {};

  Object.entries(rawRecords).forEach(([key, record]) => {
    const option = findOutcomeOptionByKey(plannerOutcomePayload.options, key);
    outcomeRecords[key] = normalizeOutcomeRecord(record, baseTrainees, baseMeta, option?.label);
  });

  const legacyOutcomeKey =
    findOutcomeKeyByLabel(plannerOutcomePayload.options, baseMeta.learningOutcome)
    || createOutcomeKeyFromLabel(baseMeta.learningOutcome);

  if (!Object.keys(outcomeRecords).length) {
    outcomeRecords[legacyOutcomeKey] = normalizeOutcomeRecord(
      {
        learningOutcome: baseMeta.learningOutcome,
        dateOfAssessment: baseMeta.dateOfAssessment,
        trainees: baseTrainees,
        toer: baseToer,
      },
      baseTrainees,
      baseMeta,
      baseMeta.learningOutcome,
    );
  }

  const selectedOutcomeKey = resolveSelectedOutcomeKey(
    parsed?.selectedOutcomeKey,
    plannerOutcomePayload.options,
    outcomeRecords,
    baseMeta.learningOutcome,
  );

  if (!outcomeRecords[selectedOutcomeKey]) {
    const selectedOption = findOutcomeOptionByKey(plannerOutcomePayload.options, selectedOutcomeKey);
    outcomeRecords[selectedOutcomeKey] = normalizeOutcomeRecord(
      {
        learningOutcome: selectedOption?.label || baseMeta.learningOutcome,
        dateOfAssessment: baseMeta.dateOfAssessment,
        trainees: baseTrainees,
        toer: baseToer,
      },
      baseTrainees,
      baseMeta,
      selectedOption?.label || baseMeta.learningOutcome,
    );
  }

  const selectedRecord = outcomeRecords[selectedOutcomeKey];

  return {
    meta: {
      ...baseMeta,
      learningOutcome: selectedRecord.learningOutcome,
      dateOfAssessment: selectedRecord.dateOfAssessment,
    },
    components: fallback.components,
    trainees: cloneTrainees(selectedRecord.trainees),
    toer: cloneToerState(selectedRecord.toer, selectedRecord.trainees, baseMeta),
    outcomeOptions: plannerOutcomePayload.options,
    outcomeSourceLabel: plannerOutcomePayload.sourceLabel,
    selectedOutcomeKey,
    outcomeRecords,
  };
}

function refreshPlannerOutcomeOptions({ persist = true } = {}) {
  syncCurrentOutcomeRecord();

  const plannerOutcomePayload = getPlannerOutcomePayload({
    tradeName: state.meta.tradeName,
    trainingYear: state.toer.year,
    institution: state.meta.itiName,
    fallbackLabel: state.meta.learningOutcome || appData.meta.learningOutcome,
  });

  state.outcomeOptions = plannerOutcomePayload.options;
  state.outcomeSourceLabel = plannerOutcomePayload.sourceLabel;
  syncOutcomeRecordsWithOptions(plannerOutcomePayload.options);

  const nextSelectedKey = resolveSelectedOutcomeKey(
    state.selectedOutcomeKey,
    plannerOutcomePayload.options,
    state.outcomeRecords,
    state.meta.learningOutcome,
  );

  activateOutcomeRecord(nextSelectedKey, { syncCurrent: false });

  if (persist) {
    persistState();
  }
}

function resolveSelectedOutcomeKey(preferredKey, options, records, fallbackLabel) {
  if (preferredKey && records[preferredKey]) {
    return preferredKey;
  }

  const optionMatch = findOutcomeKeyByLabel(options, fallbackLabel);
  if (optionMatch && records[optionMatch]) {
    return optionMatch;
  }

  if (optionMatch) {
    return optionMatch;
  }

  const recordKeys = Object.keys(records || {});
  if (recordKeys.length) {
    return recordKeys[0];
  }

  return options[0]?.key || createOutcomeKeyFromLabel(fallbackLabel);
}

function activateOutcomeRecord(key, { syncCurrent = true } = {}) {
  if (!key) {
    return;
  }

  if (syncCurrent) {
    syncCurrentOutcomeRecord();
  }

  const option = findOutcomeOptionByKey(state.outcomeOptions, key);
  const record = ensureOutcomeRecord(key, option?.label);
  state.selectedOutcomeKey = key;
  state.meta.learningOutcome = record.learningOutcome || option?.label || "";
  state.meta.dateOfAssessment = record.dateOfAssessment || "";
  state.trainees = cloneTrainees(record.trainees);
  state.toer = cloneToerState(record.toer, state.trainees, state.meta);
  selectedAnnex3Index = Math.max(0, Math.min(selectedAnnex3Index, state.trainees.length - 1));
}

function ensureOutcomeRecord(key, fallbackLabel = "") {
  if (!state.outcomeRecords || typeof state.outcomeRecords !== "object") {
    state.outcomeRecords = {};
  }

  if (!state.outcomeRecords[key]) {
    const option = findOutcomeOptionByKey(state.outcomeOptions, key);
    state.outcomeRecords[key] = createBlankOutcomeRecord(option?.label || fallbackLabel);
  } else {
    state.outcomeRecords[key] = normalizeOutcomeRecord(
      state.outcomeRecords[key],
      createBlankTraineesFromRoster(buildRosterTemplate()),
      state.meta,
      fallbackLabel || findOutcomeOptionByKey(state.outcomeOptions, key)?.label,
    );
  }

  return state.outcomeRecords[key];
}

function syncCurrentOutcomeRecord() {
  if (!state || !state.selectedOutcomeKey) {
    return;
  }

  const label = getSelectedOutcomeLabel() || state.meta.learningOutcome || "";
  state.outcomeRecords[state.selectedOutcomeKey] = {
    learningOutcome: label,
    dateOfAssessment: String(state.meta.dateOfAssessment || ""),
    trainees: cloneTrainees(state.trainees),
    toer: cloneToerState(state.toer, state.trainees, {
      ...state.meta,
      learningOutcome: label,
    }),
  };
}

function syncOutcomeRecordsWithOptions(options) {
  if (!state.outcomeRecords || typeof state.outcomeRecords !== "object") {
    state.outcomeRecords = {};
  }

  const nextRecords = { ...state.outcomeRecords };
  Object.entries(nextRecords).forEach(([key, record]) => {
    const matchedKey = findOutcomeKeyByLabel(options, record?.learningOutcome);
    if (
      key.startsWith("local-outcome::")
      && matchedKey
      && matchedKey !== key
      && !nextRecords[matchedKey]
    ) {
      nextRecords[matchedKey] = normalizeOutcomeRecord(
        record,
        createBlankTraineesFromRoster(buildRosterTemplate()),
        state.meta,
        findOutcomeOptionByKey(options, matchedKey)?.label,
      );
      delete nextRecords[key];
      if (state.selectedOutcomeKey === key) {
        state.selectedOutcomeKey = matchedKey;
      }
    }
  });

  options.forEach((option) => {
    if (!nextRecords[option.key]) {
      nextRecords[option.key] = createBlankOutcomeRecord(option.label);
      return;
    }

    nextRecords[option.key] = normalizeOutcomeRecord(
      {
        ...nextRecords[option.key],
        learningOutcome: option.label,
      },
      createBlankTraineesFromRoster(buildRosterTemplate()),
      state.meta,
      option.label,
    );
  });

  state.outcomeRecords = nextRecords;
}

function normalizeOutcomeRecord(record, fallbackTrainees, meta, fallbackLabel = "") {
  const trainees = Array.isArray(record?.trainees)
    ? normalizeTrainees(record.trainees)
    : cloneTrainees(fallbackTrainees);
  const learningOutcome = String(record?.learningOutcome || fallbackLabel || "");

  return {
    learningOutcome,
    dateOfAssessment: String(record?.dateOfAssessment || ""),
    trainees,
    toer: normalizeToerState(
      record?.toer,
      trainees,
      {
        ...meta,
        learningOutcome,
      },
    ),
  };
}

function createBlankOutcomeRecord(learningOutcome = "") {
  const trainees = createBlankTraineesFromRoster(buildRosterTemplate());
  const fallbackToer = createDefaultToerState(trainees, {
    ...state.meta,
    learningOutcome,
  });
  return {
    learningOutcome: String(learningOutcome || ""),
    dateOfAssessment: "",
    trainees,
    toer: normalizeToerState(
      {
        ...fallbackToer,
        trainerAddress: state.toer?.trainerAddress || fallbackToer.trainerAddress,
        unit: state.toer?.unit || fallbackToer.unit,
        year: state.toer?.year || fallbackToer.year,
        shift: state.toer?.shift || fallbackToer.shift,
      },
      trainees,
      {
        ...state.meta,
        learningOutcome,
      },
    ),
  };
}

function buildRosterTemplate() {
  const source =
    Array.isArray(state?.trainees) && state.trainees.length
      ? state.trainees
      : normalizeTrainees(appData.trainees);

  return source.map((trainee) => ({
    admNo: trainee.admNo || "",
    name: trainee.name || "",
    fatherName: trainee.fatherName || "",
  }));
}

function createBlankTraineesFromRoster(rosterTemplate) {
  return normalizeTrainees(
    rosterTemplate.map((trainee) => ({
      admNo: trainee.admNo || "",
      name: trainee.name || "",
      fatherName: trainee.fatherName || "",
      marks: splitTotalIntoComponents(0),
      total: 0,
      result: "N",
    })),
  );
}

function cloneTrainees(trainees) {
  return normalizeTrainees(structuredClone(Array.isArray(trainees) ? trainees : []));
}

function cloneToerState(toer, trainees, meta) {
  return normalizeToerState(structuredClone(toer || {}), cloneTrainees(trainees), meta);
}

function getSelectedOutcomeLabel() {
  return findOutcomeOptionByKey(state.outcomeOptions, state.selectedOutcomeKey)?.label || "";
}

function getOutcomeSourceNote() {
  if (state.outcomeSourceLabel) {
    return `Using Planner splitup: ${state.outcomeSourceLabel}. Each outcome keeps its own date, marks, and TOER timings.`;
  }

  return "Planner splitup not detected yet. Each outcome will still keep its own date, marks, and TOER timings.";
}

function getPlannerOutcomePayload({ tradeName = "", trainingYear = "", institution = "", fallbackLabel = "" } = {}) {
  const datasets = readPlannerOutcomeDatasets();
  const dataset = pickPlannerDataset(datasets, { tradeName, trainingYear, institution });
  const options = dataset ? createOutcomeOptionsForDataset(dataset) : [];

  if (options.length) {
    return {
      options,
      sourceLabel: [dataset.trainingYear, dataset.sourceWorkbook || dataset.trade].filter(Boolean).join(" | "),
    };
  }

  return {
    options: [createFallbackOutcomeOption(fallbackLabel || appData.meta.learningOutcome)],
    sourceLabel: "",
  };
}

function readPlannerOutcomeDatasets() {
  const registry = readPlannerOutcomeRegistry();
  const scanned = scanPlannerOutcomeDatasetsFromLocalStorage();
  const datasets = new Map();

  scanned.forEach((dataset) => {
    datasets.set(dataset.key, dataset);
  });

  registry.forEach((dataset) => {
    datasets.set(dataset.key, dataset);
  });

  return [...datasets.values()];
}

function readPlannerOutcomeRegistry() {
  try {
    const raw = window.localStorage.getItem(PLANNER_OUTCOME_STORAGE_KEY);
    if (!raw) {
      return [];
    }

    const parsed = JSON.parse(raw);
    const datasets =
      parsed && typeof parsed === "object" && parsed.datasets && typeof parsed.datasets === "object"
        ? parsed.datasets
        : {};
    const lastActiveKey = String(parsed?.lastActiveKey || "");

    return Object.entries(datasets)
      .map(([key, dataset]) => ({
        ...dataset,
        key,
        isLastActive: key === lastActiveKey,
      }))
      .filter((dataset) => Array.isArray(dataset.outcomes) && dataset.outcomes.length);
  } catch {
    return [];
  }
}

function scanPlannerOutcomeDatasetsFromLocalStorage() {
  const datasets = [];

  for (let index = 0; index < window.localStorage.length; index += 1) {
    const key = window.localStorage.key(index);
    if (!key || !key.startsWith("program-of-coaching-entry-v")) {
      continue;
    }

    try {
      const parsed = JSON.parse(window.localStorage.getItem(key) || "null");
      if (!parsed?.programData || typeof parsed.programData !== "object") {
        continue;
      }

      const dataset = buildPlannerDatasetFromProgramData(parsed.programData, key);
      if (dataset.outcomes.length) {
        datasets.push(dataset);
      }
    } catch {
      // Ignore invalid planner caches.
    }
  }

  return datasets;
}

function buildPlannerDatasetFromProgramData(programData, key) {
  const meta = programData?.meta || {};
  const outcomes = [];
  const seen = new Set();

  (programData?.skill?.entries || []).forEach((item) => {
    if (item?.isSpecial || item?.isAssessment) {
      return;
    }

    const outcomeNo = String(item?.outcomeNo || "").trim();
    const outcomeName = String(item?.outcomeName || "").trim();
    if (!outcomeNo || !outcomeName || seen.has(outcomeNo)) {
      return;
    }

    seen.add(outcomeNo);
    outcomes.push({
      outcomeNo,
      outcomeName,
    });
  });

  return {
    key: String(key || createOutcomeKeyFromLabel(meta.sourceWorkbook || meta.trade || meta.trainingYear || "planner")),
    trade: String(meta.trade || ""),
    trainingYear: String(meta.trainingYear || ""),
    institution: String(meta.institution || ""),
    sourceWorkbook: String(meta.sourceWorkbook || ""),
    updatedAt: 0,
    isLastActive: false,
    outcomes,
  };
}

function createOutcomeOptionsForDataset(dataset) {
  return (dataset.outcomes || []).map((outcome) => ({
    key: buildOutcomeKey(dataset.key, outcome.outcomeNo, outcome.outcomeName),
    datasetKey: dataset.key,
    no: String(outcome.outcomeNo || ""),
    name: String(outcome.outcomeName || ""),
    label: formatOutcomeLabel(outcome.outcomeNo, outcome.outcomeName),
  }));
}

function pickPlannerDataset(datasets, { tradeName = "", trainingYear = "", institution = "" } = {}) {
  if (!Array.isArray(datasets) || !datasets.length) {
    return null;
  }

  const desiredYear = normalizeTrainingYear(trainingYear);
  const desiredTrade = normalizeTradeText(tradeName);
  const desiredInstitution = normalizeTradeText(institution);
  let bestDataset = datasets[0];
  let bestScore = -Infinity;

  datasets.forEach((dataset, index) => {
    let score = index;
    if (dataset.isLastActive) {
      score += 40;
    }
    if (desiredYear && normalizeTrainingYear(dataset.trainingYear) === desiredYear) {
      score += 100;
    }
    if (desiredTrade && looksLikeTradeMatch(dataset.trade, desiredTrade)) {
      score += 30;
    }
    if (desiredInstitution && normalizeTradeText(dataset.institution) === desiredInstitution) {
      score += 10;
    }

    if (score > bestScore) {
      bestScore = score;
      bestDataset = dataset;
    }
  });

  return bestDataset;
}

function normalizeTrainingYear(value) {
  const text = String(value || "").trim().toUpperCase();
  if (!text) {
    return "";
  }
  if (text.includes("II") || text.includes("SECOND") || /\b2\b/.test(text)) {
    return "2";
  }
  if (text.includes("I") || text.includes("FIRST") || /\b1\b/.test(text)) {
    return "1";
  }
  return text.replace(/[^0-9A-Z]/g, "");
}

function normalizeTradeText(value) {
  return String(value || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function looksLikeTradeMatch(datasetTrade, desiredTrade) {
  const left = normalizeTradeText(datasetTrade);
  const right = normalizeTradeText(desiredTrade);
  if (!left || !right) {
    return false;
  }
  if (left === right || left.includes(right) || right.includes(left)) {
    return true;
  }

  const leftTokens = new Set(left.split(" "));
  return right.split(" ").some((token) => token.length > 2 && leftTokens.has(token));
}

function createFallbackOutcomeOption(label) {
  const safeLabel = String(label || "Learning outcome").trim() || "Learning outcome";
  return {
    key: createOutcomeKeyFromLabel(safeLabel),
    datasetKey: "local",
    no: "",
    name: safeLabel,
    label: safeLabel,
  };
}

function buildOutcomeKey(datasetKey, outcomeNo, outcomeName) {
  const safeCode = String(outcomeNo || "").trim();
  if (safeCode) {
    return `${datasetKey}::learning-outcome::${safeCode}`;
  }
  return createOutcomeKeyFromLabel(`${datasetKey} ${outcomeName || "learning-outcome"}`);
}

function createOutcomeKeyFromLabel(label) {
  const slug = String(label || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return `local-outcome::${slug || "default"}`;
}

function formatOutcomeLabel(outcomeNo, outcomeName) {
  const safeNo = String(outcomeNo || "").trim().replace(/\.$/, "");
  const safeName = String(outcomeName || "").trim();

  if (!safeNo) {
    return safeName || "Learning outcome";
  }
  if (!safeName) {
    return safeNo;
  }
  if (
    safeName.startsWith(`${safeNo}.`)
    || safeName.startsWith(`${safeNo})`)
    || safeName.startsWith(`${safeNo} -`)
  ) {
    return safeName;
  }

  return `${safeNo}. ${safeName}`;
}

function findOutcomeOptionByKey(options, key) {
  return (options || []).find((option) => option.key === key) || null;
}

function findOutcomeKeyByLabel(options, label) {
  const safeLabel = String(label || "").trim().toLowerCase();
  if (!safeLabel) {
    return "";
  }

  return (
    (options || []).find((option) => String(option.label || "").trim().toLowerCase() === safeLabel)?.key
    || ""
  );
}

function syncPortalManagedToerFieldsAcrossOutcomes(sharedFields) {
  Object.entries(state.outcomeRecords || {}).forEach(([key, record]) => {
    const trainees = Array.isArray(record?.trainees)
      ? cloneTrainees(record.trainees)
      : createBlankTraineesFromRoster(buildRosterTemplate());
    state.outcomeRecords[key] = normalizeOutcomeRecord(
      {
        ...record,
        toer: {
          ...(record?.toer || {}),
          ...sharedFields,
        },
      },
      trainees,
      state.meta,
      record?.learningOutcome || findOutcomeOptionByKey(state.outcomeOptions, key)?.label,
    );
  });
}

function syncMetaFields(key, value, source) {
  document.querySelectorAll(`[data-meta-key="${key}"]`).forEach((field) => {
    if (field !== source) {
      field.value = value;
    }
  });
}

function updateAnnexTotals(traineeIndex) {
  const trainee = state.trainees[traineeIndex];
  const total = getTraineeTotal(trainee);
  const result = getResult(total);
  const totalCell = annexPanel.querySelector(`[data-total-index="${traineeIndex}"]`);
  const resultCell = annexPanel.querySelector(`[data-result-index="${traineeIndex}"]`);

  if (totalCell) {
    totalCell.textContent = formatMark(total);
  }

  if (resultCell) {
    resultCell.textContent = result;
  }
}

function renderMarkEntryRow(trainee, index) {
  const total = getTraineeTotal(trainee);
  const override = state.toer.overrides[index] || createToerOverride();
  const startTime = override.useCustomTime ? override.startTime : state.toer.defaultStartTime;
  const endTime = override.useCustomTime ? override.endTime : state.toer.defaultEndTime;
  return `
    <tr>
      <td>${index + 1}</td>
      <td>${escapeHtml(trainee.admNo)}</td>
      <td>${escapeHtml(trainee.name)}</td>
      <td><input type="number" min="0" max="100" step="1" data-total-index="${index}" value="${escapeAttribute(String(total))}" /></td>
      <td data-mark-result-index="${index}">${getResult(total)}</td>
      <td>
        <label class="toer-row-check">
          <input type="checkbox" data-toer-override-index="${index}" ${override.useCustomTime ? "checked" : ""} />
          <span>Custom</span>
        </label>
      </td>
      <td>${renderTimeControl(startTime, { index, field: "startTime", disabled: !override.useCustomTime })}</td>
      <td>${renderTimeControl(endTime, { index, field: "endTime", disabled: !override.useCustomTime })}</td>
    </tr>
  `;
}

function renderAnnex3Group(group) {
  const span = group.rows.length + 1;
  return group.rows.map((row, index) => `
    <tr>
      ${index === 0 ? `<td rowspan="${span}" class="annex3-merged annex3-slno">${group.groupNo}</td>` : ""}
      ${index === 0 ? `<td rowspan="${span}" class="annex3-param annex3-merged">${escapeHtml(group.parameter)}</td>` : ""}
      <td colspan="2" class="annex3-comp">${escapeHtml(row.name)}</td>
      <td>${row.max}</td>
      <td>${row.awarded}</td>
    </tr>
  `).join("") + `
    <tr>
      <td colspan="2" class="annex3-comp"><strong>TOTAL</strong></td>
      <td><strong>${group.maxTotal}</strong></td>
      <td><strong>${group.total}</strong></td>
    </tr>
  `;
}

function renderToerField(key, label, type = "text") {
  return `
    <div class="field-group">
      <label for="toer-${key}">${escapeHtml(label)}</label>
      <input id="toer-${key}" type="${type}" data-toer-key="${key}" value="${escapeAttribute(state.toer[key] || "")}" />
    </div>
  `;
}

function renderToerTimeField(key, label) {
  return `
    <div class="field-group">
      <label>${escapeHtml(label)}</label>
      ${renderTimeControl(state.toer[key], { key })}
    </div>
  `;
}

function renderTimeControl(value, options = {}) {
  const parts = parseTimeParts(value);
  const disabled = options.disabled ? "disabled" : "";
  const dataAttrs =
    options.key !== undefined
      ? `data-toer-time-key="${options.key}"`
      : `data-toer-time-index="${options.index}" data-time-field="${options.field}"`;

  return `
    <div class="time-entry ${options.disabled ? "is-disabled" : ""}">
      <input class="time-hour" type="number" min="1" max="12" ${dataAttrs} data-time-part="hour" value="${escapeAttribute(parts.hour)}" ${disabled} />
      <span>:</span>
      <input class="time-minute" type="number" min="0" max="59" ${dataAttrs} data-time-part="minute" value="${escapeAttribute(parts.minute)}" ${disabled} />
      <select class="time-period" ${dataAttrs} data-time-part="period" ${disabled}>
        <option value="AM"${parts.period === "AM" ? " selected" : ""}>AM</option>
        <option value="PM"${parts.period === "PM" ? " selected" : ""}>PM</option>
      </select>
    </div>
  `;
}

function renderEvidenceCheckbox(key, label) {
  return `
    <label>
      <input type="checkbox" data-toer-key="${key}" ${state.toer.evidence[key] ? "checked" : ""} />
      <span>${escapeHtml(label)}</span>
    </label>
  `;
}

function renderToerRow(trainee, index) {
  const override = state.toer.overrides[index] || createToerOverride();
  const startTime = override.useCustomTime ? override.startTime : state.toer.defaultStartTime;
  const endTime = override.useCustomTime ? override.endTime : state.toer.defaultEndTime;
  const band = getPerformanceBand(getTraineeTotal(trainee));

  return `
    <tr>
      <td>${index + 1}</td>
      <td class="toer-name">${escapeHtml(trainee.name)}</td>
      <td>${escapeHtml(formatTimeForDisplay(startTime))}</td>
      <td>${escapeHtml(formatTimeForDisplay(endTime))}</td>
      <td class="toer-mark">${band === "VG" ? "&#10003;" : ""}</td>
      <td class="toer-mark">${band === "G" ? "&#10003;" : ""}</td>
      <td class="toer-mark">${band === "M" ? "&#10003;" : ""}</td>
      <td class="toer-mark">${band === "P" ? "&#10003;" : ""}</td>
      <td>${state.toer.evidence.video ? "Y" : ""}</td>
      <td>${state.toer.evidence.photo ? "Y" : ""}</td>
      <td>${state.toer.evidence.record ? "Y" : ""}</td>
      <td>${state.toer.evidence.physical ? "Y" : ""}</td>
      <td>${state.toer.evidence.chart ? "Y" : ""}</td>
      <td>${escapeHtml(state.toer.anyOther)}</td>
      <td></td>
    </tr>
  `;
}

function getTraineeTotal(trainee) {
  return trainee.marks.reduce((sum, mark) => sum + toNumber(mark), 0);
}

function getResult(total) {
  return total < 60 ? "N" : "Y";
}

function getPerformanceBand(total) {
  if (total > 90) return "VG";
  if (total >= 75) return "G";
  if (total >= 60) return "M";
  return "P";
}

function buildAnnex3Groups(trainee) {
  return annex3Template.map((group) => {
    const total = trainee.marks[group.annex2Index] || 0;
    const rows = splitGroupMarks(total, group.rows);
    return {
      ...group,
      rows,
      total,
      maxTotal: group.rows.reduce((sum, row) => sum + row.max, 0),
    };
  });
}

function splitGroupMarks(total, templateRows) {
  const safeTotal = clampWholeNumber(total, 0, templateRows.reduce((sum, row) => sum + row.max, 0));
  const rows = templateRows.map((row) => ({ ...row, awarded: 0 }));

  let remaining = safeTotal;

  rows.forEach((row) => {
    if (row.locked) {
      const award = Math.min(row.max, remaining);
      row.awarded = award;
      remaining -= award;
    }
  });

  if (remaining <= 0) {
    return rows;
  }

  const adjustable = rows.filter((row) => !row.locked);
  const maxAdjustable = adjustable.reduce((sum, row) => sum + row.max, 0);

  if (maxAdjustable <= 0) {
    return rows;
  }

  adjustable.forEach((row) => {
    const exact = (remaining * row.max) / maxAdjustable;
    row.awarded += Math.min(row.max, Math.floor(exact));
  });

  let assigned = rows.reduce((sum, row) => sum + row.awarded, 0);
  let leftovers = safeTotal - assigned;

  const fractions = adjustable
    .map((row) => {
      const exact = (remaining * row.max) / maxAdjustable;
      return { row, fraction: exact - Math.floor(exact) };
    })
    .sort((a, b) => b.fraction - a.fraction || a.row.awarded - b.row.awarded);

  fractions.forEach(({ row }) => {
    if (leftovers <= 0) {
      return;
    }
    if (row.awarded < row.max) {
      row.awarded += 1;
      leftovers -= 1;
    }
  });

  let cursor = 0;
  while (leftovers > 0) {
    const row = adjustable[cursor % adjustable.length];
    if (row.awarded < row.max) {
      row.awarded += 1;
      leftovers -= 1;
    }
    cursor += 1;
  }

  return rows;
}

async function downloadAnnex3PdfForCurrent() {
  const trainee = state.trainees[selectedAnnex3Index] || state.trainees[0];
  if (!trainee) return;

  const pdfDoc = await PDFLib.PDFDocument.create();
  await addAnnex3PdfPage(pdfDoc, trainee);
  const bytes = await pdfDoc.save();
  triggerPdfDownload(bytes, `annex-3-${sanitizeFilename(trainee.admNo)}.pdf`);
}

async function downloadCombinedAnnex3Pdf() {
  const pdfDoc = await PDFLib.PDFDocument.create();
  for (const trainee of state.trainees) {
    await addAnnex3PdfPage(pdfDoc, trainee);
  }
  const bytes = await pdfDoc.save();
  triggerPdfDownload(bytes, "annex-3-all-trainees.pdf");
}

function downloadAnnex3Excel() {
  const trainee = state.trainees[selectedAnnex3Index] || state.trainees[0];
  const paper = annex3Panel.querySelector(".annex3-paper");
  if (!trainee || !paper) {
    return;
  }

  downloadExcelDocument({
    filename: `annex-3-${sanitizeFilename(trainee.admNo || trainee.name || "current")}.xls`,
    title: "Annexure III",
    worksheetName: "Annexure III",
    pageOrientation: "portrait",
    sources: paper,
  });
}

async function downloadAnnex2Pdf() {
  try {
    const pdfDoc = await PDFLib.PDFDocument.create();
    await addAnnexPreviewPdfPage(pdfDoc);
    const bytes = await pdfDoc.save();
    triggerPdfDownload(bytes, "annex-2-landscape.pdf");
  } catch (error) {
    console.error("Annex II preview export failed. Falling back to the manual PDF layout.", error);
    const pdfDoc = await PDFLib.PDFDocument.create();
    await addAnnex2PdfPage(pdfDoc);
    const bytes = await pdfDoc.save();
    triggerPdfDownload(bytes, "annex-2-landscape.pdf");
  }
}

function downloadAnnex2Excel() {
  const annexTable = annexPanel.querySelector("#annexTable");
  if (!annexTable) {
    return;
  }

  downloadExcelDocument({
    filename: "annex-2-landscape.xls",
    title: "Annexure II",
    worksheetName: "Annexure II",
    pageOrientation: "landscape",
    sources: annexTable,
  });
}

async function withAnnexPreviewExportNode(task) {
  const paper = document.querySelector("#annexPrintArea");
  const content = document.querySelector("#annexFitContent");

  if (!paper || !content) {
    throw new Error("Annex II preview is not available.");
  }

  syncAnnexScale();
  await waitForNextFrame();
  await waitForFontsReady();

  const exportHost = document.createElement("div");
  exportHost.setAttribute("aria-hidden", "true");
  exportHost.style.position = "fixed";
  exportHost.style.left = "-100000px";
  exportHost.style.top = "0";
  exportHost.style.opacity = "0";
  exportHost.style.pointerEvents = "none";
  exportHost.style.zIndex = "-1";
  exportHost.style.background = "#fff";

  const exportNode = buildAnnexPreviewExportNode(paper, content);
  exportHost.appendChild(exportNode);
  document.body.appendChild(exportHost);

  try {
    await waitForNextFrame();
    const rect = exportNode.getBoundingClientRect();
    if (!rect.width || !rect.height) {
      throw new Error("Annex II preview measured at zero size.");
    }
    return await task(exportNode, rect);
  } finally {
    exportHost.remove();
  }
}

function buildAnnexPreviewExportNode(paper, content) {
  const clone = cloneNodeForExport(paper);
  const stageClone = clone.querySelector("#annexFitStage");
  const contentClone = clone.querySelector("#annexFitContent");
  const naturalWidth = Math.max(
    Math.ceil(content.scrollWidth || 0),
    Math.ceil(content.getBoundingClientRect().width || 0),
  );

  clone.style.display = "inline-block";
  clone.style.width = "auto";
  clone.style.maxWidth = "none";
  clone.style.margin = "0";
  clone.style.boxSizing = "border-box";

  if (stageClone) {
    stageClone.style.width = `${naturalWidth}px`;
    stageClone.style.maxWidth = "none";
    stageClone.style.overflow = "visible";
  }

  if (contentClone) {
    contentClone.style.transform = "none";
    contentClone.style.width = `${naturalWidth}px`;
    contentClone.style.height = "auto";
    contentClone.style.maxWidth = "none";
    contentClone.style.overflow = "visible";
    contentClone.style.willChange = "auto";
  }

  return clone;
}

function cloneNodeForExport(node) {
  if (node.nodeType === Node.TEXT_NODE) {
    return node.cloneNode(false);
  }

  if (node.nodeType !== Node.ELEMENT_NODE) {
    return null;
  }

  if (
    node instanceof HTMLInputElement
    || node instanceof HTMLTextAreaElement
    || node instanceof HTMLSelectElement
  ) {
    return createExportFieldNode(node);
  }

  if (node.tagName === "SCRIPT") {
    return null;
  }

  const clone = node.cloneNode(false);
  copyComputedStyles(node, clone);

  Array.from(node.childNodes).forEach((child) => {
    const childClone = cloneNodeForExport(child);
    if (childClone) {
      clone.appendChild(childClone);
    }
  });

  return clone;
}

function createExportFieldNode(field) {
  const replacement = document.createElement(
    field instanceof HTMLTextAreaElement ? "div" : "span",
  );
  const computed = window.getComputedStyle(field);

  copyComputedStyles(field, replacement);
  replacement.setAttribute("data-export-field", "true");
  replacement.textContent = getExportFieldValue(field) || " ";
  replacement.style.display = computed.display === "inline" ? "inline-block" : "block";
  replacement.style.boxSizing = "border-box";
  replacement.style.whiteSpace = field instanceof HTMLTextAreaElement ? "pre-wrap" : "pre-wrap";
  replacement.style.overflow = "hidden";
  replacement.style.textOverflow = "clip";
  replacement.style.webkitAppearance = "none";
  replacement.style.appearance = "none";

  return replacement;
}

function getExportFieldValue(field) {
  if (field instanceof HTMLSelectElement) {
    return field.selectedOptions[0]?.textContent?.trim() || field.value || "";
  }

  if (field instanceof HTMLInputElement && field.type === "checkbox") {
    return field.checked ? "Yes" : "No";
  }

  return field.value || field.getAttribute("value") || "";
}

function copyComputedStyles(source, target) {
  const computed = window.getComputedStyle(source);

  for (let index = 0; index < computed.length; index += 1) {
    const property = computed[index];
    target.style.setProperty(
      property,
      computed.getPropertyValue(property),
      computed.getPropertyPriority(property),
    );
  }
}

async function addAnnexPreviewPdfPage(pdfDoc) {
  await withAnnexPreviewExportNode(async (exportNode, exportRect) => {
    const table = exportNode.querySelector("#annexTable");
    if (!table) {
      throw new Error("Annex II table could not be located.");
    }

    const tableRect = table.getBoundingClientRect();
    const cropPadding = 3;
    const contentRect = {
      left: tableRect.left - cropPadding,
      top: tableRect.top - cropPadding,
      width: tableRect.width + cropPadding * 2,
      height: tableRect.height + cropPadding * 2,
    };
    const page = pdfDoc.addPage([841.89, 595.28]);
    const font = await pdfDoc.embedFont(PDFLib.StandardFonts.Helvetica);
    const bold = await pdfDoc.embedFont(PDFLib.StandardFonts.HelveticaBold);
    const black = PDFLib.rgb(0, 0, 0);
    const pageMargin = 6;
    const layoutWidth = contentRect.width;
    const layoutHeight = contentRect.height;
    const scale = Math.min(
      (page.getWidth() - pageMargin * 2) / layoutWidth,
      (page.getHeight() - pageMargin * 2) / layoutHeight,
    );
    const originX = (page.getWidth() - layoutWidth * scale) / 2;
    const originY = (page.getHeight() - layoutHeight * scale) / 2;

    exportNode.querySelectorAll("#annexTable td, #annexTable th").forEach((cell) => {
      drawAnnexPreviewCell(page, cell, {
        exportRect: contentRect,
        layoutHeight,
        originX,
        originY,
        scale,
        font,
        bold,
        black,
      });
    });
  });
}

function drawAnnexPreviewCell(page, cell, context) {
  const cellRect = cell.getBoundingClientRect();
  const cellBox = getPdfBoxFromRect(cellRect, context.exportRect, context.layoutHeight, context);
  const cellStyles = window.getComputedStyle(cell);
  const background = getPdfColorFromCss(cellStyles.backgroundColor);

  page.drawRectangle({
    x: cellBox.x,
    y: cellBox.y,
    width: cellBox.width,
    height: cellBox.height,
    borderWidth: Math.max(0.45, (Number.parseFloat(cellStyles.borderTopWidth) || 1) * context.scale),
    borderColor: context.black,
    color: background || PDFLib.rgb(1, 1, 1),
  });

  const verticalText = cell.querySelector(".vertical-text");
  if (verticalText) {
    drawAnnexPreviewVerticalText(page, verticalText, context);
    return;
  }

  const textSource =
    cell.querySelector("[data-export-field='true']")
    || cell.querySelector(".signature-designation")
    || cell;
  const text = normalizePdfText(textSource.textContent);

  if (!text) {
    return;
  }

  const textRect = textSource === cell ? cellRect : textSource.getBoundingClientRect();
  drawAnnexPreviewText(page, text, textRect, cell, textSource, context);
}

function drawAnnexPreviewText(page, text, textRect, cell, textSource, context) {
  const styles = window.getComputedStyle(textSource);
  const fontSizePx = Number.parseFloat(styles.fontSize) || 12;
  const fontSize = Math.max(5, fontSizePx * context.scale);
  const lineHeight = Math.max(
    fontSize + 0.8,
    parsePdfLineHeight(styles.lineHeight, fontSizePx) * context.scale,
  );
  const usedFont = usesBoldFont(styles.fontWeight) ? context.bold : context.font;
  const paddingLeft = (Number.parseFloat(styles.paddingLeft) || 0) * context.scale;
  const paddingRight = (Number.parseFloat(styles.paddingRight) || 0) * context.scale;
  const paddingTop = (Number.parseFloat(styles.paddingTop) || 0) * context.scale;
  const paddingBottom = (Number.parseFloat(styles.paddingBottom) || 0) * context.scale;
  const box = getPdfBoxFromRect(textRect, context.exportRect, context.layoutHeight, context);
  const textWidth = Math.max(6, box.width - paddingLeft - paddingRight);
  const textHeight = Math.max(lineHeight, box.height - paddingTop - paddingBottom);
  const isFieldValue = textSource !== cell;
  const maxLines = isFieldValue ? 1 : Math.max(1, Math.floor(textHeight / lineHeight));
  const lines = wrapText(text, textWidth, usedFont, fontSize, maxLines);
  const blockHeight = lines.length * lineHeight;
  const align = getPdfTextAlign(cell, textSource, styles.textAlign);
  const valign = getPdfTextValign(cell, textSource);
  let baseY = box.y + box.height - paddingTop - fontSize;

  if (valign === "middle") {
    baseY = box.y + (box.height + blockHeight) / 2 - fontSize;
  } else if (valign === "bottom") {
    baseY = box.y + paddingBottom + blockHeight - fontSize;
  }

  lines.forEach((line, index) => {
    const lineWidth = usedFont.widthOfTextAtSize(line, fontSize);
    let drawX = box.x + paddingLeft;

    if (align === "center") {
      drawX = box.x + (box.width - lineWidth) / 2;
    } else if (align === "right") {
      drawX = box.x + box.width - paddingRight - lineWidth;
    }

    page.drawText(line, {
      x: Math.max(box.x + paddingLeft, drawX),
      y: baseY - index * lineHeight,
      size: fontSize,
      font: usedFont,
      color: context.black,
    });
  });
}

function drawAnnexPreviewVerticalText(page, element, context) {
  const styles = window.getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  const box = getPdfBoxFromRect(rect, context.exportRect, context.layoutHeight, context);
  const fontSizePx = Number.parseFloat(styles.fontSize) || 11;
  const fontSize = Math.max(4.8, fontSizePx * context.scale);
  const lineHeight = Math.max(
    fontSize + 0.6,
    parsePdfLineHeight(styles.lineHeight, fontSizePx) * context.scale,
  );
  const usedFont = usesBoldFont(styles.fontWeight) ? context.bold : context.font;
  const text = normalizePdfText(element.textContent);
  const lines = wrapText(text, Math.max(6, box.height - 8), usedFont, fontSize, Math.max(1, Math.floor(box.width / lineHeight)));
  const blockWidth = lines.length * lineHeight;
  const startX = box.x + (box.width - blockWidth) / 2 + fontSize * 0.18;

  lines.forEach((line, index) => {
    const lineWidth = usedFont.widthOfTextAtSize(line, fontSize);
    const drawX = startX + index * lineHeight;
    const drawY = box.y + (box.height - lineWidth) / 2;

    page.drawText(line, {
      x: drawX,
      y: drawY,
      size: fontSize,
      font: usedFont,
      color: context.black,
      rotate: PDFLib.degrees(90),
    });
  });
}

function getPdfBoxFromRect(rect, exportRect, layoutHeight, context) {
  return {
    x: context.originX + (rect.left - exportRect.left) * context.scale,
    y:
      context.originY
      + (layoutHeight - (rect.top - exportRect.top) - rect.height) * context.scale,
    width: rect.width * context.scale,
    height: rect.height * context.scale,
  };
}

function getPdfColorFromCss(value) {
  const match = String(value || "").match(
    /rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*[,/]\s*(\d+(?:\.\d+)?))?\s*\)/i,
  );

  if (!match) {
    return null;
  }

  const alpha = match[4] === undefined ? 1 : Number.parseFloat(match[4]);
  if (!Number.isFinite(alpha) || alpha <= 0) {
    return null;
  }

  return PDFLib.rgb(
    Number.parseFloat(match[1]) / 255,
    Number.parseFloat(match[2]) / 255,
    Number.parseFloat(match[3]) / 255,
  );
}

function normalizePdfText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function usesBoldFont(weight) {
  const numericWeight = Number.parseInt(weight, 10);
  return Number.isFinite(numericWeight) ? numericWeight >= 600 : /bold/i.test(String(weight || ""));
}

function parsePdfLineHeight(lineHeight, fallbackFontSize) {
  const numericLineHeight = Number.parseFloat(lineHeight);
  if (Number.isFinite(numericLineHeight)) {
    return numericLineHeight;
  }

  return fallbackFontSize * 1.2;
}

function getPdfTextAlign(cell, textSource, cssAlign) {
  if (textSource.classList.contains("signature-designation")) {
    return "center";
  }

  if (cell.classList.contains("annex-label") || cell.classList.contains("annex-value") || cell.classList.contains("name-cell")) {
    return "left";
  }

  if (cssAlign === "right" || cssAlign === "end") {
    return "right";
  }

  return cssAlign === "left" || cssAlign === "start" ? "left" : "center";
}

function getPdfTextValign(cell, textSource) {
  if (textSource.classList.contains("signature-designation") || cell.closest(".signature-row")) {
    return "bottom";
  }

  return "middle";
}

function waitForNextFrame() {
  return new Promise((resolve) => {
    requestAnimationFrame(() => {
      resolve();
    });
  });
}

async function waitForFontsReady() {
  if (!document.fonts?.ready) {
    return;
  }

  try {
    await document.fonts.ready;
  } catch (error) {
    console.warn("Continuing Annex II export before all fonts finished loading.", error);
  }
}

async function addAnnex2PdfPage(pdfDoc) {
  const page = pdfDoc.addPage([841.89, 595.28]);
  const font = await pdfDoc.embedFont(PDFLib.StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(PDFLib.StandardFonts.HelveticaBold);
  const black = PDFLib.rgb(0, 0, 0);
  const headerFill = PDFLib.rgb(0.94, 0.96, 0.98);
  const margin = 12;
  const pageWidth = page.getWidth();
  const pageHeight = page.getHeight();
  const tableWidth = pageWidth - margin * 2;
  const tableHeight = pageHeight - margin * 2;
  const baseColWidths = [90, 220, 210, ...state.components.map(() => 70), 90, 68];
  const colScale = tableWidth / baseColWidths.reduce((sum, width) => sum + width, 0);
  const colWidths = baseColWidths.map((width) => width * colScale);
  colWidths[colWidths.length - 1] =
    tableWidth - colWidths.slice(0, -1).reduce((sum, width) => sum + width, 0);

  const traineeCount = Math.max(state.trainees.length, 1);
  const titleHeight = 18;
  const metaRowHeight = 18;
  const learningOutcomeHeight = 24;
  const headerTopHeight = 20;
  const headerBottomHeight = 66;
  const signatureHeight = 34;
  const fixedHeight =
    titleHeight +
    metaRowHeight * 4 +
    learningOutcomeHeight +
    headerTopHeight +
    headerBottomHeight +
    signatureHeight;
  const traineeRowHeight = (tableHeight - fixedHeight) / traineeCount;
  const rowFontSize = traineeRowHeight >= 15 ? 6.9 : traineeRowHeight >= 12 ? 6.3 : 5.7;
  const narrowFontSize = Math.max(5.1, rowFontSize - 0.3);
  let y = pageHeight - margin;

  const colX = (index) => margin + colWidths.slice(0, index).reduce((sum, width) => sum + width, 0);
  const spanWidth = (start, count) => colWidths.slice(start, start + count).reduce((sum, width) => sum + width, 0);

  const drawCell = (x, top, width, height, cell = {}) => {
    page.drawRectangle({
      x,
      y: top - height,
      width,
      height,
      borderWidth: cell.borderWidth ?? 1,
      borderColor: black,
      color: cell.background || undefined,
    });

    if (cell.text === undefined || cell.text === null || cell.text === "") {
      return;
    }

    const usedFont = cell.bold ? bold : font;
    const fontSize = cell.fontSize ?? 7;
    const lineHeight = cell.lineHeight ?? fontSize + 1;
    const textPaddingX = cell.paddingX ?? 3;
    const textPaddingY = cell.paddingY ?? 3;
    const lines = wrapText(
      String(cell.text),
      Math.max(6, width - textPaddingX * 2),
      usedFont,
      fontSize,
      cell.maxLines ?? 4,
    );
    const blockHeight = lines.length * lineHeight;
    const drawTop =
      cell.valign === "center"
        ? top - Math.max(0, (height - blockHeight) / 2) - fontSize
        : top - textPaddingY - fontSize;

    lines.forEach((line, index) => {
      const lineWidth = usedFont.widthOfTextAtSize(line, fontSize);
      let drawX = x + textPaddingX;
      if (cell.align === "center") {
        drawX = x + Math.max(textPaddingX, (width - lineWidth) / 2);
      } else if (cell.align === "right") {
        drawX = x + Math.max(textPaddingX, width - lineWidth - textPaddingX);
      }

      page.drawText(line, {
        x: drawX,
        y: drawTop - index * lineHeight,
        size: fontSize,
        font: usedFont,
        color: black,
      });
    });
  };

  const drawRow = (height, cells) => {
    const top = y;
    let x = margin;
    cells.forEach((cell, index) => {
      const width = cell.width ?? colWidths[index] ?? 50;
      drawCell(x, top, width, height, cell);
      x += width;
    });
    y -= height;
  };

  drawRow(titleHeight, [
    {
      width: tableWidth,
      text: state.meta.title || "ANNEXTURE - II",
      bold: true,
      align: "center",
      valign: "center",
      fontSize: 9.5,
      lineHeight: 10.5,
    },
  ]);

  drawRow(metaRowHeight, [
    { width: spanWidth(0, 2), text: appData.meta.assessorLabel, bold: true, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(2, 5), text: state.meta.assessor, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(7, 3), text: appData.meta.yearLabel, bold: true, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(10, 4), text: state.meta.yearEnrolment, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
  ]);
  drawRow(metaRowHeight, [
    { width: spanWidth(0, 2), text: appData.meta.itiLabel, bold: true, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(2, 5), text: state.meta.itiName, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(7, 3), text: appData.meta.dateLabel, bold: true, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(10, 4), text: state.meta.dateOfAssessment, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
  ]);
  drawRow(metaRowHeight, [
    { width: spanWidth(0, 2), text: appData.meta.industryLabel, bold: true, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(2, 5), text: state.meta.industryName, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(7, 3), text: appData.meta.locationLabel, bold: true, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
    { width: spanWidth(10, 4), text: state.meta.assessmentLocation, align: "left", valign: "center", fontSize: 6.4, maxLines: 2 },
  ]);
  drawRow(metaRowHeight, [
    { width: spanWidth(0, 2), text: appData.meta.tradeLabel, bold: true, align: "left", valign: "center", fontSize: 6.2, maxLines: 2 },
    { width: spanWidth(2, 2), text: state.meta.tradeName, align: "left", valign: "center", fontSize: 6.2, maxLines: 2 },
    { width: spanWidth(4, 2), text: appData.meta.examLabel, bold: true, align: "left", valign: "center", fontSize: 6.2, maxLines: 2 },
    { width: spanWidth(6, 2), text: state.meta.examination, align: "left", valign: "center", fontSize: 6.2, maxLines: 2 },
    { width: spanWidth(8, 3), text: appData.meta.durationLabel, bold: true, align: "left", valign: "center", fontSize: 6.2, maxLines: 2 },
    { width: spanWidth(11, 3), text: state.meta.durationOfTrade, align: "left", valign: "center", fontSize: 6.2, maxLines: 2 },
  ]);
  drawRow(learningOutcomeHeight, [
    { width: spanWidth(0, 2), text: appData.meta.learningOutcomeLabel, bold: true, align: "left", valign: "center", fontSize: 6.2, maxLines: 2 },
    { width: spanWidth(2, 12), text: state.meta.learningOutcome, align: "left", valign: "center", fontSize: 6.2, maxLines: 2 },
  ]);

  const headerTop = y;
  const headerTotalHeight = headerTopHeight + headerBottomHeight;
  drawCell(colX(0), headerTop, colWidths[0], headerTotalHeight, {
    text: "Adm No",
    bold: true,
    align: "center",
    valign: "center",
    background: headerFill,
    fontSize: 6.4,
    maxLines: 2,
  });
  drawCell(colX(1), headerTop, spanWidth(1, 2), headerTopHeight, {
    text: "MAXIMUM MARKS (TOTAL 100 MARKS)",
    bold: true,
    align: "center",
    valign: "center",
    background: headerFill,
    fontSize: 6.2,
    maxLines: 2,
  });
  state.components.forEach((component, index) => {
    drawCell(colX(3 + index), headerTop, colWidths[3 + index], headerTopHeight, {
      text: String(component.maxMark),
      bold: true,
      align: "center",
      valign: "center",
      background: headerFill,
      fontSize: 6.6,
      maxLines: 1,
    });
  });
  drawCell(colX(12), headerTop, colWidths[12], headerTotalHeight, {
    text: "Total Internal Assessment Marks",
    bold: true,
    align: "center",
    valign: "center",
    background: headerFill,
    fontSize: 5.8,
    maxLines: 4,
  });
  drawCell(colX(13), headerTop, colWidths[13], headerTotalHeight, {
    text: "Result (Y/N)",
    bold: true,
    align: "center",
    valign: "center",
    background: headerFill,
    fontSize: 5.8,
    maxLines: 3,
  });

  y -= headerTopHeight;
  drawCell(colX(1), y, colWidths[1], headerBottomHeight, {
    text: "CANDIDATE NAME",
    bold: true,
    align: "center",
    valign: "center",
    background: headerFill,
    fontSize: 5.8,
    maxLines: 2,
  });
  drawCell(colX(2), y, colWidths[2], headerBottomHeight, {
    text: "FATHER'S/MOTHER'S NAME",
    bold: true,
    align: "center",
    valign: "center",
    background: headerFill,
    fontSize: 5.8,
    maxLines: 3,
  });
  state.components.forEach((component, index) => {
    drawCell(colX(3 + index), y, colWidths[3 + index], headerBottomHeight, {
      text: component.name,
      bold: true,
      align: "center",
      valign: "center",
      background: headerFill,
      fontSize: 5.2,
      lineHeight: 5.9,
      maxLines: 6,
      paddingX: 2,
    });
  });
  y -= headerBottomHeight;

  state.trainees.forEach((trainee) => {
    const total = getTraineeTotal(trainee);
    const result = getResult(total);

    drawRow(traineeRowHeight, [
      { text: trainee.admNo, align: "center", valign: "center", fontSize: rowFontSize, maxLines: 2, paddingX: 2 },
      { text: trainee.name, align: "left", valign: "center", fontSize: rowFontSize, maxLines: 2, paddingX: 2 },
      { text: trainee.fatherName, align: "left", valign: "center", fontSize: rowFontSize, maxLines: 2, paddingX: 2 },
      ...trainee.marks.map((mark) => ({
        text: formatMark(mark),
        align: "center",
        valign: "center",
        fontSize: narrowFontSize,
        maxLines: 1,
        paddingX: 1.5,
      })),
      { text: formatMark(total), align: "center", valign: "center", fontSize: narrowFontSize, bold: true, maxLines: 1 },
      { text: result, align: "center", valign: "center", fontSize: narrowFontSize, bold: true, maxLines: 1 },
    ]);
  });

  drawRow(signatureHeight, [
    { width: spanWidth(0, 3), text: state.meta.instructorLeft, bold: true, align: "center", valign: "center", fontSize: 6.2, maxLines: 2 },
    { width: spanWidth(3, 4), text: state.meta.instructorMiddle, bold: true, align: "center", valign: "center", fontSize: 6.2, maxLines: 2 },
    { width: spanWidth(7, 7), text: state.meta.principal, bold: true, align: "center", valign: "center", fontSize: 6.2, maxLines: 2 },
  ]);

  page.drawRectangle({
    x: margin,
    y: margin,
    width: tableWidth,
    height: tableHeight,
    borderWidth: 1.3,
    borderColor: black,
  });
}

async function downloadToerPdf() {
  const pdfDoc = await PDFLib.PDFDocument.create();
  await addToerPdfPage(pdfDoc);
  const bytes = await pdfDoc.save();
  triggerPdfDownload(bytes, "toer-landscape.pdf");
}

function downloadToerExcel() {
  const paper = toerPanel.querySelector(".toer-paper");
  if (!paper) {
    return;
  }

  downloadExcelDocument({
    filename: "toer-landscape.xls",
    title: "TOER",
    worksheetName: "TOER",
    pageOrientation: "landscape",
    sources: paper,
  });
}

async function addToerPdfPage(pdfDoc) {
  const page = pdfDoc.addPage([841.89, 595.28]);
  const font = await pdfDoc.embedFont(PDFLib.StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(PDFLib.StandardFonts.HelveticaBold);
  const black = PDFLib.rgb(0, 0, 0);
  const blue = PDFLib.rgb(0.929, 0.953, 0.973);
  const margin = 12;
  const pageWidth = page.getWidth();
  const pageHeight = page.getHeight();
  const tableWidth = pageWidth - margin * 2;
  const tableHeight = pageHeight - margin * 2;
  const baseColWidths = [36, 159, 64, 64, 34, 34, 34, 34, 46, 46, 46, 50, 46, 62, 58];
  const colScale = tableWidth / baseColWidths.reduce((sum, width) => sum + width, 0);
  const colWidths = baseColWidths.map((width) => width * colScale);
  colWidths[colWidths.length - 1] =
    tableWidth - colWidths.slice(0, -1).reduce((sum, width) => sum + width, 0);

  const titleHeight = 22;
  const instituteHeight = 20;
  const trainerHeight = 22;
  const shiftHeight = 18;
  const learningOutcomeHeight = 28;
  const header1Height = 24;
  const header2Height = 22;
  const signatureSpaceHeight = 42;
  const signatureLabelHeight = 20;
  const fixedHeight =
    titleHeight +
    instituteHeight +
    trainerHeight +
    shiftHeight +
    learningOutcomeHeight +
    header1Height +
    header2Height +
    signatureSpaceHeight +
    signatureLabelHeight;
  const traineeRowHeight = (tableHeight - fixedHeight) / state.trainees.length;
  const tableTop = pageHeight - margin;
  let y = tableTop;

  const colX = (index) => margin + colWidths.slice(0, index).reduce((sum, width) => sum + width, 0);
  const spanWidth = (start, count) => colWidths.slice(start, start + count).reduce((sum, width) => sum + width, 0);

  const drawCell = (x, top, width, height, cell = {}) => {
    const rect = { x, y: top - height, width, height, borderWidth: 1, borderColor: black };
    if (cell.background) rect.color = cell.background;
    page.drawRectangle(rect);

    if (cell.text === undefined || cell.text === null || cell.text === "") return;

    const usedFont = cell.bold ? bold : font;
    const fontSize = cell.fontSize ?? 7.7;
    const lineHeight = fontSize + 1;
    const lines = wrapText(String(cell.text), width - 6, usedFont, fontSize, cell.maxLines ?? 3);
    const blockHeight = lines.length * lineHeight;
    const baseY =
      cell.valign === "center"
        ? top - (height - blockHeight) / 2 - fontSize
        : top - fontSize - 4;

    lines.forEach((line, index) => {
      const lineWidth = usedFont.widthOfTextAtSize(line, fontSize);
      let drawX = x + 3;
      if (cell.align === "center") {
        drawX = x + Math.max(0, (width - lineWidth) / 2);
      } else if (cell.align === "right") {
        drawX = x + Math.max(0, width - lineWidth - 3);
      }
      page.drawText(line, {
        x: drawX,
        y: baseY - index * lineHeight,
        size: fontSize,
        font: usedFont,
        color: black,
      });
    });
  };

  const drawRow = (height, cells) => {
    const top = y;
    let x = margin;
    cells.forEach((cell, index) => {
      const width = cell.width ?? colWidths[index] ?? 50;
      drawCell(x, top, width, height, cell);
      x += width;
    });
    y -= height;
  };

  drawRow(titleHeight, [{ width: tableWidth, text: "TRAINER'S OBSERVATION & EVIDENCE REPORT", bold: true, align: "center", valign: "center", fontSize: 10.5 }]);
  drawRow(instituteHeight, [
    { width: spanWidth(0, 4), text: `Name of Institute: ${formatInstituteForToer(state.meta.itiName)}`, bold: true, valign: "center", fontSize: 8 },
    { width: spanWidth(4, 11), text: `Trade: ${formatTradeForToer(state.meta.tradeName)}`, bold: true, valign: "center", fontSize: 8 },
  ]);
  drawRow(trainerHeight, [
    { width: spanWidth(0, 4), text: `Name & Address of the Trainer: ${state.toer.trainerAddress}`, bold: true, valign: "center", fontSize: 8, maxLines: 2 },
    { width: spanWidth(4, 11), text: `Unit: ${state.toer.unit}     Year: ${state.toer.year}`, bold: true, valign: "center", fontSize: 8 },
  ]);
  drawRow(shiftHeight, [
    { width: spanWidth(0, 4), text: "" },
    { width: spanWidth(4, 11), text: `Shift : ${state.toer.shift}`, bold: true, valign: "center", fontSize: 8 },
  ]);
  drawRow(learningOutcomeHeight, [
    { width: spanWidth(0, 3), text: "No. & Name of Learning Outcome:", bold: true, valign: "center", fontSize: 8 },
    { width: spanWidth(3, 12), text: state.meta.learningOutcome, valign: "center", fontSize: 8, maxLines: 2 },
  ]);

  const headerTop = y;
  const header1 = header1Height;
  const header2 = header2Height;
  const headerTotal = header1 + header2;
  [
    { index: 0, text: "Sl. No." },
    { index: 1, text: "Name of Trainee" },
    { index: 2, text: "Starting Time" },
    { index: 3, text: "Finishing Time" },
    { index: 14, text: "Remarks" },
  ].forEach((cell) => {
    drawCell(colX(cell.index), headerTop, colWidths[cell.index], headerTotal, {
      text: cell.text,
      bold: true,
      align: "center",
      valign: "center",
      background: blue,
      fontSize: 7.4,
      maxLines: 3,
    });
  });
  drawCell(colX(4), headerTop, spanWidth(4, 4), header1, { text: "Overall Performance", bold: true, align: "center", valign: "center", background: blue, fontSize: 7.5 });
  drawCell(colX(8), headerTop, spanWidth(8, 6), header1, { text: "Evidences available Remarks", bold: true, align: "center", valign: "center", background: blue, fontSize: 7.5 });
  y -= header1;
  ["VG", "G", "M", "P", "Video Y/N", "Photo Y/N", "Record Y/N", "Physical Y/N", "Chart Y/N", "Any other"].forEach((label, offset) => {
    const columnIndex = 4 + offset;
    drawCell(colX(columnIndex), y, colWidths[columnIndex], header2, {
      text: label,
      bold: true,
      align: "center",
      valign: "center",
      background: blue,
      fontSize: 6.9,
      maxLines: 2,
    });
  });
  y -= header2;

  state.trainees.forEach((trainee, index) => {
    const total = getTraineeTotal(trainee);
    const band = getPerformanceBand(total);
    const override = state.toer.overrides[index] || createToerOverride();
    const startTime = override.useCustomTime ? override.startTime : state.toer.defaultStartTime;
    const endTime = override.useCustomTime ? override.endTime : state.toer.defaultEndTime;
    drawRow(traineeRowHeight, [
      { text: index + 1, align: "center", valign: "center", fontSize: 7.6 },
      { text: trainee.name, valign: "center", fontSize: 7.4, maxLines: 2 },
      { text: formatTimeForDisplay(startTime), align: "center", valign: "center", fontSize: 7.6 },
      { text: formatTimeForDisplay(endTime), align: "center", valign: "center", fontSize: 7.6 },
      { text: band === "VG" ? "Y" : "", align: "center", valign: "center", bold: true, fontSize: 8 },
      { text: band === "G" ? "Y" : "", align: "center", valign: "center", bold: true, fontSize: 8 },
      { text: band === "M" ? "Y" : "", align: "center", valign: "center", bold: true, fontSize: 8 },
      { text: band === "P" ? "Y" : "", align: "center", valign: "center", bold: true, fontSize: 8 },
      { text: state.toer.evidence.video ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.evidence.photo ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.evidence.record ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.evidence.physical ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.evidence.chart ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.anyOther, align: "center", valign: "center", fontSize: 7.2, maxLines: 2 },
      { text: "", fontSize: 7.4 },
    ]);
  });

  drawRow(signatureSpaceHeight, [
    { width: spanWidth(0, 4), text: "" },
    { width: spanWidth(4, 4), text: "" },
    { width: spanWidth(8, 5), text: "" },
    { width: spanWidth(13, 2), text: "" },
  ]);
  drawRow(signatureLabelHeight, [
    { width: spanWidth(0, 4), text: "VG- above 90%, G- 75-90 %, M- 60-75 %, P- Below 60%", bold: true, valign: "center", fontSize: 7.2, maxLines: 2 },
    { width: spanWidth(4, 4), text: "SIGN.OF VP/PRINCIPAL", bold: true, align: "center", valign: "center", fontSize: 7.4 },
    { width: spanWidth(8, 5), text: "SIGN OF GI", bold: true, align: "center", valign: "center", fontSize: 7.4 },
    { width: spanWidth(13, 2), text: "SIGN. OF TRAINER", bold: true, align: "center", valign: "center", fontSize: 7.4 },
  ]);

  page.drawRectangle({
    x: margin,
    y: margin,
    width: tableWidth,
    height: tableHeight,
    borderWidth: 1.4,
    borderColor: black,
  });
}

async function addAnnex3PdfPage(pdfDoc, trainee) {
  const page = pdfDoc.addPage([595.28, 841.89]);
  const font = await pdfDoc.embedFont(PDFLib.StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(PDFLib.StandardFonts.HelveticaBold);
  const blue = PDFLib.rgb(0.858, 0.918, 0.969);
  const black = PDFLib.rgb(0, 0, 0);
  const margin = 16;
  const pageWidth = page.getWidth();
  const pageHeight = page.getHeight();
  const tableWidth = pageWidth - margin * 2;
  const colWidths = [34, 130, 241, 74, tableWidth - 34 - 130 - 241 - 74];

  let y = pageHeight - margin;

  const drawCell = (x, top, width, height, cell = {}) => {
    const rectOptions = {
      x,
      y: top - height,
      width,
      height,
      borderWidth: 1,
      borderColor: black,
    };
    if (cell.background) {
      rectOptions.color = cell.background;
    }
    page.drawRectangle(rectOptions);

    if (cell.text === undefined || cell.text === null) {
      return;
    }

    const usedFont = cell.bold ? bold : font;
    const fontSize = cell.fontSize ?? 7.8;
    const maxLines = cell.maxLines ?? 3;
    const lineHeight = fontSize + 1;
    const lines = wrapText(String(cell.text), width - 8, usedFont, fontSize, maxLines);
    const blockHeight = lines.length * lineHeight;
    const baseY =
      cell.valign === "center"
        ? top - (height - blockHeight) / 2 - fontSize
        : top - fontSize - 4;

    lines.forEach((line, index) => {
      const lineWidth = usedFont.widthOfTextAtSize(line, fontSize);
      let drawX = x + 4;
      if (cell.align === "center") {
        drawX = x + Math.max(0, (width - lineWidth) / 2);
      } else if (cell.align === "right") {
        drawX = x + Math.max(0, width - lineWidth - 4);
      }
      page.drawText(line, {
        x: drawX,
        y: baseY - index * lineHeight,
        size: fontSize,
        font: usedFont,
        color: black,
      });
    });
  };

  const drawRow = (height, cells) => {
    const top = y;
    let x = margin;
    cells.forEach((cell, index) => {
      const width = cell.width ?? colWidths[index] ?? 60;
      drawCell(x, top, width, height, cell);
      x += width;
    });
    y -= height;
  };

  const drawSpanningRow = (height, segments) => {
    const top = y;
    let x = margin;
    segments.forEach((segment) => {
      drawCell(x, top, segment.width, height, segment);
      x += segment.width;
    });
    y -= height;
  };

  const groups = buildAnnex3Groups(trainee);
  const grandTotal = groups.reduce((sum, group) => sum + group.total, 0);

  drawSpanningRow(22, [{ width: tableWidth, text: "ANNEXURE - III", bold: true, align: "center", fontSize: 10.8, valign: "center" }]);
  drawSpanningRow(17, [{ width: 230, text: "Name & Address of the Assessor", bold: true }, { width: tableWidth - 230, text: state.meta.assessor }]);
  drawSpanningRow(17, [{ width: 230, text: "Name & Address of I T I", bold: true }, { width: tableWidth - 230, text: state.meta.itiName, maxLines: 2 }]);
  drawSpanningRow(17, [{ width: 230, text: "Subject Name", bold: true }, { width: tableWidth - 230, text: "Trade Practical" }]);
  drawSpanningRow(17, [{ width: 230, text: "Trade Name", bold: true }, { width: tableWidth - 230, text: state.meta.tradeName }]);
  drawSpanningRow(30, [{ width: 150, text: "Learning Outcome", bold: true }, { width: tableWidth - 150, text: state.meta.learningOutcome, maxLines: 2 }]);
  drawRow(18, [
    { text: "Adm.No", bold: true, align: "center", width: 78, valign: "center" },
    { text: "Name of The Candidate", bold: true, align: "center", width: 192, valign: "center" },
    { text: "Acadamic Span", bold: true, align: "center", width: 126, valign: "center" },
    { text: "Date of Assesment", bold: true, align: "center", width: tableWidth - 396, valign: "center" },
  ]);
  drawRow(18, [
    { text: trainee.admNo, width: 78, align: "center", valign: "center" },
    { text: trainee.name, width: 192, align: "center", valign: "center" },
    { text: state.meta.yearEnrolment, width: 126, align: "center", valign: "center" },
    { text: state.meta.dateOfAssessment, width: tableWidth - 396, align: "center", valign: "center" },
  ]);
  drawRow(28, [
    { text: "Sl No", bold: true, align: "center", width: colWidths[0], background: blue, valign: "center", fontSize: 7.7 },
    { text: "ASSESSMENT PARAMETERS", bold: true, align: "center", width: colWidths[1], background: blue, valign: "center", fontSize: 7.7 },
    { text: "COMPONENT OF ASSESSMENT PARAMETERS", bold: true, align: "center", width: colWidths[2], background: blue, valign: "center", fontSize: 7.7 },
    { text: "MAX.MARKS BREAK-UP", bold: true, align: "center", width: colWidths[3], background: blue, valign: "center", fontSize: 7.2 },
    { text: "MARKS AWARDED", bold: true, align: "center", width: colWidths[4], background: blue, valign: "center", fontSize: 7.2 },
  ]);

  groups.forEach((group) => {
    const rowHeight = 14.7;
    const totalHeight = 14.7;
    const groupTop = y;
    const groupHeight = group.rows.length * rowHeight + totalHeight;
    const componentX = margin + colWidths[0] + colWidths[1];
    const maxX = componentX + colWidths[2];
    const awardX = maxX + colWidths[3];

    drawCell(margin, groupTop, colWidths[0], groupHeight, {
      text: group.groupNo,
      align: "center",
      valign: "center",
      fontSize: 7.8,
    });
    drawCell(margin + colWidths[0], groupTop, colWidths[1], groupHeight, {
      text: group.parameter,
      align: "center",
      valign: "center",
      bold: true,
      fontSize: 7.3,
      maxLines: 5,
    });

    group.rows.forEach((row, index) => {
      const rowTop = y;
      drawCell(componentX, rowTop, colWidths[2], rowHeight, { text: row.name, fontSize: 7.1, maxLines: 2, valign: "center" });
      drawCell(maxX, rowTop, colWidths[3], rowHeight, { text: row.max, align: "center", valign: "center", fontSize: 7.8 });
      drawCell(awardX, rowTop, colWidths[4], rowHeight, { text: row.awarded, align: "center", valign: "center", fontSize: 7.8 });
      y -= rowHeight;
    });
    drawCell(componentX, y, colWidths[2], totalHeight, { text: "TOTAL", bold: true, valign: "center", fontSize: 7.8 });
    drawCell(maxX, y, colWidths[3], totalHeight, { text: group.maxTotal, bold: true, align: "center", valign: "center", fontSize: 7.8 });
    drawCell(awardX, y, colWidths[4], totalHeight, { text: group.total, bold: true, align: "center", valign: "center", fontSize: 7.8 });
    y -= totalHeight;
  });

  drawRow(18, [
    { text: "GRAND TOTAL", width: colWidths[0] + colWidths[1] + colWidths[2], bold: true, valign: "center" },
    { text: 100, width: colWidths[3], bold: true, align: "center", valign: "center" },
    { text: grandTotal, width: colWidths[4], bold: true, align: "center", valign: "center" },
  ]);
  drawSpanningRow(58, [
    { width: tableWidth / 3, text: "" },
    { width: tableWidth / 3, text: "" },
    { width: tableWidth / 3, text: "" },
  ]);
  drawSpanningRow(20, [
    { width: tableWidth / 3, text: "Signature of the Candidate", bold: true, align: "center", valign: "center", fontSize: 7.4 },
    { width: tableWidth / 3, text: "Group Instructor", bold: true, align: "center", valign: "center", fontSize: 7.4 },
    { width: tableWidth / 3, text: "Signature, Name & Designation of Accessor", bold: true, align: "center", valign: "center", fontSize: 7.1 },
  ]);
}

function drawWrappedText(page, text, x, topY, width, fontSize, font, align = "left") {
  const lines = wrapText(text, width, font, fontSize);
  lines.forEach((line, index) => {
    const lineWidth = font.widthOfTextAtSize(line, fontSize);
    let drawX = x;
    if (align === "center") {
      drawX = x + Math.max(0, (width - lineWidth) / 2);
    } else if (align === "right") {
      drawX = x + Math.max(0, width - lineWidth);
    }
    page.drawText(line, {
      x: drawX,
      y: topY - index * (fontSize + 1),
      size: fontSize,
      font,
      color: PDFLib.rgb(0, 0, 0),
    });
  });
}

function wrapText(text, width, font, fontSize, maxLines = 3) {
  const words = String(text).split(/\s+/).filter(Boolean);
  if (!words.length) return [""];
  const lines = [];
  let current = words[0];
  for (let i = 1; i < words.length; i += 1) {
    const next = `${current} ${words[i]}`;
    if (font.widthOfTextAtSize(next, fontSize) <= width) {
      current = next;
    } else {
      lines.push(current);
      current = words[i];
    }
  }
  lines.push(current);
  return lines.slice(0, maxLines);
}

function triggerPdfDownload(bytes, filename) {
  const blob = new Blob([bytes], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function sanitizeFilename(value) {
  return String(value).replace(/[<>:"/\\|?*]+/g, "-");
}

function splitTotalIntoComponents(total, components = appData.components) {
  const maxMarks = components.map((component) => toNumber(component.maxMark));
  const safeTotal = clampWholeNumber(total, 0, 100);
  const marks = new Array(maxMarks.length).fill(0);

  if (safeTotal <= 0) {
    return marks;
  }

  const safetyFloor = 13;
  const safetyIndex = 0;
  const guaranteedSafety = Math.min(maxMarks[safetyIndex], Math.min(safetyFloor, safeTotal));
  marks[safetyIndex] = guaranteedSafety;

  let remaining = safeTotal - guaranteedSafety;
  const capacities = maxMarks.map((max, index) => max - marks[index]);
  const totalRemainingCapacity = capacities.reduce((sum, value) => sum + value, 0);

  if (remaining <= 0 || totalRemainingCapacity <= 0) {
    return marks;
  }

  const fractionalParts = [];

  capacities.forEach((capacity, index) => {
    if (capacity <= 0) {
      fractionalParts.push({ index, fraction: 0 });
      return;
    }

    const exactShare = (remaining * capacity) / totalRemainingCapacity;
    const wholeShare = Math.min(capacity, Math.floor(exactShare));
    marks[index] += wholeShare;
    fractionalParts.push({ index, fraction: exactShare - wholeShare });
  });

  let assigned = marks.reduce((sum, value) => sum + value, 0);
  let leftovers = safeTotal - assigned;

  fractionalParts
    .sort((a, b) => b.fraction - a.fraction || capacities[b.index] - capacities[a.index])
    .forEach(({ index }) => {
      if (leftovers <= 0) {
        return;
      }
      if (marks[index] < maxMarks[index]) {
        marks[index] += 1;
        leftovers -= 1;
      }
    });

  let rotateIndex = 0;
  while (leftovers > 0) {
    const index = rotateIndex % marks.length;
    if (marks[index] < maxMarks[index]) {
      marks[index] += 1;
      leftovers -= 1;
    }
    rotateIndex += 1;
  }

  return marks;
}

function syncAnnexScale() {
  const stage = document.querySelector("#annexFitStage");
  const content = document.querySelector("#annexFitContent");

  if (!stage || !content) {
    return;
  }

  content.style.transform = "scale(1)";
  content.style.width = "fit-content";
  content.style.height = "auto";

  const stageWidth = stage.clientWidth;
  const naturalWidth = content.scrollWidth;

  if (!stageWidth || !naturalWidth) {
    return;
  }

  const scale = Math.min(1, stageWidth / naturalWidth);
  content.style.transform = `scale(${scale})`;
  content.style.width = `${naturalWidth}px`;
  content.style.height = `${content.scrollHeight * scale}px`;
}

function normalizeMeta(meta) {
  return {
    ...meta,
    examination:
      meta.examination && meta.examination !== meta.durationLabel ? meta.examination : "",
  };
}

function buildTrainerAddress(instructorName, itiName) {
  return [String(instructorName || "").trim(), String(itiName || "").trim()]
    .filter(Boolean)
    .join(", ");
}

function createDefaultToerState(trainees, meta) {
  return {
    trainerAddress: buildTrainerAddress(meta.assessor, meta.itiName),
    unit: "1",
    year: "1",
    shift: "II",
    defaultStartTime: "",
    defaultEndTime: "",
    evidence: {
      video: false,
      photo: false,
      record: false,
      physical: false,
      chart: true,
    },
    anyOther: "",
    overrides: trainees.map(() => createToerOverride()),
  };
}

function createToerOverride() {
  return {
    useCustomTime: false,
    startTime: "",
    endTime: "",
  };
}

function normalizeToerState(rawToer, trainees, meta) {
  const fallback = createDefaultToerState(trainees, meta);
  const incoming = rawToer || {};
  const overrides = Array.isArray(incoming.overrides) ? incoming.overrides : [];

  return {
    ...fallback,
    ...incoming,
    evidence: {
      ...fallback.evidence,
      ...(incoming.evidence || {}),
    },
    overrides: trainees.map((_, index) => ({
      ...createToerOverride(),
      ...(overrides[index] || {}),
    })),
  };
}

function normalizeTrainees(trainees) {
  return trainees.map((trainee) => {
    const total = clampWholeNumber(
      Array.isArray(trainee.marks)
        ? trainee.marks.reduce((sum, mark) => sum + toNumber(mark), 0)
        : trainee.total,
      0,
      100,
    );

    return {
      ...trainee,
      marks: splitTotalIntoComponents(total),
    };
  });
}

function readTimeControlValue(source) {
  const control = source.closest(".time-entry");
  if (!control) {
    return "";
  }

  const hour = clampWholeNumber(control.querySelector("[data-time-part='hour']")?.value, 1, 12);
  const minute = clampWholeNumber(control.querySelector("[data-time-part='minute']")?.value, 0, 59);
  const period = control.querySelector("[data-time-part='period']")?.value === "AM" ? "AM" : "PM";
  const hour24 = period === "PM" ? (hour % 12) + 12 : hour % 12;
  return `${String(hour24).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

function parseTimeParts(value) {
  if (!value) {
    return { hour: "", minute: "", period: "AM" };
  }

  const text = String(value).trim().toUpperCase();
  const match12 = text.match(/^(\d{1,2})(?::(\d{1,2}))?\s*(AM|PM)$/);
  if (match12) {
    return {
      hour: String(clampWholeNumber(match12[1], 1, 12)),
      minute: String(clampWholeNumber(match12[2] ?? 0, 0, 59)).padStart(2, "0"),
      period: match12[3],
    };
  }

  const [hourText, minuteText = "00"] = text.split(":");
  const hour24 = clampWholeNumber(hourText, 0, 23);
  const period = hour24 >= 12 ? "PM" : "AM";
  const hour12 = hour24 % 12 || 12;
  return {
    hour: String(hour12),
    minute: String(clampWholeNumber(minuteText, 0, 59)).padStart(2, "0"),
    period,
  };
}

function formatTimeForDisplay(value) {
  if (!value) {
    return "";
  }

  const [hourText, minuteText = "00"] = String(value).split(":");
  const hour = Number(hourText);
  const minute = Number(minuteText);

  if (!Number.isFinite(hour) || !Number.isFinite(minute)) {
    return value;
  }

  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${String(minute).padStart(2, "0")} ${suffix}`;
}

function formatInstituteForToer(itiName) {
  return String(itiName || "")
    .replace("Govt: Industrial Training Institute", "GOVT ITI")
    .replace("panniyannore", "PANNIYANNORE")
    .trim();
}

function formatTradeForToer(tradeName) {
  const value = String(tradeName || "").trim().toUpperCase();
  if (value === "DCIVIL") {
    return "D/CIVIL";
  }
  return value;
}

function toNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function formatMark(value) {
  return String(clampWholeNumber(value, 0, 100));
}

function clampWholeNumber(value, min, max) {
  const rounded = Math.round(toNumber(value));
  return Math.max(min, Math.min(max, rounded));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#96;");
}

function applyPortalSharedData(payload) {
  if (!payload || typeof payload !== "object") {
    return;
  }

  syncCurrentOutcomeRecord();
  state.meta.assessor = String(payload.instructorName ?? state.meta.assessor ?? "");
  state.meta.yearEnrolment = formatAcademicSpanForAnnex(
    payload.session ?? payload.academicSpan ?? state.meta.yearEnrolment
  );
  state.meta.itiName = String(payload.itiName ?? payload.institution ?? state.meta.itiName ?? "");
  state.meta.tradeName = String(
    payload.tradeNameShort
    ?? payload.tradeShort
    ?? payload.annexTradeName
    ?? payload.tradeName
    ?? state.meta.tradeName
    ?? ""
  );
  state.meta.durationOfTrade = String(payload.durationOfCourse ?? state.meta.durationOfTrade ?? "");

  if (Array.isArray(payload.rosterEntries) && payload.rosterEntries.length) {
    Object.entries(state.outcomeRecords || {}).forEach(([key, record]) => {
      const mergedTrainees = buildPortalTrainees(payload.rosterEntries, record?.trainees);
      state.outcomeRecords[key] = normalizeOutcomeRecord(
        {
          ...record,
          trainees: mergedTrainees,
        },
        mergedTrainees,
        state.meta,
        record?.learningOutcome || findOutcomeOptionByKey(state.outcomeOptions, key)?.label,
      );
    });

    state.trainees = buildPortalTrainees(payload.rosterEntries, state.trainees);
  }

  const sharedToerFields = {
    trainerAddress:
      buildTrainerAddress(
        payload.instructorName ?? state.meta.assessor,
        payload.itiName ?? payload.institution ?? state.meta.itiName
      )
      || String(state.toer.trainerAddress || ""),
    unit: String(payload.unit ?? state.toer.unit ?? ""),
    shift: String(payload.shift ?? payload.shiftShort ?? payload.shiftLabel ?? state.toer.shift ?? ""),
  };

  if (payload.trainingYear !== undefined && payload.trainingYear !== null) {
    const trainingYear = String(payload.trainingYear || "").trim();
    if (trainingYear) {
      sharedToerFields.year = trainingYear;
    }
  }

  state.toer = normalizeToerState(
    {
      ...state.toer,
      ...sharedToerFields,
    },
    state.trainees,
    state.meta,
  );
  syncPortalManagedToerFieldsAcrossOutcomes(sharedToerFields);
  refreshPlannerOutcomeOptions({ persist: false });

  persistState();
  renderTabs();
  renderPanels();
  lockPortalManagedFields();
  syncAnnexScale();
  notifyPortalApplied();
}

function buildPortalTrainees(rosterEntries, existingTrainees = state.trainees) {
  const existingList = Array.isArray(existingTrainees) ? normalizeTrainees(existingTrainees) : [];
  const byAdmission = new Map(
    existingList
      .map((trainee) => [String(trainee.admNo || "").trim().toUpperCase(), trainee])
      .filter(([admNo]) => admNo),
  );

  const nextTrainees = rosterEntries.map((entry, index) => {
    const admissionKey = String(entry.admNo || "").trim().toUpperCase();
    const existing = (admissionKey && byAdmission.get(admissionKey)) || existingList[index];
    const total = existing ? getTraineeTotal(existing) : 0;
    const marks = Array.isArray(existing?.marks) ? existing.marks.slice() : splitTotalIntoComponents(total);

    return {
      admNo: entry.admNo || existing?.admNo || "",
      name: entry.name || existing?.name || `Trainee ${index + 1}`,
      fatherName: entry.fatherName || existing?.fatherName || "",
      marks,
      total,
      result: existing?.result || "Y",
    };
  });

  return normalizeTrainees(nextTrainees);
}

function formatAcademicSpanForAnnex(value) {
  return String(value || "")
    .trim()
    .replace(/\s*-\s*/g, " -")
    .replace(/\s+/g, " ");
}

function lockPortalManagedFields() {
  [
    "[data-meta-key='yearEnrolment']",
    "[data-meta-key='itiName']",
    "[data-meta-key='tradeName']",
    "[data-toer-key='unit']",
    "[data-toer-key='year']",
    "[data-toer-key='shift']",
  ].forEach((selector) => {
    document.querySelectorAll(selector).forEach((field) => {
      field.readOnly = true;
      field.title = "Managed from the Common Details tab";
    });
  });
}

function lockOutcomeManagedFields() {
  [
    "[data-meta-key='dateOfAssessment']",
    "[data-meta-key='learningOutcome']",
  ].forEach((selector) => {
    document.querySelectorAll(selector).forEach((field) => {
      if (marksPanel.contains(field)) {
        field.readOnly = false;
        field.title = "";
        return;
      }
      field.readOnly = true;
      field.title = "Edit from the Mark Entry tab";
    });
  });
}

function notifyPortalReady() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage({ type: "portal:ready", app: "annex" }, "*");
  reportPortalHeight();
}

function notifyPortalApplied() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:applied", app: "annex", height: getPortalHeight() },
    "*",
  );
}

function reportPortalHeight() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:height", app: "annex", height: getPortalHeight() },
    "*",
  );
}

function getPortalHeight() {
  const shell = document.querySelector(".app-shell");
  const bodyStyles = window.getComputedStyle(document.body);
  const bodyMargins =
    (Number.parseFloat(bodyStyles.marginTop) || 0)
    + (Number.parseFloat(bodyStyles.marginBottom) || 0);
  const contentHeight = shell
    ? Math.max(shell.scrollHeight || 0, shell.offsetHeight || 0)
    : Math.max(
      document.documentElement?.scrollHeight || 0,
      document.body?.scrollHeight || 0,
      document.documentElement?.offsetHeight || 0,
      document.body?.offsetHeight || 0,
    );

  return contentHeight + bodyMargins;
}

window.addEventListener("message", (event) => {
  if (event.data?.type !== "portal-shared-update" || event.data?.app !== "annex") {
    return;
  }

  applyPortalSharedData(event.data.payload);
});

window.addEventListener("load", () => {
  if (window.parent !== window) {
    lockPortalManagedFields();
    notifyPortalReady();
  }
});

window.addEventListener("storage", (event) => {
  if (
    event.key !== PLANNER_OUTCOME_STORAGE_KEY
    && !String(event.key || "").startsWith("program-of-coaching-entry-v")
  ) {
    return;
  }

  refreshPlannerOutcomeOptions({ persist: false });
  renderPanels();
});

window.addEventListener("resize", reportPortalHeight);

if (typeof ResizeObserver === "function") {
  const portalObserver = new ResizeObserver(() => {
    reportPortalHeight();
  });
  portalObserver.observe(document.querySelector(".app-shell") || document.body);
}
