const BASE_DATA = window.PROGRAM_DATA;
const LEGACY_DATA_ENTRY_STORAGE_KEY =
  `program-of-coaching-entry-v1::${BASE_DATA.meta.sourceWorkbook}::${BASE_DATA.meta.trade}::${BASE_DATA.meta.trainingYear}`;
const LEGACY_DATA_ENTRY_STORAGE_KEY_V2 =
  `program-of-coaching-entry-v2::${BASE_DATA.meta.sourceWorkbook}::${BASE_DATA.meta.trade}::${BASE_DATA.meta.trainingYear}`;
const DATA_ENTRY_STORAGE_KEY =
  `program-of-coaching-entry-v3::${BASE_DATA.meta.sourceWorkbook}::${BASE_DATA.meta.trade}::${BASE_DATA.meta.trainingYear}`;
const SHARED_OUTCOME_STORAGE_KEY = "iti-planner-outcome-index-v1";
const EMPTY_PLANNER_VALUES = Object.freeze({
  proposedDate: "",
  conductedDate: "",
  completed: false,
});
const PREVIEW_MONTHS = [
  ["AUGUST", "Aug"],
  ["SEPTEMBER", "Sep"],
  ["OCTOBER", "Oct"],
  ["NOVEMBER", "Nov"],
  ["DECEMBER", "Dec"],
  ["JANUARY", "Jan"],
  ["FEBRUARY", "Feb"],
  ["MARCH", "Mar"],
  ["APRIL", "Apl"],
  ["MAY", "May"],
  ["JUNE", "Jun"],
];
const PREVIEW_MONTH_INDEX = Object.fromEntries(PREVIEW_MONTHS.map(([key], index) => [key, index]));
const EMBEDDED_MODE = new URLSearchParams(window.location.search).get("embedded") === "1";
const SKILL_ENTRY_COLUMNS = [
  "sheet_row",
  "year",
  "month",
  "week",
  "outcome_no",
  "outcome_name",
  "row_type",
  "job_no",
  "job_name",
  "task_no",
  "task_name",
  "assessment_label",
];
const THEORY_ENTRY_COLUMNS = [
  "sheet_row",
  "year",
  "month",
  "week",
  "outcome_no",
  "outcome_name",
  "lesson_no",
  "lesson_name",
  "topic_no",
  "topic_name",
];

function createEmptyLinkedMonthlyPlan() {
  return {
    currentMonthValue: "",
    currentMonthKey: "",
    tradeValue: "",
    institution: "",
    tradeNameShort: "",
    session: "",
    shift: "",
    unit: "",
    months: {},
  };
}

let data = cloneProgramData(BASE_DATA);
let views = {
  skill: [],
  theory: [],
};
let skillAnticipatedMetrics = createEmptyMetricMap();
let theoryAnticipatedMetrics = createEmptyMetricMap();
let localIdCounter = 0;

const state = {
  activeTab: getInitialTab(),
  search: "",
  planner: loadPlannerState(),
  linkedMonthlyPlan: createEmptyLinkedMonthlyPlan(),
  monthTabs: {
    skill: "ALL",
    theory: "ALL",
  },
  outcomeFilters: {
    skill: "ALL",
    theory: "ALL",
  },
  expanded: {
    skill: {},
    theory: {},
  },
  dataEntry: loadDataEntryState(),
  dataEntryStatus: "",
  dataEntryStatusType: "",
};

const dom = {
  appShell: document.querySelector(".app-shell"),
  heroTitle: document.getElementById("heroTitle"),
  heroText: document.getElementById("heroText"),
  heroPanel: document.getElementById("heroPanel"),
  tabList: document.getElementById("tabList"),
  searchField: document.getElementById("searchField"),
  searchInput: document.getElementById("searchInput"),
  dataEntryPanel: document.getElementById("dataEntryPanel"),
  skillPanel: document.getElementById("skillPanel"),
  theoryPanel: document.getElementById("theoryPanel"),
  previewPanel: document.getElementById("previewPanel"),
  pageFoot: document.getElementById("pageFoot"),
};

initialize();

function getPlannerStorageKey(programData = data) {
  const meta = programData?.meta || BASE_DATA.meta;
  return `program-of-coaching-planner-v2::${meta.sourceWorkbook || BASE_DATA.meta.sourceWorkbook}::${meta.trade || BASE_DATA.meta.trade}::${meta.trainingYear || BASE_DATA.meta.trainingYear}`;
}

function getSharedPlannerDatasetKey(programData = data) {
  const meta = programData?.meta || BASE_DATA.meta;
  return `program-of-coaching-entry-v3::${meta.sourceWorkbook || BASE_DATA.meta.sourceWorkbook}::${meta.trade || BASE_DATA.meta.trade}::${meta.trainingYear || BASE_DATA.meta.trainingYear}`;
}

function updateSharedOutcomeIndex(programData = data) {
  try {
    const summary = buildPlannerOutcomeSummary(programData);
    if (!summary.outcomes.length) {
      return;
    }

    const raw = window.localStorage.getItem(SHARED_OUTCOME_STORAGE_KEY);
    const registry =
      raw && typeof raw === "string"
        ? JSON.parse(raw)
        : {};
    const datasets =
      registry && typeof registry === "object" && registry.datasets && typeof registry.datasets === "object"
        ? registry.datasets
        : {};

    window.localStorage.setItem(
      SHARED_OUTCOME_STORAGE_KEY,
      JSON.stringify({
        datasets: {
          ...datasets,
          [summary.key]: summary,
        },
        lastActiveKey: summary.key,
      }),
    );
  } catch {
    // Keep the planner usable even if shared outcome sync is blocked.
  }
}

function buildPlannerOutcomeSummary(programData = data) {
  const meta = programData?.meta || BASE_DATA.meta;
  const seenOutcomes = new Set();
  const outcomes = [];

  (programData?.skill?.entries || []).forEach((item) => {
    if (item?.isSpecial || item?.isAssessment) {
      return;
    }

    const outcomeNo = String(item?.outcomeNo || "").trim();
    const outcomeName = String(item?.outcomeName || "").trim();
    if (!outcomeNo || !outcomeName || seenOutcomes.has(outcomeNo)) {
      return;
    }

    seenOutcomes.add(outcomeNo);
    outcomes.push({
      outcomeNo,
      outcomeName,
    });
  });

  return {
    key: getSharedPlannerDatasetKey(programData),
    trade: String(meta.trade || ""),
    trainingYear: String(meta.trainingYear || ""),
    institution: String(meta.institution || ""),
    sourceWorkbook: String(meta.sourceWorkbook || ""),
    updatedAt: Date.now(),
    outcomes,
  };
}

function getInitialTab() {
  const requestedTab = new URLSearchParams(window.location.search).get("tab");
  return ["data-entry", "skill", "theory", "preview"].includes(requestedTab) ? requestedTab : "skill";
}

function initialize() {
  applyDataEntryState({ silent: true });
  applyEmbeddedMode();
  renderHero();
  renderTabs();
  renderDataEntryPanel();
  renderSkillPanel();
  renderTheoryPanel();
  renderPreviewPanel();
  updateActivePanel();
  bindEvents();
  renderFooter();
  window.requestAnimationFrame(reportPlannerHeight);
}

function bindEvents() {
  dom.searchInput.addEventListener("input", (event) => {
    state.search = event.target.value.trim().toLowerCase();
    renderAllPanels();
  });

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) {
      return;
    }

    const tabButton = target.closest("[data-tab]");
    if (tabButton instanceof HTMLButtonElement) {
      state.activeTab = tabButton.dataset.tab;
      renderTabs();
      updateActivePanel();
      return;
    }

    const monthTabButton = target.closest("[data-month-tab]");
    if (monthTabButton instanceof HTMLButtonElement) {
      const { scope, monthKey } = monthTabButton.dataset;
      if (!scope || !monthKey || !state.monthTabs[scope]) {
        return;
      }

      state.monthTabs[scope] = monthKey;
      syncOutcomeFilterWithMonth(scope);
      renderSection(scope);
      return;
    }

    const toggleButton = target.closest("[data-toggle-outcome]");
    if (toggleButton instanceof HTMLButtonElement) {
      const { scope, outcomeKey } = toggleButton.dataset;
      if (!scope || !outcomeKey || !state.expanded[scope]) {
        return;
      }

      state.expanded[scope][outcomeKey] = !state.expanded[scope][outcomeKey];
      renderSection(scope);
    }
  });

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof Element)) {
      return;
    }

    const actionButton = target.closest("[data-action]");
    if (!(actionButton instanceof HTMLButtonElement)) {
      return;
    }

    if (actionButton.dataset.action === "print-preview") {
      window.print();
      return;
    }

    if (actionButton.dataset.action === "apply-data-entry") {
      applyDataEntryFromDom();
      return;
    }

    if (actionButton.dataset.action === "reset-data-entry") {
      resetDataEntryToDefault();
      return;
    }

    handleDataEntryAction(actionButton);
  });

  document.addEventListener("input", (event) => {
    const target = event.target;
    if (
      (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) &&
      target.dataset.entryField
    ) {
      updateDataEntryField(target);
      return;
    }

    if (!(target instanceof HTMLInputElement) || !target.matches("input[data-plan-field]")) {
      return;
    }

    const { planScope, planKey, planField } = target.dataset;
    if (!planScope || !planKey || !planField) {
      return;
    }

    const value = target.type === "checkbox" ? target.checked : target.value;
    updatePlannerField(planScope, planKey, planField, value);
    renderSection(planScope);
    renderPreviewPanel();
  });

  document.addEventListener("change", (event) => {
    const target = event.target;
    if (target instanceof HTMLInputElement && target.matches("input[data-splitup-upload]")) {
      void handleSplitupWorkbookUpload(target);
      return;
    }

    if (target instanceof HTMLSelectElement && target.dataset.outcomeFilter) {
      const scope = target.dataset.outcomeFilter;
      if (!scope || !(scope in state.outcomeFilters)) {
        return;
      }

      state.outcomeFilters[scope] = target.value || "ALL";
      if (target.value && target.value !== "ALL") {
        state.expanded[scope][target.value] = true;
      }
      renderSection(scope);
      return;
    }

    if (
      (target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement) &&
      target.dataset.entryField
    ) {
      updateDataEntryField(target);
    }
  });

  window.addEventListener("message", (event) => {
    if (event.data?.type !== "monthly-plan-sync" || event.data?.app !== "program-planner") {
      return;
    }

    applyMonthlyPlanSync(event.data.payload);
  });
}

function renderHero() {
  const meta = data.meta;
  dom.heroTitle.textContent = `${meta.trade} | ${meta.trainingYear}`;
  dom.heroText.textContent =
    `View or upload the splitup workbook, then track proposed and conducted dates in the coaching tabs and Preview.`;

  const pills = [
    ["ITI", meta.institution],
    ["Session", meta.session],
    ["NSQF", meta.nsqfLevel],
    ["Skill jobs", String(data.skill.totals.jobs)],
    ["Theory topics", String(data.theory.totals.topics)],
  ];

  dom.heroPanel.innerHTML = pills
    .map(
      ([label, value]) => `
        <div class="meta-pill">
          <strong>${escapeHtml(label)}</strong>
          <span>${escapeHtml(value)}</span>
        </div>
      `,
    )
    .join("");
}

function renderTabs() {
  const tabs = [
    ["data-entry", "Split Up"],
    ["skill", "Professional Skill"],
    ["theory", "Professional Knowledge"],
    ["preview", "Preview"],
  ];

  dom.tabList.innerHTML = tabs
    .map(
      ([key, label]) => `
        <button
          class="tab-button ${state.activeTab === key ? "is-active" : ""}"
          type="button"
          role="tab"
          aria-selected="${state.activeTab === key ? "true" : "false"}"
          data-tab="${escapeHtml(key)}"
        >
          ${escapeHtml(label)}
        </button>
      `,
    )
    .join("");
}

function renderAllPanels() {
  renderDataEntryPanel();
  renderSkillPanel();
  renderTheoryPanel();
  renderPreviewPanel();
  reportPlannerHeight();
}

function renderSection(sectionKey) {
  if (sectionKey === "data-entry") {
    renderDataEntryPanel();
    return;
  }

  if (sectionKey === "skill") {
    renderSkillPanel();
    return;
  }

  if (sectionKey === "theory") {
    renderTheoryPanel();
  }
}

function renderDataEntryPanel() {
  const skillEntries = getOrderedWorkbookEntries(data.skill.entries);
  const theoryEntries = getOrderedWorkbookEntries(data.theory.entries);
  const sourceSheets = Array.isArray(data.meta.sourceSheets)
    ? data.meta.sourceSheets.filter(Boolean).join(" | ")
    : "";
  const statusMarkup = state.dataEntryStatus
    ? `<div class="entry-status ${getEntryStatusClassName(state.dataEntryStatusType)}">${escapeHtml(state.dataEntryStatus)}</div>`
    : "";

  dom.dataEntryPanel.innerHTML = `
    ${renderPanelIntro(
      "Split Up",
      "View the splitup in a simple read-only table. Upload a new Excel workbook and the planner will rebuild automatically from the skill and theory sheets.",
      `${data.skill.totals.tasks} skill tasks | ${data.theory.totals.topics} knowledge topics`,
    )}
    <div class="splitup-toolbar">
      <label class="splitup-file-field">
        <span>Upload Excel Splitup (.xlsx)</span>
        <input type="file" accept=".xlsx,.xlsm" data-splitup-upload>
      </label>
      <button class="tab-button" type="button" data-action="reset-data-entry">Use Built-in Splitup</button>
    </div>
    <p class="splitup-note">Upload the first-year or second-year splitup workbook in <code>.xlsx</code> or <code>.xlsm</code> format. The planner reads the Professional Skill and Professional Knowledge sheets automatically.</p>
    ${statusMarkup}
    <div class="splitup-summary-grid">
      ${renderSplitupSummaryCard("Workbook", data.meta.sourceWorkbook || "Built-in splitup", sourceSheets ? `Sheets: ${sourceSheets}` : "Bundled planner splitup")}
      ${renderSplitupSummaryCard("Trade", `${data.meta.trade} | ${data.meta.trainingYear}`, `${data.meta.institution} | Session ${data.meta.session}`)}
      ${renderSplitupSummaryCard(
        "Professional Skill",
        `${data.skill.totals.tasks} tasks`,
        `${data.skill.totals.assessments} assessments | ${countSpecialEntries(data.skill.entries)} special rows`,
      )}
      ${renderSplitupSummaryCard(
        "Professional Knowledge",
        `${data.theory.totals.topics} topics`,
        `${data.theory.totals.assessments} assessments | ${countSpecialEntries(data.theory.entries)} special rows`,
      )}
    </div>
    <div class="data-entry-stack">
      <section class="data-entry-card">
        <div class="data-entry-head">
          <div>
            <h3>Professional Skill Splitup</h3>
            <p>Read-only workbook view of tasks, assessments, and special rows in the order they appear in the Excel sheet.</p>
          </div>
          <div class="splitup-section-pill">${renderSplitupCountLabel(data.skill.entries, "skill")}</div>
        </div>
        ${renderWorkbookEntriesTable(skillEntries, "skill")}
      </section>
      <section class="data-entry-card">
        <div class="data-entry-head">
          <div>
            <h3>Professional Knowledge Splitup</h3>
            <p>Read-only workbook view of topics, assessments, and special rows in the order they appear in the Excel sheet.</p>
          </div>
          <div class="splitup-section-pill">${renderSplitupCountLabel(data.theory.entries, "theory")}</div>
        </div>
        ${renderWorkbookEntriesTable(theoryEntries, "theory")}
      </section>
    </div>
  `;
}

function renderSkillPanel() {
  const outcomes = getFilteredOutcomes("skill");
  dom.skillPanel.innerHTML = renderPlannerPanel({
    sectionKey: "skill",
    title: "Professional Skill",
    note:
      "Choose the month first, then pick a learning outcome from the dropdown to open only the jobs and assessment inside it.",
    rowsLabel: "jobs",
    rows: outcomes,
  });
}

function renderTheoryPanel() {
  const outcomes = getFilteredOutcomes("theory");
  dom.theoryPanel.innerHTML = renderPlannerPanel({
    sectionKey: "theory",
    title: "Professional Knowledge",
    note:
      "Choose the month first, then pick a learning outcome from the dropdown to open only the topics under it. Use dates and the check mark to track completion.",
    rowsLabel: "topics",
    rows: outcomes,
    extraContent: renderTheoryExamTracker(),
  });
}

function renderPlannerPanel({ sectionKey, title, note, rowsLabel, rows, extraContent = "" }) {
  const totals = getSectionStats(rows, sectionKey);
  const panelControls = renderPanelControls(sectionKey);

  if (!rows.length) {
    return `
      ${renderPanelIntro(title, note, `${totals.outcomes} outcomes`)}
      ${panelControls}
      <div class="empty-state">No matching learning outcomes were found for the current search.</div>
      ${extraContent}
    `;
  }

  return `
    ${renderPanelIntro(
      title,
      note,
      `${totals.completed}/${totals.total} ${escapeHtml(rowsLabel)} completed`,
    )}
    ${panelControls}
    <div class="accordion-list">
      ${rows.map((outcome) => renderOutcomeCard(outcome, sectionKey, rowsLabel)).join("")}
    </div>
    ${extraContent}
  `;
}

function renderPanelControls(sectionKey) {
  return `
    <div class="panel-controls">
      ${renderMonthTabs(sectionKey)}
      ${renderOutcomeFilterControl(sectionKey)}
    </div>
  `;
}

function renderPanelIntro(title, note, pill) {
  return `
    <div class="panel-intro">
      <div>
        <h2>${escapeHtml(title)}</h2>
        <p>${escapeHtml(note)}</p>
      </div>
      <div class="panel-pill">${escapeHtml(pill)}</div>
    </div>
  `;
}

function renderSplitupSummaryCard(label, value, note) {
  return `
    <article class="splitup-summary-card">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
      <small>${escapeHtml(note)}</small>
    </article>
  `;
}

function renderSplitupCountLabel(entries, mode) {
  const regularLabel = mode === "skill" ? "tasks" : "topics";
  const regularCount = entries.filter((entry) => !entry.isAssessment && !entry.isSpecial).length;
  const assessmentCount = entries.filter((entry) => entry.isAssessment).length;
  const specialCount = countSpecialEntries(entries);
  return `${regularCount} ${regularLabel} | ${assessmentCount} assessments${specialCount ? ` | ${specialCount} special` : ""}`;
}

function renderWorkbookEntriesTable(entries, mode) {
  if (!entries.length) {
    return '<div class="empty-state">No splitup rows were found for this section.</div>';
  }

  const middleHeading = mode === "skill" ? "Job / Assessment" : "Lesson / Assessment";
  const lastHeading = mode === "skill" ? "Task / Note" : "Topic / Note";

  return `
    <div class="preview-table-wrap splitup-table-wrap">
      <table class="preview-table splitup-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Year</th>
            <th>Month</th>
            <th>Week</th>
            <th>Type</th>
            <th>Outcome</th>
            <th>${escapeHtml(middleHeading)}</th>
            <th>${escapeHtml(lastHeading)}</th>
          </tr>
        </thead>
        <tbody>
          ${entries.map((entry, index) => renderWorkbookEntryRow(entry, index, mode)).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderWorkbookEntryRow(entry, index, mode) {
  const typeMeta = getWorkbookEntryTypeMeta(entry, mode);
  const outcomeMarkup = entry.isSpecial
    ? `<strong>Special row</strong><span>${escapeHtml(entry.specialLabel || "-")}</span>`
    : renderWorkbookCellMarkup(
        entry.outcomeNo ? `Outcome ${entry.outcomeNo}` : "",
        entry.outcomeName || entry.assessmentLabel || "-",
      );
  const sectionCode = mode === "skill" ? entry.jobNo : entry.lessonNo;
  const sectionLabel = mode === "skill" ? entry.jobName : entry.lessonName;
  const detailCode = mode === "skill" ? entry.taskNo : entry.topicNo;
  const detailLabel = mode === "skill" ? entry.taskName : entry.topicName;
  const sectionMarkup = entry.isAssessment || entry.isSpecial
    ? `<span class="splitup-empty">${entry.isAssessment ? "Assessment row" : "-"}</span>`
    : renderWorkbookCellMarkup(sectionCode, sectionLabel);
  const detailMarkup = entry.isAssessment
    ? `<strong>${escapeHtml(entry.assessmentLabel || "Assessment")}</strong><span>Outcome check / test row</span>`
    : entry.isSpecial
      ? `<strong>${escapeHtml(entry.specialLabel || "-")}</strong><span>Workbook note / special block</span>`
      : renderWorkbookCellMarkup(detailCode, detailLabel);

  return `
    <tr>
      <td>${index + 1}</td>
      <td>${escapeHtml(entry.year || "-")}</td>
      <td>${escapeHtml(entry.monthLabel || "-")}</td>
      <td>${escapeHtml(entry.weekLabel || "-")}</td>
      <td><span class="status-pill ${typeMeta.className}">${escapeHtml(typeMeta.label)}</span></td>
      <td>${outcomeMarkup}</td>
      <td>${sectionMarkup}</td>
      <td>${detailMarkup}</td>
    </tr>
  `;
}

function renderWorkbookCellMarkup(code, label) {
  const safeCode = String(code || "").trim();
  const safeLabel = String(label || "").trim();
  if (!safeCode && !safeLabel) {
    return '<span class="splitup-empty">-</span>';
  }

  if (!safeCode) {
    return `<span>${escapeHtml(safeLabel)}</span>`;
  }

  if (!safeLabel) {
    return `<strong>${escapeHtml(safeCode)}</strong>`;
  }

  return `<strong>${escapeHtml(safeCode)}</strong><span>${escapeHtml(safeLabel)}</span>`;
}

function getWorkbookEntryTypeMeta(entry, mode) {
  if (entry.isSpecial) {
    return { label: "Special", className: "is-neutral" };
  }

  if (entry.isAssessment) {
    return { label: "Assessment", className: "is-pending" };
  }

  return { label: mode === "skill" ? "Task" : "Topic", className: "is-done" };
}

function getOrderedWorkbookEntries(entries) {
  return [...(entries || [])].sort((left, right) => (left.sheetRow || 0) - (right.sheetRow || 0));
}

function countSpecialEntries(entries) {
  return (entries || []).filter((entry) => entry.isSpecial).length;
}

function getEntryStatusClassName(statusType) {
  if (statusType === "error") {
    return "is-error";
  }
  if (statusType === "info") {
    return "is-info";
  }
  return "is-success";
}

function renderSkillEntryGrid() {
  if (!state.dataEntry.skillRows.length) {
    return '<div class="empty-state">No professional skill rows added yet.</div>';
  }

  return `
    <div class="entry-grid-wrap">
      <table class="entry-grid entry-grid--skill">
        <thead>
          <tr>
            <th>#</th>
            <th>Year</th>
            <th>Month</th>
            <th>Week</th>
            <th>Outcome</th>
            <th>Outcome Name</th>
            <th>Job</th>
            <th>Job Name</th>
            <th>Task</th>
            <th>Task Name</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${state.dataEntry.skillRows.map((row, index) => renderSkillGridRow(row, index)).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderSkillAssessmentGrid() {
  if (!state.dataEntry.skillAssessments.length) {
    return '<div class="empty-state">No skill assessment rows added yet.</div>';
  }

  return `
    <div class="entry-grid-wrap">
      <table class="entry-grid entry-grid--assessment">
        <thead>
          <tr>
            <th>#</th>
            <th>Year</th>
            <th>Month</th>
            <th>Week</th>
            <th>Outcome</th>
            <th>Outcome Name</th>
            <th>Assessment Label</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${state.dataEntry.skillAssessments.map((row, index) => renderSkillAssessmentRow(row, index)).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderTheoryEntryGrid() {
  if (!state.dataEntry.theoryRows.length) {
    return '<div class="empty-state">No professional knowledge rows added yet.</div>';
  }

  return `
    <div class="entry-grid-wrap">
      <table class="entry-grid entry-grid--theory">
        <thead>
          <tr>
            <th>#</th>
            <th>Year</th>
            <th>Month</th>
            <th>Week</th>
            <th>Outcome</th>
            <th>Outcome Name</th>
            <th>Lesson</th>
            <th>Lesson Name</th>
            <th>Topic</th>
            <th>Topic Name</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${state.dataEntry.theoryRows.map((row, index) => renderTheoryGridRow(row, index)).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderSkillGridRow(row, index) {
  const schedule = getSchedulePickerMeta(row.monthKey, row.weekLabel, row.year);
  return `
    <tr>
      <td class="entry-grid-index">${index + 1}</td>
      <td>${escapeHtml(schedule.year)}</td>
      <td>${renderGridMonthSelect("skillRow", row.id, row.monthKey)}</td>
      <td>${renderGridWeekSlider("skillRow", row.id, schedule)}</td>
      <td>${renderGridTextInput("skillRow", row.id, "outcomeNo", row.outcomeNo, "1")}</td>
      <td>${renderGridTextInput("skillRow", row.id, "outcomeName", row.outcomeName, "Enter outcome name")}</td>
      <td>${renderGridTextInput("skillRow", row.id, "jobNo", row.jobNo, "1.1")}</td>
      <td>${renderGridTextInput("skillRow", row.id, "jobName", row.jobName, "Enter job name")}</td>
      <td>${renderGridTextInput("skillRow", row.id, "taskNo", row.taskNo, "1.1.1")}</td>
      <td>${renderGridTextInput("skillRow", row.id, "taskName", row.taskName, "Enter task name")}</td>
      <td class="entry-grid-action">
        <button class="tab-button builder-remove" type="button" data-action="remove-skill-row" data-row-id="${escapeHtml(row.id)}">Remove</button>
      </td>
    </tr>
  `;
}

function renderSkillAssessmentRow(row, index) {
  const schedule = getSchedulePickerMeta(row.monthKey, row.weekLabel, row.year);
  return `
    <tr>
      <td class="entry-grid-index">${index + 1}</td>
      <td>${escapeHtml(schedule.year)}</td>
      <td>${renderGridMonthSelect("skillAssessment", row.id, row.monthKey)}</td>
      <td>${renderGridWeekSlider("skillAssessment", row.id, schedule)}</td>
      <td>${renderGridTextInput("skillAssessment", row.id, "outcomeNo", row.outcomeNo, "1")}</td>
      <td>${renderGridTextInput("skillAssessment", row.id, "outcomeName", row.outcomeName, "Enter outcome name")}</td>
      <td>${renderGridTextInput("skillAssessment", row.id, "label", row.label, "Assessment for outcome")}</td>
      <td class="entry-grid-action">
        <button class="tab-button builder-remove" type="button" data-action="remove-skill-assessment" data-row-id="${escapeHtml(row.id)}">Remove</button>
      </td>
    </tr>
  `;
}

function renderTheoryGridRow(row, index) {
  const schedule = getSchedulePickerMeta(row.monthKey, row.weekLabel, row.year);
  return `
    <tr>
      <td class="entry-grid-index">${index + 1}</td>
      <td>${escapeHtml(schedule.year)}</td>
      <td>${renderGridMonthSelect("theoryRow", row.id, row.monthKey)}</td>
      <td>${renderGridWeekSlider("theoryRow", row.id, schedule)}</td>
      <td>${renderGridTextInput("theoryRow", row.id, "outcomeNo", row.outcomeNo, "1")}</td>
      <td>${renderGridTextInput("theoryRow", row.id, "outcomeName", row.outcomeName, "Enter outcome name")}</td>
      <td>${renderGridTextInput("theoryRow", row.id, "lessonNo", row.lessonNo, "1.1")}</td>
      <td>${renderGridTextInput("theoryRow", row.id, "lessonName", row.lessonName, "Enter lesson name")}</td>
      <td>${renderGridTextInput("theoryRow", row.id, "topicNo", row.topicNo, "1.1.1")}</td>
      <td>${renderGridTextInput("theoryRow", row.id, "topicName", row.topicName, "Enter topic name")}</td>
      <td class="entry-grid-action">
        <button class="tab-button builder-remove" type="button" data-action="remove-theory-row" data-row-id="${escapeHtml(row.id)}">Remove</button>
      </td>
    </tr>
  `;
}

function renderGridTextInput(entryField, rowId, field, value, placeholder) {
  return `
    <input
      class="grid-input"
      type="text"
      value="${escapeHtml(value || "")}"
      placeholder="${escapeHtml(placeholder || "")}"
      data-entry-field="${escapeHtml(entryField)}"
      data-row-id="${escapeHtml(rowId)}"
      data-field="${escapeHtml(field)}"
    >
  `;
}

function renderGridMonthSelect(entryField, rowId, value) {
  return `
    <select
      class="grid-select"
      data-entry-field="${escapeHtml(entryField)}"
      data-row-id="${escapeHtml(rowId)}"
      data-field="monthKey"
    >
      ${BASE_DATA.months
        .map(
          (month) => `
            <option value="${escapeHtml(month.key)}"${month.key === value ? " selected" : ""}>${escapeHtml(month.label)}</option>
          `,
        )
        .join("")}
    </select>
  `;
}

function renderGridWeekSlider(entryField, rowId, schedule) {
  return `
    <label class="week-slider-field">
      <input
        class="week-slider"
        type="range"
        min="1"
        max="${escapeHtml(String(schedule.weekCount))}"
        step="1"
        value="${escapeHtml(String(schedule.weekValue))}"
        data-entry-field="${escapeHtml(entryField)}"
        data-row-id="${escapeHtml(rowId)}"
        data-field="weekLabel"
      >
      <span>${escapeHtml(schedule.monthLabel)} | W${escapeHtml(String(schedule.weekValue))} of ${escapeHtml(String(schedule.weekCount))}</span>
    </label>
  `;
}

function renderSkillOutcomeBuilder(outcome, index) {
  return `
    <article class="builder-card">
      <div class="builder-card-head">
        <div>
          <div class="builder-eyebrow">Professional Skill Outcome ${index + 1}</div>
          <h4>Learning Outcome ${escapeHtml(outcome.outcomeNo || String(index + 1))}</h4>
        </div>
        <button
          class="tab-button builder-remove"
          type="button"
          data-action="remove-skill-outcome"
          data-outcome-id="${escapeHtml(outcome.id)}"
        >
          Remove Outcome
        </button>
      </div>
      <div class="builder-field-grid builder-field-grid--two">
        ${renderBuilderInput("Outcome No.", "text", outcome.outcomeNo, {
          entryField: "skillOutcome",
          outcomeId: outcome.id,
          field: "outcomeNo",
          placeholder: "16",
        })}
        ${renderBuilderInput("Outcome Name", "text", outcome.outcomeName, {
          entryField: "skillOutcome",
          outcomeId: outcome.id,
          field: "outcomeName",
          placeholder: "Enter the learning outcome name",
        })}
      </div>
      <div class="builder-subsection">
        <div class="builder-subhead">
          <h5>Jobs and Tasks</h5>
          <button class="tab-button" type="button" data-action="add-skill-job" data-outcome-id="${escapeHtml(outcome.id)}">Add Job</button>
        </div>
        <div class="builder-stack">
          ${outcome.jobs.length
            ? outcome.jobs.map((job, jobIndex) => renderSkillJobBuilder(outcome, job, jobIndex)).join("")
            : '<div class="empty-state">No jobs added yet.</div>'}
        </div>
      </div>
      <div class="builder-subsection builder-subsection--soft">
        <div class="builder-subhead">
          <h5>Assessment</h5>
          <p>One assessment row is used for this learning outcome in the preview.</p>
        </div>
        <div class="builder-field-grid builder-field-grid--four">
          ${renderBuilderInput("Assessment Label", "text", outcome.assessment.label, {
            entryField: "skillAssessment",
            outcomeId: outcome.id,
            field: "label",
            placeholder: `Assessment for Outcome ${outcome.outcomeNo || index + 1}`,
          })}
          ${renderBuilderInput("Year", "text", outcome.assessment.year, {
            entryField: "skillAssessment",
            outcomeId: outcome.id,
            field: "year",
            placeholder: "1st Year",
          })}
          ${renderBuilderMonthSelect("Month", outcome.assessment.monthKey, {
            entryField: "skillAssessment",
            outcomeId: outcome.id,
            field: "monthKey",
          })}
          ${renderBuilderInput("Week", "text", outcome.assessment.weekLabel, {
            entryField: "skillAssessment",
            outcomeId: outcome.id,
            field: "weekLabel",
            placeholder: "1 or W1",
          })}
        </div>
      </div>
    </article>
  `;
}

function renderSkillJobBuilder(outcome, job, index) {
  return `
    <section class="nested-builder-card">
      <div class="builder-card-head builder-card-head--nested">
        <div>
          <div class="builder-eyebrow">Job ${index + 1}</div>
          <h5>${escapeHtml(job.jobNo || `Job ${index + 1}`)}</h5>
        </div>
        <button
          class="tab-button builder-remove"
          type="button"
          data-action="remove-skill-job"
          data-outcome-id="${escapeHtml(outcome.id)}"
          data-job-id="${escapeHtml(job.id)}"
        >
          Remove Job
        </button>
      </div>
      <div class="builder-field-grid builder-field-grid--two">
        ${renderBuilderInput("Job No.", "text", job.jobNo, {
          entryField: "skillJob",
          outcomeId: outcome.id,
          jobId: job.id,
          field: "jobNo",
          placeholder: "16.1",
        })}
        ${renderBuilderInput("Job Name", "text", job.jobName, {
          entryField: "skillJob",
          outcomeId: outcome.id,
          jobId: job.id,
          field: "jobName",
          placeholder: "Enter job name",
        })}
      </div>
      <div class="builder-subsection">
        <div class="builder-subhead">
          <h6>Tasks</h6>
          <button class="tab-button" type="button" data-action="add-skill-task" data-outcome-id="${escapeHtml(outcome.id)}" data-job-id="${escapeHtml(job.id)}">Add Task</button>
        </div>
        <div class="builder-list">
          ${job.tasks.length
            ? job.tasks.map((task, taskIndex) => renderSkillTaskBuilder(outcome, job, task, taskIndex)).join("")
            : '<div class="empty-state">No tasks added yet.</div>'}
        </div>
      </div>
      <div class="builder-subsection">
        <div class="builder-subhead">
          <h6>Planned Range</h6>
          <p>Select which task span belongs to one month and week.</p>
          <button class="tab-button" type="button" data-action="add-skill-plan" data-outcome-id="${escapeHtml(outcome.id)}" data-job-id="${escapeHtml(job.id)}">Add Planned Range</button>
        </div>
        <div class="builder-stack">
          ${job.plans.length
            ? job.plans.map((plan, planIndex) => renderSkillPlanBuilder(outcome, job, plan, planIndex)).join("")
            : '<div class="empty-state">No planned range added yet.</div>'}
        </div>
      </div>
    </section>
  `;
}

function renderSkillTaskBuilder(outcome, job, task, index) {
  return `
    <div class="builder-inline-row">
      ${renderBuilderInput(`Task ${index + 1} No.`, "text", task.taskNo, {
        entryField: "skillTask",
        outcomeId: outcome.id,
        jobId: job.id,
        taskId: task.id,
        field: "taskNo",
        placeholder: "16.1.1",
      })}
      ${renderBuilderInput(`Task ${index + 1} Name`, "text", task.taskName, {
        entryField: "skillTask",
        outcomeId: outcome.id,
        jobId: job.id,
        taskId: task.id,
        field: "taskName",
        placeholder: "Enter task name",
      })}
      <div class="builder-row-action">
        <button
          class="tab-button builder-remove"
          type="button"
          data-action="remove-skill-task"
          data-outcome-id="${escapeHtml(outcome.id)}"
          data-job-id="${escapeHtml(job.id)}"
          data-task-id="${escapeHtml(task.id)}"
        >
          Remove
        </button>
      </div>
    </div>
  `;
}

function renderSkillPlanBuilder(outcome, job, plan, index) {
  return `
    <div class="plan-card">
      <div class="builder-card-head builder-card-head--nested">
        <div>
          <div class="builder-eyebrow">Range ${index + 1}</div>
          <h6>${escapeHtml(job.jobNo || "Job")} plan</h6>
        </div>
        <button
          class="tab-button builder-remove"
          type="button"
          data-action="remove-skill-plan"
          data-outcome-id="${escapeHtml(outcome.id)}"
          data-job-id="${escapeHtml(job.id)}"
          data-plan-id="${escapeHtml(plan.id)}"
        >
          Remove Range
        </button>
      </div>
      <div class="builder-field-grid builder-field-grid--five">
        ${renderBuilderInput("Year", "text", plan.year, {
          entryField: "skillPlan",
          outcomeId: outcome.id,
          jobId: job.id,
          planId: plan.id,
          field: "year",
          placeholder: "1st Year",
        })}
        ${renderBuilderMonthSelect("Month", plan.monthKey, {
          entryField: "skillPlan",
          outcomeId: outcome.id,
          jobId: job.id,
          planId: plan.id,
          field: "monthKey",
        })}
        ${renderBuilderInput("Week", "text", plan.weekLabel, {
          entryField: "skillPlan",
          outcomeId: outcome.id,
          jobId: job.id,
          planId: plan.id,
          field: "weekLabel",
          placeholder: "1 or W1",
        })}
        ${renderBuilderOptionSelect("From Task", plan.fromTaskId, job.tasks, "taskNo", "taskName", {
          entryField: "skillPlan",
          outcomeId: outcome.id,
          jobId: job.id,
          planId: plan.id,
          field: "fromTaskId",
          placeholder: "Select task",
        })}
        ${renderBuilderOptionSelect("To Task", plan.toTaskId, job.tasks, "taskNo", "taskName", {
          entryField: "skillPlan",
          outcomeId: outcome.id,
          jobId: job.id,
          planId: plan.id,
          field: "toTaskId",
          placeholder: "Select task",
        })}
      </div>
    </div>
  `;
}

function renderTheoryOutcomeBuilder(outcome, index) {
  return `
    <article class="builder-card">
      <div class="builder-card-head">
        <div>
          <div class="builder-eyebrow">Professional Knowledge Outcome ${index + 1}</div>
          <h4>Learning Outcome ${escapeHtml(outcome.outcomeNo || String(index + 1))}</h4>
        </div>
        <button
          class="tab-button builder-remove"
          type="button"
          data-action="remove-theory-outcome"
          data-outcome-id="${escapeHtml(outcome.id)}"
        >
          Remove Outcome
        </button>
      </div>
      <div class="builder-field-grid builder-field-grid--two">
        ${renderBuilderInput("Outcome No.", "text", outcome.outcomeNo, {
          entryField: "theoryOutcome",
          outcomeId: outcome.id,
          field: "outcomeNo",
          placeholder: "17",
        })}
        ${renderBuilderInput("Outcome Name", "text", outcome.outcomeName, {
          entryField: "theoryOutcome",
          outcomeId: outcome.id,
          field: "outcomeName",
          placeholder: "Enter the learning outcome name",
        })}
      </div>
      <div class="builder-subsection">
        <div class="builder-subhead">
          <h5>Lessons and Topics</h5>
          <button class="tab-button" type="button" data-action="add-theory-lesson" data-outcome-id="${escapeHtml(outcome.id)}">Add Lesson</button>
        </div>
        <div class="builder-stack">
          ${outcome.lessons.length
            ? outcome.lessons.map((lesson, lessonIndex) => renderTheoryLessonBuilder(outcome, lesson, lessonIndex)).join("")
            : '<div class="empty-state">No lessons added yet.</div>'}
        </div>
      </div>
    </article>
  `;
}

function renderTheoryLessonBuilder(outcome, lesson, index) {
  return `
    <section class="nested-builder-card">
      <div class="builder-card-head builder-card-head--nested">
        <div>
          <div class="builder-eyebrow">Lesson ${index + 1}</div>
          <h5>${escapeHtml(lesson.lessonNo || `Lesson ${index + 1}`)}</h5>
        </div>
        <button
          class="tab-button builder-remove"
          type="button"
          data-action="remove-theory-lesson"
          data-outcome-id="${escapeHtml(outcome.id)}"
          data-lesson-id="${escapeHtml(lesson.id)}"
        >
          Remove Lesson
        </button>
      </div>
      <div class="builder-field-grid builder-field-grid--two">
        ${renderBuilderInput("Lesson No.", "text", lesson.lessonNo, {
          entryField: "theoryLesson",
          outcomeId: outcome.id,
          lessonId: lesson.id,
          field: "lessonNo",
          placeholder: "17.1",
        })}
        ${renderBuilderInput("Lesson Name", "text", lesson.lessonName, {
          entryField: "theoryLesson",
          outcomeId: outcome.id,
          lessonId: lesson.id,
          field: "lessonName",
          placeholder: "Enter lesson name",
        })}
      </div>
      <div class="builder-subsection">
        <div class="builder-subhead">
          <h6>Topics</h6>
          <button class="tab-button" type="button" data-action="add-theory-topic" data-outcome-id="${escapeHtml(outcome.id)}" data-lesson-id="${escapeHtml(lesson.id)}">Add Topic</button>
        </div>
        <div class="builder-list">
          ${lesson.topics.length
            ? lesson.topics.map((topic, topicIndex) => renderTheoryTopicBuilder(outcome, lesson, topic, topicIndex)).join("")
            : '<div class="empty-state">No topics added yet.</div>'}
        </div>
      </div>
      <div class="builder-subsection">
        <div class="builder-subhead">
          <h6>Planned Range</h6>
          <p>Select which topic span belongs to one month and week.</p>
          <button class="tab-button" type="button" data-action="add-theory-plan" data-outcome-id="${escapeHtml(outcome.id)}" data-lesson-id="${escapeHtml(lesson.id)}">Add Planned Range</button>
        </div>
        <div class="builder-stack">
          ${lesson.plans.length
            ? lesson.plans.map((plan, planIndex) => renderTheoryPlanBuilder(outcome, lesson, plan, planIndex)).join("")
            : '<div class="empty-state">No planned range added yet.</div>'}
        </div>
      </div>
    </section>
  `;
}

function renderTheoryTopicBuilder(outcome, lesson, topic, index) {
  return `
    <div class="builder-inline-row">
      ${renderBuilderInput(`Topic ${index + 1} No.`, "text", topic.topicNo, {
        entryField: "theoryTopic",
        outcomeId: outcome.id,
        lessonId: lesson.id,
        topicId: topic.id,
        field: "topicNo",
        placeholder: "17.1.1",
      })}
      ${renderBuilderInput(`Topic ${index + 1} Name`, "text", topic.topicName, {
        entryField: "theoryTopic",
        outcomeId: outcome.id,
        lessonId: lesson.id,
        topicId: topic.id,
        field: "topicName",
        placeholder: "Enter topic name",
      })}
      <div class="builder-row-action">
        <button
          class="tab-button builder-remove"
          type="button"
          data-action="remove-theory-topic"
          data-outcome-id="${escapeHtml(outcome.id)}"
          data-lesson-id="${escapeHtml(lesson.id)}"
          data-topic-id="${escapeHtml(topic.id)}"
        >
          Remove
        </button>
      </div>
    </div>
  `;
}

function renderTheoryPlanBuilder(outcome, lesson, plan, index) {
  return `
    <div class="plan-card">
      <div class="builder-card-head builder-card-head--nested">
        <div>
          <div class="builder-eyebrow">Range ${index + 1}</div>
          <h6>${escapeHtml(lesson.lessonNo || "Lesson")} plan</h6>
        </div>
        <button
          class="tab-button builder-remove"
          type="button"
          data-action="remove-theory-plan"
          data-outcome-id="${escapeHtml(outcome.id)}"
          data-lesson-id="${escapeHtml(lesson.id)}"
          data-plan-id="${escapeHtml(plan.id)}"
        >
          Remove Range
        </button>
      </div>
      <div class="builder-field-grid builder-field-grid--five">
        ${renderBuilderInput("Year", "text", plan.year, {
          entryField: "theoryPlan",
          outcomeId: outcome.id,
          lessonId: lesson.id,
          planId: plan.id,
          field: "year",
          placeholder: "1st Year",
        })}
        ${renderBuilderMonthSelect("Month", plan.monthKey, {
          entryField: "theoryPlan",
          outcomeId: outcome.id,
          lessonId: lesson.id,
          planId: plan.id,
          field: "monthKey",
        })}
        ${renderBuilderInput("Week", "text", plan.weekLabel, {
          entryField: "theoryPlan",
          outcomeId: outcome.id,
          lessonId: lesson.id,
          planId: plan.id,
          field: "weekLabel",
          placeholder: "1 or W1",
        })}
        ${renderBuilderOptionSelect("From Topic", plan.fromTopicId, lesson.topics, "topicNo", "topicName", {
          entryField: "theoryPlan",
          outcomeId: outcome.id,
          lessonId: lesson.id,
          planId: plan.id,
          field: "fromTopicId",
          placeholder: "Select topic",
        })}
        ${renderBuilderOptionSelect("To Topic", plan.toTopicId, lesson.topics, "topicNo", "topicName", {
          entryField: "theoryPlan",
          outcomeId: outcome.id,
          lessonId: lesson.id,
          planId: plan.id,
          field: "toTopicId",
          placeholder: "Select topic",
        })}
      </div>
    </div>
  `;
}

function renderBuilderInput(label, type, value, dataset) {
  return `
    <label class="builder-field">
      <span>${escapeHtml(label)}</span>
      <input
        type="${escapeHtml(type)}"
        value="${escapeHtml(value || "")}"
        ${renderBuilderDataset(dataset)}
        ${dataset.placeholder ? `placeholder="${escapeHtml(dataset.placeholder)}"` : ""}
      >
    </label>
  `;
}

function renderBuilderMonthSelect(label, value, dataset) {
  return `
    <label class="builder-field">
      <span>${escapeHtml(label)}</span>
      <select ${renderBuilderDataset(dataset)}>
        <option value="">Select month</option>
        ${BASE_DATA.months
          .map(
            (month) => `
              <option value="${escapeHtml(month.key)}"${value === month.key ? " selected" : ""}>
                ${escapeHtml(month.label)}
              </option>
            `,
          )
          .join("")}
      </select>
    </label>
  `;
}

function renderBuilderOptionSelect(label, value, options, codeKey, nameKey, dataset) {
  return `
    <label class="builder-field">
      <span>${escapeHtml(label)}</span>
      <select ${renderBuilderDataset(dataset)}>
        <option value="">${escapeHtml(dataset.placeholder || "Select")}</option>
        ${options
          .map(
            (option) => `
              <option value="${escapeHtml(option.id)}"${value === option.id ? " selected" : ""}>
                ${escapeHtml([option[codeKey], option[nameKey]].filter(Boolean).join(" | "))}
              </option>
            `,
          )
          .join("")}
      </select>
    </label>
  `;
}

function renderBuilderDataset(dataset) {
  return Object.entries(dataset)
    .filter(([key, value]) => key !== "placeholder" && value !== undefined && value !== null && value !== "")
    .map(([key, value]) => `data-${toKebabCase(key)}="${escapeHtml(String(value))}"`)
    .join(" ");
}

function renderMonthTabs(sectionKey) {
  const activeMonth = state.monthTabs[sectionKey];
  const tabs = [["ALL", "All Months"], ...PREVIEW_MONTHS];

  return `
    <div class="month-subtabs" aria-label="${escapeHtml(sectionKey)} month tabs">
      ${tabs
        .map(
          ([monthKey, label]) => `
            <button
              class="month-subtab ${activeMonth === monthKey ? "is-active" : ""}"
              type="button"
              data-month-tab="true"
              data-scope="${escapeHtml(sectionKey)}"
              data-month-key="${escapeHtml(monthKey)}"
            >
              ${escapeHtml(label === "All Months" ? label : label)}
            </button>
          `,
        )
        .join("")}
    </div>
  `;
}

function renderOutcomeFilterControl(sectionKey) {
  const activeValue = state.outcomeFilters[sectionKey] || "ALL";
  const options = getOutcomeFilterOptions(sectionKey);

  return `
    <label class="outcome-filter">
      <span>Learning Outcome</span>
      <select data-outcome-filter="${escapeHtml(sectionKey)}">
        <option value="ALL"${activeValue === "ALL" ? " selected" : ""}>All Learning Outcomes</option>
        ${options
          .map(
            (option) => `
              <option value="${escapeHtml(option.key)}"${activeValue === option.key ? " selected" : ""}>
                ${escapeHtml(`LO ${option.no} - ${option.name}`)}
              </option>
            `,
          )
          .join("")}
      </select>
    </label>
  `;
}

function renderOutcomeCard(outcome, sectionKey, rowsLabel) {
  const statRows = sectionKey === "skill" ? outcome.jobRows : outcome.rows;
  const completedCount = statRows.filter((row) => getPlannerValues(sectionKey, row.planKey).completed).length;
  const isSelectedOutcome = state.outcomeFilters[sectionKey] === outcome.key;
  const isOpen = isSelectedOutcome || Boolean(state.expanded[sectionKey]?.[outcome.key]);
  const cardClasses = [
    "outcome-card",
    isOpen ? "is-open" : "",
    statRows.length > 0 && completedCount === statRows.length ? "is-complete" : "",
  ]
    .filter(Boolean)
    .join(" ");

  return `
    <article class="${cardClasses}">
      <button
        class="outcome-toggle"
        type="button"
        data-toggle-outcome="true"
        data-scope="${escapeHtml(sectionKey)}"
        data-outcome-key="${escapeHtml(outcome.key)}"
      >
        <div class="outcome-main">
          <div class="outcome-label">Outcome ${escapeHtml(outcome.no)}</div>
          <div class="outcome-title">${escapeHtml(outcome.name)}</div>
          <div class="outcome-stats">
            ${escapeHtml(String(statRows.length))} ${escapeHtml(rowsLabel)} | ${escapeHtml(
              String(completedCount),
            )} completed
          </div>
        </div>
        <div class="outcome-arrow">&rsaquo;</div>
      </button>
      <div class="outcome-body">
        <div class="entry-list">
          ${outcome.rows.map((row) => renderEntryRow(row, sectionKey)).join("")}
        </div>
      </div>
    </article>
  `;
}

function renderEntryRow(row, sectionKey) {
  const planner = getPlannerValues(sectionKey, row.planKey);
  const effectiveProposedDate = getEffectiveProposedDate(sectionKey, row);
  const linkedProposedDate = getLinkedProposedDate(sectionKey, row);
  const effectiveConductedDate = getEffectiveConductedDate(sectionKey, row);
  const linkedConductedDate = getLinkedConductedDate(sectionKey, row);
  const isLinkedProposedDate = Boolean(linkedProposedDate);
  const isLinkedConductedDate = Boolean(linkedConductedDate);
  const completedClass = planner.completed ? "is-complete" : "";
  const secondaryLine =
    sectionKey === "skill"
      ? row.kind === "assessment"
        ? `Assessment | ${row.scheduleLabel}`
        : `${row.scheduleLabel} | ${row.taskCount} task${row.taskCount === 1 ? "" : "s"}`
      : `${row.lessonLabel} | ${row.scheduleLabel}`;

  return `
    <div class="entry-row ${completedClass}">
      <div class="entry-main">
        <div class="entry-topline">
          <span class="entry-code">${escapeHtml(row.code)}</span>
          <span class="status-pill ${planner.completed ? "is-done" : "is-pending"}">
            ${planner.completed ? "Completed" : "Pending"}
          </span>
        </div>
        <div class="entry-title">${escapeHtml(row.title)}</div>
        <div class="entry-subline">${escapeHtml(secondaryLine)}</div>
      </div>
      <div class="entry-controls">
        <label class="mini-field ${isLinkedProposedDate ? "is-linked" : ""}">
          <span>Proposed date</span>
          ${isLinkedProposedDate ? '<span class="mini-hint">From Monthly Plan</span>' : ""}
          <input
            type="date"
            value="${escapeHtml(effectiveProposedDate)}"
            data-plan-scope="${escapeHtml(sectionKey)}"
            data-plan-key="${escapeHtml(row.planKey)}"
            data-plan-field="proposedDate"
            ${isLinkedProposedDate ? 'readonly aria-readonly="true" title="Taken from the Monthly Plan tab"' : ""}
          >
        </label>
        <label class="mini-field ${isLinkedConductedDate ? "is-linked" : ""}">
          <span>Conducted date</span>
          ${isLinkedConductedDate ? '<span class="mini-hint">From Diary</span>' : ""}
          <input
            type="date"
            value="${escapeHtml(effectiveConductedDate)}"
            data-plan-scope="${escapeHtml(sectionKey)}"
            data-plan-key="${escapeHtml(row.planKey)}"
            data-plan-field="conductedDate"
            ${isLinkedConductedDate ? 'readonly aria-readonly="true" title="Taken from the Diary tab"' : ""}
          >
        </label>
        <label class="check-field">
          <input
            type="checkbox"
            ${planner.completed ? "checked" : ""}
            data-plan-scope="${escapeHtml(sectionKey)}"
            data-plan-key="${escapeHtml(row.planKey)}"
            data-plan-field="completed"
          >
          <span>Done</span>
        </label>
      </div>
    </div>
  `;
}

function renderTheoryExamTracker() {
  const examRows = getTheoryMonthlyExamRows();
  if (!examRows.length) {
    return `
      <section class="exam-block">
        <div class="exam-block-head">
          <h3>Monthly Assessment</h3>
          <p>No theory exam is planned for the selected month.</p>
        </div>
      </section>
    `;
  }

  return `
    <section class="exam-block">
      <div class="exam-block-head">
        <h3>Monthly Assessment</h3>
        <p>Use one exam tracker for each month in professional knowledge.</p>
      </div>
      <div class="entry-list">
        ${examRows.map((row) => renderEntryRow(row, "theory")).join("")}
      </div>
    </section>
  `;
}

function getTheoryMonthlyExamRows() {
  const activeMonth = state.monthTabs.theory;
  const allowedMonths = activeMonth === "ALL" ? getTheoryExamMonthKeys() : [activeMonth];

  return allowedMonths
    .filter((monthKey) => theoryAnticipatedMetrics[monthKey]?.assessments)
    .map((monthKey) => {
      const monthLabel = PREVIEW_MONTHS.find(([key]) => key === monthKey)?.[1] || monthKey;
      return {
        planKey: getTheoryExamPlanKey(monthKey),
        code: `${monthLabel.toUpperCase()} EXAM`,
        title: `Professional Knowledge monthly assessment for ${monthLabel}`,
        lessonLabel: "Monthly assessment",
        scheduleLabel: monthLabel,
      };
    });
}

function renderPreviewPanel() {
  const skillProgressMetrics = buildSkillProgressMetrics();
  const theoryProgressMetrics = buildTheoryProgressMetrics();

  dom.previewPanel.innerHTML = `
    <div class="preview-actions">
      <div class="preview-print-note">A4 landscape print layout for both preview sheets</div>
      <button class="print-button" type="button" data-action="print-preview">Print All Preview Sheets</button>
    </div>
    <div class="program-sheet-shell">
      ${renderSkillPreviewSheet(skillProgressMetrics)}
      ${renderTheoryPreviewSheet(theoryProgressMetrics)}
    </div>
  `;
}

function getPreviewMetaFields() {
  return {
    institution: String(state.linkedMonthlyPlan.institution || data.meta.institution || "").trim(),
    tradeNameShort: String(state.linkedMonthlyPlan.tradeNameShort || data.meta.trade || "").trim(),
    session: String(state.linkedMonthlyPlan.session || data.meta.session || "").trim(),
    shift: String(state.linkedMonthlyPlan.shift || data.meta.shift || "").trim(),
    unit: String(state.linkedMonthlyPlan.unit || data.meta.unit || data.meta.trainingYear || "").trim(),
  };
}

function renderSkillPreviewSheet(progressMetrics) {
  const previewMeta = getPreviewMetaFields();
  return `
    <div class="program-sheet-paper">
      <div class="program-sheet-code">NSF11</div>
      <table class="program-table" aria-label="Programme of Coaching - Professional Skill">
        <colgroup>
          <col class="program-col-parameter">
          ${PREVIEW_MONTHS.map(() => '<col class="program-col-month">').join("")}
        </colgroup>
        <tbody>
          <tr>
            <th class="program-main-title" colspan="12">INDUSTRIAL TRAINING DEPARTMENT . KERALA</th>
          </tr>
          <tr>
            <th class="program-subtitle" colspan="12">PROGRAMME OF COACHING - PROFESSIONAL SKILL</th>
          </tr>
          <tr>
            <th class="program-meta-label">Name of I.T.I :</th>
            <td class="program-meta-value" colspan="8">${escapeHtml(previewMeta.institution)}</td>
            <th class="program-meta-label program-meta-label--side">Trade</th>
            <td class="program-meta-value" colspan="2">${escapeHtml(previewMeta.tradeNameShort)}</td>
          </tr>
          <tr>
            <th class="program-meta-label">Session :</th>
            <td class="program-meta-value" colspan="3">${escapeHtml(previewMeta.session)}</td>
            <th class="program-meta-label program-meta-label--side">Shift :</th>
            <td class="program-meta-value" colspan="4">${escapeHtml(previewMeta.shift)}</td>
            <th class="program-meta-label program-meta-label--side">Unit</th>
            <td class="program-meta-value" colspan="2">${escapeHtml(previewMeta.unit)}</td>
          </tr>
          <tr>
            <th class="program-header-label">Parameters</th>
            ${PREVIEW_MONTHS.map(([, label]) => `<th class="program-month-head">${escapeHtml(label)}</th>`).join("")}
          </tr>
          ${renderProgramSection("A) ANTICIPATED", [
            renderProgramValueRow("i) No. of Learning Outcome", skillAnticipatedMetrics, "outcomes"),
            renderProgramValueRow("ii) No. of Jobs", skillAnticipatedMetrics, "jobs"),
            renderProgramValueRow("iii) No. of Tasks", skillAnticipatedMetrics, "tasks"),
          ])}
          ${renderProgramSection("B) BALANCE CARRY OVER FROM PREVIOUS MONTH", [
            renderProgramValueRow("i) No. of Learning Outcome", progressMetrics.carried, "outcomes"),
            renderProgramValueRow("ii) No. of Jobs", progressMetrics.carried, "jobs"),
            renderProgramValueRow("iii) No. of Tasks", progressMetrics.carried, "tasks"),
          ])}
          ${renderProgramSection("C) Total (a + b)", [
            renderProgramValueRow("i) No. of Learning Outcome", progressMetrics.total, "outcomes"),
            renderProgramValueRow("ii) No. of Jobs", progressMetrics.total, "jobs"),
            renderProgramValueRow("iii) No. of Tasks", progressMetrics.total, "tasks"),
          ])}
          ${renderProgramSection("D) ACHIEVED", [
            renderProgramValueRow("i) No. of Learning Outcome", progressMetrics.achieved, "outcomes"),
            renderProgramValueRow("ii) No. of Jobs", progressMetrics.achieved, "jobs"),
            renderProgramValueRow("iii) No. of Tasks", progressMetrics.achieved, "tasks"),
          ])}
          ${renderProgramSection("E) BALANCE TO CARRY OVER TO NEXT MONTH", [
            renderProgramValueRow("i) No. of Learning Outcome", progressMetrics.balance, "outcomes"),
            renderProgramValueRow("ii) No. of Jobs", progressMetrics.balance, "jobs"),
            renderProgramValueRow("iii) No. of Tasks", progressMetrics.balance, "tasks"),
          ])}
          ${renderProgramSection("ASSESSMENTS", [
            renderProgramValueRow("a) Anticipated", skillAnticipatedMetrics, "assessments"),
            renderProgramValueRow("b)Balance carry over from previous month", progressMetrics.carried, "assessments"),
            renderProgramValueRow("c) Total (a+b)", progressMetrics.total, "assessments"),
            renderProgramValueRow("d) Achieved Assessments", progressMetrics.achieved, "assessments"),
            renderProgramValueRow("e) Balance if any ( c -d)", progressMetrics.balance, "assessments"),
          ])}
        </tbody>
      </table>
      ${renderProgramSheetFoot()}
    </div>
  `;
}

function renderTheoryPreviewSheet(progressMetrics) {
  const previewMeta = getPreviewMetaFields();
  return `
    <div class="program-sheet-paper">
      <div class="program-sheet-code">NSF12</div>
      <table class="program-table" aria-label="Programme of Coaching - Professional Knowledge">
        <colgroup>
          <col class="program-col-parameter">
          ${PREVIEW_MONTHS.map(() => '<col class="program-col-month">').join("")}
        </colgroup>
        <tbody>
          <tr>
            <th class="program-main-title" colspan="12">INDUSTRIAL TRAINING DEPARTMENT . KERALA</th>
          </tr>
          <tr>
            <th class="program-subtitle" colspan="12">PROGRAMME OF COACHING</th>
          </tr>
          <tr>
            <th class="program-meta-label">Name of I.T.I:</th>
            <td class="program-meta-value" colspan="8">${escapeHtml(previewMeta.institution)}</td>
            <th class="program-meta-label program-meta-label--side">Trade:</th>
            <td class="program-meta-value" colspan="2">${escapeHtml(previewMeta.tradeNameShort)}</td>
          </tr>
          <tr>
            <th class="program-meta-label">Session:</th>
            <td class="program-meta-value" colspan="4">${escapeHtml(previewMeta.session)}</td>
            <th class="program-meta-label program-meta-label--side">Shift:</th>
            <td class="program-meta-value" colspan="3">${escapeHtml(previewMeta.shift)}</td>
            <th class="program-meta-label program-meta-label--side">Unit:</th>
            <td class="program-meta-value" colspan="2">${escapeHtml(previewMeta.unit)}</td>
          </tr>
          <tr>
            <th class="program-header-label">Parameters</th>
            ${PREVIEW_MONTHS.map(([, label]) => `<th class="program-month-head">${escapeHtml(label)}</th>`).join("")}
          </tr>
          ${renderProgramBannerRow("I. Professional Knowledge", "program-subsection-head")}
          ${renderProgramValueRow("a) Anticipated Lessons", theoryAnticipatedMetrics, "lessons", "program-row-accent")}
          ${renderProgramValueRow("b)Balance carry over from previous month", progressMetrics.carried, "lessons")}
          ${renderProgramValueRow("c) Total (a + b)", progressMetrics.total, "lessons")}
          ${renderProgramValueRow("d) Achieved Lessons", progressMetrics.achieved, "lessons")}
          ${renderProgramValueRow("e) Balance if any ( c - d)", progressMetrics.balance, "lessons")}
          ${renderProgramValueRow("g) Anticipated Tests/Assessments", theoryAnticipatedMetrics, "assessments", "program-row-accent")}
          ${renderProgramValueRow("h)Balance carry over from previous month", progressMetrics.carried, "assessments")}
          ${renderProgramValueRow("i) Total (g + h)", progressMetrics.total, "assessments")}
          ${renderProgramValueRow("j) Achieved Tests/Assessments", progressMetrics.achieved, "assessments")}
          ${renderProgramValueRow("k) Balance if any (i - j)", progressMetrics.balance, "assessments")}
        </tbody>
      </table>
      ${renderProgramSheetFoot()}
    </div>
  `;
}

function renderProgramSheetFoot() {
  return `
    <div class="program-signatures">
      <div class="program-signature-label">PRINCIPAL/VP</div>
      <div class="program-signature-label">GROUP INSTRUCTOR</div>
      <div class="program-signature-label">SECTION INSTRUCTOR</div>
    </div>
    <div class="program-note">NB : This document should be displayed in workshop</div>
    <div class="program-suiit-row">
      <span class="program-suiit-line"></span>
      <span class="program-suiit-label">SUIIT</span>
      <span class="program-suiit-line"></span>
    </div>
  `;
}

function updateActivePanel() {
  const panels = {
    "data-entry": dom.dataEntryPanel,
    skill: dom.skillPanel,
    theory: dom.theoryPanel,
    preview: dom.previewPanel,
  };

  Object.entries(panels).forEach(([key, panel]) => {
    if (key === state.activeTab) {
      panel.classList.remove("is-hidden");
    } else {
      panel.classList.add("is-hidden");
    }
  });

  updateToolbarState();
  reportPlannerHeight();
}

function updateToolbarState() {
  if (!dom.searchField) {
    return;
  }

  dom.searchField.classList.toggle("is-hidden", !["skill", "theory"].includes(state.activeTab));
}

function renderFooter() {
  dom.pageFoot.textContent =
    `Source workbook: ${data.meta.sourceWorkbook} | Sheets used: ${data.meta.sourceSheets.join(", ")} | ` +
    `Entries save in this browser for ${data.meta.trade}.`;
}

function handleDataEntryAction(button) {
  const action = button.dataset.action;
  switch (action) {
    case "add-skill-row":
      state.dataEntry.skillRows.push(createSkillEntryRow());
      break;
    case "remove-skill-row":
      state.dataEntry.skillRows = state.dataEntry.skillRows.filter((row) => row.id !== button.dataset.rowId);
      break;
    case "add-skill-assessment":
      state.dataEntry.skillAssessments.push(createSkillAssessmentRow());
      break;
    case "remove-skill-assessment":
      state.dataEntry.skillAssessments = state.dataEntry.skillAssessments.filter((row) => row.id !== button.dataset.rowId);
      break;
    case "add-theory-row":
      state.dataEntry.theoryRows.push(createTheoryEntryRow());
      break;
    case "remove-theory-row":
      state.dataEntry.theoryRows = state.dataEntry.theoryRows.filter((row) => row.id !== button.dataset.rowId);
      break;
    default:
      return;
  }

  state.dataEntryStatus = "";
  state.dataEntryStatusType = "";
  saveDataEntryState();
  renderDataEntryPanel();
  reportPlannerHeight();
}

function updateDataEntryField(target) {
  const value = target.value;

  const rowId = target.dataset.rowId;
  const field = target.dataset.field;
  if (!rowId || !field) {
    return;
  }

  const collection = getDataEntryCollection(target.dataset.entryField);
  if (!collection) {
    return;
  }

  const row = collection.find((item) => item.id === rowId);
  if (!row) {
    return;
  }

  row[field] = field === "weekLabel" ? String(Math.max(1, Number.parseInt(value, 10) || 1)) : value;
  normalizeScheduleRow(row);

  state.dataEntryStatus = "";
  state.dataEntryStatusType = "";
  saveDataEntryState();

  if (target instanceof HTMLSelectElement && field === "monthKey") {
    renderDataEntryPanel();
    reportPlannerHeight();
    return;
  }

  if (target instanceof HTMLInputElement && target.type === "range") {
    syncWeekSliderDisplay(target, row);
  }
}

function findSkillOutcome(outcomeId) {
  return state.dataEntry.skillOutcomes.find((outcome) => outcome.id === outcomeId) || null;
}

function findSkillJob(outcomeId, jobId) {
  return findSkillOutcome(outcomeId)?.jobs.find((job) => job.id === jobId) || null;
}

function findSkillTask(outcomeId, jobId, taskId) {
  return findSkillJob(outcomeId, jobId)?.tasks.find((task) => task.id === taskId) || null;
}

function findSkillPlan(outcomeId, jobId, planId) {
  return findSkillJob(outcomeId, jobId)?.plans.find((plan) => plan.id === planId) || null;
}

function findTheoryOutcome(outcomeId) {
  return state.dataEntry.theoryOutcomes.find((outcome) => outcome.id === outcomeId) || null;
}

function findTheoryLesson(outcomeId, lessonId) {
  return findTheoryOutcome(outcomeId)?.lessons.find((lesson) => lesson.id === lessonId) || null;
}

function findTheoryTopic(outcomeId, lessonId, topicId) {
  return findTheoryLesson(outcomeId, lessonId)?.topics.find((topic) => topic.id === topicId) || null;
}

function findTheoryPlan(outcomeId, lessonId, planId) {
  return findTheoryLesson(outcomeId, lessonId)?.plans.find((plan) => plan.id === planId) || null;
}

async function handleSplitupWorkbookUpload(input) {
  const file = input.files?.[0];
  if (!file) {
    return;
  }

  state.dataEntryStatus = `Reading ${file.name}...`;
  state.dataEntryStatusType = "info";
  renderDataEntryPanel();
  updateActivePanel();

  try {
    const importedProgramData = await parseSplitupWorkbookFile(file);
    state.dataEntry = createDataEntryStateFromProgramData(importedProgramData);
    applyDataEntryState({
      successMessage: `${file.name} imported successfully.`,
    });
  } catch (error) {
    state.dataEntryStatus = error instanceof Error ? error.message : "Could not read the workbook.";
    state.dataEntryStatusType = "error";
    renderDataEntryPanel();
    updateActivePanel();
  } finally {
    input.value = "";
  }
}

function loadDataEntryState() {
  const fallback = createDefaultDataEntryState(BASE_DATA);

  try {
    const rawValue = window.localStorage.getItem(DATA_ENTRY_STORAGE_KEY);
    if (rawValue) {
      return normalizeDataEntryState(JSON.parse(rawValue), fallback);
    }

    const legacyV2 = window.localStorage.getItem(LEGACY_DATA_ENTRY_STORAGE_KEY_V2);
    if (legacyV2) {
      return migrateLegacyDataEntryState(JSON.parse(legacyV2), fallback);
    }

    const legacyV1 = window.localStorage.getItem(LEGACY_DATA_ENTRY_STORAGE_KEY);
    if (legacyV1) {
      return migrateLegacyDataEntryState(JSON.parse(legacyV1), fallback);
    }

    return fallback;
  } catch {
    try {
      const legacyV2 = window.localStorage.getItem(LEGACY_DATA_ENTRY_STORAGE_KEY_V2);
      if (legacyV2) {
        return migrateLegacyDataEntryState(JSON.parse(legacyV2), fallback);
      }
      const legacyV1 = window.localStorage.getItem(LEGACY_DATA_ENTRY_STORAGE_KEY);
      if (legacyV1) {
        return migrateLegacyDataEntryState(JSON.parse(legacyV1), fallback);
      }
    } catch {
      return fallback;
    }

    return fallback;
  }
}

function saveDataEntryState() {
  try {
    window.localStorage.setItem(DATA_ENTRY_STORAGE_KEY, JSON.stringify(state.dataEntry));
  } catch {
    // Keep working even if the browser blocks persistence.
  }
}

function createDefaultDataEntryState(programData = BASE_DATA) {
  return createDataEntryStateFromProgramData(programData);
}

function applyDataEntryFromDom() {
  applyDataEntryState();
}

function resetDataEntryToDefault() {
  state.dataEntry = createDefaultDataEntryState(BASE_DATA);
  saveDataEntryState();
  applyDataEntryState({ successMessage: "Default workbook rows restored." });
}

function applyDataEntryState({
  silent = false,
  rerender = true,
  persist = true,
  successMessage = "Data entry applied to the planner.",
} = {}) {
  try {
    const nextData = cloneProgramData(buildProgramDataFromEntryState(state.dataEntry));
    if (getPlannerStorageKey(nextData) !== getPlannerStorageKey(data)) {
      state.planner = loadPlannerState(nextData);
    }
    data = nextData;
    refreshDerivedData();
    updateSharedOutcomeIndex(nextData);

    if (persist) {
      saveDataEntryState();
    }

    if (!silent) {
      state.dataEntryStatus = successMessage;
      state.dataEntryStatusType = "success";
    }

    if (rerender) {
      renderHero();
      renderTabs();
      renderAllPanels();
      updateActivePanel();
      renderFooter();
    }
  } catch (error) {
    if (silent) {
      state.dataEntry = createDefaultDataEntryState(BASE_DATA);
      data = cloneProgramData(BASE_DATA);
      refreshDerivedData();
      return;
    }

    state.dataEntryStatus = error instanceof Error ? error.message : "Could not apply data entry.";
    state.dataEntryStatusType = "error";
    renderDataEntryPanel();
    updateActivePanel();
  }
}

function refreshDerivedData() {
  views = {
    skill: buildSkillOutcomes(),
    theory: buildTheoryOutcomes(),
  };
  skillAnticipatedMetrics = buildSkillAnticipatedMetrics();
  theoryAnticipatedMetrics = buildTheoryAnticipatedMetrics();
  ensureOutcomeFiltersAreValid();
  state.expanded.skill = createDefaultExpandedState("skill");
  state.expanded.theory = createDefaultExpandedState("theory");
}

function ensureOutcomeFiltersAreValid() {
  ["skill", "theory"].forEach((sectionKey) => {
    const validKeys = new Set(views[sectionKey].map((outcome) => outcome.key));
    if (!validKeys.has(state.outcomeFilters[sectionKey])) {
      state.outcomeFilters[sectionKey] = "ALL";
    }
    syncOutcomeFilterWithMonth(sectionKey);
  });
}

function normalizeDataEntryState(value, fallback = createDefaultDataEntryState(BASE_DATA)) {
  if (!value || typeof value !== "object") {
    return fallback;
  }

  if (value.programData && typeof value.programData === "object") {
    return createDataEntryStateFromProgramData(value.programData);
  }

  if (
    Array.isArray(value.skillRows) &&
    Array.isArray(value.skillAssessments) &&
    Array.isArray(value.theoryRows)
  ) {
    try {
      return createDataEntryStateFromProgramData(buildProgramDataFromLegacyEntryState(value));
    } catch {
      return fallback;
    }
  }

  if (Array.isArray(value.skillOutcomes) && Array.isArray(value.theoryOutcomes)) {
    return migrateLegacyDataEntryState(value, fallback);
  }

  if (typeof value.skillText === "string" || typeof value.theoryText === "string") {
    return migrateLegacyDataEntryState(value, fallback);
  }

  return fallback;
}

function migrateLegacyDataEntryState(value, fallback = createDefaultDataEntryState(BASE_DATA)) {
  try {
    if (Array.isArray(value?.skillOutcomes) && Array.isArray(value?.theoryOutcomes)) {
      return normalizeDataEntryState(flattenNestedDataEntryState(value), fallback);
    }

    const skillText =
      typeof value?.skillText === "string" ? value.skillText : serializeSkillEntries(BASE_DATA.skill.entries);
    const theoryText =
      typeof value?.theoryText === "string" ? value.theoryText : serializeTheoryEntries(BASE_DATA.theory.entries);
    const migratedProgramData = buildProgramDataFromEntryTexts(skillText, theoryText);
    return buildDataEntryStateFromProgramData(migratedProgramData);
  } catch {
    return fallback;
  }
}

function buildSkillOutcomes() {
  const outcomes = new Map();

  data.skill.entries
    .filter((item) => !item.isSpecial && item.outcomeNo)
    .forEach((item) => {
      let outcome = outcomes.get(item.outcomeNo);
      if (!outcome) {
        outcome = {
          key: item.outcomeNo,
          no: item.outcomeNo,
          name: item.outcomeName,
          rowsMap: new Map(),
          assessmentItem: null,
        };
        outcomes.set(item.outcomeNo, outcome);
      }

      const schedulePoint = {
        monthLabel: item.monthLabel,
        weekLabel: item.weekLabel,
        sheetRow: item.sheetRow,
      };

      if (item.isAssessment) {
        outcome.assessmentItem = {
          planKey: getSkillAssessmentPlanKey(item),
          code: "ASMT",
          title: item.assessmentLabel || `Assessment for Outcome No. ${item.outcomeNo}`,
          kind: "assessment",
          schedulePoints: [schedulePoint],
          firstSheetRow: item.sheetRow,
        };
        return;
      }

      if (!item.jobNo) {
        return;
      }

      let row = outcome.rowsMap.get(item.jobNo);
      if (!row) {
        row = {
          planKey: getSkillPlanKey(item),
          code: item.jobNo,
          linkedCode: item.jobNo,
          title: item.jobName,
          kind: "job",
          taskCodes: new Set(),
          schedulePoints: [],
        };
        outcome.rowsMap.set(item.jobNo, row);
      }

      if (item.taskNo) {
        row.taskCodes.add(item.taskNo);
      }
      row.schedulePoints.push(schedulePoint);
    });

  return [...outcomes.values()].map((outcome) => ({
    key: outcome.key,
    no: outcome.no,
    name: outcome.name,
    jobRows: [...outcome.rowsMap.values()]
      .map((row) => ({
        planKey: row.planKey,
        code: row.code,
        title: row.title,
        kind: row.kind,
        taskCount: row.taskCodes.size,
        scheduleLabel: getScheduleLabel(row.schedulePoints),
        monthKeys: getMonthKeysFromPoints(row.schedulePoints),
        monthSortRows: getMonthSortRows(row.schedulePoints),
        endMonthKey: getLatestMonthKey(getMonthKeysFromPoints(row.schedulePoints)),
        firstSheetRow: Math.min(...row.schedulePoints.map((point) => point.sheetRow)),
      }))
      .sort((left, right) => left.firstSheetRow - right.firstSheetRow),
    assessmentRow: outcome.assessmentItem
      ? {
          planKey: outcome.assessmentItem.planKey,
          code: outcome.assessmentItem.code,
          linkedCode: outcome.no,
          title: outcome.assessmentItem.title,
          kind: "assessment",
          taskCount: 0,
          scheduleLabel: getScheduleLabel(outcome.assessmentItem.schedulePoints),
          monthKeys: getMonthKeysFromPoints(outcome.assessmentItem.schedulePoints),
          monthSortRows: getMonthSortRows(outcome.assessmentItem.schedulePoints),
          endMonthKey: getLatestMonthKey(getMonthKeysFromPoints(outcome.assessmentItem.schedulePoints)),
          firstSheetRow: outcome.assessmentItem.firstSheetRow,
        }
      : null,
  })).map((outcome) => ({
    ...outcome,
    rows: [...outcome.jobRows, ...(outcome.assessmentRow ? [outcome.assessmentRow] : [])].sort(
      (left, right) => left.firstSheetRow - right.firstSheetRow,
    ),
  }));
}

function buildTheoryOutcomes() {
  const outcomes = new Map();

  data.theory.entries
    .filter((item) => !item.isAssessment && !item.isSpecial && item.outcomeNo && item.topicNo)
    .forEach((item) => {
      let outcome = outcomes.get(item.outcomeNo);
      if (!outcome) {
        outcome = {
          key: item.outcomeNo,
          no: item.outcomeNo,
          name: item.outcomeName,
          rows: [],
        };
        outcomes.set(item.outcomeNo, outcome);
      }

      outcome.rows.push({
        planKey: getTheoryPlanKey(item),
        code: item.topicNo,
        linkedCode: item.topicNo,
        title: item.topicName,
        lessonLabel: `${item.lessonNo} | ${item.lessonName}`,
        scheduleLabel: getScheduleLabel([
          {
            monthLabel: item.monthLabel,
            weekLabel: item.weekLabel,
            sheetRow: item.sheetRow,
          },
        ]),
        monthKeys: [item.monthKey],
        monthSortRows: { [item.monthKey]: item.sheetRow },
        firstSheetRow: item.sheetRow,
      });
    });

  return [...outcomes.values()].map((outcome) => ({
    ...outcome,
    rows: outcome.rows.sort((left, right) => left.firstSheetRow - right.firstSheetRow),
  }));
}

function getFilteredOutcomes(sectionKey) {
  const source = views[sectionKey];
  const monthKey = state.monthTabs[sectionKey];
  const selectedOutcomeKey = state.outcomeFilters[sectionKey] || "ALL";

  return source
    .filter((outcome) => selectedOutcomeKey === "ALL" || outcome.key === selectedOutcomeKey)
    .map((outcome) => filterOutcome(outcome, sectionKey, monthKey))
    .filter(Boolean)
    .sort((left, right) => compareOutcomes(left, right, monthKey));
}

function filterOutcome(outcome, sectionKey, monthKey) {
  const monthFilteredRows =
    monthKey === "ALL" ? outcome.rows : outcome.rows.filter((row) => row.monthKeys.includes(monthKey));
  if (!monthFilteredRows.length) {
    return null;
  }

  const outcomeMatches = matchesSearch([outcome.no, outcome.name]);
  if (outcomeMatches) {
    return {
      ...outcome,
      rows: monthFilteredRows,
      jobRows: monthFilteredRows.filter((row) => row.kind !== "assessment"),
      sortRow: getOutcomeSortRow(monthFilteredRows, monthKey),
    };
  }

  const filteredRows = monthFilteredRows.filter((row) => rowMatchesSearch(outcome, row, sectionKey));
  if (!filteredRows.length) {
    return null;
  }

  return {
    ...outcome,
    rows: filteredRows,
    jobRows: filteredRows.filter((row) => row.kind !== "assessment"),
    sortRow: getOutcomeSortRow(filteredRows, monthKey),
  };
}

function rowMatchesSearch(outcome, row, sectionKey) {
  const planner = getPlannerValues(sectionKey, row.planKey);
  const proposedDate = getEffectiveProposedDate(sectionKey, row);
  const conductedDate = getEffectiveConductedDate(sectionKey, row);
  const values =
    sectionKey === "skill"
      ? [
          outcome.no,
          outcome.name,
          row.code,
          row.title,
          row.kind,
          row.scheduleLabel,
          row.kind === "assessment" ? "assessment" : row.taskCount,
          proposedDate,
          conductedDate,
          planner.completed ? "completed" : "pending",
        ]
      : [
          outcome.no,
          outcome.name,
          row.code,
          row.title,
          row.lessonLabel,
          row.scheduleLabel,
          proposedDate,
          conductedDate,
          planner.completed ? "completed" : "pending",
        ];

  return matchesSearch(values);
}

function matchesSearch(values) {
  if (!state.search) {
    return true;
  }

  return values.join(" ").toLowerCase().includes(state.search);
}

function getSectionStats(outcomes, sectionKey) {
  const rows =
    sectionKey === "skill"
      ? outcomes.flatMap((outcome) => outcome.jobRows)
      : outcomes.flatMap((outcome) => outcome.rows);
  const completed = rows.filter((row) => getPlannerValues(sectionKey, row.planKey).completed).length;
  return {
    outcomes: outcomes.length,
    total: rows.length,
    completed,
  };
}

function compareOutcomes(left, right, monthKey) {
  const leftSort = left.sortRow ?? getOutcomeSortRow(left.rows, monthKey);
  const rightSort = right.sortRow ?? getOutcomeSortRow(right.rows, monthKey);
  if (leftSort !== rightSort) {
    return leftSort - rightSort;
  }

  return compareOutcomeNumbers(left.no, right.no);
}

function getOutcomeSortRow(rows, monthKey) {
  const relevantRows =
    monthKey === "ALL"
      ? rows
      : rows.filter((row) => row.monthKeys.includes(monthKey));

  return Math.min(...relevantRows.map((row) => row.monthSortRows[monthKey] ?? row.firstSheetRow));
}

function compareOutcomeNumbers(left, right) {
  return Number.parseFloat(left) - Number.parseFloat(right);
}

function getOutcomeFilterOptions(sectionKey) {
  const monthKey = state.monthTabs[sectionKey];

  return views[sectionKey]
    .filter((outcome) => monthKey === "ALL" || outcome.rows.some((row) => row.monthKeys.includes(monthKey)))
    .sort((left, right) => compareOutcomes(left, right, monthKey))
    .map((outcome) => ({
      key: outcome.key,
      no: outcome.no,
      name: outcome.name,
    }));
}

function syncOutcomeFilterWithMonth(sectionKey) {
  const currentSelection = state.outcomeFilters[sectionKey];
  if (currentSelection === "ALL") {
    return;
  }

  const validKeys = new Set(getOutcomeFilterOptions(sectionKey).map((option) => option.key));
  if (!validKeys.has(currentSelection)) {
    state.outcomeFilters[sectionKey] = "ALL";
  }
}

function createDefaultExpandedState(sectionKey) {
  const firstOutcome = views[sectionKey][0];
  if (!firstOutcome) {
    return {};
  }

  return {
    [firstOutcome.key]: true,
  };
}

function loadPlannerState(programData = data) {
  try {
    const rawValue = window.localStorage.getItem(getPlannerStorageKey(programData));
    if (!rawValue) {
      return { skill: {}, theory: {} };
    }

    return normalizePlannerState(JSON.parse(rawValue));
  } catch (error) {
    return { skill: {}, theory: {} };
  }
}

function normalizePlannerState(value) {
  const next = { skill: {}, theory: {} };
  if (!value || typeof value !== "object") {
    return next;
  }

  ["skill", "theory"].forEach((sectionKey) => {
    const section = value[sectionKey];
    if (!section || typeof section !== "object") {
      return;
    }

    Object.entries(section).forEach(([planKey, fields]) => {
      if (!fields || typeof fields !== "object") {
        return;
      }

      next[sectionKey][planKey] = {
        proposedDate: String(fields.proposedDate || ""),
        conductedDate: String(fields.conductedDate || ""),
        completed: Boolean(fields.completed),
      };
    });
  });

  return next;
}

function savePlannerState() {
  try {
    window.localStorage.setItem(getPlannerStorageKey(data), JSON.stringify(state.planner));
  } catch (error) {
    // Keep the page usable even if persistence is unavailable.
  }
}

function updatePlannerField(sectionKey, planKey, field, value) {
  if (!state.planner[sectionKey]) {
    state.planner[sectionKey] = {};
  }

  const current = state.planner[sectionKey][planKey] || {
    proposedDate: "",
    conductedDate: "",
    completed: false,
  };
  const next = {
    ...current,
    [field]: value,
  };

  if (!next.proposedDate && !next.conductedDate && !next.completed) {
    delete state.planner[sectionKey][planKey];
  } else {
    state.planner[sectionKey][planKey] = next;
  }

  savePlannerState();
}

function getPlannerValues(sectionKey, planKey) {
  if (!planKey) {
    return EMPTY_PLANNER_VALUES;
  }

  return state.planner[sectionKey]?.[planKey] || EMPTY_PLANNER_VALUES;
}

function getEffectiveProposedDate(sectionKey, row) {
  return getLinkedProposedDate(sectionKey, row) || getPlannerValues(sectionKey, row.planKey).proposedDate;
}

function getLinkedProposedDate(sectionKey, row) {
  return getLinkedDate("proposed", sectionKey, row);
}

function getEffectiveConductedDate(sectionKey, row) {
  return getLinkedConductedDate(sectionKey, row) || getPlannerValues(sectionKey, row.planKey).conductedDate;
}

function getLinkedConductedDate(sectionKey, row) {
  return getLinkedDate("conducted", sectionKey, row);
}

function getLinkedDate(kind, sectionKey, row) {
  const linkedCode = getLinkedCodeForRow(row);
  if (!linkedCode) {
    return "";
  }

  const linkedMonths = Object.values(state.linkedMonthlyPlan.months || {});
  if (!linkedMonths.length) {
    return "";
  }

  const activeMonth = state.monthTabs[sectionKey];
  const scopedMonths = activeMonth === "ALL"
    ? linkedMonths
    : linkedMonths.filter((month) => month.monthKey === activeMonth);
  const linkedDate = getLinkedDateFromMonthCollection(scopedMonths, sectionKey, row, linkedCode, kind);

  if (linkedDate) {
    return linkedDate;
  }

  const currentMonthKey = state.linkedMonthlyPlan.currentMonthKey;
  if (currentMonthKey && currentMonthKey !== activeMonth) {
    const currentMonthDate = getLinkedDateFromMonthCollection(
      linkedMonths.filter((month) => month.monthKey === currentMonthKey),
      sectionKey,
      row,
      linkedCode,
      kind,
    );
    if (currentMonthDate) {
      return currentMonthDate;
    }
  }

  return getLinkedDateFromMonthCollection(linkedMonths, sectionKey, row, linkedCode, kind);
}

function getLinkedDateFromMonthCollection(months, sectionKey, row, linkedCode, kind) {
  const dates = months
    .map((month) => getLinkedDateFromMonth(month, sectionKey, row, linkedCode, kind))
    .filter(Boolean)
    .sort();

  return dates[0] || "";
}

function getLinkedDateFromMonth(month, sectionKey, row, linkedCode, kind) {
  const dateBucket = kind === "conducted" ? month?.conductedDates : month?.proposedDates;
  if (!dateBucket || typeof dateBucket !== "object") {
    return "";
  }

  if (sectionKey === "skill") {
    if (row.kind === "assessment") {
      return kind === "proposed" ? dateBucket.skillAssessments?.[linkedCode] || "" : "";
    }
    return dateBucket.skill?.[linkedCode] || "";
  }

  if (String(row.planKey || "").startsWith("theory-exam::")) {
    return "";
  }

  return dateBucket.theory?.[linkedCode] || "";
}

function getLinkedCodeForRow(row) {
  return String(row?.linkedCode ?? row?.code ?? "").trim();
}

function buildSkillAnticipatedMetrics() {
  const metrics = createEmptyMetricMap();

  data.skill.entries
    .filter((item) => !item.isSpecial)
    .forEach((item) => {
      if (item.isAssessment && metrics[item.monthKey]) {
        metrics[item.monthKey].assessments += 1;
        return;
      }

      if (metrics[item.monthKey]) {
        metrics[item.monthKey].tasks += 1;
      }
    });

  const outcomeEndMonth = new Map();
  const jobEndMonth = new Map();

  data.skill.entries
    .filter((item) => !item.isAssessment && !item.isSpecial && item.monthKey in metrics)
    .forEach((item) => {
      updateLatestMonth(outcomeEndMonth, item.outcomeNo, item.monthKey);
      updateLatestMonth(jobEndMonth, `${item.outcomeNo}::${item.jobNo}`, item.monthKey);
    });

  outcomeEndMonth.forEach((monthKey) => {
    metrics[monthKey].outcomes += 1;
  });
  jobEndMonth.forEach((monthKey) => {
    metrics[monthKey].jobs += 1;
  });

  return metrics;
}

function buildSkillAchievedMetrics() {
  return buildSkillProgressMetrics().achieved;
}

function buildSkillProgressMetrics() {
  const carried = createEmptyMetricMap();
  const total = createEmptyMetricMap();
  const achieved = createEmptyMetricMap();
  const balance = createEmptyMetricMap();

  const jobFlow = buildMonthlyFlow(
    views.skill.flatMap((outcome) =>
      outcome.jobRows.map((row) => ({
        dueMonthKey: row.endMonthKey,
        completedMonthKey: getCompletedMonthForPlanKey("skill", row.planKey),
        weight: 1,
      })),
    ),
  );

  const outcomeFlow = buildMonthlyFlow(
    views.skill.map((outcome) => ({
      dueMonthKey: getLatestMonthKey(outcome.jobRows.map((row) => row.endMonthKey)),
      completedMonthKey: getOutcomeCompletedMonthKey(outcome.jobRows),
      weight: 1,
    })),
  );

  const taskFlow = buildMonthlyFlow(
    data.skill.entries
      .filter((item) => !item.isAssessment && !item.isSpecial && item.monthKey in PREVIEW_MONTH_INDEX)
      .map((item) => ({
        dueMonthKey: item.monthKey,
        completedMonthKey: getCompletedMonthForPlanKey("skill", getSkillPlanKey(item)),
        weight: 1,
      })),
  );

  const assessmentFlow = buildMonthlyFlow(
    views.skill
      .filter((outcome) => outcome.assessmentRow)
      .map((outcome) => ({
        dueMonthKey: outcome.assessmentRow.endMonthKey,
        completedMonthKey: getCompletedMonthForPlanKey("skill", outcome.assessmentRow.planKey),
        weight: 1,
      })),
  );

  PREVIEW_MONTHS.forEach(([monthKey]) => {
    carried[monthKey].outcomes = outcomeFlow[monthKey].carried;
    carried[monthKey].jobs = jobFlow[monthKey].carried;
    carried[monthKey].tasks = taskFlow[monthKey].carried;
    carried[monthKey].assessments = assessmentFlow[monthKey].carried;

    total[monthKey].outcomes = outcomeFlow[monthKey].total;
    total[monthKey].jobs = jobFlow[monthKey].total;
    total[monthKey].tasks = taskFlow[monthKey].total;
    total[monthKey].assessments = assessmentFlow[monthKey].total;

    achieved[monthKey].outcomes = outcomeFlow[monthKey].achieved;
    achieved[monthKey].jobs = jobFlow[monthKey].achieved;
    achieved[monthKey].tasks = taskFlow[monthKey].achieved;
    achieved[monthKey].assessments = assessmentFlow[monthKey].achieved;

    balance[monthKey].outcomes = outcomeFlow[monthKey].balance;
    balance[monthKey].jobs = jobFlow[monthKey].balance;
    balance[monthKey].tasks = taskFlow[monthKey].balance;
    balance[monthKey].assessments = assessmentFlow[monthKey].balance;
  });

  return {
    carried,
    total,
    achieved,
    balance,
  };
}

function buildTheoryAnticipatedMetrics() {
  const metrics = createEmptyMetricMap();
  const lessonEndMonth = new Map();

  data.theory.entries
    .filter((item) => !item.isAssessment && !item.isSpecial && item.lessonNo && item.monthKey in metrics)
    .forEach((item) => {
      updateLatestMonth(lessonEndMonth, `${item.outcomeNo}::${item.lessonNo}`, item.monthKey);
    });

  lessonEndMonth.forEach((monthKey) => {
    metrics[monthKey].lessons += 1;
  });

  Object.entries(metrics).forEach(([, values]) => {
    values.assessments = values.lessons > 0 ? 1 : 0;
  });

  return metrics;
}

function buildTheoryProgressMetrics() {
  const carried = createEmptyMetricMap();
  const total = createEmptyMetricMap();
  const achieved = createEmptyMetricMap();
  const balance = createEmptyMetricMap();

  const lessonFlow = buildMonthlyFlow(buildTheoryLessonEntities());
  const assessmentFlow = buildMonthlyFlow(
    getTheoryExamMonthKeys().map((monthKey) => ({
      dueMonthKey: monthKey,
      completedMonthKey: getCompletedMonthForPlanKey("theory", getTheoryExamPlanKey(monthKey)),
      weight: 1,
    })),
  );

  PREVIEW_MONTHS.forEach(([monthKey]) => {
    carried[monthKey].lessons = lessonFlow[monthKey].carried;
    carried[monthKey].assessments = assessmentFlow[monthKey].carried;

    total[monthKey].lessons = lessonFlow[monthKey].total;
    total[monthKey].assessments = assessmentFlow[monthKey].total;

    achieved[monthKey].lessons = lessonFlow[monthKey].achieved;
    achieved[monthKey].assessments = assessmentFlow[monthKey].achieved;

    balance[monthKey].lessons = lessonFlow[monthKey].balance;
    balance[monthKey].assessments = assessmentFlow[monthKey].balance;
  });

  return {
    carried,
    total,
    achieved,
    balance,
  };
}

function createEmptyMetricMap() {
  return Object.fromEntries(
    PREVIEW_MONTHS.map(([key]) => [
      key,
      {
        outcomes: 0,
        jobs: 0,
        tasks: 0,
        lessons: 0,
        assessments: 0,
      },
    ]),
  );
}

function renderProgramSection(title, rows) {
  return `
    <tr>
      <th class="program-section-head" colspan="12">${escapeHtml(title)}</th>
    </tr>
    ${rows.join("")}
  `;
}

function renderProgramBannerRow(label, rowClass = "program-subsection-head") {
  return `
    <tr>
      <th class="${rowClass}" colspan="12">${escapeHtml(label)}</th>
    </tr>
  `;
}

function renderProgramValueRow(label, metrics, key, rowClass = "") {
  return `
    <tr class="${rowClass}">
      <th class="program-row-label">${escapeHtml(label)}</th>
      ${PREVIEW_MONTHS.map(([monthKey]) => renderProgramCell(metrics?.[monthKey]?.[key])).join("")}
    </tr>
  `;
}

function renderProgramCell(value) {
  const displayValue = value === 0 ? "0" : value ? String(value) : "";
  return `<td class="program-value-cell">${displayValue ? escapeHtml(displayValue) : ""}</td>`;
}

function updateLatestMonth(lookup, entryKey, monthKey) {
  const current = lookup.get(entryKey);
  if (!current || PREVIEW_MONTH_INDEX[monthKey] > PREVIEW_MONTH_INDEX[current]) {
    lookup.set(entryKey, monthKey);
  }
}

function getMonthKeyFromDate(value) {
  if (!value) {
    return "";
  }

  const parts = String(value).split("-");
  if (parts.length < 2) {
    return "";
  }

  const monthNumber = Number(parts[1]);
  const lookup = {
    1: "JANUARY",
    2: "FEBRUARY",
    3: "MARCH",
    4: "APRIL",
    5: "MAY",
    6: "JUNE",
    7: "JULY",
    8: "AUGUST",
    9: "SEPTEMBER",
    10: "OCTOBER",
    11: "NOVEMBER",
    12: "DECEMBER",
  };

  return lookup[monthNumber] || "";
}

function getMonthKeysFromPoints(points) {
  return [...new Set(points.map((point) => getMonthKeyFromLabel(point.monthLabel)).filter(Boolean))];
}

function getMonthSortRows(points) {
  const sortRows = {};
  points.forEach((point) => {
    const monthKey = getMonthKeyFromLabel(point.monthLabel);
    if (!monthKey) {
      return;
    }

    if (!sortRows[monthKey] || point.sheetRow < sortRows[monthKey]) {
      sortRows[monthKey] = point.sheetRow;
    }
  });

  return sortRows;
}

function getMonthKeyFromLabel(label) {
  const normalized = String(label || "").trim().toUpperCase();
  return PREVIEW_MONTH_INDEX[normalized] !== undefined ? normalized : "";
}

function getScheduleLabel(points) {
  const sorted = [...points].sort((left, right) => left.sheetRow - right.sheetRow);
  const first = sorted[0];
  const last = sorted[sorted.length - 1];
  if (!first) {
    return "";
  }

  if (first.monthLabel === last.monthLabel) {
    if (first.weekLabel === last.weekLabel) {
      return `${first.monthLabel} | ${formatWeek(first.weekLabel)}`;
    }
    return `${first.monthLabel} | ${formatWeek(first.weekLabel)} - ${formatWeek(last.weekLabel)}`;
  }

  return `${first.monthLabel} ${formatWeek(first.weekLabel)} - ${last.monthLabel} ${formatWeek(last.weekLabel)}`;
}

function formatWeek(weekLabel) {
  const value = String(weekLabel || "").trim();
  if (!value) {
    return "Week ?";
  }

  return /^\d+$/.test(value) ? `W${value}` : value;
}

function getSkillPlanKey(item) {
  return `skill::${item.outcomeNo}::${item.jobNo}`;
}

function getSkillAssessmentPlanKey(item) {
  return `skill-assessment::${item.outcomeNo}`;
}

function getTheoryPlanKey(item) {
  return `theory::${item.outcomeNo}::${item.lessonNo}::${item.topicNo}`;
}

function getTheoryExamPlanKey(monthKey) {
  return `theory-exam::${monthKey}`;
}

function getLatestMonthKey(monthKeys) {
  return monthKeys.reduce((latest, monthKey) => {
    if (!monthKey) {
      return latest;
    }
    if (!latest) {
      return monthKey;
    }
    return PREVIEW_MONTH_INDEX[monthKey] > PREVIEW_MONTH_INDEX[latest] ? monthKey : latest;
  }, "");
}

function getCompletedMonthForPlanKey(sectionKey, planKey) {
  const planner = getPlannerValues(sectionKey, planKey);
  if (!planner.completed) {
    return "";
  }
  return getMonthKeyFromDate(getEffectiveConductedDateForPlanKey(sectionKey, planKey));
}

function getEffectiveConductedDateForPlanKey(sectionKey, planKey) {
  const row = findPlannerRowByPlanKey(sectionKey, planKey);
  if (row) {
    return getEffectiveConductedDate(sectionKey, row);
  }

  return getPlannerValues(sectionKey, planKey).conductedDate;
}

function findPlannerRowByPlanKey(sectionKey, planKey) {
  if (!planKey) {
    return null;
  }

  if (sectionKey === "skill") {
    for (const outcome of views.skill) {
      const matchedRow = outcome.rows.find((row) => row.planKey === planKey);
      if (matchedRow) {
        return matchedRow;
      }
    }
    return null;
  }

  for (const outcome of views.theory) {
    const matchedRow = outcome.rows.find((row) => row.planKey === planKey);
    if (matchedRow) {
      return matchedRow;
    }
  }

  return null;
}

function getOutcomeCompletedMonthKey(jobRows) {
  let latestMonthKey = "";

  for (const row of jobRows) {
    const completedMonthKey = getCompletedMonthForPlanKey("skill", row.planKey);
    if (!completedMonthKey || !(completedMonthKey in PREVIEW_MONTH_INDEX)) {
      return "";
    }
    if (!latestMonthKey || PREVIEW_MONTH_INDEX[completedMonthKey] > PREVIEW_MONTH_INDEX[latestMonthKey]) {
      latestMonthKey = completedMonthKey;
    }
  }

  return latestMonthKey;
}

function getLatestCompletedMonthForPlanKeys(sectionKey, planKeys) {
  let latestMonthKey = "";

  for (const planKey of planKeys) {
    const completedMonthKey = getCompletedMonthForPlanKey(sectionKey, planKey);
    if (!completedMonthKey || !(completedMonthKey in PREVIEW_MONTH_INDEX)) {
      return "";
    }
    if (!latestMonthKey || PREVIEW_MONTH_INDEX[completedMonthKey] > PREVIEW_MONTH_INDEX[latestMonthKey]) {
      latestMonthKey = completedMonthKey;
    }
  }

  return latestMonthKey;
}

function buildTheoryLessonEntities() {
  const lessons = new Map();

  data.theory.entries
    .filter((item) => !item.isAssessment && !item.isSpecial && item.lessonNo && item.topicNo)
    .forEach((item) => {
      const lessonKey = `${item.outcomeNo}::${item.lessonNo}`;
      let lesson = lessons.get(lessonKey);
      if (!lesson) {
        lesson = {
          monthKeys: new Set(),
          topicPlanKeys: [],
        };
        lessons.set(lessonKey, lesson);
      }

      lesson.monthKeys.add(item.monthKey);
      lesson.topicPlanKeys.push(getTheoryPlanKey(item));
    });

  return [...lessons.values()].map((lesson) => ({
    dueMonthKey: getLatestMonthKey([...lesson.monthKeys]),
    completedMonthKey: getLatestCompletedMonthForPlanKeys("theory", lesson.topicPlanKeys),
    weight: 1,
  }));
}

function getTheoryExamMonthKeys() {
  return PREVIEW_MONTHS.map(([monthKey]) => monthKey).filter((monthKey) => theoryAnticipatedMetrics[monthKey]?.lessons > 0);
}

function buildMonthlyFlow(entities) {
  return Object.fromEntries(
    PREVIEW_MONTHS.map(([monthKey], monthIndex) => {
      const totals = entities.reduce(
        (totals, entity) => {
          const dueIndex = PREVIEW_MONTH_INDEX[entity.dueMonthKey];
          const completedIndex =
            entity.completedMonthKey && entity.completedMonthKey in PREVIEW_MONTH_INDEX
              ? PREVIEW_MONTH_INDEX[entity.completedMonthKey]
              : -1;
          const weight = entity.weight ?? 1;

          if (dueIndex === undefined) {
            return totals;
          }

          if (dueIndex === monthIndex) {
            totals.anticipated += weight;
          }
          if (dueIndex < monthIndex && (completedIndex === -1 || completedIndex > monthIndex - 1)) {
            totals.carried += weight;
          }
          if (completedIndex === monthIndex) {
            totals.achieved += weight;
          }
          if (dueIndex <= monthIndex && (completedIndex === -1 || completedIndex > monthIndex)) {
            totals.balance += weight;
          }

          return totals;
        },
        {
          anticipated: 0,
          carried: 0,
          achieved: 0,
          balance: 0,
          total: 0,
        },
      );
      totals.total = totals.anticipated + totals.carried;
      return [monthKey, totals];
    }),
  );
}

function buildDataEntryStateFromProgramData(programData) {
  return createDataEntryStateFromProgramData(programData);
}

function buildSkillGridRowsFromEntries(entries) {
  return [...entries]
    .filter((item) => !item.isSpecial && !item.isAssessment)
    .sort((left, right) => left.sheetRow - right.sheetRow)
    .map((item) =>
      normalizeEntryGridRow(
        {
          id: createLocalId("skill-row"),
          year: item.year || "",
          monthKey: item.monthKey || "",
          weekLabel: item.weekLabel || "",
          outcomeNo: item.outcomeNo || "",
          outcomeName: item.outcomeName || "",
          jobNo: item.jobNo || "",
          jobName: item.jobName || "",
          taskNo: item.taskNo || "",
          taskName: item.taskName || "",
        },
        "skill",
      ),
    )
    .filter(Boolean);
}

function buildSkillAssessmentRowsFromEntries(entries) {
  return [...entries]
    .filter((item) => !item.isSpecial && item.isAssessment)
    .sort((left, right) => left.sheetRow - right.sheetRow)
    .map((item) =>
      normalizeAssessmentGridRow({
        id: createLocalId("skill-assessment"),
        year: item.year || "",
        monthKey: item.monthKey || "",
        weekLabel: item.weekLabel || "",
        outcomeNo: item.outcomeNo || "",
        outcomeName: item.outcomeName || "",
        label: item.assessmentLabel || "",
      }),
    )
    .filter(Boolean);
}

function buildTheoryGridRowsFromEntries(entries) {
  return [...entries]
    .filter((item) => !item.isSpecial && !item.isAssessment)
    .sort((left, right) => left.sheetRow - right.sheetRow)
    .map((item) =>
      normalizeEntryGridRow(
        {
          id: createLocalId("theory-row"),
          year: item.year || "",
          monthKey: item.monthKey || "",
          weekLabel: item.weekLabel || "",
          outcomeNo: item.outcomeNo || "",
          outcomeName: item.outcomeName || "",
          lessonNo: item.lessonNo || "",
          lessonName: item.lessonName || "",
          topicNo: item.topicNo || "",
          topicName: item.topicName || "",
        },
        "theory",
      ),
    )
    .filter(Boolean);
}

function normalizeEntryGridRow(value, mode) {
  if (!value || typeof value !== "object") {
    return null;
  }

  const baseRow = {
    id: getBuilderId(value.id, `${mode}-row`),
    year: String(value.year || ""),
    monthKey: normalizeMonthValue(value.monthKey || value.monthLabel || getDefaultMonthKey()).monthKey ||
      getDefaultMonthKey(),
    weekLabel: String(value.weekLabel || "1"),
    outcomeNo: String(value.outcomeNo || ""),
    outcomeName: String(value.outcomeName || ""),
  };

  const row =
    mode === "skill"
      ? {
          ...baseRow,
          jobNo: String(value.jobNo || ""),
          jobName: String(value.jobName || ""),
          taskNo: String(value.taskNo || ""),
          taskName: String(value.taskName || ""),
        }
      : {
          ...baseRow,
          lessonNo: String(value.lessonNo || ""),
          lessonName: String(value.lessonName || ""),
          topicNo: String(value.topicNo || ""),
          topicName: String(value.topicName || ""),
        };

  normalizeScheduleRow(row);
  return row;
}

function normalizeAssessmentGridRow(value) {
  if (!value || typeof value !== "object") {
    return null;
  }

  const row = {
    id: getBuilderId(value.id, "skill-assessment"),
    year: String(value.year || ""),
    monthKey: normalizeMonthValue(value.monthKey || value.monthLabel || getDefaultMonthKey()).monthKey ||
      getDefaultMonthKey(),
    weekLabel: String(value.weekLabel || "1"),
    outcomeNo: String(value.outcomeNo || ""),
    outcomeName: String(value.outcomeName || ""),
    label: String(value.label || ""),
  };
  normalizeScheduleRow(row);
  return row;
}

function normalizeScheduleRow(row) {
  if (!row || typeof row !== "object") {
    return row;
  }

  const schedule = getSchedulePickerMeta(row.monthKey, row.weekLabel, row.year);
  row.monthKey = schedule.monthKey;
  row.weekLabel = String(schedule.weekValue);
  row.year = schedule.year;
  return row;
}

function createSkillEntryRow() {
  return normalizeEntryGridRow(
    {
      id: createLocalId("skill-row"),
      monthKey: getDefaultMonthKey(),
      weekLabel: "1",
      outcomeNo: "",
      outcomeName: "",
      jobNo: "",
      jobName: "",
      taskNo: "",
      taskName: "",
    },
    "skill",
  );
}

function createSkillRowFromTemplate(sourceRow, mode = "outcome") {
  if (!sourceRow) {
    return createSkillEntryRow();
  }

  const base = normalizeEntryGridRow(
    {
      ...sourceRow,
      id: createLocalId("skill-row"),
    },
    "skill",
  );
  const nextOutcomeNo = incrementDottedCode(base.outcomeNo);
  const nextJobNo = incrementDottedCode(base.jobNo) || appendChildCode(base.outcomeNo);
  const nextTaskNo = incrementDottedCode(base.taskNo) || appendChildCode(base.jobNo);

  if (mode === "task") {
    return normalizeEntryGridRow(
      {
        ...base,
        id: createLocalId("skill-row"),
        taskNo: nextTaskNo,
        taskName: "",
      },
      "skill",
    );
  }

  if (mode === "job") {
    return normalizeEntryGridRow(
      {
        ...base,
        id: createLocalId("skill-row"),
        jobNo: nextJobNo,
        jobName: "",
        taskNo: appendChildCode(nextJobNo),
        taskName: "",
      },
      "skill",
    );
  }

  return normalizeEntryGridRow(
    {
      ...base,
      id: createLocalId("skill-row"),
      outcomeNo: nextOutcomeNo,
      outcomeName: "",
      jobNo: appendChildCode(nextOutcomeNo),
      jobName: "",
      taskNo: appendChildCode(appendChildCode(nextOutcomeNo)),
      taskName: "",
    },
    "skill",
  );
}

function createSkillAssessmentRow() {
  return normalizeAssessmentGridRow({
    id: createLocalId("skill-assessment"),
    monthKey: getDefaultMonthKey(),
    weekLabel: "1",
    outcomeNo: "",
    outcomeName: "",
    label: "",
  });
}

function createSkillAssessmentRowFromTemplate(sourceRow) {
  if (!sourceRow) {
    return createSkillAssessmentRow();
  }

  const fromSkillRow = "jobNo" in sourceRow || "taskNo" in sourceRow
    ? normalizeEntryGridRow(
        {
          ...sourceRow,
          id: createLocalId("skill-row"),
        },
        "skill",
      )
    : null;
  const base = normalizeAssessmentGridRow(
    {
      ...sourceRow,
      id: createLocalId("skill-assessment"),
      outcomeNo: sourceRow.outcomeNo || fromSkillRow?.outcomeNo || "",
      outcomeName: sourceRow.outcomeName || fromSkillRow?.outcomeName || "",
      label: sourceRow.label || "",
      monthKey: sourceRow.monthKey || fromSkillRow?.monthKey || getDefaultMonthKey(),
      weekLabel: sourceRow.weekLabel || fromSkillRow?.weekLabel || "1",
      year: sourceRow.year || fromSkillRow?.year || "",
    },
  );

  const nextOutcomeNo = incrementDottedCode(base.outcomeNo);
  return normalizeAssessmentGridRow({
    ...base,
    id: createLocalId("skill-assessment"),
    outcomeNo: nextOutcomeNo || base.outcomeNo,
    outcomeName: "",
    label: nextOutcomeNo ? `Assessment for Outcome ${nextOutcomeNo}` : "",
  });
}

function createTheoryEntryRow() {
  return normalizeEntryGridRow(
    {
      id: createLocalId("theory-row"),
      monthKey: getDefaultMonthKey(),
      weekLabel: "1",
      outcomeNo: "",
      outcomeName: "",
      lessonNo: "",
      lessonName: "",
      topicNo: "",
      topicName: "",
    },
    "theory",
  );
}

function createTheoryRowFromTemplate(sourceRow, mode = "outcome") {
  if (!sourceRow) {
    return createTheoryEntryRow();
  }

  const base = normalizeEntryGridRow(
    {
      ...sourceRow,
      id: createLocalId("theory-row"),
    },
    "theory",
  );
  const nextOutcomeNo = incrementDottedCode(base.outcomeNo);
  const nextLessonNo = incrementDottedCode(base.lessonNo) || appendChildCode(base.outcomeNo);
  const nextTopicNo = incrementDottedCode(base.topicNo) || appendChildCode(base.lessonNo);

  if (mode === "topic") {
    return normalizeEntryGridRow(
      {
        ...base,
        id: createLocalId("theory-row"),
        topicNo: nextTopicNo,
        topicName: "",
      },
      "theory",
    );
  }

  if (mode === "lesson") {
    return normalizeEntryGridRow(
      {
        ...base,
        id: createLocalId("theory-row"),
        lessonNo: nextLessonNo,
        lessonName: "",
        topicNo: appendChildCode(nextLessonNo),
        topicName: "",
      },
      "theory",
    );
  }

  return normalizeEntryGridRow(
    {
      ...base,
      id: createLocalId("theory-row"),
      outcomeNo: nextOutcomeNo,
      outcomeName: "",
      lessonNo: appendChildCode(nextOutcomeNo),
      lessonName: "",
      topicNo: appendChildCode(appendChildCode(nextOutcomeNo)),
      topicName: "",
    },
    "theory",
  );
}

function getDataEntryCollection(entryField) {
  const mapping = {
    skillRow: state.dataEntry.skillRows,
    skillAssessment: state.dataEntry.skillAssessments,
    theoryRow: state.dataEntry.theoryRows,
  };
  return mapping[entryField] || null;
}

function buildProgramDataFromEntryState(entryState) {
  if (entryState?.programData) {
    return rebuildImportedProgramData(entryState.programData);
  }

  return buildProgramDataFromLegacyEntryState(entryState);
}

function buildProgramDataFromLegacyEntryState(entryState) {
  const skillEntries = buildSkillEntriesFromGridRows(entryState.skillRows || [], entryState.skillAssessments || []);
  const theoryEntries = buildTheoryEntriesFromGridRows(entryState.theoryRows || []);

  if (!skillEntries.length) {
    throw new Error("Professional Skill data entry is empty.");
  }

  if (!theoryEntries.length) {
    throw new Error("Professional Knowledge data entry is empty.");
  }

  return {
    meta: {
      ...BASE_DATA.meta,
    },
    months: BASE_DATA.months.map((month) => ({ ...month })),
    skill: {
      ...BASE_DATA.skill,
      entries: skillEntries,
      months: buildSkillMonths(skillEntries),
      totals: buildSkillTotals(skillEntries),
    },
    theory: {
      ...BASE_DATA.theory,
      entries: theoryEntries,
      months: buildTheoryMonths(theoryEntries),
      totals: buildTheoryTotals(theoryEntries),
    },
  };
}

function buildSkillEntriesFromGridRows(skillRows, skillAssessments) {
  const entries = [];
  let sheetRow = 1;

  skillRows.forEach((row, index) => {
    const normalizedRow = normalizeEntryGridRow(row, "skill");
    if (isSkillGridRowBlank(normalizedRow)) {
      return;
    }

    const monthInfo = normalizeMonthValue(normalizedRow.monthKey);
    entries.push({
      sheetRow: sheetRow++,
      year: normalizedRow.year,
      monthKey: monthInfo.monthKey,
      monthLabel: monthInfo.monthLabel,
      weekLabel: normalizedRow.weekLabel,
      outcomeNo: requireBuilderValue(normalizedRow.outcomeNo, `Professional Skill row ${index + 1} outcome number`),
      outcomeName: requireBuilderValue(normalizedRow.outcomeName, `Professional Skill row ${index + 1} outcome name`),
      isAssessment: false,
      isSpecial: false,
      specialLabel: "",
      jobNo: requireBuilderValue(normalizedRow.jobNo, `Professional Skill row ${index + 1} job number`),
      jobName: requireBuilderValue(normalizedRow.jobName, `Professional Skill row ${index + 1} job name`),
      taskNo: requireBuilderValue(normalizedRow.taskNo, `Professional Skill row ${index + 1} task number`),
      taskName: requireBuilderValue(normalizedRow.taskName, `Professional Skill row ${index + 1} task name`),
      assessmentLabel: "",
    });
  });

  skillAssessments.forEach((row, index) => {
    const normalizedRow = normalizeAssessmentGridRow(row);
    if (isAssessmentGridRowBlank(normalizedRow)) {
      return;
    }

    const monthInfo = normalizeMonthValue(normalizedRow.monthKey);
    entries.push({
      sheetRow: sheetRow++,
      year: normalizedRow.year,
      monthKey: monthInfo.monthKey,
      monthLabel: monthInfo.monthLabel,
      weekLabel: normalizedRow.weekLabel,
      outcomeNo: requireBuilderValue(normalizedRow.outcomeNo, `Skill assessment row ${index + 1} outcome number`),
      outcomeName: requireBuilderValue(normalizedRow.outcomeName, `Skill assessment row ${index + 1} outcome name`),
      isAssessment: true,
      isSpecial: false,
      specialLabel: "",
      jobNo: "",
      jobName: "",
      taskNo: "",
      taskName: "",
      assessmentLabel: requireBuilderValue(normalizedRow.label, `Skill assessment row ${index + 1} label`),
    });
  });

  return entries;
}

function buildTheoryEntriesFromGridRows(theoryRows) {
  const entries = [];
  let sheetRow = 1;

  theoryRows.forEach((row, index) => {
    const normalizedRow = normalizeEntryGridRow(row, "theory");
    if (isTheoryGridRowBlank(normalizedRow)) {
      return;
    }

    const monthInfo = normalizeMonthValue(normalizedRow.monthKey);
    entries.push({
      sheetRow: sheetRow++,
      year: normalizedRow.year,
      monthKey: monthInfo.monthKey,
      monthLabel: monthInfo.monthLabel,
      weekLabel: normalizedRow.weekLabel,
      outcomeNo: requireBuilderValue(normalizedRow.outcomeNo, `Professional Knowledge row ${index + 1} outcome number`),
      outcomeName: requireBuilderValue(normalizedRow.outcomeName, `Professional Knowledge row ${index + 1} outcome name`),
      isAssessment: false,
      isSpecial: false,
      specialLabel: "",
      lessonNo: requireBuilderValue(normalizedRow.lessonNo, `Professional Knowledge row ${index + 1} lesson number`),
      lessonName: requireBuilderValue(normalizedRow.lessonName, `Professional Knowledge row ${index + 1} lesson name`),
      topicNo: requireBuilderValue(normalizedRow.topicNo, `Professional Knowledge row ${index + 1} topic number`),
      topicName: requireBuilderValue(normalizedRow.topicName, `Professional Knowledge row ${index + 1} topic name`),
      assessmentLabel: "",
    });
  });

  return entries;
}

function isSkillGridRowBlank(row) {
  return ![
    row.outcomeNo,
    row.outcomeName,
    row.jobNo,
    row.jobName,
    row.taskNo,
    row.taskName,
  ]
    .join("")
    .trim();
}

function isAssessmentGridRowBlank(row) {
  return ![row.outcomeNo, row.outcomeName, row.label].join("").trim();
}

function isTheoryGridRowBlank(row) {
  return ![
    row.outcomeNo,
    row.outcomeName,
    row.lessonNo,
    row.lessonName,
    row.topicNo,
    row.topicName,
  ]
    .join("")
    .trim();
}

function flattenNestedDataEntryState(value) {
  const next = {
    skillRows: [],
    skillAssessments: [],
    theoryRows: [],
  };

  (value.skillOutcomes || []).forEach((outcome) => {
    const outcomeNo = String(outcome?.outcomeNo || "");
    const outcomeName = String(outcome?.outcomeName || "");

    (outcome?.jobs || []).forEach((job) => {
      const tasks = Array.isArray(job?.tasks) ? job.tasks : [];
      (job?.plans || []).forEach((plan) => {
        const schedule = getSchedulePickerMeta(plan?.monthKey, plan?.weekLabel, plan?.year);
        const startIndex = tasks.findIndex((task) => task.id === plan?.fromTaskId);
        const endIndex = tasks.findIndex((task) => task.id === plan?.toTaskId);
        const fromIndex = startIndex === -1 ? 0 : Math.min(startIndex, endIndex === -1 ? startIndex : endIndex);
        const toIndex = endIndex === -1 ? fromIndex : Math.max(startIndex === -1 ? endIndex : startIndex, endIndex);
        tasks.slice(fromIndex, toIndex + 1).forEach((task) => {
          next.skillRows.push(
            normalizeEntryGridRow(
              {
                id: createLocalId("skill-row"),
                year: schedule.year,
                monthKey: schedule.monthKey,
                weekLabel: schedule.weekValue,
                outcomeNo,
                outcomeName,
                jobNo: String(job?.jobNo || ""),
                jobName: String(job?.jobName || ""),
                taskNo: String(task?.taskNo || ""),
                taskName: String(task?.taskName || ""),
              },
              "skill",
            ),
          );
        });
      });

      if (!job?.plans?.length) {
        tasks.forEach((task) => {
          next.skillRows.push(
            normalizeEntryGridRow(
              {
                id: createLocalId("skill-row"),
                monthKey: getDefaultMonthKey(),
                weekLabel: "1",
                outcomeNo,
                outcomeName,
                jobNo: String(job?.jobNo || ""),
                jobName: String(job?.jobName || ""),
                taskNo: String(task?.taskNo || ""),
                taskName: String(task?.taskName || ""),
              },
              "skill",
            ),
          );
        });
      }
    });

    if (outcome?.assessment) {
      const assessment = outcome.assessment;
      if (
        String(assessment.label || "").trim() ||
        String(assessment.monthKey || "").trim() ||
        String(assessment.weekLabel || "").trim()
      ) {
        next.skillAssessments.push(
          normalizeAssessmentGridRow({
            id: createLocalId("skill-assessment"),
            year: assessment.year || "",
            monthKey: assessment.monthKey || getDefaultMonthKey(),
            weekLabel: assessment.weekLabel || "1",
            outcomeNo,
            outcomeName,
            label: assessment.label || "",
          }),
        );
      }
    }
  });

  (value.theoryOutcomes || []).forEach((outcome) => {
    const outcomeNo = String(outcome?.outcomeNo || "");
    const outcomeName = String(outcome?.outcomeName || "");

    (outcome?.lessons || []).forEach((lesson) => {
      const topics = Array.isArray(lesson?.topics) ? lesson.topics : [];
      (lesson?.plans || []).forEach((plan) => {
        const schedule = getSchedulePickerMeta(plan?.monthKey, plan?.weekLabel, plan?.year);
        const startIndex = topics.findIndex((topic) => topic.id === plan?.fromTopicId);
        const endIndex = topics.findIndex((topic) => topic.id === plan?.toTopicId);
        const fromIndex = startIndex === -1 ? 0 : Math.min(startIndex, endIndex === -1 ? startIndex : endIndex);
        const toIndex = endIndex === -1 ? fromIndex : Math.max(startIndex === -1 ? endIndex : startIndex, endIndex);
        topics.slice(fromIndex, toIndex + 1).forEach((topic) => {
          next.theoryRows.push(
            normalizeEntryGridRow(
              {
                id: createLocalId("theory-row"),
                year: schedule.year,
                monthKey: schedule.monthKey,
                weekLabel: schedule.weekValue,
                outcomeNo,
                outcomeName,
                lessonNo: String(lesson?.lessonNo || ""),
                lessonName: String(lesson?.lessonName || ""),
                topicNo: String(topic?.topicNo || ""),
                topicName: String(topic?.topicName || ""),
              },
              "theory",
            ),
          );
        });
      });

      if (!lesson?.plans?.length) {
        topics.forEach((topic) => {
          next.theoryRows.push(
            normalizeEntryGridRow(
              {
                id: createLocalId("theory-row"),
                monthKey: getDefaultMonthKey(),
                weekLabel: "1",
                outcomeNo,
                outcomeName,
                lessonNo: String(lesson?.lessonNo || ""),
                lessonName: String(lesson?.lessonName || ""),
                topicNo: String(topic?.topicNo || ""),
                topicName: String(topic?.topicName || ""),
              },
              "theory",
            ),
          );
        });
      }
    });
  });

  return next;
}

function requireBuilderValue(value, label) {
  const trimmedValue = String(value || "").trim();
  if (!trimmedValue) {
    throw new Error(`${label} is required.`);
  }
  return trimmedValue;
}

function incrementDottedCode(value) {
  const rawValue = String(value || "").trim();
  if (!rawValue) {
    return "";
  }

  const parts = rawValue.split(".");
  const lastPart = parts.at(-1) || "";
  if (/^\d+$/.test(lastPart)) {
    const width = lastPart.length;
    const nextValue = String(Number.parseInt(lastPart, 10) + 1).padStart(width, "0");
    parts[parts.length - 1] = nextValue;
    return parts.join(".");
  }

  return rawValue.replace(/(\d+)(?!.*\d)/, (match) => String(Number.parseInt(match, 10) + 1).padStart(match.length, "0"));
}

function appendChildCode(value) {
  const rawValue = String(value || "").trim();
  return rawValue ? `${rawValue}.1` : "";
}

function getDefaultMonthKey() {
  return BASE_DATA.months.find((month) => month.key === "SEPTEMBER")?.key || BASE_DATA.months[0]?.key || "AUGUST";
}

function getSchedulePickerMeta(monthKey, weekLabel, yearValue = "") {
  const normalizedMonthKey = normalizeMonthValue(monthKey || getDefaultMonthKey()).monthKey || getDefaultMonthKey();
  const year = String(yearValue || getCalendarYearForMonth(normalizedMonthKey));
  const weekCount = getWeeksInMonth(year, normalizedMonthKey);
  const weekValue = clampWeekValue(weekLabel, weekCount);
  const monthLabel = BASE_DATA.months.find((month) => month.key === normalizedMonthKey)?.label || normalizedMonthKey;
  const monthShortLabel = PREVIEW_MONTHS.find(([key]) => key === normalizedMonthKey)?.[1] || monthLabel.slice(0, 3);
  const dayCount = new Date(Number.parseInt(year, 10), getMonthNumberFromKey(normalizedMonthKey), 0).getDate();
  const startDay = ((weekValue - 1) * 7) + 1;
  const endDay = Math.min(weekValue * 7, dayCount);

  return {
    monthKey: normalizedMonthKey,
    monthLabel,
    monthShortLabel,
    year,
    weekCount,
    weekValue,
    rangeLabel: `${String(startDay).padStart(2, "0")}-${String(endDay).padStart(2, "0")} ${monthShortLabel} ${year}`,
  };
}

function clampWeekValue(value, weekCount) {
  const match = String(value || "1").match(/\d+/);
  const numericValue = Number.parseInt(match?.[0] || "1", 10);
  if (!Number.isFinite(numericValue)) {
    return 1;
  }
  return Math.max(1, Math.min(weekCount, numericValue));
}

function getCalendarYearForMonth(monthKey) {
  const startYear = getAcademicStartYear();
  if (["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE"].includes(monthKey)) {
    return startYear + 1;
  }
  return startYear;
}

function getAcademicStartYear() {
  const sessionValue = String(BASE_DATA.meta.session || "");
  const yearMatches = [...sessionValue.matchAll(/\d{4}/g)].map((match) => Number.parseInt(match[0], 10));
  const baseYear = yearMatches[0] || new Date().getFullYear();
  return baseYear + getTrainingYearOffset();
}

function getTrainingYearOffset() {
  const trainingYear = String(BASE_DATA.meta.trainingYear || "").toUpperCase();
  if (trainingYear.includes("II") || trainingYear.includes("2")) {
    return 1;
  }
  return 0;
}

function getWeeksInMonth(yearValue, monthKey) {
  const year = Number.parseInt(String(yearValue || getCalendarYearForMonth(monthKey)), 10);
  const monthNumber = getMonthNumberFromKey(monthKey);
  if (!year || !monthNumber) {
    return 4;
  }

  const dayCount = new Date(year, monthNumber, 0).getDate();
  return Math.max(4, Math.ceil(dayCount / 7));
}

function getMonthNumberFromKey(monthKey) {
  const index = PREVIEW_MONTHS.findIndex(([key]) => key === monthKey);
  if (index === -1) {
    return 0;
  }
  return index >= 5 ? index - 4 : index + 8;
}

function syncWeekSliderDisplay(input, row) {
  const field = input.closest(".week-slider-field");
  const label = field?.querySelector("span");
  if (!(label instanceof HTMLElement)) {
    return;
  }

  const schedule = getSchedulePickerMeta(row.monthKey, row.weekLabel, row.year);
  label.textContent = `${schedule.monthLabel} | W${schedule.weekValue} of ${schedule.weekCount}`;
  input.max = String(schedule.weekCount);
  input.value = String(schedule.weekValue);
}

function buildProgramDataFromEntryTexts(skillText, theoryText) {
  const skillEntries = parseSkillEntryText(skillText);
  const theoryEntries = parseTheoryEntryText(theoryText);

  return {
    meta: {
      ...BASE_DATA.meta,
    },
    months: BASE_DATA.months.map((month) => ({ ...month })),
    skill: {
      ...BASE_DATA.skill,
      entries: skillEntries,
      months: buildSkillMonths(skillEntries),
      totals: buildSkillTotals(skillEntries),
    },
    theory: {
      ...BASE_DATA.theory,
      entries: theoryEntries,
      months: buildTheoryMonths(theoryEntries),
      totals: buildTheoryTotals(theoryEntries),
    },
  };
}

function cloneProgramData(source) {
  return {
    meta: {
      ...source.meta,
      sourceSheets: [...(source.meta?.sourceSheets || [])],
    },
    months: (source.months || []).map((month) => ({ ...month })),
    skill: {
      ...source.skill,
      totals: { ...(source.skill?.totals || {}) },
      months: (source.skill?.months || []).map((month) => ({
        ...month,
        anticipated: { ...(month.anticipated || {}) },
      })),
      entries: (source.skill?.entries || []).map((entry) => ({ ...entry })),
    },
    theory: {
      ...source.theory,
      totals: { ...(source.theory?.totals || {}) },
      months: (source.theory?.months || []).map((month) => ({
        ...month,
        anticipated: { ...(month.anticipated || {}) },
      })),
      entries: (source.theory?.entries || []).map((entry) => ({ ...entry })),
    },
  };
}

function createDataEntryStateFromProgramData(programData = BASE_DATA) {
  return {
    version: 4,
    programData: rebuildImportedProgramData(programData),
  };
}

function rebuildImportedProgramData(programData = BASE_DATA) {
  const meta = normalizeImportedProgramMeta(programData?.meta, BASE_DATA.meta);
  const skillEntries = normalizeImportedEntries(programData?.skill?.entries, "skill");
  const theoryEntries = normalizeImportedEntries(programData?.theory?.entries, "theory");

  if (!skillEntries.length) {
    throw new Error("Professional Skill splitup is empty.");
  }

  if (!theoryEntries.length) {
    throw new Error("Professional Knowledge splitup is empty.");
  }

  const sourceSheets = [
    String(programData?.skill?.sheetName || meta.sourceSheets?.[0] || BASE_DATA.skill.sheetName || "SKILL").trim(),
    String(programData?.theory?.sheetName || meta.sourceSheets?.[1] || BASE_DATA.theory.sheetName || "THEORY").trim(),
  ].filter(Boolean);

  return {
    meta: {
      ...meta,
      sourceSheets,
    },
    months: BASE_DATA.months.map((month) => ({ ...month })),
    skill: {
      ...BASE_DATA.skill,
      sheetName: sourceSheets[0] || BASE_DATA.skill.sheetName,
      mode: "skill",
      entries: skillEntries,
      months: buildSkillMonths(skillEntries),
      totals: buildSkillTotals(skillEntries),
    },
    theory: {
      ...BASE_DATA.theory,
      sheetName: sourceSheets[1] || BASE_DATA.theory.sheetName,
      mode: "theory",
      entries: theoryEntries,
      months: buildTheoryMonths(theoryEntries),
      totals: buildTheoryTotals(theoryEntries),
    },
  };
}

function normalizeImportedProgramMeta(meta, fallback = BASE_DATA.meta) {
  const sourceSheets = Array.isArray(meta?.sourceSheets)
    ? meta.sourceSheets.map((sheet) => collapseWorksheetText(sheet)).filter(Boolean)
    : [...(fallback.sourceSheets || [])];

  return {
    department: collapseWorksheetText(meta?.department) || fallback.department,
    skillTitle: collapseWorksheetText(meta?.skillTitle) || fallback.skillTitle,
    theoryTitle: collapseWorksheetText(meta?.theoryTitle) || fallback.theoryTitle,
    institution: collapseWorksheetText(meta?.institution) || fallback.institution,
    session: collapseWorksheetText(meta?.session) || fallback.session,
    trade: collapseWorksheetText(meta?.trade) || fallback.trade,
    nsqfLevel: collapseWorksheetText(meta?.nsqfLevel) || fallback.nsqfLevel,
    trainingYear: collapseWorksheetText(meta?.trainingYear) || fallback.trainingYear,
    skillSubject: collapseWorksheetText(meta?.skillSubject) || fallback.skillSubject,
    theorySubject: collapseWorksheetText(meta?.theorySubject) || fallback.theorySubject,
    sourceWorkbook: collapseWorksheetText(meta?.sourceWorkbook) || fallback.sourceWorkbook,
    sourceSheets,
  };
}

function normalizeImportedEntries(entries, mode) {
  return [...(entries || [])]
    .map((entry, index) => normalizeImportedEntry(entry, mode, index))
    .filter(Boolean)
    .sort((left, right) => left.sheetRow - right.sheetRow);
}

function normalizeImportedEntry(entry, mode, index) {
  if (!entry || typeof entry !== "object") {
    return null;
  }

  const monthInfo = normalizeMonthValue(entry.monthKey || entry.monthLabel);
  if (!monthInfo.monthKey) {
    return null;
  }

  const isSpecial = Boolean(entry.isSpecial);
  const isAssessment = Boolean(entry.isAssessment);
  const specialLabel = collapseWorksheetText(entry.specialLabel || entry.outcomeName || entry.weekLabel || "");
  const assessmentLabel = collapseWorksheetText(
    entry.assessmentLabel || entry.outcomeName || (entry.outcomeNo ? `Assessment for Outcome No ${entry.outcomeNo}` : ""),
  );
  const baseEntry = {
    sheetRow: normalizeSheetRow(entry.sheetRow, index),
    year: collapseWorksheetText(entry.year),
    monthKey: monthInfo.monthKey,
    monthLabel: monthInfo.monthLabel,
    weekLabel: collapseWorksheetText(entry.weekLabel),
    outcomeNo: isSpecial ? "" : collapseWorksheetText(entry.outcomeNo),
    outcomeName: isAssessment ? assessmentLabel : collapseWorksheetText(entry.outcomeName),
    isAssessment,
    isSpecial,
    specialLabel: isSpecial ? specialLabel : "",
    assessmentLabel: isAssessment ? assessmentLabel : "",
  };

  if (mode === "skill") {
    return {
      ...baseEntry,
      jobNo: isAssessment || isSpecial ? "" : collapseWorksheetText(entry.jobNo),
      jobName: isAssessment || isSpecial ? "" : collapseWorksheetText(entry.jobName),
      taskNo: isAssessment || isSpecial ? "" : collapseWorksheetText(entry.taskNo),
      taskName: isAssessment || isSpecial ? "" : collapseWorksheetText(entry.taskName),
    };
  }

  return {
    ...baseEntry,
    lessonNo: isAssessment || isSpecial ? "" : collapseWorksheetText(entry.lessonNo),
    lessonName: isAssessment || isSpecial ? "" : collapseWorksheetText(entry.lessonName),
    topicNo: isAssessment || isSpecial ? "" : collapseWorksheetText(entry.topicNo),
    topicName: isAssessment || isSpecial ? "" : collapseWorksheetText(entry.topicName),
  };
}

async function parseSplitupWorkbookFile(file) {
  const fileName = String(file?.name || "").trim();
  if (!/\.(xlsx|xlsm)$/i.test(fileName)) {
    throw new Error("Please upload the splitup workbook as an .xlsx or .xlsm file.");
  }

  const bytes = new Uint8Array(await file.arrayBuffer());
  const archive = readZipDirectory(bytes);
  const workbookSheets = await readWorkbookSheets(bytes, archive);
  const skillSheet = pickWorkbookSheet(workbookSheets, "skill");
  const theorySheet = pickWorkbookSheet(workbookSheets, "theory");

  if (!skillSheet || !theorySheet) {
    throw new Error("Could not find both Professional Skill and Professional Knowledge sheets in this workbook.");
  }

  const skillEntries = parseWorkbookEntries(skillSheet, "skill");
  const theoryEntries = parseWorkbookEntries(theorySheet, "theory");
  const meta = extractWorkbookMeta(skillSheet, theorySheet, fileName);

  return rebuildImportedProgramData({
    meta,
    skill: {
      sheetName: skillSheet.name,
      entries: skillEntries,
    },
    theory: {
      sheetName: theorySheet.name,
      entries: theoryEntries,
    },
  });
}

async function readWorkbookSheets(bytes, archive) {
  const sharedStrings = archive.has("xl/sharedStrings.xml")
    ? parseSharedStrings(await readZipEntryText(bytes, archive.get("xl/sharedStrings.xml")))
    : [];
  const sheetDescriptors = await getWorkbookSheetDescriptors(bytes, archive);
  const sheets = [];

  for (const descriptor of sheetDescriptors) {
    if (!archive.has(descriptor.path)) {
      continue;
    }

    const worksheetXml = await readZipEntryText(bytes, archive.get(descriptor.path));
    const records = parseWorksheetRecords(worksheetXml, sharedStrings);
    const header = findWorkbookHeaderDescriptor(records);
    sheets.push({
      ...descriptor,
      header,
      records,
    });
  }

  return sheets;
}

async function getWorkbookSheetDescriptors(bytes, archive) {
  if (!archive.has("xl/workbook.xml")) {
    return Array.from(archive.keys())
      .filter((name) => name.startsWith("xl/worksheets/"))
      .map((path, index) => ({
        name: `Sheet ${index + 1}`,
        path,
      }));
  }

  const workbookXml = await readZipEntryText(bytes, archive.get("xl/workbook.xml"));
  const relsXml = archive.has("xl/_rels/workbook.xml.rels")
    ? await readZipEntryText(bytes, archive.get("xl/_rels/workbook.xml.rels"))
    : "";
  const workbookDoc = parseXml(workbookXml);
  const relsDoc = relsXml ? parseXml(relsXml) : null;
  const relationships = new Map();

  if (relsDoc) {
    getElementsByLocalName(relsDoc, "Relationship").forEach((node) => {
      relationships.set(node.getAttribute("Id"), normalizeWorksheetPath(node.getAttribute("Target")));
    });
  }

  return getElementsByLocalName(workbookDoc, "sheet").map((sheetNode, index) => {
    const relationshipId =
      sheetNode.getAttribute("r:id") ||
      sheetNode.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id") ||
      "";
    const fallbackPath = `xl/worksheets/sheet${index + 1}.xml`;
    return {
      name: collapseWorksheetText(sheetNode.getAttribute("name")) || `Sheet ${index + 1}`,
      path: relationships.get(relationshipId) || fallbackPath,
    };
  });
}

function pickWorkbookSheet(workbookSheets, mode) {
  return [...workbookSheets]
    .filter((sheet) => sheet.header?.mode === mode)
    .sort((left, right) => scoreWorkbookSheet(right, mode) - scoreWorkbookSheet(left, mode))[0] || null;
}

function scoreWorkbookSheet(sheet, mode) {
  const normalizedName = normalizeWorkbookHeaderValue(sheet.name);
  const preHeaderRecords = sheet.records.slice(0, (sheet.header?.recordIndex || 0) + 1);
  let score = sheet.records.length;

  if (normalizedName.includes(mode === "skill" ? "skill" : "theory")) {
    score += 40;
  }
  if (mode === "skill" && normalizedName.includes("practical")) {
    score += 10;
  }
  if (mode === "theory" && (normalizedName.includes("knowledge") || normalizedName.includes("theory"))) {
    score += 10;
  }
  if (/\(\d+\)/.test(sheet.name)) {
    score -= 20;
  }
  if (preHeaderRecords.some((record) => record.values.some((cell) => normalizeWorkbookHeaderValue(cell) === "nameofiti"))) {
    score += 100;
  }
  if (preHeaderRecords.some((record) => record.values.some((cell) => normalizeWorkbookHeaderValue(cell).includes("splitupsyllabus")))) {
    score += 40;
  }

  return score;
}

function findWorkbookHeaderDescriptor(records) {
  for (let index = 0; index < records.length; index += 1) {
    const normalizedRow = records[index].values.map((cell) => normalizeWorkbookHeaderValue(cell));
    const skillColumns = buildWorkbookColumnIndexes(normalizedRow, {
      year: ["year"],
      month: ["month"],
      week: ["weekno", "week"],
      outcomeNo: ["outcomeno"],
      outcomeName: ["outcomename"],
      jobNo: ["jobno"],
      jobName: ["jobname"],
      taskNo: ["taskno"],
      taskName: ["taskname"],
    });
    if (hasWorkbookColumns(skillColumns, ["year", "month", "week", "outcomeNo", "outcomeName", "jobNo", "jobName", "taskNo", "taskName"])) {
      return {
        mode: "skill",
        recordIndex: index,
        rowNumber: records[index].rowNumber,
        columns: skillColumns,
      };
    }

    const theoryColumns = buildWorkbookColumnIndexes(normalizedRow, {
      year: ["year"],
      month: ["month"],
      week: ["weekno", "week"],
      outcomeNo: ["outcomeno"],
      outcomeName: ["outcomename"],
      lessonNo: ["lessonno"],
      lessonName: ["lessonname"],
      topicNo: ["topicno"],
      topicName: ["topicname"],
    });
    if (hasWorkbookColumns(theoryColumns, ["year", "month", "week", "outcomeNo", "outcomeName", "lessonNo", "lessonName", "topicNo", "topicName"])) {
      return {
        mode: "theory",
        recordIndex: index,
        rowNumber: records[index].rowNumber,
        columns: theoryColumns,
      };
    }
  }

  return null;
}

function buildWorkbookColumnIndexes(normalizedRow, aliases) {
  return Object.fromEntries(
    Object.entries(aliases).map(([key, choices]) => [
      key,
      normalizedRow.findIndex((cell) => choices.includes(cell)),
    ]),
  );
}

function hasWorkbookColumns(columns, requiredKeys) {
  return requiredKeys.every((key) => Number.isInteger(columns[key]) && columns[key] >= 0);
}

function extractWorkbookMeta(skillSheet, theorySheet, fileName) {
  const meta = {
    ...BASE_DATA.meta,
    sourceWorkbook: fileName,
    sourceSheets: [skillSheet.name, theorySheet.name],
  };

  applyWorkbookMeta(meta, skillSheet, "skill");
  applyWorkbookMeta(meta, theorySheet, "theory");
  return normalizeImportedProgramMeta(meta, BASE_DATA.meta);
}

function applyWorkbookMeta(meta, sheet, mode) {
  const rows = sheet.records
    .slice(0, Math.max(8, (sheet.header?.recordIndex || 0) + 1))
    .map((record) => record.values.map((cell) => collapseWorksheetText(cell)));

  rows.forEach((row) => {
    const normalized = row.map((cell) => normalizeWorkbookHeaderValue(cell));
    const rowText = row.filter(Boolean).join(" ").trim();

    if (!meta.department && /industrial training department/i.test(rowText)) {
      meta.department = row.find(Boolean) || meta.department;
    }
    if (mode === "skill" && !meta.skillTitle && /professional skill/i.test(rowText)) {
      meta.skillTitle = row.find(Boolean) || meta.skillTitle;
    }
    if (mode === "theory" && !meta.theoryTitle && /professional knowledge/i.test(rowText)) {
      meta.theoryTitle = row.find(Boolean) || meta.theoryTitle;
    }

    normalized.forEach((cell, index) => {
      if (cell === "nameofiti") {
        meta.institution = findNextNonEmptyValue(row, index + 1) || meta.institution;
      }
      if (cell === "trade") {
        meta.trade = findNextNonEmptyValue(row, index + 1) || meta.trade;
      }
      if (cell === "nsqflevel") {
        meta.nsqfLevel = findNextNonEmptyValue(row, index + 1) || meta.nsqfLevel;
      }
      if (cell === "subject") {
        const subjectValue = findNextNonEmptyValue(row, index + 1);
        if (subjectValue) {
          if (mode === "skill") {
            meta.skillSubject = subjectValue;
          } else {
            meta.theorySubject = subjectValue;
          }
        }
      }
    });

    if (normalized.includes("nameofiti") && normalized.includes("year")) {
      const sessionValue = findNextNonEmptyValue(row, normalized.lastIndexOf("year") + 1);
      if (sessionValue) {
        meta.session = sessionValue;
      }
    }

    if (normalized.includes("subject") && normalized.includes("year")) {
      const trainingYearValue = findNextNonEmptyValue(row, normalized.lastIndexOf("year") + 1);
      if (trainingYearValue) {
        meta.trainingYear = trainingYearValue;
      }
    }
  });
}

function parseWorkbookEntries(sheet, mode) {
  if (!sheet.header) {
    return [];
  }

  const context = {
    year: "",
    monthKey: "",
    monthLabel: "",
    weekLabel: "",
    outcomeNo: "",
    outcomeName: "",
    jobNo: "",
    jobName: "",
    lessonNo: "",
    lessonName: "",
  };
  const entries = [];

  sheet.records.slice(sheet.header.recordIndex + 1).forEach((record, index) => {
    const raw = readWorkbookRow(record.values, sheet.header.columns, mode);
    if (Object.values(raw).every((value) => !value)) {
      return;
    }

    const rawYear = raw.year;
    const rawMonth = raw.month;
    const rawWeek = raw.week;
    const assessmentLabel = detectWorkbookAssessmentLabel(raw, mode);
    const specialLabel = detectWorkbookSpecialLabel(raw, mode);
    const monthInfo = rawMonth
      ? normalizeMonthValue(rawMonth)
      : { monthKey: context.monthKey, monthLabel: context.monthLabel };

    if (rawYear) {
      context.year = rawYear;
    }
    if (monthInfo.monthKey) {
      context.monthKey = monthInfo.monthKey;
      context.monthLabel = monthInfo.monthLabel;
    }
    if (rawWeek && !(specialLabel && mode === "theory" && specialLabel === rawWeek && !looksLikeWeekValue(rawWeek))) {
      context.weekLabel = rawWeek;
    }

    const rowBase = {
      sheetRow: record.rowNumber || sheet.header.rowNumber + index + 1,
      year: rawYear || context.year,
      monthKey: monthInfo.monthKey,
      monthLabel: monthInfo.monthLabel,
      weekLabel: rawWeek || context.weekLabel,
    };

    if (specialLabel) {
      entries.push({
        ...rowBase,
        outcomeNo: "",
        outcomeName: "",
        isAssessment: false,
        isSpecial: true,
        specialLabel,
        assessmentLabel: "",
        ...(mode === "skill"
          ? { jobNo: "", jobName: "", taskNo: "", taskName: "" }
          : { lessonNo: "", lessonName: "", topicNo: "", topicName: "" }),
      });
      return;
    }

    if (assessmentLabel) {
      const assessmentOutcomeNo = raw.outcomeNo || extractOutcomeNumberFromAssessmentText(assessmentLabel) || context.outcomeNo;
      entries.push({
        ...rowBase,
        outcomeNo: assessmentOutcomeNo,
        outcomeName: assessmentLabel,
        isAssessment: true,
        isSpecial: false,
        specialLabel: "",
        assessmentLabel,
        ...(mode === "skill"
          ? { jobNo: "", jobName: "", taskNo: "", taskName: "" }
          : { lessonNo: "", lessonName: "", topicNo: "", topicName: "" }),
      });
      return;
    }

    if (raw.outcomeNo) {
      context.outcomeNo = raw.outcomeNo;
    }
    if (raw.outcomeName) {
      context.outcomeName = raw.outcomeName;
    }

    if (mode === "skill") {
      if (raw.jobNo) {
        context.jobNo = raw.jobNo;
      }
      if (raw.jobName) {
        context.jobName = raw.jobName;
      }

      const taskNo = raw.taskNo;
      const taskName = raw.taskName;
      if (!context.outcomeNo || !context.outcomeName || !taskNo || !taskName) {
        return;
      }

      entries.push({
        ...rowBase,
        outcomeNo: context.outcomeNo,
        outcomeName: context.outcomeName,
        isAssessment: false,
        isSpecial: false,
        specialLabel: "",
        jobNo: raw.jobNo || context.jobNo,
        jobName: raw.jobName || context.jobName,
        taskNo,
        taskName,
        assessmentLabel: "",
      });
      return;
    }

    if (raw.lessonNo) {
      context.lessonNo = raw.lessonNo;
    }
    if (raw.lessonName) {
      context.lessonName = raw.lessonName;
    }

    const topicNo = raw.topicNo;
    const topicName = raw.topicName;
    if (!context.outcomeNo || !context.outcomeName || !topicNo || !topicName) {
      return;
    }

    entries.push({
      ...rowBase,
      outcomeNo: context.outcomeNo,
      outcomeName: context.outcomeName,
      isAssessment: false,
      isSpecial: false,
      specialLabel: "",
      lessonNo: raw.lessonNo || context.lessonNo,
      lessonName: raw.lessonName || context.lessonName,
      topicNo,
      topicName,
      assessmentLabel: "",
    });
  });

  return entries;
}

function readWorkbookRow(values, columns, mode) {
  const base = {
    year: collapseWorksheetText(values[columns.year]),
    month: collapseWorksheetText(values[columns.month]),
    week: collapseWorksheetText(values[columns.week]),
    outcomeNo: collapseWorksheetText(values[columns.outcomeNo]),
    outcomeName: collapseWorksheetText(values[columns.outcomeName]),
  };

  if (mode === "skill") {
    return {
      ...base,
      jobNo: collapseWorksheetText(values[columns.jobNo]),
      jobName: collapseWorksheetText(values[columns.jobName]),
      taskNo: collapseWorksheetText(values[columns.taskNo]),
      taskName: collapseWorksheetText(values[columns.taskName]),
    };
  }

  return {
    ...base,
    lessonNo: collapseWorksheetText(values[columns.lessonNo]),
    lessonName: collapseWorksheetText(values[columns.lessonName]),
    topicNo: collapseWorksheetText(values[columns.topicNo]),
    topicName: collapseWorksheetText(values[columns.topicName]),
  };
}

function detectWorkbookAssessmentLabel(raw, mode) {
  const label = collapseWorksheetText(raw.outcomeName);
  if (!label || !/^assessment\b/i.test(label)) {
    return "";
  }

  if (mode === "skill") {
    return !raw.jobNo && !raw.jobName && !raw.taskNo && !raw.taskName ? label : "";
  }

  return !raw.lessonNo && !raw.lessonName && !raw.topicNo && !raw.topicName ? label : "";
}

function detectWorkbookSpecialLabel(raw, mode) {
  if (mode === "skill") {
    if (
      raw.outcomeNo &&
      !looksLikeStructuredCode(raw.outcomeNo) &&
      !raw.outcomeName &&
      !raw.jobNo &&
      !raw.jobName &&
      !raw.taskNo &&
      !raw.taskName
    ) {
      return raw.outcomeNo;
    }

    return "";
  }

  if (
    raw.week &&
    !looksLikeWeekValue(raw.week) &&
    !raw.outcomeNo &&
    !raw.outcomeName &&
    !raw.lessonNo &&
    !raw.lessonName &&
    !raw.topicNo &&
    !raw.topicName
  ) {
    return raw.week;
  }

  return "";
}

function extractOutcomeNumberFromAssessmentText(text) {
  const matched = String(text || "").match(/outcome\s*no\.?\s*(\d+(?:\.\d+)*)/i);
  return matched?.[1] || "";
}

function looksLikeStructuredCode(value) {
  return /^\d+(?:\.\d+)*$/.test(String(value || "").trim());
}

function looksLikeWeekValue(value) {
  return /^\d+(?:\s*,\s*\d+)*$/.test(String(value || "").trim());
}

function findNextNonEmptyValue(row, startIndex) {
  for (let index = startIndex; index < row.length; index += 1) {
    const value = collapseWorksheetText(row[index]);
    if (value) {
      return value;
    }
  }
  return "";
}

function normalizeWorkbookHeaderValue(value) {
  return collapseWorksheetText(value).toLowerCase().replace(/[^a-z0-9]+/g, "");
}

function collapseWorksheetText(value) {
  return String(value ?? "")
    .replace(/\r?\n/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function readZipDirectory(bytes) {
  const eocdOffset = findZipEndOfCentralDirectory(bytes);
  if (eocdOffset < 0) {
    throw new Error("The selected file is not a valid Excel workbook.");
  }

  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const entryCount = view.getUint16(eocdOffset + 10, true);
  const centralOffset = view.getUint32(eocdOffset + 16, true);
  const archive = new Map();
  let cursor = centralOffset;

  for (let index = 0; index < entryCount; index += 1) {
    if (view.getUint32(cursor, true) !== 0x02014b50) {
      break;
    }

    const compressionMethod = view.getUint16(cursor + 10, true);
    const compressedSize = view.getUint32(cursor + 20, true);
    const fileNameLength = view.getUint16(cursor + 28, true);
    const extraLength = view.getUint16(cursor + 30, true);
    const commentLength = view.getUint16(cursor + 32, true);
    const localHeaderOffset = view.getUint32(cursor + 42, true);
    const fileNameBytes = bytes.slice(cursor + 46, cursor + 46 + fileNameLength);
    const fileName = decodeUtf8(fileNameBytes);

    archive.set(fileName, {
      fileName,
      compressionMethod,
      compressedSize,
      localHeaderOffset,
    });

    cursor += 46 + fileNameLength + extraLength + commentLength;
  }

  return archive;
}

function findZipEndOfCentralDirectory(bytes) {
  for (
    let index = Math.max(0, bytes.length - 22);
    index >= Math.max(0, bytes.length - 65557);
    index -= 1
  ) {
    if (
      bytes[index] === 0x50 &&
      bytes[index + 1] === 0x4b &&
      bytes[index + 2] === 0x05 &&
      bytes[index + 3] === 0x06
    ) {
      return index;
    }
  }

  return -1;
}

function normalizeWorksheetPath(target) {
  const cleaned = String(target || "").replace(/^\/+/, "");
  return cleaned.startsWith("xl/") ? cleaned : `xl/${cleaned}`;
}

async function readZipEntryText(bytes, entry) {
  const dataBytes = await extractZipEntry(bytes, entry);
  return decodeUtf8(dataBytes);
}

async function extractZipEntry(bytes, entry) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const localOffset = entry.localHeaderOffset;
  if (view.getUint32(localOffset, true) !== 0x04034b50) {
    throw new Error("The workbook ZIP header is invalid.");
  }

  const fileNameLength = view.getUint16(localOffset + 26, true);
  const extraLength = view.getUint16(localOffset + 28, true);
  const dataStart = localOffset + 30 + fileNameLength + extraLength;
  const compressed = bytes.slice(dataStart, dataStart + entry.compressedSize);

  if (entry.compressionMethod === 0) {
    return compressed;
  }

  if (entry.compressionMethod === 8) {
    if (typeof DecompressionStream === "undefined") {
      throw new Error("This browser cannot read zipped Excel files.");
    }
    const stream = new Blob([compressed]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  throw new Error(`Unsupported Excel compression method: ${entry.compressionMethod}`);
}

function parseSharedStrings(xmlText) {
  const doc = parseXml(xmlText);
  return getElementsByLocalName(doc, "si").map((node) => getNodeText(node).replace(/\r?\n/g, " ").trim());
}

function parseWorksheetRecords(xmlText, sharedStrings) {
  const doc = parseXml(xmlText);
  return getElementsByLocalName(doc, "row")
    .map((rowNode) => {
      const values = [];
      getElementsByLocalName(rowNode, "c").forEach((cellNode) => {
        const reference = cellNode.getAttribute("r") || "";
        const columnIndex = cellRefToColumnIndex(reference);
        values[columnIndex] = parseWorksheetCellValue(cellNode, sharedStrings);
      });

      while (values.length && values[values.length - 1] === "") {
        values.pop();
      }

      return {
        rowNumber: Number.parseInt(rowNode.getAttribute("r") || "0", 10) || 0,
        values: values.map((value) => String(value || "").trim()),
      };
    })
    .filter((record) => record.values.length);
}

function parseWorksheetCellValue(cellNode, sharedStrings) {
  const type = cellNode.getAttribute("t") || "";

  if (type === "inlineStr") {
    return getNodeText(cellNode);
  }

  if (type === "s") {
    const valueNode = getElementsByLocalName(cellNode, "v")[0];
    const index = Number(valueNode?.textContent || 0);
    return sharedStrings[index] || "";
  }

  if (type === "b") {
    const valueNode = getElementsByLocalName(cellNode, "v")[0];
    return valueNode?.textContent === "1" ? "TRUE" : "FALSE";
  }

  const valueNode = getElementsByLocalName(cellNode, "v")[0];
  return valueNode?.textContent || "";
}

function cellRefToColumnIndex(reference) {
  const letters = (reference.match(/[A-Z]+/i) || ["A"])[0].toUpperCase();
  let index = 0;
  for (let pointer = 0; pointer < letters.length; pointer += 1) {
    index = index * 26 + (letters.charCodeAt(pointer) - 64);
  }
  return Math.max(0, index - 1);
}

function parseXml(text) {
  return new DOMParser().parseFromString(text, "application/xml");
}

function getElementsByLocalName(root, name) {
  return Array.from(root.getElementsByTagNameNS("*", name));
}

function getNodeText(node) {
  return getElementsByLocalName(node, "t")
    .map((textNode) => textNode.textContent || "")
    .join("");
}

function decodeUtf8(bytes) {
  return new TextDecoder("utf-8").decode(bytes);
}

function serializeSkillEntries(entries) {
  const rows = [
    SKILL_ENTRY_COLUMNS.join("\t"),
    ...entries
      .filter((item) => !item.isSpecial)
      .sort((left, right) => left.sheetRow - right.sheetRow)
      .map((item) => [
        item.sheetRow,
        item.year,
        item.monthLabel,
        item.weekLabel,
        item.outcomeNo,
        item.outcomeName,
        item.isAssessment ? "assessment" : "job",
        item.jobNo,
        item.jobName,
        item.taskNo,
        item.taskName,
        item.assessmentLabel,
      ].map(escapeTsvCell).join("\t")),
  ];

  return rows.join("\n");
}

function serializeTheoryEntries(entries) {
  const rows = [
    THEORY_ENTRY_COLUMNS.join("\t"),
    ...entries
      .filter((item) => !item.isSpecial)
      .sort((left, right) => left.sheetRow - right.sheetRow)
      .map((item) => [
        item.sheetRow,
        item.year,
        item.monthLabel,
        item.weekLabel,
        item.outcomeNo,
        item.outcomeName,
        item.lessonNo,
        item.lessonName,
        item.topicNo,
        item.topicName,
      ].map(escapeTsvCell).join("\t")),
  ];

  return rows.join("\n");
}

function parseSkillEntryText(text) {
  const rows = parseDataEntryRows(text);
  if (!rows.length) {
    throw new Error("Professional Skill data entry is empty.");
  }

  return rows
    .map((columns, index) => buildSkillEntry(columns, index))
    .filter(Boolean);
}

function parseTheoryEntryText(text) {
  const rows = parseDataEntryRows(text);
  if (!rows.length) {
    throw new Error("Professional Knowledge data entry is empty.");
  }

  return rows
    .map((columns, index) => buildTheoryEntry(columns, index))
    .filter(Boolean);
}

function parseDataEntryRows(text) {
  const lines = String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trimEnd())
    .filter((line) => line.trim().length > 0);

  if (!lines.length) {
    return [];
  }

  const rows = lines.map((line) => line.split("\t").map((cell) => cell.trim()));
  const firstRow = rows[0].map((cell) => cell.toLowerCase());
  if (firstRow.includes("sheet_row")) {
    rows.shift();
  }

  return rows;
}

function buildSkillEntry(columns, index) {
  const [
    sheetRowValue = "",
    year = "",
    monthValue = "",
    week = "",
    outcomeNo = "",
    outcomeName = "",
    rowType = "",
    jobNo = "",
    jobName = "",
    taskNo = "",
    taskName = "",
    assessmentLabel = "",
  ] = columns;

  const monthInfo = normalizeMonthValue(monthValue);
  if (!monthInfo.monthKey) {
    throw new Error(`Professional Skill row ${index + 2} has an invalid month value.`);
  }

  const normalizedRowType = String(rowType || "").trim().toLowerCase();
  const isAssessment = normalizedRowType === "assessment" || (!jobNo && !taskNo && Boolean(assessmentLabel));
  const sheetRow = normalizeSheetRow(sheetRowValue, index);

  if (!String(outcomeNo || "").trim() || !String(outcomeName || "").trim()) {
    return null;
  }

  if (!isAssessment && !String(jobNo || "").trim()) {
    return null;
  }

  return {
    sheetRow,
    year: String(year || "").trim(),
    monthKey: monthInfo.monthKey,
    monthLabel: monthInfo.monthLabel,
    weekLabel: String(week || "").trim(),
    outcomeNo: String(outcomeNo || "").trim(),
    outcomeName: String(outcomeName || "").trim(),
    isAssessment,
    isSpecial: false,
    specialLabel: "",
    jobNo: isAssessment ? "" : String(jobNo || "").trim(),
    jobName: isAssessment ? "" : String(jobName || "").trim(),
    taskNo: isAssessment ? "" : String(taskNo || "").trim(),
    taskName: isAssessment ? "" : String(taskName || "").trim(),
    assessmentLabel: isAssessment ? String(assessmentLabel || `Assessment for Outcome No. ${outcomeNo}`).trim() : "",
  };
}

function buildTheoryEntry(columns, index) {
  const [
    sheetRowValue = "",
    year = "",
    monthValue = "",
    week = "",
    outcomeNo = "",
    outcomeName = "",
    lessonNo = "",
    lessonName = "",
    topicNo = "",
    topicName = "",
  ] = columns;

  const monthInfo = normalizeMonthValue(monthValue);
  if (!monthInfo.monthKey) {
    throw new Error(`Professional Knowledge row ${index + 2} has an invalid month value.`);
  }

  if (!String(outcomeNo || "").trim() || !String(outcomeName || "").trim() || !String(topicNo || "").trim()) {
    return null;
  }

  return {
    sheetRow: normalizeSheetRow(sheetRowValue, index),
    year: String(year || "").trim(),
    monthKey: monthInfo.monthKey,
    monthLabel: monthInfo.monthLabel,
    weekLabel: String(week || "").trim(),
    outcomeNo: String(outcomeNo || "").trim(),
    outcomeName: String(outcomeName || "").trim(),
    isAssessment: false,
    isSpecial: false,
    specialLabel: "",
    lessonNo: String(lessonNo || "").trim(),
    lessonName: String(lessonName || "").trim(),
    topicNo: String(topicNo || "").trim(),
    topicName: String(topicName || "").trim(),
    assessmentLabel: "",
  };
}

function buildSkillTotals(entries) {
  const activeMonths = new Set();
  const outcomes = new Set();
  const jobs = new Set();
  let assessments = 0;
  let tasks = 0;

  entries.forEach((item) => {
    if (item.monthKey) {
      activeMonths.add(item.monthKey);
    }
    if (item.outcomeNo) {
      outcomes.add(item.outcomeNo);
    }
    if (item.isAssessment) {
      assessments += 1;
      return;
    }
    if (item.jobNo) {
      jobs.add(`${item.outcomeNo}::${item.jobNo}`);
    }
    if (item.taskNo) {
      tasks += 1;
    }
  });

  return {
    outcomes: outcomes.size,
    assessments,
    activeMonths: activeMonths.size,
    jobs: jobs.size,
    tasks,
  };
}

function buildTheoryTotals(entries) {
  const activeMonths = new Set();
  const outcomes = new Set();
  const lessons = new Set();
  let assessments = 0;
  let topics = 0;

  entries.forEach((item) => {
    if (item.monthKey) {
      activeMonths.add(item.monthKey);
    }
    if (item.outcomeNo) {
      outcomes.add(item.outcomeNo);
    }
    if (item.lessonNo) {
      lessons.add(`${item.outcomeNo}::${item.lessonNo}`);
    }
    if (item.isAssessment) {
      assessments += 1;
      return;
    }
    if (item.topicNo) {
      topics += 1;
    }
  });

  return {
    outcomes: outcomes.size,
    assessments,
    lessons: lessons.size,
    topics,
    activeMonths: activeMonths.size,
  };
}

function buildSkillMonths(entries) {
  const assessmentCounts = Object.fromEntries(PREVIEW_MONTHS.map(([monthKey]) => [monthKey, 0]));
  const yearByMonth = {};

  entries.forEach((item) => {
    if (item.year && !yearByMonth[item.monthKey]) {
      yearByMonth[item.monthKey] = item.year;
    }
    if (item.isAssessment && assessmentCounts[item.monthKey] !== undefined) {
      assessmentCounts[item.monthKey] += 1;
    }
  });

  return BASE_DATA.months.map((month) => ({
    monthKey: month.key,
    monthLabel: month.label,
    year: yearByMonth[month.key] || "",
    weeks: [],
    anticipated: {
      outcomes: 0,
      assessments: assessmentCounts[month.key] || 0,
      jobs: 0,
      tasks: 0,
      lessons: 0,
      topics: 0,
    },
  }));
}

function buildTheoryMonths(entries) {
  const lessonEndMonth = new Map();
  const assessmentCounts = Object.fromEntries(PREVIEW_MONTHS.map(([monthKey]) => [monthKey, 0]));
  const yearByMonth = {};

  entries.forEach((item) => {
    if (item.year && !yearByMonth[item.monthKey]) {
      yearByMonth[item.monthKey] = item.year;
    }
    if (item.isAssessment && assessmentCounts[item.monthKey] !== undefined) {
      assessmentCounts[item.monthKey] += 1;
      return;
    }
    if (item.lessonNo) {
      updateLatestMonth(lessonEndMonth, `${item.outcomeNo}::${item.lessonNo}`, item.monthKey);
    }
  });

  const lessonCounts = Object.fromEntries(PREVIEW_MONTHS.map(([monthKey]) => [monthKey, 0]));
  lessonEndMonth.forEach((monthKey) => {
    if (lessonCounts[monthKey] !== undefined) {
      lessonCounts[monthKey] += 1;
    }
  });

  return BASE_DATA.months.map((month) => ({
    monthKey: month.key,
    monthLabel: month.label,
    year: yearByMonth[month.key] || "",
    weeks: [],
    anticipated: {
      outcomes: 0,
      assessments: assessmentCounts[month.key] || 0,
      jobs: 0,
      tasks: 0,
      lessons: lessonCounts[month.key] || 0,
      topics: 0,
    },
  }));
}

function normalizeMonthValue(value) {
  const rawValue = String(value || "").trim();
  if (!rawValue) {
    return { monthKey: "", monthLabel: "" };
  }

  const normalized = rawValue.toUpperCase();
  const directMatch = BASE_DATA.months.find((month) => month.key === normalized);
  if (directMatch) {
    return { monthKey: directMatch.key, monthLabel: directMatch.label };
  }

  const labelMatch = BASE_DATA.months.find((month) => month.label.toUpperCase() === normalized);
  if (labelMatch) {
    return { monthKey: labelMatch.key, monthLabel: labelMatch.label };
  }

  const shortMatch = PREVIEW_MONTHS.find(([, shortLabel]) => shortLabel.toUpperCase() === normalized);
  if (shortMatch) {
    return {
      monthKey: shortMatch[0],
      monthLabel: BASE_DATA.months.find((month) => month.key === shortMatch[0])?.label || shortMatch[1],
    };
  }

  return { monthKey: "", monthLabel: "" };
}

function normalizeSheetRow(value, index) {
  const parsed = Number.parseInt(String(value || "").trim(), 10);
  return Number.isFinite(parsed) ? parsed : index + 1;
}

function escapeTsvCell(value) {
  return String(value ?? "").replace(/\r?\n/g, " ").trim();
}

function getBuilderId(value, prefix) {
  const rawValue = String(value || "").trim();
  return rawValue || createLocalId(prefix);
}

function createLocalId(prefix) {
  localIdCounter += 1;
  return `${prefix}-${Date.now().toString(36)}-${localIdCounter.toString(36)}`;
}

function toKebabCase(value) {
  return String(value || "")
    .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
    .replace(/[_\s]+/g, "-")
    .toLowerCase();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function applyEmbeddedMode() {
  document.documentElement.classList.toggle("is-embedded", EMBEDDED_MODE);
  document.body.classList.toggle("is-embedded", EMBEDDED_MODE);
}

function applyMonthlyPlanSync(payload) {
  state.linkedMonthlyPlan = normalizeLinkedMonthlyPlan(payload);

  if (state.linkedMonthlyPlan.currentMonthKey in PREVIEW_MONTH_INDEX) {
    state.monthTabs.skill = state.linkedMonthlyPlan.currentMonthKey;
    state.monthTabs.theory = state.linkedMonthlyPlan.currentMonthKey;
  }

  syncOutcomeFilterWithMonth("skill");
  syncOutcomeFilterWithMonth("theory");

  renderAllPanels();
}

function normalizeLinkedMonthlyPlan(value) {
  const next = createEmptyLinkedMonthlyPlan();
  if (!value || typeof value !== "object") {
    return next;
  }

  next.currentMonthValue = String(value.currentMonthValue || "");
  next.currentMonthKey = String(value.currentMonthKey || "");
  next.tradeValue = String(value.tradeValue || "");
  next.institution = String(value.institution || "");
  next.tradeNameShort = String(value.tradeNameShort || "");
  next.session = String(value.session || "");
  next.shift = String(value.shift || "");
  next.unit = String(value.unit || "");

  if (!value.months || typeof value.months !== "object") {
    return next;
  }

  Object.entries(value.months).forEach(([monthValue, monthData]) => {
    const monthKey = String(monthData?.monthKey || getMonthKeyFromDate(`${monthValue}-01`) || "");
    if (!monthKey) {
      return;
    }

    next.months[monthValue] = {
      monthKey,
      proposedDates: {
        skill: normalizeLinkedDateMap(monthData?.proposedDates?.skill),
        theory: normalizeLinkedDateMap(monthData?.proposedDates?.theory),
        skillAssessments: normalizeLinkedDateMap(monthData?.proposedDates?.skillAssessments),
      },
      conductedDates: {
        skill: normalizeLinkedDateMap(monthData?.conductedDates?.skill),
        theory: normalizeLinkedDateMap(monthData?.conductedDates?.theory),
      },
    };
  });

  return next;
}

function normalizeLinkedDateMap(value) {
  const next = {};
  if (!value || typeof value !== "object") {
    return next;
  }

  Object.entries(value).forEach(([key, dateValue]) => {
    const code = String(key || "").trim();
    const isoDate = String(dateValue || "").trim();
    if (!code || !isoDate) {
      return;
    }

    next[code] = isoDate;
  });

  return next;
}

function notifyPlannerReady() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "program-planner:ready", app: "program-planner", height: getPlannerHeight() },
    "*",
  );
}

function reportPlannerHeight() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "program-planner:height", app: "program-planner", height: getPlannerHeight() },
    "*",
  );
}

function getPlannerHeight() {
  const appShell = dom.appShell;
  if (appShell instanceof HTMLElement) {
    const styles = window.getComputedStyle(appShell);
    const marginTop = Number.parseFloat(styles.marginTop) || 0;
    const marginBottom = Number.parseFloat(styles.marginBottom) || 0;
    return Math.ceil(appShell.getBoundingClientRect().height + marginTop + marginBottom);
  }

  return Math.max(
    document.documentElement?.scrollHeight || 0,
    document.body?.scrollHeight || 0,
    document.documentElement?.offsetHeight || 0,
    document.body?.offsetHeight || 0,
  );
}

window.addEventListener("load", () => {
  notifyPlannerReady();
});

window.addEventListener("resize", () => {
  reportPlannerHeight();
});

if (typeof ResizeObserver === "function") {
  const plannerObserver = new ResizeObserver(() => {
    reportPlannerHeight();
  });
  if (dom.appShell instanceof HTMLElement) {
    plannerObserver.observe(dom.appShell);
  } else {
    plannerObserver.observe(document.body);
  }
}
