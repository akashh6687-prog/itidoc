const appData = window.APP_DATA;
const storageKey = "annex-ii-site-state-v2";

const workbookName = document.querySelector("#workbookName");
const traineeCount = document.querySelector("#traineeCount");
const componentCount = document.querySelector("#componentCount");
const mainTabs = document.querySelector("#mainTabs");
const detailsPanel = document.querySelector("#detailsPanel");
const marksPanel = document.querySelector("#marksPanel");
const annexPanel = document.querySelector("#annexPanel");
const annex3Panel = document.querySelector("#annex3Panel");
const toerPanel = document.querySelector("#toerPanel");

const tabs = [
  { id: "details", label: "Trainee Details" },
  { id: "marks", label: "Mark Entry" },
  { id: "annex", label: "Annex II Format" },
  { id: "annex3", label: "Annex 3" },
  { id: "toer", label: "TOER" },
];

const annex3Template = [
  {
    groupNo: 1,
    parameter: "SAFETY CONCIOUSNESS",
    annex2Index: 0,
    rows: [
      { name: "DRESS CODE", max: 2, locked: true },
      { name: "USE PPE", max: 3, locked: true },
      { name: "APPLY/PRACTICE SAFETY", max: 10 },
    ],
  },
  {
    groupNo: 2,
    parameter: "WORKPLACE HYGIENE & ECONOMICAL USE OF MATERIALS",
    annex2Index: 1,
    rows: [
      { name: "MAINTAIN PERSONAL & WORKPLACE CLEANLINESS", max: 3 },
      { name: "DISPOSE SCRAP AS PER STANDARD PRACTICE", max: 2 },
      { name: "SELECT APPROPRIATE MATERIAL & MINIMIZE WASTAGE", max: 5 },
    ],
  },
  {
    groupNo: 3,
    parameter: "ATTENDANCE / PUNCTUALITY",
    annex2Index: 2,
    rows: [
      { name: "INITIATIVE", max: 3 },
      { name: "ACCOUNTABILITY", max: 3 },
      { name: "PARTICIPATE IN WORK", max: 4 },
    ],
  },
  {
    groupNo: 4,
    parameter: "ABILITY TO FOLLOW MANUALS / WRITTEN INSTRUCTIONS",
    annex2Index: 3,
    rows: [
      { name: "SELECT RIGHT MANUAL", max: 1 },
      { name: "SEARCH FOR APPROPRIATE TOPIC", max: 2 },
      { name: "READ & INTERPRET MANUAL", max: 2 },
    ],
  },
  {
    groupNo: 5,
    parameter: "APPLICATION OF KNOWLEDGE",
    annex2Index: 4,
    rows: [
      { name: "PLAN THE WORK", max: 4 },
      { name: "SELECT APPROPRIATE TOOLS & EQUIPMENT", max: 3 },
      { name: "REVIEW THE WORK", max: 3 },
    ],
  },
  {
    groupNo: 6,
    parameter: "SKILLS TO HANDLE TOOLS & EQUIPMENT",
    annex2Index: 5,
    rows: [
      { name: "HANDLE & USE TOOLS & EQUIPMENT", max: 4 },
      { name: "MAINTAIN SAFETY IN HANDLING", max: 3 },
      { name: "CARE & MAINTAIN", max: 3 },
    ],
  },
  {
    groupNo: 7,
    parameter: "SPEED IN DOING WORK",
    annex2Index: 6,
    rows: [
      { name: "PROPERLY SEQUENCE THE WORK", max: 3 },
      { name: "USE APPROPRIATE TECHNIQUE", max: 5 },
      { name: "REVIEW THE WORK DURING EXECUTION", max: 2 },
    ],
  },
  {
    groupNo: 8,
    parameter: "QUALITY IN WORKMANSHIP",
    annex2Index: 7,
    rows: [
      { name: "ACHIEVE WORK WITH HIGH ACCURACY", max: 7 },
      { name: "CONFORM TO REQUIREMENT", max: 3 },
      { name: "SATISFY THE PURPOSE", max: 5 },
    ],
  },
  {
    groupNo: 9,
    parameter: "VIVA",
    annex2Index: 8,
    rows: [
      { name: "RESPONSE WITH CLARITY", max: 5 },
      { name: "TECHNICAL UNDERSTANDING", max: 7 },
      { name: "CONSCIOUS TOWARDS JOB ROLE", max: 3 },
    ],
  },
];

let activeTab = "details";
let state = loadState();
let selectedAnnex3Index = 0;

initialize();

function initialize() {
  workbookName.textContent = appData.workbookName;
  traineeCount.textContent = String(state.trainees.length);
  componentCount.textContent = String(state.components.length);

  renderTabs();
  renderPanels();
  window.addEventListener("resize", syncAnnexScale);
}

function renderTabs() {
  mainTabs.innerHTML = "";

  tabs.forEach((tab) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `tab-button${tab.id === activeTab ? " is-active" : ""}`;
    button.textContent = tab.label;
    button.addEventListener("click", () => {
      activeTab = tab.id;
      renderTabs();
      renderPanels();
    });
    mainTabs.appendChild(button);
  });
}

function renderPanels() {
  detailsPanel.classList.toggle("hidden", activeTab !== "details");
  marksPanel.classList.toggle("hidden", activeTab !== "marks");
  annexPanel.classList.toggle("hidden", activeTab !== "annex");
  annex3Panel.classList.toggle("hidden", activeTab !== "annex3");
  toerPanel.classList.toggle("hidden", activeTab !== "toer");

  renderDetailsPanel();
  renderMarksPanel();
  renderAnnexPanel();
  renderAnnex3Panel();
  renderToerPanel();
}

function renderDetailsPanel() {
  detailsPanel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 1</p>
        <h2 class="panel-title">Trainee master details</h2>
      </div>
      <p class="panel-note">Edit names and header information here. The Annex II tab updates live.</p>
    </div>

    <div class="details-layout">
      <div class="meta-editor">
        ${renderMetaField("assessor", "Assessor")}
        ${renderMetaField("yearEnrolment", "Year of enrolment")}
        ${renderMetaField("itiName", "ITI name and address")}
        ${renderMetaField("dateOfAssessment", "Date of assessment")}
        ${renderMetaField("industryName", "Industry name and address")}
        ${renderMetaField("assessmentLocation", "Assessment location")}
        ${renderMetaField("tradeName", "Trade name")}
        ${renderMetaField("examination", "Examination")}
        ${renderMetaField("durationOfTrade", "Duration of trade")}
        ${renderMetaField("instructorMiddle", "Instructor")}
        ${renderMetaField("principal", "Principal")}
        <div class="field-group" style="grid-column: 1 / -1;">
          <label for="learningOutcome">Learning outcome</label>
          <textarea id="learningOutcome" data-meta-key="learningOutcome">${escapeHtml(state.meta.learningOutcome)}</textarea>
        </div>
      </div>

      <div class="table-wrap">
        <table class="trainee-table">
          <thead>
            <tr>
              <th>SL</th>
              <th>Adm No</th>
              <th>Name</th>
              <th>Father's Name</th>
            </tr>
          </thead>
          <tbody>
            ${state.trainees.map(renderTraineeEditorRow).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;

  detailsPanel.querySelectorAll("[data-meta-key]").forEach((field) => {
    field.addEventListener("input", handleMetaInput);
  });

  detailsPanel.querySelectorAll("[data-trainee-index]").forEach((field) => {
    field.addEventListener("input", handleTraineeInput);
  });
}

function renderAnnexPanel() {
  annexPanel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 3</p>
        <h2 class="panel-title">Annex II exact-style marks sheet</h2>
      </div>
      <div class="panel-actions">
        <p class="panel-note">Component marks are generated automatically from the total mark entry tab.</p>
        <button type="button" class="print-button" id="printAnnexBtn">Print A4 Landscape</button>
      </div>
    </div>

    <div class="annex-paper" id="annexPrintArea">
      <div class="annex-fit-stage" id="annexFitStage">
        <div class="annex-fit-content" id="annexFitContent">
      <table class="annex-table" id="annexTable">
        <colgroup>
          <col style="width: 90px;" />
          <col style="width: 220px;" />
          <col style="width: 210px;" />
          ${state.components.map(() => '<col style="width: 70px;" />').join("")}
          <col style="width: 90px;" />
          <col style="width: 68px;" />
        </colgroup>
        <tbody>
          <tr class="title-row">
            <td colspan="14">${escapeHtml(state.meta.title)}</td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.assessorLabel)}</td>
            <td colspan="5" class="annex-value"><input class="annex-inline-input" data-meta-key="assessor" value="${escapeAttribute(state.meta.assessor)}" /></td>
            <td colspan="3" class="annex-label">${escapeHtml(appData.meta.yearLabel)}</td>
            <td colspan="4" class="annex-value"><input class="annex-inline-input" data-meta-key="yearEnrolment" value="${escapeAttribute(state.meta.yearEnrolment)}" /></td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.itiLabel)}</td>
            <td colspan="5" class="annex-value"><input class="annex-inline-input" data-meta-key="itiName" value="${escapeAttribute(state.meta.itiName)}" /></td>
            <td colspan="3" class="annex-label">${escapeHtml(appData.meta.dateLabel)}</td>
            <td colspan="4" class="annex-value"><input class="annex-inline-input" data-meta-key="dateOfAssessment" value="${escapeAttribute(state.meta.dateOfAssessment)}" /></td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.industryLabel)}</td>
            <td colspan="5" class="annex-value"><input class="annex-inline-input" data-meta-key="industryName" value="${escapeAttribute(state.meta.industryName)}" /></td>
            <td colspan="3" class="annex-label">${escapeHtml(appData.meta.locationLabel)}</td>
            <td colspan="4" class="annex-value"><input class="annex-inline-input" data-meta-key="assessmentLocation" value="${escapeAttribute(state.meta.assessmentLocation)}" /></td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.tradeLabel)}</td>
            <td colspan="2" class="annex-value"><input class="annex-inline-input" data-meta-key="tradeName" value="${escapeAttribute(state.meta.tradeName)}" /></td>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.examLabel)}</td>
            <td colspan="2" class="annex-value"><input class="annex-inline-input" data-meta-key="examination" value="${escapeAttribute(state.meta.examination)}" /></td>
            <td colspan="3" class="annex-label">${escapeHtml(appData.meta.durationLabel)}</td>
            <td colspan="3" class="annex-value"><input class="annex-inline-input" data-meta-key="durationOfTrade" value="${escapeAttribute(state.meta.durationOfTrade)}" /></td>
          </tr>
          <tr>
            <td colspan="2" class="annex-label">${escapeHtml(appData.meta.learningOutcomeLabel)}</td>
            <td colspan="12" class="annex-value"><input class="annex-inline-input" data-meta-key="learningOutcome" value="${escapeAttribute(state.meta.learningOutcome)}" /></td>
          </tr>
          <tr>
            <td rowspan="2" class="head-small">Adm No</td>
            <td colspan="2" class="head-small">MAXIMUM MARKS (TOTAL 100 MARKS)</td>
            ${state.components.map((component) => `<td class="head-small">${escapeHtml(String(component.maxMark))}</td>`).join("")}
            <td rowspan="2" class="head-small">Total Internal Assessment Marks</td>
            <td rowspan="2" class="head-small">Result (Y/N)</td>
          </tr>
          <tr>
            <td class="head-small">CANDIDATE NAME</td>
            <td class="head-small">FATHER'S/MOTHER'S NAME</td>
            ${state.components.map((component) => `<td><div class="vertical-text">${escapeHtml(component.name)}</div></td>`).join("")}
          </tr>
          ${state.trainees.map(renderAnnexRow).join("")}
          <tr class="signature-row">
            <td colspan="3"><div class="signature-designation">${escapeHtml(state.meta.instructorLeft)}</div></td>
            <td colspan="4"><div class="signature-designation"><input class="annex-inline-input" data-meta-key="instructorMiddle" value="${escapeAttribute(state.meta.instructorMiddle)}" /></div></td>
            <td colspan="7"><div class="signature-designation"><input class="annex-inline-input" data-meta-key="principal" value="${escapeAttribute(state.meta.principal)}" /></div></td>
          </tr>
        </tbody>
      </table>
        </div>
      </div>
    </div>
  `;

  annexPanel.querySelectorAll("[data-meta-key]").forEach((field) => {
    field.addEventListener("input", handleMetaInput);
  });

  annexPanel.querySelectorAll("[data-mark-index]").forEach((field) => {
    field.addEventListener("input", handleMarkInput);
  });

  const printButton = annexPanel.querySelector("#printAnnexBtn");
  if (printButton) {
    printButton.addEventListener("click", () => {
      window.print();
    });
  }

  syncAnnexScale();
}

function renderMarksPanel() {
  marksPanel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 2</p>
        <h2 class="panel-title">Total mark entry</h2>
      </div>
      <p class="panel-note">Enter total marks out of 100 and set any trainee-specific TOER time exceptions here.</p>
    </div>

    <div class="table-wrap">
      <table class="trainee-table">
        <thead>
          <tr>
            <th>SL</th>
            <th>Adm No</th>
            <th>Name</th>
            <th>Total Mark / 100</th>
            <th>Result</th>
            <th>Custom TOER Time</th>
            <th>Starting Time</th>
            <th>Finishing Time</th>
          </tr>
        </thead>
        <tbody>
          ${state.trainees.map((trainee, index) => renderMarkEntryRow(trainee, index)).join("")}
        </tbody>
      </table>
    </div>
  `;

  marksPanel.querySelectorAll("[data-total-index]").forEach((field) => {
    field.addEventListener("input", handleTotalMarkInput);
  });

  marksPanel.querySelectorAll("[data-toer-override-index]").forEach((field) => {
    field.addEventListener("change", handleToerOverrideToggle);
  });

  marksPanel.querySelectorAll("[data-toer-time-index]").forEach((field) => {
    field.addEventListener("input", handleToerTimeInput);
    field.addEventListener("change", handleToerTimeInput);
  });
}

function renderAnnex3Panel() {
  const trainee = state.trainees[selectedAnnex3Index] || state.trainees[0];
  if (!trainee) {
    annex3Panel.innerHTML = "";
    return;
  }

  const groups = buildAnnex3Groups(trainee);
  const grandTotal = groups.reduce((sum, group) => sum + group.total, 0);

  annex3Panel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 4</p>
        <h2 class="panel-title">Annex III detailed assessment sheet</h2>
      </div>
      <div class="panel-actions">
        <p class="panel-note">Each Annex II division is split into detailed component marks here.</p>
        <button type="button" class="print-button" id="downloadAnnex3Btn">Download Current PDF</button>
        <button type="button" class="print-button" id="downloadAllAnnex3Btn">Download Combined PDF</button>
      </div>
    </div>

    <div class="annex3-select-row">
      <div class="field-group">
        <label for="annex3TraineeSelect">Select trainee</label>
        <select id="annex3TraineeSelect">
          ${state.trainees.map((item, index) => `<option value="${index}"${index === selectedAnnex3Index ? " selected" : ""}>${escapeHtml(item.admNo)} - ${escapeHtml(item.name)}</option>`).join("")}
        </select>
      </div>
    </div>

    <div class="annex3-paper">
      <table class="annex3-table">
        <tbody>
          <tr>
            <td colspan="6" class="annex3-title">ANNEXURE - III</td>
          </tr>
          <tr>
            <td colspan="3" class="annex3-label">Name & Address of the Assessor</td>
            <td colspan="3" class="annex3-value">${escapeHtml(state.meta.assessor)}</td>
          </tr>
          <tr>
            <td colspan="3" class="annex3-label">Name & Address of I T I</td>
            <td colspan="3" class="annex3-value">${escapeHtml(state.meta.itiName)}</td>
          </tr>
          <tr>
            <td colspan="3" class="annex3-label">Subject Name</td>
            <td colspan="3" class="annex3-value">Trade Practical</td>
          </tr>
          <tr>
            <td colspan="3" class="annex3-label">Trade Name</td>
            <td colspan="3" class="annex3-value">${escapeHtml(state.meta.tradeName)}</td>
          </tr>
          <tr>
            <td colspan="2" class="annex3-label">Learning Outcome</td>
            <td colspan="4" class="annex3-value">${escapeHtml(state.meta.learningOutcome)}</td>
          </tr>
          <tr>
            <td class="annex3-subhead">Adm.No</td>
            <td colspan="2" class="annex3-subhead">Name of The Candidate</td>
            <td class="annex3-subhead">Academic Span</td>
            <td colspan="2" class="annex3-subhead">Date of Assessment</td>
          </tr>
          <tr>
            <td>${escapeHtml(trainee.admNo)}</td>
            <td colspan="2">${escapeHtml(trainee.name)}</td>
            <td>${escapeHtml(state.meta.yearEnrolment.replaceAll("-2027", "- 2027"))}</td>
            <td colspan="2">${escapeHtml(state.meta.dateOfAssessment)}</td>
          </tr>
          <tr>
            <td class="annex3-subhead">Sl No</td>
            <td class="annex3-subhead">ASSESSMENT PARAMETERS</td>
            <td colspan="2" class="annex3-subhead">COMPONENT OF ASSESSMENT PARAMETERS</td>
            <td class="annex3-subhead">MAX.MARKS BREAK-UP</td>
            <td class="annex3-subhead">MARKS AWARDED</td>
          </tr>
          ${groups.map(renderAnnex3Group).join("")}
          <tr class="annex3-grand">
            <td colspan="4" class="annex3-label">GRAND TOTAL</td>
            <td>100</td>
            <td>${grandTotal}</td>
          </tr>
          <tr class="annex3-sign-space">
            <td colspan="2"></td>
            <td colspan="2"></td>
            <td colspan="2"></td>
          </tr>
          <tr class="annex3-sign-label">
            <td colspan="2" class="annex3-label">Signature of the Candidate</td>
            <td colspan="2" class="annex3-label">Group Instructor</td>
            <td colspan="2" class="annex3-label">Signature, Name & Designation of Accessor</td>
          </tr>
        </tbody>
      </table>
    </div>
  `;

  const select = annex3Panel.querySelector("#annex3TraineeSelect");
  if (select) {
    select.addEventListener("change", (event) => {
      selectedAnnex3Index = Number(event.target.value);
      renderAnnex3Panel();
    });
  }

  const downloadCurrent = annex3Panel.querySelector("#downloadAnnex3Btn");
  if (downloadCurrent) {
    downloadCurrent.addEventListener("click", async () => {
      await downloadAnnex3PdfForCurrent();
    });
  }

  const downloadAll = annex3Panel.querySelector("#downloadAllAnnex3Btn");
  if (downloadAll) {
    downloadAll.addEventListener("click", async () => {
      await downloadCombinedAnnex3Pdf();
    });
  }
}

function renderToerPanel() {
  toerPanel.innerHTML = `
    <div class="panel-head">
      <div>
        <p class="section-kicker">Tab 5</p>
        <h2 class="panel-title">Trainer's Observation & Evidence Report</h2>
      </div>
      <div class="panel-actions">
        <p class="panel-note">Performance is calculated automatically from each trainee's total mark percentage.</p>
        <button type="button" class="print-button" id="downloadToerPdfBtn">Download Landscape PDF</button>
      </div>
    </div>

    <div class="toer-controls">
      <div class="toer-meta-grid">
        ${renderToerField("trainerAddress", "Trainer Name & Address")}
        ${renderToerField("unit", "Unit")}
        ${renderToerField("year", "Year")}
        ${renderToerField("shift", "Shift")}
        ${renderToerTimeField("defaultStartTime", "Default Starting Time")}
        ${renderToerTimeField("defaultEndTime", "Default Finishing Time")}
      </div>

      <div class="toer-evidence">
        <strong>Evidence Report Available</strong>
        ${renderEvidenceCheckbox("video", "Video")}
        ${renderEvidenceCheckbox("photo", "Photo")}
        ${renderEvidenceCheckbox("record", "Record")}
        ${renderEvidenceCheckbox("physical", "Physical")}
        ${renderEvidenceCheckbox("chart", "Chart Sheet")}
        <label>
          <span>Any Other</span>
          <input class="toer-other-input" data-toer-key="anyOther" value="${escapeAttribute(state.toer.anyOther)}" />
        </label>
      </div>
    </div>

    <div class="toer-paper">
      <table class="toer-table">
        <colgroup>
          <col style="width:58px;" />
          <col style="width:220px;" />
          <col style="width:110px;" />
          <col style="width:110px;" />
          <col style="width:58px;" />
          <col style="width:58px;" />
          <col style="width:58px;" />
          <col style="width:58px;" />
          <col style="width:78px;" />
          <col style="width:78px;" />
          <col style="width:78px;" />
          <col style="width:84px;" />
          <col style="width:78px;" />
          <col style="width:100px;" />
          <col style="width:92px;" />
        </colgroup>
        <tbody>
          <tr>
            <td colspan="15" class="toer-title">TRAINER'S OBSERVATION & EVIDENCE REPORT</td>
          </tr>
          <tr>
            <td colspan="4" class="toer-label">Name of Institute: ${escapeHtml(formatInstituteForToer(state.meta.itiName))}</td>
            <td colspan="11" class="toer-label">Trade: ${escapeHtml(formatTradeForToer(state.meta.tradeName))}</td>
          </tr>
          <tr>
            <td colspan="4" class="toer-label">Name & Address of the Trainer: ${escapeHtml(state.toer.trainerAddress)}</td>
            <td colspan="11" class="toer-label">Unit: ${escapeHtml(state.toer.unit)}&nbsp;&nbsp;&nbsp;&nbsp;Year: ${escapeHtml(state.toer.year)}</td>
          </tr>
          <tr>
            <td colspan="4"></td>
            <td colspan="11" class="toer-label">Shift : ${escapeHtml(state.toer.shift)}</td>
          </tr>
          <tr>
            <td colspan="3" class="toer-label">No. & Name of Learning Outcome:</td>
            <td colspan="12" class="toer-value">${escapeHtml(state.meta.learningOutcome)}</td>
          </tr>
          <tr>
            <td rowspan="2" class="toer-subhead">Sl. No.</td>
            <td rowspan="2" class="toer-subhead">Name of Trainee</td>
            <td rowspan="2" class="toer-subhead">Starting Time</td>
            <td rowspan="2" class="toer-subhead">Finishing Time</td>
            <td colspan="4" class="toer-subhead">Overall Performance</td>
            <td colspan="6" class="toer-subhead">Evidences available Remarks</td>
            <td rowspan="2" class="toer-subhead">Remarks</td>
          </tr>
          <tr>
            <td class="toer-subhead">VG</td>
            <td class="toer-subhead">G</td>
            <td class="toer-subhead">M</td>
            <td class="toer-subhead">P</td>
            <td class="toer-subhead">Video<br/>Y/N</td>
            <td class="toer-subhead">Photo<br/>Y/N</td>
            <td class="toer-subhead">Record<br/>Y/N</td>
            <td class="toer-subhead">Physical<br/>Y/N</td>
            <td class="toer-subhead">Chart<br/>Y/N</td>
            <td class="toer-subhead">Any other</td>
          </tr>
          ${state.trainees.map(renderToerRow).join("")}
          <tr class="toer-sign-space">
            <td colspan="4"></td>
            <td colspan="4"></td>
            <td colspan="5"></td>
            <td colspan="2"></td>
          </tr>
          <tr class="toer-sign-note">
            <td colspan="4" class="toer-label">VG- above 90%, G- 75-90 %, M- 60-75 %, P- Below 60%</td>
            <td colspan="4" class="toer-label">SIGN.OF VP/PRINCIPAL</td>
            <td colspan="5" class="toer-label">SIGN OF GI</td>
            <td colspan="2" class="toer-label">SIGN. OF TRAINER</td>
          </tr>
        </tbody>
      </table>
    </div>
  `;

  const downloadButton = toerPanel.querySelector("#downloadToerPdfBtn");
  if (downloadButton) {
    downloadButton.addEventListener("click", async () => {
      await downloadToerPdf();
    });
  }

  toerPanel.querySelectorAll("[data-toer-key]").forEach((field) => {
    field.addEventListener("input", handleToerMetaInput);
    field.addEventListener("change", handleToerMetaInput);
  });

  toerPanel.querySelectorAll("[data-toer-time-key]").forEach((field) => {
    field.addEventListener("input", handleToerDefaultTimeInput);
    field.addEventListener("change", handleToerDefaultTimeInput);
  });
}

function renderMetaField(key, label) {
  return `
    <div class="field-group">
      <label for="${key}">${escapeHtml(label)}</label>
      <input id="${key}" data-meta-key="${key}" value="${escapeAttribute(state.meta[key] || "")}" />
    </div>
  `;
}

function renderTraineeEditorRow(trainee, index) {
  return `
    <tr>
      <td>${index + 1}</td>
      <td><input data-trainee-index="${index}" data-field="admNo" value="${escapeAttribute(trainee.admNo)}" /></td>
      <td><input data-trainee-index="${index}" data-field="name" value="${escapeAttribute(trainee.name)}" /></td>
      <td><input data-trainee-index="${index}" data-field="fatherName" value="${escapeAttribute(trainee.fatherName)}" /></td>
    </tr>
  `;
}

function renderAnnexRow(trainee, traineeIndex) {
  const total = getTraineeTotal(trainee);
  const result = getResult(total);

  return `
    <tr class="marks-row">
      <td>${escapeHtml(trainee.admNo)}</td>
      <td class="name-cell">${escapeHtml(trainee.name)}</td>
      <td class="name-cell">${escapeHtml(trainee.fatherName)}</td>
      ${trainee.marks.map((mark, componentIndex) => `
        <td>
          <input
            class="marks-input"
            type="number"
            step="1"
            min="0"
            max="${escapeAttribute(String(state.components[componentIndex].maxMark))}"
            value="${escapeAttribute(formatMark(mark))}"
            data-mark-index="${traineeIndex}"
            data-component-index="${componentIndex}"
            readonly
          />
        </td>
      `).join("")}
      <td class="total-cell" data-total-index="${traineeIndex}">${formatMark(total)}</td>
      <td class="result-cell" data-result-index="${traineeIndex}">${escapeHtml(result)}</td>
    </tr>
  `;
}

function handleMetaInput(event) {
  const key = event.target.dataset.metaKey;
  state.meta[key] = event.target.value;
  persistState();
  syncMetaFields(key, event.target.value, event.target);
  renderAnnex3Panel();
  renderToerPanel();
}

function handleTraineeInput(event) {
  const index = Number(event.target.dataset.traineeIndex);
  const field = event.target.dataset.field;
  state.trainees[index][field] = event.target.value;
  persistState();
  renderAnnex3Panel();
  renderToerPanel();
}

function handleMarkInput(event) {
  event.preventDefault();
}

function handleTotalMarkInput(event) {
  const traineeIndex = Number(event.target.dataset.totalIndex);
  const total = clampWholeNumber(event.target.value, 0, 100);
  state.trainees[traineeIndex].marks = splitTotalIntoComponents(total);
  persistState();
  renderAnnexPanel();
  renderAnnex3Panel();
  renderToerPanel();
}

function handleToerMetaInput(event) {
  const key = event.target.dataset.toerKey;
  const isCheckbox = event.target.type === "checkbox";

  if (["video", "photo", "record", "physical", "chart"].includes(key)) {
    state.toer.evidence[key] = event.target.checked;
  } else {
    state.toer[key] = isCheckbox ? event.target.checked : event.target.value;
  }

  persistState();
  renderMarksPanel();
  renderToerPanel();
}

function handleToerOverrideToggle(event) {
  const index = Number(event.target.dataset.toerOverrideIndex);
  const override = state.toer.overrides[index] || createToerOverride();
  override.useCustomTime = event.target.checked;

  if (!override.useCustomTime) {
    override.startTime = "";
    override.endTime = "";
  } else {
    override.startTime ||= state.toer.defaultStartTime;
    override.endTime ||= state.toer.defaultEndTime;
  }

  state.toer.overrides[index] = override;
  persistState();
  renderMarksPanel();
  renderToerPanel();
}

function handleToerTimeInput(event) {
  const index = Number(event.target.dataset.toerTimeIndex);
  const field = event.target.dataset.timeField;
  const override = state.toer.overrides[index] || createToerOverride();
  override[field] = readTimeControlValue(event.target);
  state.toer.overrides[index] = override;
  persistState();

  if (event.type === "change") {
    renderToerPanel();
  }
}

function handleToerDefaultTimeInput(event) {
  const key = event.target.dataset.toerTimeKey;
  state.toer[key] = readTimeControlValue(event.target);
  persistState();

  if (event.type === "change") {
    renderMarksPanel();
    renderToerPanel();
  }
}

function loadState() {
  const fallback = structuredClone({
    meta: normalizeMeta(appData.meta),
    components: appData.components,
    trainees: normalizeTrainees(appData.trainees),
    toer: createDefaultToerState(normalizeTrainees(appData.trainees), normalizeMeta(appData.meta)),
  });

  const raw = localStorage.getItem(storageKey);
  if (!raw) {
    return fallback;
  }

  try {
    const parsed = JSON.parse(raw);
    return {
      meta: { ...fallback.meta, ...(parsed.meta || {}) },
      components: fallback.components,
      trainees: Array.isArray(parsed.trainees) ? normalizeTrainees(parsed.trainees) : fallback.trainees,
      toer: normalizeToerState(parsed.toer, Array.isArray(parsed.trainees) ? normalizeTrainees(parsed.trainees) : fallback.trainees, { ...fallback.meta, ...(parsed.meta || {}) }),
    };
  } catch {
    return fallback;
  }
}

function persistState() {
  localStorage.setItem(storageKey, JSON.stringify(state));
  traineeCount.textContent = String(state.trainees.length);
}

function syncMetaFields(key, value, source) {
  document.querySelectorAll(`[data-meta-key="${key}"]`).forEach((field) => {
    if (field !== source) {
      field.value = value;
    }
  });
}

function updateAnnexTotals(traineeIndex) {
  const trainee = state.trainees[traineeIndex];
  const total = getTraineeTotal(trainee);
  const result = getResult(total);
  const totalCell = annexPanel.querySelector(`[data-total-index="${traineeIndex}"]`);
  const resultCell = annexPanel.querySelector(`[data-result-index="${traineeIndex}"]`);

  if (totalCell) {
    totalCell.textContent = formatMark(total);
  }

  if (resultCell) {
    resultCell.textContent = result;
  }
}

function renderMarkEntryRow(trainee, index) {
  const total = getTraineeTotal(trainee);
  const override = state.toer.overrides[index] || createToerOverride();
  const startTime = override.useCustomTime ? override.startTime : state.toer.defaultStartTime;
  const endTime = override.useCustomTime ? override.endTime : state.toer.defaultEndTime;
  return `
    <tr>
      <td>${index + 1}</td>
      <td>${escapeHtml(trainee.admNo)}</td>
      <td>${escapeHtml(trainee.name)}</td>
      <td><input type="number" min="0" max="100" step="1" data-total-index="${index}" value="${escapeAttribute(String(total))}" /></td>
      <td>${getResult(total)}</td>
      <td>
        <label class="toer-row-check">
          <input type="checkbox" data-toer-override-index="${index}" ${override.useCustomTime ? "checked" : ""} />
          <span>Custom</span>
        </label>
      </td>
      <td>${renderTimeControl(startTime, { index, field: "startTime", disabled: !override.useCustomTime })}</td>
      <td>${renderTimeControl(endTime, { index, field: "endTime", disabled: !override.useCustomTime })}</td>
    </tr>
  `;
}

function renderAnnex3Group(group) {
  const span = group.rows.length + 1;
  return group.rows.map((row, index) => `
    <tr>
      ${index === 0 ? `<td rowspan="${span}" class="annex3-merged annex3-slno">${group.groupNo}</td>` : ""}
      ${index === 0 ? `<td rowspan="${span}" class="annex3-param annex3-merged">${escapeHtml(group.parameter)}</td>` : ""}
      <td colspan="2" class="annex3-comp">${escapeHtml(row.name)}</td>
      <td>${row.max}</td>
      <td>${row.awarded}</td>
    </tr>
  `).join("") + `
    <tr>
      <td colspan="2" class="annex3-comp"><strong>TOTAL</strong></td>
      <td><strong>${group.maxTotal}</strong></td>
      <td><strong>${group.total}</strong></td>
    </tr>
  `;
}

function renderToerField(key, label, type = "text") {
  return `
    <div class="field-group">
      <label for="toer-${key}">${escapeHtml(label)}</label>
      <input id="toer-${key}" type="${type}" data-toer-key="${key}" value="${escapeAttribute(state.toer[key] || "")}" />
    </div>
  `;
}

function renderToerTimeField(key, label) {
  return `
    <div class="field-group">
      <label>${escapeHtml(label)}</label>
      ${renderTimeControl(state.toer[key], { key })}
    </div>
  `;
}

function renderTimeControl(value, options = {}) {
  const parts = parseTimeParts(value);
  const disabled = options.disabled ? "disabled" : "";
  const dataAttrs =
    options.key !== undefined
      ? `data-toer-time-key="${options.key}"`
      : `data-toer-time-index="${options.index}" data-time-field="${options.field}"`;

  return `
    <div class="time-entry ${options.disabled ? "is-disabled" : ""}">
      <input class="time-hour" type="number" min="1" max="12" ${dataAttrs} data-time-part="hour" value="${escapeAttribute(parts.hour)}" ${disabled} />
      <span>:</span>
      <input class="time-minute" type="number" min="0" max="59" ${dataAttrs} data-time-part="minute" value="${escapeAttribute(parts.minute)}" ${disabled} />
      <select class="time-period" ${dataAttrs} data-time-part="period" ${disabled}>
        <option value="AM"${parts.period === "AM" ? " selected" : ""}>AM</option>
        <option value="PM"${parts.period === "PM" ? " selected" : ""}>PM</option>
      </select>
    </div>
  `;
}

function renderEvidenceCheckbox(key, label) {
  return `
    <label>
      <input type="checkbox" data-toer-key="${key}" ${state.toer.evidence[key] ? "checked" : ""} />
      <span>${escapeHtml(label)}</span>
    </label>
  `;
}

function renderToerRow(trainee, index) {
  const override = state.toer.overrides[index] || createToerOverride();
  const startTime = override.useCustomTime ? override.startTime : state.toer.defaultStartTime;
  const endTime = override.useCustomTime ? override.endTime : state.toer.defaultEndTime;
  const band = getPerformanceBand(getTraineeTotal(trainee));

  return `
    <tr>
      <td>${index + 1}</td>
      <td class="toer-name">${escapeHtml(trainee.name)}</td>
      <td>${escapeHtml(formatTimeForDisplay(startTime))}</td>
      <td>${escapeHtml(formatTimeForDisplay(endTime))}</td>
      <td class="toer-mark">${band === "VG" ? "&#10003;" : ""}</td>
      <td class="toer-mark">${band === "G" ? "&#10003;" : ""}</td>
      <td class="toer-mark">${band === "M" ? "&#10003;" : ""}</td>
      <td class="toer-mark">${band === "P" ? "&#10003;" : ""}</td>
      <td>${state.toer.evidence.video ? "Y" : ""}</td>
      <td>${state.toer.evidence.photo ? "Y" : ""}</td>
      <td>${state.toer.evidence.record ? "Y" : ""}</td>
      <td>${state.toer.evidence.physical ? "Y" : ""}</td>
      <td>${state.toer.evidence.chart ? "Y" : ""}</td>
      <td>${escapeHtml(state.toer.anyOther)}</td>
      <td></td>
    </tr>
  `;
}

function getTraineeTotal(trainee) {
  return trainee.marks.reduce((sum, mark) => sum + toNumber(mark), 0);
}

function getResult(total) {
  return total < 60 ? "N" : "Y";
}

function getPerformanceBand(total) {
  if (total > 90) return "VG";
  if (total >= 75) return "G";
  if (total >= 60) return "M";
  return "P";
}

function buildAnnex3Groups(trainee) {
  return annex3Template.map((group) => {
    const total = trainee.marks[group.annex2Index] || 0;
    const rows = splitGroupMarks(total, group.rows);
    return {
      ...group,
      rows,
      total,
      maxTotal: group.rows.reduce((sum, row) => sum + row.max, 0),
    };
  });
}

function splitGroupMarks(total, templateRows) {
  const safeTotal = clampWholeNumber(total, 0, templateRows.reduce((sum, row) => sum + row.max, 0));
  const rows = templateRows.map((row) => ({ ...row, awarded: 0 }));

  let remaining = safeTotal;

  rows.forEach((row) => {
    if (row.locked) {
      const award = Math.min(row.max, remaining);
      row.awarded = award;
      remaining -= award;
    }
  });

  if (remaining <= 0) {
    return rows;
  }

  const adjustable = rows.filter((row) => !row.locked);
  const maxAdjustable = adjustable.reduce((sum, row) => sum + row.max, 0);

  if (maxAdjustable <= 0) {
    return rows;
  }

  adjustable.forEach((row) => {
    const exact = (remaining * row.max) / maxAdjustable;
    row.awarded += Math.min(row.max, Math.floor(exact));
  });

  let assigned = rows.reduce((sum, row) => sum + row.awarded, 0);
  let leftovers = safeTotal - assigned;

  const fractions = adjustable
    .map((row) => {
      const exact = (remaining * row.max) / maxAdjustable;
      return { row, fraction: exact - Math.floor(exact) };
    })
    .sort((a, b) => b.fraction - a.fraction || a.row.awarded - b.row.awarded);

  fractions.forEach(({ row }) => {
    if (leftovers <= 0) {
      return;
    }
    if (row.awarded < row.max) {
      row.awarded += 1;
      leftovers -= 1;
    }
  });

  let cursor = 0;
  while (leftovers > 0) {
    const row = adjustable[cursor % adjustable.length];
    if (row.awarded < row.max) {
      row.awarded += 1;
      leftovers -= 1;
    }
    cursor += 1;
  }

  return rows;
}

async function downloadAnnex3PdfForCurrent() {
  const trainee = state.trainees[selectedAnnex3Index] || state.trainees[0];
  if (!trainee) return;

  const pdfDoc = await PDFLib.PDFDocument.create();
  await addAnnex3PdfPage(pdfDoc, trainee);
  const bytes = await pdfDoc.save();
  triggerPdfDownload(bytes, `annex-3-${sanitizeFilename(trainee.admNo)}.pdf`);
}

async function downloadCombinedAnnex3Pdf() {
  const pdfDoc = await PDFLib.PDFDocument.create();
  for (const trainee of state.trainees) {
    await addAnnex3PdfPage(pdfDoc, trainee);
  }
  const bytes = await pdfDoc.save();
  triggerPdfDownload(bytes, "annex-3-all-trainees.pdf");
}

async function downloadToerPdf() {
  const pdfDoc = await PDFLib.PDFDocument.create();
  await addToerPdfPage(pdfDoc);
  const bytes = await pdfDoc.save();
  triggerPdfDownload(bytes, "toer-landscape.pdf");
}

async function addToerPdfPage(pdfDoc) {
  const page = pdfDoc.addPage([841.89, 595.28]);
  const font = await pdfDoc.embedFont(PDFLib.StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(PDFLib.StandardFonts.HelveticaBold);
  const black = PDFLib.rgb(0, 0, 0);
  const blue = PDFLib.rgb(0.929, 0.953, 0.973);
  const margin = 12;
  const pageWidth = page.getWidth();
  const pageHeight = page.getHeight();
  const tableWidth = pageWidth - margin * 2;
  const tableHeight = pageHeight - margin * 2;
  const baseColWidths = [36, 159, 64, 64, 34, 34, 34, 34, 46, 46, 46, 50, 46, 62, 58];
  const colScale = tableWidth / baseColWidths.reduce((sum, width) => sum + width, 0);
  const colWidths = baseColWidths.map((width) => width * colScale);
  colWidths[colWidths.length - 1] =
    tableWidth - colWidths.slice(0, -1).reduce((sum, width) => sum + width, 0);

  const titleHeight = 22;
  const instituteHeight = 20;
  const trainerHeight = 22;
  const shiftHeight = 18;
  const learningOutcomeHeight = 28;
  const header1Height = 24;
  const header2Height = 22;
  const signatureSpaceHeight = 42;
  const signatureLabelHeight = 20;
  const fixedHeight =
    titleHeight +
    instituteHeight +
    trainerHeight +
    shiftHeight +
    learningOutcomeHeight +
    header1Height +
    header2Height +
    signatureSpaceHeight +
    signatureLabelHeight;
  const traineeRowHeight = (tableHeight - fixedHeight) / state.trainees.length;
  const tableTop = pageHeight - margin;
  let y = tableTop;

  const colX = (index) => margin + colWidths.slice(0, index).reduce((sum, width) => sum + width, 0);
  const spanWidth = (start, count) => colWidths.slice(start, start + count).reduce((sum, width) => sum + width, 0);

  const drawCell = (x, top, width, height, cell = {}) => {
    const rect = { x, y: top - height, width, height, borderWidth: 1, borderColor: black };
    if (cell.background) rect.color = cell.background;
    page.drawRectangle(rect);

    if (cell.text === undefined || cell.text === null || cell.text === "") return;

    const usedFont = cell.bold ? bold : font;
    const fontSize = cell.fontSize ?? 7.7;
    const lineHeight = fontSize + 1;
    const lines = wrapText(String(cell.text), width - 6, usedFont, fontSize, cell.maxLines ?? 3);
    const blockHeight = lines.length * lineHeight;
    const baseY =
      cell.valign === "center"
        ? top - (height - blockHeight) / 2 - fontSize
        : top - fontSize - 4;

    lines.forEach((line, index) => {
      const lineWidth = usedFont.widthOfTextAtSize(line, fontSize);
      let drawX = x + 3;
      if (cell.align === "center") {
        drawX = x + Math.max(0, (width - lineWidth) / 2);
      } else if (cell.align === "right") {
        drawX = x + Math.max(0, width - lineWidth - 3);
      }
      page.drawText(line, {
        x: drawX,
        y: baseY - index * lineHeight,
        size: fontSize,
        font: usedFont,
        color: black,
      });
    });
  };

  const drawRow = (height, cells) => {
    const top = y;
    let x = margin;
    cells.forEach((cell, index) => {
      const width = cell.width ?? colWidths[index] ?? 50;
      drawCell(x, top, width, height, cell);
      x += width;
    });
    y -= height;
  };

  drawRow(titleHeight, [{ width: tableWidth, text: "TRAINER'S OBSERVATION & EVIDENCE REPORT", bold: true, align: "center", valign: "center", fontSize: 10.5 }]);
  drawRow(instituteHeight, [
    { width: spanWidth(0, 4), text: `Name of Institute: ${formatInstituteForToer(state.meta.itiName)}`, bold: true, valign: "center", fontSize: 8 },
    { width: spanWidth(4, 11), text: `Trade: ${formatTradeForToer(state.meta.tradeName)}`, bold: true, valign: "center", fontSize: 8 },
  ]);
  drawRow(trainerHeight, [
    { width: spanWidth(0, 4), text: `Name & Address of the Trainer: ${state.toer.trainerAddress}`, bold: true, valign: "center", fontSize: 8, maxLines: 2 },
    { width: spanWidth(4, 11), text: `Unit: ${state.toer.unit}     Year: ${state.toer.year}`, bold: true, valign: "center", fontSize: 8 },
  ]);
  drawRow(shiftHeight, [
    { width: spanWidth(0, 4), text: "" },
    { width: spanWidth(4, 11), text: `Shift : ${state.toer.shift}`, bold: true, valign: "center", fontSize: 8 },
  ]);
  drawRow(learningOutcomeHeight, [
    { width: spanWidth(0, 3), text: "No. & Name of Learning Outcome:", bold: true, valign: "center", fontSize: 8 },
    { width: spanWidth(3, 12), text: state.meta.learningOutcome, valign: "center", fontSize: 8, maxLines: 2 },
  ]);

  const headerTop = y;
  const header1 = header1Height;
  const header2 = header2Height;
  const headerTotal = header1 + header2;
  [
    { index: 0, text: "Sl. No." },
    { index: 1, text: "Name of Trainee" },
    { index: 2, text: "Starting Time" },
    { index: 3, text: "Finishing Time" },
    { index: 14, text: "Remarks" },
  ].forEach((cell) => {
    drawCell(colX(cell.index), headerTop, colWidths[cell.index], headerTotal, {
      text: cell.text,
      bold: true,
      align: "center",
      valign: "center",
      background: blue,
      fontSize: 7.4,
      maxLines: 3,
    });
  });
  drawCell(colX(4), headerTop, spanWidth(4, 4), header1, { text: "Overall Performance", bold: true, align: "center", valign: "center", background: blue, fontSize: 7.5 });
  drawCell(colX(8), headerTop, spanWidth(8, 6), header1, { text: "Evidences available Remarks", bold: true, align: "center", valign: "center", background: blue, fontSize: 7.5 });
  y -= header1;
  ["VG", "G", "M", "P", "Video Y/N", "Photo Y/N", "Record Y/N", "Physical Y/N", "Chart Y/N", "Any other"].forEach((label, offset) => {
    const columnIndex = 4 + offset;
    drawCell(colX(columnIndex), y, colWidths[columnIndex], header2, {
      text: label,
      bold: true,
      align: "center",
      valign: "center",
      background: blue,
      fontSize: 6.9,
      maxLines: 2,
    });
  });
  y -= header2;

  state.trainees.forEach((trainee, index) => {
    const total = getTraineeTotal(trainee);
    const band = getPerformanceBand(total);
    const override = state.toer.overrides[index] || createToerOverride();
    const startTime = override.useCustomTime ? override.startTime : state.toer.defaultStartTime;
    const endTime = override.useCustomTime ? override.endTime : state.toer.defaultEndTime;
    drawRow(traineeRowHeight, [
      { text: index + 1, align: "center", valign: "center", fontSize: 7.6 },
      { text: trainee.name, valign: "center", fontSize: 7.4, maxLines: 2 },
      { text: formatTimeForDisplay(startTime), align: "center", valign: "center", fontSize: 7.6 },
      { text: formatTimeForDisplay(endTime), align: "center", valign: "center", fontSize: 7.6 },
      { text: band === "VG" ? "Y" : "", align: "center", valign: "center", bold: true, fontSize: 8 },
      { text: band === "G" ? "Y" : "", align: "center", valign: "center", bold: true, fontSize: 8 },
      { text: band === "M" ? "Y" : "", align: "center", valign: "center", bold: true, fontSize: 8 },
      { text: band === "P" ? "Y" : "", align: "center", valign: "center", bold: true, fontSize: 8 },
      { text: state.toer.evidence.video ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.evidence.photo ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.evidence.record ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.evidence.physical ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.evidence.chart ? "Y" : "", align: "center", valign: "center", fontSize: 7.6 },
      { text: state.toer.anyOther, align: "center", valign: "center", fontSize: 7.2, maxLines: 2 },
      { text: "", fontSize: 7.4 },
    ]);
  });

  drawRow(signatureSpaceHeight, [
    { width: spanWidth(0, 4), text: "" },
    { width: spanWidth(4, 4), text: "" },
    { width: spanWidth(8, 5), text: "" },
    { width: spanWidth(13, 2), text: "" },
  ]);
  drawRow(signatureLabelHeight, [
    { width: spanWidth(0, 4), text: "VG- above 90%, G- 75-90 %, M- 60-75 %, P- Below 60%", bold: true, valign: "center", fontSize: 7.2, maxLines: 2 },
    { width: spanWidth(4, 4), text: "SIGN.OF VP/PRINCIPAL", bold: true, align: "center", valign: "center", fontSize: 7.4 },
    { width: spanWidth(8, 5), text: "SIGN OF GI", bold: true, align: "center", valign: "center", fontSize: 7.4 },
    { width: spanWidth(13, 2), text: "SIGN. OF TRAINER", bold: true, align: "center", valign: "center", fontSize: 7.4 },
  ]);

  page.drawRectangle({
    x: margin,
    y: margin,
    width: tableWidth,
    height: tableHeight,
    borderWidth: 1.4,
    borderColor: black,
  });
}

async function addAnnex3PdfPage(pdfDoc, trainee) {
  const page = pdfDoc.addPage([595.28, 841.89]);
  const font = await pdfDoc.embedFont(PDFLib.StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(PDFLib.StandardFonts.HelveticaBold);
  const blue = PDFLib.rgb(0.858, 0.918, 0.969);
  const black = PDFLib.rgb(0, 0, 0);
  const margin = 16;
  const pageWidth = page.getWidth();
  const pageHeight = page.getHeight();
  const tableWidth = pageWidth - margin * 2;
  const colWidths = [34, 130, 241, 74, tableWidth - 34 - 130 - 241 - 74];

  let y = pageHeight - margin;

  const drawCell = (x, top, width, height, cell = {}) => {
    const rectOptions = {
      x,
      y: top - height,
      width,
      height,
      borderWidth: 1,
      borderColor: black,
    };
    if (cell.background) {
      rectOptions.color = cell.background;
    }
    page.drawRectangle(rectOptions);

    if (cell.text === undefined || cell.text === null) {
      return;
    }

    const usedFont = cell.bold ? bold : font;
    const fontSize = cell.fontSize ?? 7.8;
    const maxLines = cell.maxLines ?? 3;
    const lineHeight = fontSize + 1;
    const lines = wrapText(String(cell.text), width - 8, usedFont, fontSize, maxLines);
    const blockHeight = lines.length * lineHeight;
    const baseY =
      cell.valign === "center"
        ? top - (height - blockHeight) / 2 - fontSize
        : top - fontSize - 4;

    lines.forEach((line, index) => {
      const lineWidth = usedFont.widthOfTextAtSize(line, fontSize);
      let drawX = x + 4;
      if (cell.align === "center") {
        drawX = x + Math.max(0, (width - lineWidth) / 2);
      } else if (cell.align === "right") {
        drawX = x + Math.max(0, width - lineWidth - 4);
      }
      page.drawText(line, {
        x: drawX,
        y: baseY - index * lineHeight,
        size: fontSize,
        font: usedFont,
        color: black,
      });
    });
  };

  const drawRow = (height, cells) => {
    const top = y;
    let x = margin;
    cells.forEach((cell, index) => {
      const width = cell.width ?? colWidths[index] ?? 60;
      drawCell(x, top, width, height, cell);
      x += width;
    });
    y -= height;
  };

  const drawSpanningRow = (height, segments) => {
    const top = y;
    let x = margin;
    segments.forEach((segment) => {
      drawCell(x, top, segment.width, height, segment);
      x += segment.width;
    });
    y -= height;
  };

  const groups = buildAnnex3Groups(trainee);
  const grandTotal = groups.reduce((sum, group) => sum + group.total, 0);

  drawSpanningRow(22, [{ width: tableWidth, text: "ANNEXURE - III", bold: true, align: "center", fontSize: 10.8, valign: "center" }]);
  drawSpanningRow(17, [{ width: 230, text: "Name & Address of the Assessor", bold: true }, { width: tableWidth - 230, text: state.meta.assessor }]);
  drawSpanningRow(17, [{ width: 230, text: "Name & Address of I T I", bold: true }, { width: tableWidth - 230, text: state.meta.itiName, maxLines: 2 }]);
  drawSpanningRow(17, [{ width: 230, text: "Subject Name", bold: true }, { width: tableWidth - 230, text: "Trade Practical" }]);
  drawSpanningRow(17, [{ width: 230, text: "Trade Name", bold: true }, { width: tableWidth - 230, text: state.meta.tradeName }]);
  drawSpanningRow(30, [{ width: 150, text: "Learning Outcome", bold: true }, { width: tableWidth - 150, text: state.meta.learningOutcome, maxLines: 2 }]);
  drawRow(18, [
    { text: "Adm.No", bold: true, align: "center", width: 78, valign: "center" },
    { text: "Name of The Candidate", bold: true, align: "center", width: 192, valign: "center" },
    { text: "Acadamic Span", bold: true, align: "center", width: 126, valign: "center" },
    { text: "Date of Assesment", bold: true, align: "center", width: tableWidth - 396, valign: "center" },
  ]);
  drawRow(18, [
    { text: trainee.admNo, width: 78, align: "center", valign: "center" },
    { text: trainee.name, width: 192, align: "center", valign: "center" },
    { text: state.meta.yearEnrolment, width: 126, align: "center", valign: "center" },
    { text: state.meta.dateOfAssessment, width: tableWidth - 396, align: "center", valign: "center" },
  ]);
  drawRow(28, [
    { text: "Sl No", bold: true, align: "center", width: colWidths[0], background: blue, valign: "center", fontSize: 7.7 },
    { text: "ASSESSMENT PARAMETERS", bold: true, align: "center", width: colWidths[1], background: blue, valign: "center", fontSize: 7.7 },
    { text: "COMPONENT OF ASSESSMENT PARAMETERS", bold: true, align: "center", width: colWidths[2], background: blue, valign: "center", fontSize: 7.7 },
    { text: "MAX.MARKS BREAK-UP", bold: true, align: "center", width: colWidths[3], background: blue, valign: "center", fontSize: 7.2 },
    { text: "MARKS AWARDED", bold: true, align: "center", width: colWidths[4], background: blue, valign: "center", fontSize: 7.2 },
  ]);

  groups.forEach((group) => {
    const rowHeight = 14.7;
    const totalHeight = 14.7;
    const groupTop = y;
    const groupHeight = group.rows.length * rowHeight + totalHeight;
    const componentX = margin + colWidths[0] + colWidths[1];
    const maxX = componentX + colWidths[2];
    const awardX = maxX + colWidths[3];

    drawCell(margin, groupTop, colWidths[0], groupHeight, {
      text: group.groupNo,
      align: "center",
      valign: "center",
      fontSize: 7.8,
    });
    drawCell(margin + colWidths[0], groupTop, colWidths[1], groupHeight, {
      text: group.parameter,
      align: "center",
      valign: "center",
      bold: true,
      fontSize: 7.3,
      maxLines: 5,
    });

    group.rows.forEach((row, index) => {
      const rowTop = y;
      drawCell(componentX, rowTop, colWidths[2], rowHeight, { text: row.name, fontSize: 7.1, maxLines: 2, valign: "center" });
      drawCell(maxX, rowTop, colWidths[3], rowHeight, { text: row.max, align: "center", valign: "center", fontSize: 7.8 });
      drawCell(awardX, rowTop, colWidths[4], rowHeight, { text: row.awarded, align: "center", valign: "center", fontSize: 7.8 });
      y -= rowHeight;
    });
    drawCell(componentX, y, colWidths[2], totalHeight, { text: "TOTAL", bold: true, valign: "center", fontSize: 7.8 });
    drawCell(maxX, y, colWidths[3], totalHeight, { text: group.maxTotal, bold: true, align: "center", valign: "center", fontSize: 7.8 });
    drawCell(awardX, y, colWidths[4], totalHeight, { text: group.total, bold: true, align: "center", valign: "center", fontSize: 7.8 });
    y -= totalHeight;
  });

  drawRow(18, [
    { text: "GRAND TOTAL", width: colWidths[0] + colWidths[1] + colWidths[2], bold: true, valign: "center" },
    { text: 100, width: colWidths[3], bold: true, align: "center", valign: "center" },
    { text: grandTotal, width: colWidths[4], bold: true, align: "center", valign: "center" },
  ]);
  drawSpanningRow(58, [
    { width: tableWidth / 3, text: "" },
    { width: tableWidth / 3, text: "" },
    { width: tableWidth / 3, text: "" },
  ]);
  drawSpanningRow(20, [
    { width: tableWidth / 3, text: "Signature of the Candidate", bold: true, align: "center", valign: "center", fontSize: 7.4 },
    { width: tableWidth / 3, text: "Group Instructor", bold: true, align: "center", valign: "center", fontSize: 7.4 },
    { width: tableWidth / 3, text: "Signature, Name & Designation of Accessor", bold: true, align: "center", valign: "center", fontSize: 7.1 },
  ]);
}

function drawWrappedText(page, text, x, topY, width, fontSize, font, align = "left") {
  const lines = wrapText(text, width, font, fontSize);
  lines.forEach((line, index) => {
    const lineWidth = font.widthOfTextAtSize(line, fontSize);
    let drawX = x;
    if (align === "center") {
      drawX = x + Math.max(0, (width - lineWidth) / 2);
    } else if (align === "right") {
      drawX = x + Math.max(0, width - lineWidth);
    }
    page.drawText(line, {
      x: drawX,
      y: topY - index * (fontSize + 1),
      size: fontSize,
      font,
      color: PDFLib.rgb(0, 0, 0),
    });
  });
}

function wrapText(text, width, font, fontSize, maxLines = 3) {
  const words = String(text).split(/\s+/).filter(Boolean);
  if (!words.length) return [""];
  const lines = [];
  let current = words[0];
  for (let i = 1; i < words.length; i += 1) {
    const next = `${current} ${words[i]}`;
    if (font.widthOfTextAtSize(next, fontSize) <= width) {
      current = next;
    } else {
      lines.push(current);
      current = words[i];
    }
  }
  lines.push(current);
  return lines.slice(0, maxLines);
}

function triggerPdfDownload(bytes, filename) {
  const blob = new Blob([bytes], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function sanitizeFilename(value) {
  return String(value).replace(/[<>:"/\\|?*]+/g, "-");
}

function splitTotalIntoComponents(total, components = appData.components) {
  const maxMarks = components.map((component) => toNumber(component.maxMark));
  const safeTotal = clampWholeNumber(total, 0, 100);
  const marks = new Array(maxMarks.length).fill(0);

  if (safeTotal <= 0) {
    return marks;
  }

  const safetyFloor = 13;
  const safetyIndex = 0;
  const guaranteedSafety = Math.min(maxMarks[safetyIndex], Math.min(safetyFloor, safeTotal));
  marks[safetyIndex] = guaranteedSafety;

  let remaining = safeTotal - guaranteedSafety;
  const capacities = maxMarks.map((max, index) => max - marks[index]);
  const totalRemainingCapacity = capacities.reduce((sum, value) => sum + value, 0);

  if (remaining <= 0 || totalRemainingCapacity <= 0) {
    return marks;
  }

  const fractionalParts = [];

  capacities.forEach((capacity, index) => {
    if (capacity <= 0) {
      fractionalParts.push({ index, fraction: 0 });
      return;
    }

    const exactShare = (remaining * capacity) / totalRemainingCapacity;
    const wholeShare = Math.min(capacity, Math.floor(exactShare));
    marks[index] += wholeShare;
    fractionalParts.push({ index, fraction: exactShare - wholeShare });
  });

  let assigned = marks.reduce((sum, value) => sum + value, 0);
  let leftovers = safeTotal - assigned;

  fractionalParts
    .sort((a, b) => b.fraction - a.fraction || capacities[b.index] - capacities[a.index])
    .forEach(({ index }) => {
      if (leftovers <= 0) {
        return;
      }
      if (marks[index] < maxMarks[index]) {
        marks[index] += 1;
        leftovers -= 1;
      }
    });

  let rotateIndex = 0;
  while (leftovers > 0) {
    const index = rotateIndex % marks.length;
    if (marks[index] < maxMarks[index]) {
      marks[index] += 1;
      leftovers -= 1;
    }
    rotateIndex += 1;
  }

  return marks;
}

function syncAnnexScale() {
  const stage = document.querySelector("#annexFitStage");
  const content = document.querySelector("#annexFitContent");

  if (!stage || !content) {
    return;
  }

  content.style.transform = "scale(1)";
  content.style.width = "fit-content";
  content.style.height = "auto";

  const stageWidth = stage.clientWidth;
  const naturalWidth = content.scrollWidth;

  if (!stageWidth || !naturalWidth) {
    return;
  }

  const scale = Math.min(1, stageWidth / naturalWidth);
  content.style.transform = `scale(${scale})`;
  content.style.width = `${naturalWidth}px`;
  content.style.height = `${content.scrollHeight * scale}px`;
}

function normalizeMeta(meta) {
  return {
    ...meta,
    examination:
      meta.examination && meta.examination !== meta.durationLabel ? meta.examination : "",
  };
}

function createDefaultToerState(trainees, meta) {
  return {
    trainerAddress: `${meta.assessor}, JI ${formatTradeForToer(meta.tradeName)}`.trim(),
    unit: "1",
    year: "1",
    shift: "II",
    defaultStartTime: "",
    defaultEndTime: "",
    evidence: {
      video: false,
      photo: false,
      record: false,
      physical: false,
      chart: true,
    },
    anyOther: "",
    overrides: trainees.map(() => createToerOverride()),
  };
}

function createToerOverride() {
  return {
    useCustomTime: false,
    startTime: "",
    endTime: "",
  };
}

function normalizeToerState(rawToer, trainees, meta) {
  const fallback = createDefaultToerState(trainees, meta);
  const incoming = rawToer || {};
  const overrides = Array.isArray(incoming.overrides) ? incoming.overrides : [];

  return {
    ...fallback,
    ...incoming,
    evidence: {
      ...fallback.evidence,
      ...(incoming.evidence || {}),
    },
    overrides: trainees.map((_, index) => ({
      ...createToerOverride(),
      ...(overrides[index] || {}),
    })),
  };
}

function normalizeTrainees(trainees) {
  return trainees.map((trainee) => {
    const total = clampWholeNumber(
      Array.isArray(trainee.marks)
        ? trainee.marks.reduce((sum, mark) => sum + toNumber(mark), 0)
        : trainee.total,
      0,
      100,
    );

    return {
      ...trainee,
      marks: splitTotalIntoComponents(total),
    };
  });
}

function readTimeControlValue(source) {
  const control = source.closest(".time-entry");
  if (!control) {
    return "";
  }

  const hour = clampWholeNumber(control.querySelector("[data-time-part='hour']")?.value, 1, 12);
  const minute = clampWholeNumber(control.querySelector("[data-time-part='minute']")?.value, 0, 59);
  const period = control.querySelector("[data-time-part='period']")?.value === "AM" ? "AM" : "PM";
  const hour24 = period === "PM" ? (hour % 12) + 12 : hour % 12;
  return `${String(hour24).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

function parseTimeParts(value) {
  if (!value) {
    return { hour: "", minute: "", period: "AM" };
  }

  const text = String(value).trim().toUpperCase();
  const match12 = text.match(/^(\d{1,2})(?::(\d{1,2}))?\s*(AM|PM)$/);
  if (match12) {
    return {
      hour: String(clampWholeNumber(match12[1], 1, 12)),
      minute: String(clampWholeNumber(match12[2] ?? 0, 0, 59)).padStart(2, "0"),
      period: match12[3],
    };
  }

  const [hourText, minuteText = "00"] = text.split(":");
  const hour24 = clampWholeNumber(hourText, 0, 23);
  const period = hour24 >= 12 ? "PM" : "AM";
  const hour12 = hour24 % 12 || 12;
  return {
    hour: String(hour12),
    minute: String(clampWholeNumber(minuteText, 0, 59)).padStart(2, "0"),
    period,
  };
}

function formatTimeForDisplay(value) {
  if (!value) {
    return "";
  }

  const [hourText, minuteText = "00"] = String(value).split(":");
  const hour = Number(hourText);
  const minute = Number(minuteText);

  if (!Number.isFinite(hour) || !Number.isFinite(minute)) {
    return value;
  }

  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${String(minute).padStart(2, "0")} ${suffix}`;
}

function formatInstituteForToer(itiName) {
  return String(itiName || "")
    .replace("Govt: Industrial Training Institute", "GOVT ITI")
    .replace("panniyannore", "PANNIYANNORE")
    .trim();
}

function formatTradeForToer(tradeName) {
  const value = String(tradeName || "").trim().toUpperCase();
  if (value === "DCIVIL") {
    return "D/CIVIL";
  }
  return value;
}

function toNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function formatMark(value) {
  return String(clampWholeNumber(value, 0, 100));
}

function clampWholeNumber(value, min, max) {
  const rounded = Math.round(toNumber(value));
  return Math.max(min, Math.min(max, rounded));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#96;");
}
