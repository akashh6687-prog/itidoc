(function attachOfficeExport(global) {
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function collectStyleSheetText() {
    return Array.from(document.styleSheets)
      .map((sheet) => {
        try {
          return Array.from(sheet.cssRules || [])
            .map((rule) => rule.cssText)
            .join("\n");
        } catch (error) {
          return "";
        }
      })
      .filter(Boolean)
      .join("\n");
  }

  function clearInlineScale(node) {
    if (!node?.style) {
      return;
    }

    node.style.transform = "";
    node.style.transformOrigin = "";
    node.style.width = "";
    node.style.height = "";
    node.style.maxWidth = "";
    node.style.maxHeight = "";
  }

  function getControlText(control) {
    if (!control) {
      return "";
    }

    if (control.tagName === "SELECT") {
      return control.options[control.selectedIndex]?.text ?? "";
    }

    if (control.tagName === "TEXTAREA") {
      return control.value ?? "";
    }

    if (control.type === "checkbox" || control.type === "radio") {
      return control.checked ? "Y" : "";
    }

    return control.value ?? "";
  }

  function replaceFormControls(sourceRoot, cloneRoot) {
    const sourceControls = sourceRoot.querySelectorAll("input, textarea, select");
    const cloneControls = cloneRoot.querySelectorAll("input, textarea, select");

    sourceControls.forEach((sourceControl, index) => {
      const cloneControl = cloneControls[index];
      if (!cloneControl) {
        return;
      }

      const replacement = document.createElement(sourceControl.tagName === "TEXTAREA" ? "div" : "span");
      const computed = window.getComputedStyle(sourceControl);
      const text = getControlText(sourceControl);

      replacement.className = ["office-export-field", cloneControl.className].filter(Boolean).join(" ");
      replacement.textContent = text || " ";
      replacement.style.display = computed.display === "block" ? "block" : "inline-block";
      replacement.style.width = computed.width;
      replacement.style.minHeight = computed.height;
      replacement.style.padding = computed.padding;
      replacement.style.margin = computed.margin;
      replacement.style.font = computed.font;
      replacement.style.fontSize = computed.fontSize;
      replacement.style.fontWeight = computed.fontWeight;
      replacement.style.lineHeight = computed.lineHeight;
      replacement.style.letterSpacing = computed.letterSpacing;
      replacement.style.textAlign = computed.textAlign;
      replacement.style.color = computed.color;
      replacement.style.background = "transparent";
      replacement.style.border = "none";
      replacement.style.boxSizing = "border-box";
      replacement.style.whiteSpace = sourceControl.tagName === "TEXTAREA" ? "pre-wrap" : "normal";
      replacement.style.verticalAlign = computed.verticalAlign;

      cloneControl.replaceWith(replacement);
    });
  }

  function absolutizeImages(sourceRoot, cloneRoot) {
    const sourceImages = sourceRoot.querySelectorAll("img");
    const cloneImages = cloneRoot.querySelectorAll("img");

    sourceImages.forEach((sourceImage, index) => {
      const cloneImage = cloneImages[index];
      if (!cloneImage) {
        return;
      }

      const absoluteSource = sourceImage.currentSrc || sourceImage.src || cloneImage.getAttribute("src") || "";
      if (absoluteSource) {
        cloneImage.setAttribute("src", absoluteSource);
      }
    });
  }

  function removeSelectors(root, selectors) {
    (selectors || []).forEach((selector) => {
      root.querySelectorAll(selector).forEach((node) => node.remove());
    });
  }

  function cloneExportNode(sourceNode, options = {}) {
    if (!sourceNode) {
      throw new Error("Nothing to export.");
    }

    const clone = sourceNode.cloneNode(true);
    replaceFormControls(sourceNode, clone);
    absolutizeImages(sourceNode, clone);
    removeSelectors(clone, options.removeSelectors);

    if (typeof options.transformClone === "function") {
      options.transformClone(clone, sourceNode, { clearInlineScale });
    }

    return clone;
  }

  function buildDocumentHtml({
    kind,
    title,
    bodyHtml,
    pageOrientation = "portrait",
    extraStyles = "",
    worksheetName = "Sheet1",
  }) {
    const baseStyles = collectStyleSheetText();
    const pageSize = pageOrientation === "landscape" ? "A4 landscape" : "A4 portrait";
    const namespaces =
      kind === "excel"
        ? 'xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"'
        : 'xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"';
    const officeMeta =
      kind === "excel"
        ? `<!--[if gte mso 9]><xml>
<x:ExcelWorkbook>
  <x:ExcelWorksheets>
    <x:ExcelWorksheet>
      <x:Name>${escapeXml(worksheetName)}</x:Name>
      <x:WorksheetOptions>
        <x:DisplayGridlines/>
      </x:WorksheetOptions>
    </x:ExcelWorksheet>
  </x:ExcelWorksheets>
</x:ExcelWorkbook>
</xml><![endif]-->`
        : `<!--[if gte mso 9]><xml>
<w:WordDocument>
  <w:View>Print</w:View>
  <w:DoNotOptimizeForBrowser/>
</w:WordDocument>
</xml><![endif]-->`;

    return `<!DOCTYPE html>
<html ${namespaces}>
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>${escapeXml(title)}</title>
    ${officeMeta}
    <style>
      @page {
        size: ${pageSize};
        margin: 10mm;
      }

      html, body {
        margin: 0;
        padding: 0;
        background: #ffffff;
        color: #000000;
      }

      body.office-export {
        padding: 10mm;
      }

      body.office-export--excel td,
      body.office-export--excel th {
        mso-number-format: "\\@";
      }

      .office-export-page {
        page-break-after: always;
        break-after: page;
      }

      .office-export-page:last-child {
        page-break-after: auto;
        break-after: auto;
      }

      .office-export-field {
        vertical-align: top;
      }

      .office-export img {
        max-width: 100%;
      }

      .office-export .preview-shell,
      .office-export .preview-stage,
      .office-export .sheet-scroll,
      .office-export .annex-fit-stage,
      .office-export .annex-fit-content {
        overflow: visible !important;
      }

      .office-export .progress-page,
      .office-export .annex-paper,
      .office-export .annex3-paper,
      .office-export .toer-paper {
        box-shadow: none !important;
        margin-left: auto !important;
        margin-right: auto !important;
      }

      ${baseStyles}
      ${extraStyles}
    </style>
  </head>
  <body class="office-export office-export--${kind}">
    ${bodyHtml}
  </body>
</html>`;
  }

  function escapeXml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&apos;");
  }

  function serializeBlocks(sources, options = {}) {
    return sources
      .map((source, index) => {
        const clone = cloneExportNode(source, options);
        const pageClass = options.pageBreakBetween !== false && index < sources.length - 1
          ? "office-export-page"
          : "";
        return `<section class="${pageClass}">${clone.outerHTML}</section>`;
      })
      .join("");
  }

  function downloadExcelDocument({
    filename,
    title,
    sources,
    pageOrientation = "landscape",
    worksheetName = "Sheet1",
    extraStyles = "",
    removeSelectors = [],
    transformClone,
  }) {
    const bodyHtml = serializeBlocks(Array.isArray(sources) ? sources : [sources], {
      removeSelectors,
      transformClone,
      pageBreakBetween: false,
    });
    const documentHtml = buildDocumentHtml({
      kind: "excel",
      title,
      bodyHtml,
      pageOrientation,
      worksheetName,
      extraStyles,
    });

    downloadBlob(
      new Blob(["\ufeff", documentHtml], { type: "application/vnd.ms-excel" }),
      filename,
    );
  }

  function downloadWordDocument({
    filename,
    title,
    sources,
    pageOrientation = "portrait",
    extraStyles = "",
    removeSelectors = [],
    transformClone,
  }) {
    const bodyHtml = serializeBlocks(Array.isArray(sources) ? sources : [sources], {
      removeSelectors,
      transformClone,
      pageBreakBetween: true,
    });
    const documentHtml = buildDocumentHtml({
      kind: "word",
      title,
      bodyHtml,
      pageOrientation,
      extraStyles,
    });

    downloadBlob(
      new Blob(["\ufeff", documentHtml], { type: "application/msword" }),
      filename,
    );
  }

  global.OfficeExport = {
    clearInlineScale,
    cloneExportNode,
    downloadExcelDocument,
    downloadWordDocument,
  };
})(window);
