window.APP_DATA = {
  "workbookName": "ANEX 2&3 , TOER - 1.xlsx",
  "meta": {
    "title": "ANNEXTURE - II",
    "assessorLabel": "NAME & ADDRESS OF THE ASSESSOR ",
    "assessor": "AKASH B",
    "yearLabel": "YEAR OF ENROLMENT :",
    "yearEnrolment": "2025 -2027",
    "itiLabel": "NAME & ADDRESSOF ITI (GOVT./PVT.) ",
    "itiName": "Govt: Industrial Training Institute panniyannore",
    "dateLabel": "DATE OF ASSESSMENT :",
    "dateOfAssessment": "06-10-2025",
    "industryLabel": "NAME & ADDRESS OF THE INDUSTRY ",
    "industryName": "",
    "locationLabel": "ASSESSMENT LOCATION : INDUSTRY / ITI",
    "assessmentLocation": "ITI",
    "tradeLabel": "TRADE NAME ",
    "tradeName": "DCIVIL",
    "examLabel": "EXAMINATION (I/II) :",
    "examination": "DURATION OF TRADE/COURSE :",
    "durationLabel": "DURATION OF TRADE/COURSE :",
    "durationOfTrade": "TWO YEARS",
    "learningOutcomeLabel": "LEARNING OUTCOME :",
    "learningOutcome": "1. Draw free hand sketches of hand tools used in civil work following safety precautions",
    "instructorLeft": "INSTRUCTOR",
    "instructorMiddle": "GI",
    "principal": "PRINCIPAL"
  },
  "components": [
    {
      "maxMark": 15,
      "name": "Safety Conciousness"
    },
    {
      "maxMark": 10,
      "name": "Workplace Hygiene Economical Use Of Materials"
    },
    {
      "maxMark": 10,
      "name": "Attendance / Punctuality"
    },
    {
      "maxMark": 5,
      "name": "Ability To Follow Manuals/Written Instructions"
    },
    {
      "maxMark": 10,
      "name": "Application Of Knowledge"
    },
    {
      "maxMark": 10,
      "name": "Skill To Handle Tools & Equipment"
    },
    {
      "maxMark": 10,
      "name": "Speed In Doing Work"
    },
    {
      "maxMark": 15,
      "name": "Quality In Workmanship"
    },
    {
      "maxMark": 15,
      "name": "Viva"
    }
  ],
  "trainees": [
    {
      "admNo": "837/25",
      "name": "ABHIJITH K J",
      "fatherName": "JANEESH K M",
      "marks": [
        15,
        10,
        9,
        5,
        7,
        7,
        7,
        11,
        11
      ],
      "total": 82,
      "result": "Y"
    },
    {
      "admNo": "822/25",
      "name": "ADISH U P",
      "fatherName": "PAVITHRAN U P",
      "marks": [
        15,
        10,
        9,
        5,
        7,
        7,
        7,
        11,
        11
      ],
      "total": 82,
      "result": "Y"
    },
    {
      "admNo": "797/25",
      "name": "ANUNANDANA C V",
      "fatherName": "SURESH BABU C V",
      "marks": [
        15,
        8,
        7,
        3,
        4,
        6,
        7,
        10,
        10
      ],
      "total": 70,
      "result": "Y"
    },
    {
      "admNo": "853/25",
      "name": "DEVANANDA.K.V",
      "fatherName": "ANILKUMAR K V",
      "marks": [
        15,
        10,
        9,
        5,
        7,
        7,
        4,
        11,
        11
      ],
      "total": 79,
      "result": "Y"
    },
    {
      "admNo": "833/25",
      "name": "DEVAPRIYA M K",
      "fatherName": "AJITH KUMAR.M.K",
      "marks": [
        15,
        10,
        9,
        5,
        7,
        7,
        4,
        10,
        11
      ],
      "total": 78,
      "result": "Y"
    },
    {
      "admNo": "794/25",
      "name": "DEVIKA M",
      "fatherName": "SMIJITH M",
      "marks": [
        15,
        10,
        9,
        5,
        7,
        7,
        4,
        10,
        11
      ],
      "total": 78,
      "result": "Y"
    },
    {
      "admNo": "809/25",
      "name": "DHARSANA P",
      "fatherName": "VIJESH P",
      "marks": [
        15,
        10,
        9,
        5,
        7,
        7,
        4,
        9,
        10
      ],
      "total": 76,
      "result": "Y"
    },
    {
      "admNo": "813/25",
      "name": "DIYA RAJEEVAN M T K",
      "fatherName": "RAJEEVAN M T K",
      "marks": [
        15,
        10,
        9,
        5,
        7,
        7,
        9,
        11,
        12
      ],
      "total": 85,
      "result": "Y"
    },
    {
      "admNo": "795/25",
      "name": "GOPIKA C M",
      "fatherName": "RADHAKRISHNAN",
      "marks": [
        14,
        7,
        7,
        3,
        6,
        6,
        4,
        8,
        9
      ],
      "total": 64,
      "result": "Y"
    },
    {
      "admNo": "814/25",
      "name": "GOPIKA.T.P",
      "fatherName": "SREENIVASAN T P",
      "marks": [
        15,
        9,
        8,
        5,
        7,
        7,
        4,
        10,
        11
      ],
      "total": 76,
      "result": "Y"
    },
    {
      "admNo": "897/25",
      "name": "MOHAMMED MISHAL K P",
      "fatherName": "BASHEER M",
      "marks": [
        15,
        9,
        5,
        5,
        7,
        7,
        4,
        11,
        12
      ],
      "total": 75,
      "result": "Y"
    },
    {
      "admNo": "801/25",
      "name": "NAJAH ABOOBACKER V K",
      "fatherName": "ABOOBACKER.V.K",
      "marks": [
        15,
        9,
        5,
        5,
        6,
        7,
        4,
        10,
        12
      ],
      "total": 73,
      "result": "Y"
    },
    {
      "admNo": "851/25",
      "name": "NAVATHEJ.K.P",
      "fatherName": "SUKUMARAN.K.P",
      "marks": [
        15,
        9,
        5,
        5,
        7,
        7,
        4,
        11,
        12
      ],
      "total": 75,
      "result": "Y"
    },
    {
      "admNo": "796/25",
      "name": "NIDHIYA T M",
      "fatherName": "SUDHEER T M",
      "marks": [
        15,
        9,
        5,
        5,
        7,
        7,
        4,
        9,
        11
      ],
      "total": 72,
      "result": "Y"
    },
    {
      "admNo": "887/25",
      "name": "RITHIN CHANDRAN",
      "fatherName": "CHANDRAN P",
      "marks": [
        15,
        9,
        8,
        5,
        8,
        7,
        4,
        11,
        12
      ],
      "total": 79,
      "result": "Y"
    },
    {
      "admNo": "831/25",
      "name": "SHARON P K",
      "fatherName": "P K PRASHOB",
      "marks": [
        15,
        7,
        6,
        5,
        8,
        9,
        7,
        11,
        12
      ],
      "total": 80,
      "result": "Y"
    },
    {
      "admNo": "808/25",
      "name": "SIVAPRIYA E",
      "fatherName": "CHANDRAN E",
      "marks": [
        13,
        6,
        6,
        5,
        9,
        7,
        5,
        10,
        9
      ],
      "total": 70,
      "result": "Y"
    },
    {
      "admNo": "857/25",
      "name": "SRAVAN MANU",
      "fatherName": "MANOHARAN K V",
      "marks": [
        13,
        6,
        5,
        5,
        7,
        7,
        5,
        10,
        9
      ],
      "total": 67,
      "result": "Y"
    },
    {
      "admNo": "810/25",
      "name": "SREE LAKSHMI K P",
      "fatherName": "ANILKUMAR A P",
      "marks": [
        15,
        8,
        8,
        5,
        7,
        7,
        7,
        10,
        10
      ],
      "total": 77,
      "result": "Y"
    },
    {
      "admNo": "805/25",
      "name": "VISHNU C K",
      "fatherName": "UTHAMAN C K",
      "marks": [
        15,
        8,
        9,
        5,
        7,
        9,
        7,
        12,
        11
      ],
      "total": 83,
      "result": "Y"
    },
    {
      "admNo": "811/25",
      "name": "VISMAYA T",
      "fatherName": "SURESH BABU T",
      "marks": [
        15,
        8,
        9,
        5,
        6,
        7,
        6,
        10,
        10
      ],
      "total": 76,
      "result": "Y"
    }
  ]
};