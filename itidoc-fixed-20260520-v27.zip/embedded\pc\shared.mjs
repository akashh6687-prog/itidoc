(function () {
const PAGE_SIZES = {
  main: {
    widthPt: 1190.52,
    heightPt: 841.92,
    widthMm: 420,
    heightMm: 297,
  },
  monthly: {
    widthPt: 595.28,
    heightPt: 841.89,
    widthMm: 210,
    heightMm: 297,
  },
};

const METRICS = [
  { key: "PS", short: "PS", label: "Practical Skill", group: "practical" },
  { key: "PK", short: "PK", label: "Practical Knowledge", group: "practical" },
  { key: "ES", short: "ES", label: "Employability Skills", group: "theory" },
  { key: "WCS", short: "WCS", label: "Workshop Calculation & Science", group: "theory" },
  { key: "AT", short: "AT", label: "Attendance", group: "attendance" },
];

const COLOR_ORDER = ["red", "yellow", "blue", "green"];

const COLOR_STYLES = {
  empty: { name: "Empty", fill: "#ffffff", stroke: "#1b2636", text: "#1b2636" },
  red: { name: "Red", fill: "#f3362f", stroke: "#961b16", text: "#ffffff" },
  yellow: { name: "Yellow", fill: "#ffe44d", stroke: "#8f7a00", text: "#2b2b2b" },
  blue: { name: "Blue", fill: "#196fdd", stroke: "#0d3d77", text: "#ffffff" },
  green: { name: "Green", fill: "#24cb42", stroke: "#127028", text: "#ffffff" },
};

const DEFAULT_RULES = {
  practical: [
    { color: "red", min: 0, max: 59 },
    { color: "yellow", min: 60, max: 75 },
    { color: "blue", min: 76, max: 90 },
    { color: "green", min: 91, max: 100 },
  ],
  theory: [
    { color: "red", min: 0, max: 39 },
    { color: "yellow", min: 40, max: 49 },
    { color: "blue", min: 50, max: 59 },
    { color: "green", min: 60, max: 100 },
  ],
  attendance: [
    { color: "red", min: 0, max: 79 },
    { color: "yellow", min: 80, max: 89 },
    { color: "blue", min: 90, max: 94 },
    { color: "green", min: 95, max: 100 },
  ],
};

const DEFAULT_MONTHS = [
  "August 2025",
  "September 2025",
  "October 2025",
  "November 2025",
  "December 2025",
  "January 2026",
  "February 2026",
  "March 2026",
  "April 2026",
  "May 2026",
  "June 2026",
  "July 2026",
];

const DEFAULT_STUDENTS = [
  { name: "ABHIJITH K J", admission: "837/25" },
  { name: "ADISH U P", admission: "822/25" },
  { name: "ANUNANDANA C V", admission: "797/25" },
  { name: "DEVANANDA.K.V", admission: "853/25" },
  { name: "DEVAPRIYA M K", admission: "833/25" },
  { name: "DEVIKA M", admission: "794/25" },
  { name: "DHARSANA P", admission: "809/25" },
  { name: "DIYA RAJEEVAN M T K", admission: "813/25" },
  { name: "GOPIKA C M", admission: "795/25" },
  { name: "GOPIKA.T.P", admission: "814/25" },
  { name: "MOHAMMED MISHAL K P", admission: "897/25" },
  { name: "NAJAH ABOOBACKER V K", admission: "801/25" },
  { name: "NAVATHEJ.K.P", admission: "851/25" },
  { name: "NIDHIYA T M", admission: "796/25" },
  { name: "RITHIN CHANDRAN", admission: "887/25" },
  { name: "SHARON P K", admission: "831/25" },
  { name: "SIVAPRIYA E", admission: "808/25" },
  { name: "SRAVAN MANU", admission: "857/25" },
  { name: "SREE LAKSHMI K P", admission: "810/25" },
  { name: "VISHNU C K", admission: "805/25" },
  { name: "VISMAYA T", admission: "811/25" },
];

const SAMPLE_MONTH_COLOR_ROWS = [
  ["blue", "green", "green", "green", "green"],
  ["yellow", "green", "green", "green", "yellow"],
  ["yellow", "green", "green", "green", "green"],
  ["yellow", "green", "green", "green", "green"],
  ["yellow", "green", "green", "green", "green"],
  ["yellow", "green", "green", "green", "green"],
  ["yellow", "green", "green", "green", "yellow"],
  ["blue", "green", "green", "green", "green"],
  ["yellow", "blue", "red", "yellow", "red"],
  ["yellow", "green", "green", "green", "yellow"],
  ["blue", "green", "blue", "red", "red"],
  ["yellow", "green", "green", "green", "red"],
  ["yellow", "green", "green", "blue", "green"],
  ["yellow", "green", "green", "green", "green"],
  ["yellow", "green", "green", "green", "yellow"],
  ["blue", "green", "green", "green", "green"],
  ["yellow", "green", "green", "green", "green"],
  ["yellow", "green", "red", "red", "yellow"],
  ["yellow", "green", "green", "green", "green"],
  ["blue", "green", "green", "green", "green"],
  ["yellow", "green", "green", "green", "blue"],
];

const MONTH_INDEX = {
  january: "JAN",
  february: "FEB",
  march: "MAR",
  april: "APR",
  may: "MAY",
  june: "JUN",
  july: "JUL",
  august: "AUG",
  september: "SEP",
  october: "OCT",
  november: "NOV",
  december: "DEC",
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function representativeValue(group, color) {
  const lookup = {
    practical: { red: 48, yellow: 68, blue: 83, green: 95 },
    theory: { red: 34, yellow: 44, blue: 55, green: 72 },
    attendance: { red: 74, yellow: 84, blue: 92, green: 97 },
  };
  return lookup[group]?.[color] ?? null;
}

function metricGroup(metricKey) {
  return METRICS.find((metric) => metric.key === metricKey)?.group ?? "theory";
}

function createEmptyMetricSet() {
  return { PS: null, PK: null, ES: null, WCS: null, AT: null };
}

function createRecords(studentCount, monthCount = 12) {
  return Array.from({ length: monthCount }, () =>
    Array.from({ length: studentCount }, () => createEmptyMetricSet()),
  );
}

function createSampleRecords(studentCount, monthCount = 12) {
  const records = createRecords(studentCount, monthCount);
  const sampleMonthIndex = 1;
  for (let studentIndex = 0; studentIndex < Math.min(studentCount, SAMPLE_MONTH_COLOR_ROWS.length); studentIndex += 1) {
    const colors = SAMPLE_MONTH_COLOR_ROWS[studentIndex];
    METRICS.forEach((metric, metricIndex) => {
      records[sampleMonthIndex][studentIndex][metric.key] = representativeValue(metric.group, colors[metricIndex]);
    });
  }
  return records;
}

function createDefaultState() {
  return {
    header: {
      institution: "GOVT. ITI PANNIYANNORE",
      title: "TRAINEES PROGRESS & ATTENDANCE CHART",
      trade: "DCIVIL",
      academicYear: "2025-26",
      shift: "SHIFT 1",
      unit: "1",
    },
    months: DEFAULT_MONTHS.map((label) => ({ label })),
    selectedHalf: 0,
    selectedMonth: 1,
    students: DEFAULT_STUDENTS.map((student, index) => ({
      id: `student-${index + 1}`,
      name: student.name,
      admission: student.admission,
    })),
    rules: clone(DEFAULT_RULES),
    records: createSampleRecords(DEFAULT_STUDENTS.length, DEFAULT_MONTHS.length),
  };
}

function normaliseMonth(value, fallback) {
  const label = typeof value?.label === "string" && value.label.trim() ? value.label.trim() : fallback;
  return { label };
}

function normaliseStudent(value, index) {
  const fallback = DEFAULT_STUDENTS[index] ?? { name: `Trainee ${index + 1}`, admission: "" };
  const name = typeof value?.name === "string" && value.name.trim() ? value.name.trim() : fallback.name;
  const admission = typeof value?.admission === "string" ? value.admission.trim() : fallback.admission;
  return {
    id: typeof value?.id === "string" && value.id.trim() ? value.id.trim() : `student-${index + 1}`,
    name,
    admission,
  };
}

function normaliseNumeric(value) {
  if (value === null || value === undefined || value === "") return null;
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return null;
  return Math.max(0, Math.min(100, Math.round(numeric)));
}

function normaliseRules(inputRules) {
  const safeRules = clone(DEFAULT_RULES);
  for (const group of Object.keys(safeRules)) {
    if (!Array.isArray(inputRules?.[group])) continue;
    safeRules[group] = inputRules[group].map((entry, index) => ({
      color: COLOR_ORDER[index] ?? safeRules[group][index]?.color ?? "red",
      min: normaliseNumeric(entry?.min) ?? safeRules[group][index].min,
      max: normaliseNumeric(entry?.max) ?? safeRules[group][index].max,
    }));
  }
  return safeRules;
}

function normaliseRecords(inputRecords, students, months) {
  const fallback = createSampleRecords(students.length, months.length);
  return months.map((_, monthIndex) =>
    students.map((_, studentIndex) => {
      const source = inputRecords?.[monthIndex]?.[studentIndex] ?? fallback[monthIndex][studentIndex] ?? createEmptyMetricSet();
      const record = createEmptyMetricSet();
      for (const metric of METRICS) {
        record[metric.key] = normaliseNumeric(source?.[metric.key]);
      }
      return record;
    }),
  );
}

function ensureState(input) {
  const defaults = createDefaultState();
  const header = {
    institution:
      typeof input?.header?.institution === "string" && input.header.institution.trim()
        ? input.header.institution.trim()
        : defaults.header.institution,
    title:
      typeof input?.header?.title === "string" && input.header.title.trim()
        ? input.header.title.trim()
        : defaults.header.title,
    trade:
      typeof input?.header?.trade === "string" && input.header.trade.trim()
        ? input.header.trade.trim()
        : defaults.header.trade,
    academicYear:
      typeof input?.header?.academicYear === "string" && input.header.academicYear.trim()
        ? input.header.academicYear.trim()
        : defaults.header.academicYear,
    shift:
      typeof input?.header?.shift === "string" && input.header.shift.trim()
        ? input.header.shift.trim()
        : defaults.header.shift,
    unit:
      typeof input?.header?.unit === "string" && input.header.unit.trim()
        ? input.header.unit.trim()
        : defaults.header.unit,
  };

  const months = DEFAULT_MONTHS.map((label, index) => normaliseMonth(input?.months?.[index], label));
  const students = (Array.isArray(input?.students) && input.students.length ? input.students : defaults.students).map((student, index) =>
    normaliseStudent(student, index),
  );

  const selectedHalf = Number.isInteger(input?.selectedHalf) ? Math.max(0, Math.min(1, input.selectedHalf)) : defaults.selectedHalf;
  const selectedMonth = Number.isInteger(input?.selectedMonth) ? Math.max(0, Math.min(11, input.selectedMonth)) : defaults.selectedMonth;
  const rules = normaliseRules(input?.rules);
  const records = normaliseRecords(input?.records, students, months);

  return { header, months, students, selectedHalf, selectedMonth, rules, records };
}

function formatDisplayMonth(label) {
  return String(label ?? "").trim().toUpperCase();
}

function toRangeFragment(label) {
  const safe = String(label ?? "").trim();
  const match = safe.match(/^([A-Za-z]+)\s+(\d{4})$/);
  if (!match) return safe.toUpperCase();
  const monthKey = match[1].toLowerCase();
  return `${MONTH_INDEX[monthKey] ?? match[1].slice(0, 3).toUpperCase()} ${match[2]}`;
}

function getHalfMonths(months, halfIndex) {
  const offset = halfIndex === 1 ? 6 : 0;
  return months.slice(offset, offset + 6);
}

function getHalfRangeLabel(months, halfIndex) {
  const halfMonths = getHalfMonths(months, halfIndex);
  if (!halfMonths.length) return "";
  const first = toRangeFragment(halfMonths[0].label);
  const last = toRangeFragment(halfMonths[halfMonths.length - 1].label);
  return `${first} - ${last}`;
}

function serializeRoster(students) {
  return students.map((student) => `${student.name} | ${student.admission}`).join("\n");
}

function parseRoster(text) {
  const lines = String(text ?? "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  return lines.map((line, index) => {
    const parts = line.split("|").map((part) => part.trim());
    if (parts.length >= 2) {
      return { id: `student-${index + 1}`, name: parts[0], admission: parts.slice(1).join(" | ") };
    }

    const tabParts = line.split("\t").map((part) => part.trim()).filter(Boolean);
    if (tabParts.length >= 2) {
      return { id: `student-${index + 1}`, name: tabParts[0], admission: tabParts.slice(1).join(" ") };
    }

    return { id: `student-${index + 1}`, name: line, admission: "" };
  });
}

function getMetricColor(metricKey, value, rules) {
  if (value === null || value === undefined || value === "") return "empty";
  const group = metricGroup(metricKey);
  const numeric = normaliseNumeric(value);
  if (numeric === null) return "empty";
  const bands = rules?.[group] ?? DEFAULT_RULES[group];
  const match = bands.find((band) => numeric >= band.min && numeric <= band.max);
  return match?.color ?? bands[bands.length - 1]?.color ?? "green";
}

function getMetricDescription(metricKey) {
  return METRICS.find((metric) => metric.key === metricKey)?.label ?? metricKey;
}

function getMainLayout(studentCount) {
  const page = PAGE_SIZES.main;
  const margins = { left: 8, right: 8, top: 7, bottom: 7 };
  const header = { institution: 7, title: 8, meta: 9, month: 6.5, metric: 6.5 };
  const legendsHeight = 39;
  const bodyGap = 5;
  const fixedColumns = { serial: 10.5, name: 76, admission: 21 };
  const innerWidth = page.widthMm - margins.left - margins.right;
  const metricsWidth = innerWidth - fixedColumns.serial - fixedColumns.name - fixedColumns.admission;
  const metricColumnWidth = metricsWidth / (6 * METRICS.length);
  const availableBodyHeight =
    page.heightMm -
    margins.top -
    margins.bottom -
    header.institution -
    header.title -
    header.meta -
    header.month -
    header.metric -
    legendsHeight -
    bodyGap;

  return {
    page,
    margins,
    header,
    legendsHeight,
    bodyGap,
    fixedColumns,
    metricColumnWidth,
    rowHeight: availableBodyHeight / Math.max(studentCount, 1),
    innerWidth,
  };
}

function getMonthlyLayout(studentCount) {
  const page = PAGE_SIZES.monthly;
  const panel = getMonthPanelLayout(studentCount);

  return {
    page,
    panel,
    offsetX: (page.widthMm - panel.widthMm) / 2,
    offsetY: (page.heightMm - panel.heightMm) / 2,
  };
}

function getMonthPanelLayout(studentCount) {
  const main = getMainLayout(studentCount);
  const widthMm = main.metricColumnWidth * METRICS.length;
  const heightMm = main.header.month + main.header.metric + main.rowHeight * Math.max(studentCount, 1);

  return {
    widthMm,
    heightMm,
    header: {
      month: main.header.month,
      metric: main.header.metric,
    },
    metricColumnWidth: main.metricColumnWidth,
    rowHeight: main.rowHeight,
  };
}

function getLegendData(rules) {
  return COLOR_ORDER.map((color) => ({
    color,
    practical: rules.practical.find((band) => band.color === color),
    theory: rules.theory.find((band) => band.color === color),
    attendance: rules.attendance.find((band) => band.color === color),
  }));
}

function formatBandText(band, suffix = "%") {
  if (!band) return "";
  if (band.min === band.max) return `${band.min}${suffix}`;
  if (band.min <= 0) return `< ${band.max + 1}${suffix}`;
  if (band.max >= 100) return `${band.min}${suffix} and above`;
  return `${band.min}${suffix} to ${band.max}${suffix}`;
}

globalThis.ProgressChartShared = {
  PAGE_SIZES,
  METRICS,
  COLOR_ORDER,
  COLOR_STYLES,
  DEFAULT_RULES,
  DEFAULT_MONTHS,
  DEFAULT_STUDENTS,
  createEmptyMetricSet,
  createRecords,
  createDefaultState,
  ensureState,
  formatDisplayMonth,
  getHalfMonths,
  getHalfRangeLabel,
  serializeRoster,
  parseRoster,
  getMetricColor,
  getMetricDescription,
  getMainLayout,
  getMonthPanelLayout,
  getMonthlyLayout,
  getLegendData,
  formatBandText,
};
})();
