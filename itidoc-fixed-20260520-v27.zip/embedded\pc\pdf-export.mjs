(function () {
const {
  COLOR_STYLES,
  METRICS,
  PAGE_SIZES,
  ensureState,
  formatBandText,
  formatDisplayMonth,
  getHalfMonths,
  getHalfRangeLabel,
  getLegendData,
  getMainLayout,
  getMonthPanelLayout,
  getMetricColor,
  getMetricDescription,
  getMonthlyLayout,
} = globalThis.ProgressChartShared;

const PT_PER_MM = 72 / 25.4;
const GRID_HEX = "#1f2c3d";
const ACCENT_HEX = "#1c5f71";
const META_FILL_HEX = "#f4fbf9";
const RANGE_FILL_HEX = "#fbf7e8";
const MONTH_FILL_HEX = "#f3f8ff";

function getPdfLib() {
  const lib = globalThis.PDFLib;
  if (!lib) {
    throw new Error("PDF library is not loaded.");
  }
  return lib;
}

function mm(value) {
  return value * PT_PER_MM;
}

function yFromTop(pageHeightMm, topMm, heightMm) {
  return mm(pageHeightMm - topMm - heightMm);
}

function colorFromHex(hex) {
  const { rgb } = getPdfLib();
  const safe = hex.replace("#", "");
  const value = safe.length === 3 ? safe.split("").map((part) => part + part).join("") : safe;
  return rgb(
    parseInt(value.slice(0, 2), 16) / 255,
    parseInt(value.slice(2, 4), 16) / 255,
    parseInt(value.slice(4, 6), 16) / 255,
  );
}

const GRID = () => colorFromHex(GRID_HEX);
const ACCENT = () => colorFromHex(ACCENT_HEX);
const META_FILL = () => colorFromHex(META_FILL_HEX);
const RANGE_FILL = () => colorFromHex(RANGE_FILL_HEX);
const MONTH_FILL = () => colorFromHex(MONTH_FILL_HEX);

function fitFont(font, text, maxWidthPt, startSize, minSize = 5) {
  let size = startSize;
  while (size > minSize && font.widthOfTextAtSize(text, size) > maxWidthPt) {
    size -= 0.2;
  }
  return size;
}

function drawBox(page, pageHeightMm, xMm, topMm, widthMm, heightMm, options = {}) {
  page.drawRectangle({
    x: mm(xMm),
    y: yFromTop(pageHeightMm, topMm, heightMm),
    width: mm(widthMm),
    height: mm(heightMm),
    borderColor: options.borderColor ?? GRID(),
    borderWidth: options.borderWidth ?? 0.8,
    color: options.fillColor,
    opacity: options.opacity ?? 1,
  });
}

function drawTextInBox(page, pageHeightMm, text, box, options = {}) {
  const safeText = String(text ?? "").trim();
  if (!safeText) return;

  const paddingMm = options.paddingMm ?? 1.4;
  const font = options.font;
  const baseSize = options.size ?? 10;
  const minSize = options.minSize ?? 4.5;
  const align = options.align ?? "center";
  const maxWidthPt = Math.max(mm(box.widthMm - paddingMm * 2), 6);
  const fontSize = fitFont(font, safeText, maxWidthPt, baseSize, minSize);
  const textWidth = font.widthOfTextAtSize(safeText, fontSize);
  const textHeight = font.heightAtSize(fontSize);

  let xPt = mm(box.xMm + paddingMm);
  if (align === "center") {
    xPt = mm(box.xMm) + (mm(box.widthMm) - textWidth) / 2;
  } else if (align === "right") {
    xPt = mm(box.xMm + box.widthMm - paddingMm) - textWidth;
  }

  const bottomPt = yFromTop(pageHeightMm, box.topMm, box.heightMm);
  const yPt = bottomPt + (mm(box.heightMm) - textHeight) / 2 + fontSize * 0.12;

  page.drawText(safeText, {
    x: xPt,
    y: yPt,
    size: fontSize,
    font,
    color: options.color ?? GRID(),
  });
}

function drawCircle(page, pageHeightMm, centerXMm, centerYMm, radiusMm, colorName) {
  const style = COLOR_STYLES[colorName] ?? COLOR_STYLES.empty;
  page.drawCircle({
    x: mm(centerXMm),
    y: mm(pageHeightMm - centerYMm),
    size: mm(radiusMm),
    borderColor: GRID(),
    borderWidth: 0.8,
    color: colorName === "empty" ? undefined : colorFromHex(style.fill),
  });
}

function drawLine(page, pageHeightMm, startXMm, startYMm, endXMm, endYMm, thickness = 0.8) {
  page.drawLine({
    start: { x: mm(startXMm), y: mm(pageHeightMm - startYMm) },
    end: { x: mm(endXMm), y: mm(pageHeightMm - endYMm) },
    thickness,
    color: GRID(),
  });
}

function drawCropMarks(page, pageHeightMm, xMm, topMm, widthMm, heightMm) {
  const markLength = 4;
  const markOffset = 1.8;
  const left = xMm;
  const right = xMm + widthMm;
  const bottom = topMm + heightMm;

  drawLine(page, pageHeightMm, left - markOffset - markLength, topMm, left - markOffset, topMm, 0.65);
  drawLine(page, pageHeightMm, left, topMm - markOffset - markLength, left, topMm - markOffset, 0.65);

  drawLine(page, pageHeightMm, right + markOffset, topMm, right + markOffset + markLength, topMm, 0.65);
  drawLine(page, pageHeightMm, right, topMm - markOffset - markLength, right, topMm - markOffset, 0.65);

  drawLine(page, pageHeightMm, left - markOffset - markLength, bottom, left - markOffset, bottom, 0.65);
  drawLine(page, pageHeightMm, left, bottom + markOffset, left, bottom + markOffset + markLength, 0.65);

  drawLine(page, pageHeightMm, right + markOffset, bottom, right + markOffset + markLength, bottom, 0.65);
  drawLine(page, pageHeightMm, right, bottom + markOffset, right, bottom + markOffset + markLength, 0.65);
}

function legendLabel(group, band) {
  if (!band) return "";
  if (group === "practical") {
    if (band.min <= 0) return `Practical < ${band.max + 1}%`;
    if (band.max >= 100) return `Practical ${band.min}% and above`;
    return `Practical ${band.min}% to ${band.max}%`;
  }
  if (group === "attendance") {
    if (band.min <= 0) return `Attendance below ${band.max + 1}%`;
    if (band.max >= 100) return `Attendance ${band.min}% to ${band.max}%`;
    return `Attendance ${band.min}% to ${band.max}%`;
  }
  if (band.min <= 0) return `ES / WCS / ED < ${band.max + 1}%`;
  if (band.max >= 100) return `ES / WCS / ED ${band.min}% and above`;
  return `ES / WCS / ED ${band.min}% to ${band.max}%`;
}

function drawMainPage(page, fonts, state, halfIndex, options = {}) {
  const layout = getMainLayout(state.students.length);
  const pageHeightMm = PAGE_SIZES.main.heightMm;
  const left = layout.margins.left;
  const right = left + layout.innerWidth;
  const rangeWidth = 52;
  const titleWidth = layout.innerWidth - rangeWidth;
  const rangeLabel = getHalfRangeLabel(state.months, halfIndex);
  const months = getHalfMonths(state.months, halfIndex);
  const monthOffset = halfIndex * 6;

  let top = layout.margins.top;

  drawBox(page, pageHeightMm, left, top, titleWidth, layout.header.institution, { borderWidth: 0.9 });
  drawBox(page, pageHeightMm, left + titleWidth, top, rangeWidth, layout.header.institution + layout.header.title, {
    fillColor: RANGE_FILL(),
    borderWidth: 0.9,
  });
  drawTextInBox(
    page,
    pageHeightMm,
    state.header.institution.toUpperCase(),
    { xMm: left, topMm: top, widthMm: titleWidth, heightMm: layout.header.institution },
    { font: fonts.bold, size: 14, color: ACCENT() },
  );

  top += layout.header.institution;
  drawBox(page, pageHeightMm, left, top, titleWidth, layout.header.title, { borderWidth: 0.9 });
  drawTextInBox(
    page,
    pageHeightMm,
    state.header.title.toUpperCase(),
    { xMm: left, topMm: top, widthMm: titleWidth, heightMm: layout.header.title },
    { font: fonts.bold, size: 16 },
  );
  drawTextInBox(
    page,
    pageHeightMm,
    rangeLabel,
    { xMm: left + titleWidth, topMm: layout.margins.top, widthMm: rangeWidth, heightMm: layout.header.institution + layout.header.title },
    { font: fonts.bold, size: 10.5 },
  );

  top += layout.header.title;
  const metaColumns = [148, 132, 62, 62];
  const metaLabels = [
    `TRADE : ${state.header.trade}`,
    `YEAR : ${state.header.academicYear}`,
    `SHIFT : ${state.header.shift}`,
    `UNIT : ${state.header.unit}`,
  ];

  let metaX = left;
  metaColumns.forEach((widthMm, index) => {
    drawBox(page, pageHeightMm, metaX, top, widthMm, layout.header.meta, { fillColor: META_FILL(), borderWidth: 0.9 });
    drawTextInBox(
      page,
      pageHeightMm,
      metaLabels[index],
      { xMm: metaX, topMm: top, widthMm, heightMm: layout.header.meta },
      { font: fonts.bold, size: 10.5, color: index === 0 || index === 1 ? colorFromHex("#c2272d") : ACCENT(), align: index === 0 ? "left" : "center", paddingMm: 2 },
    );
    metaX += widthMm;
  });

  top += layout.header.meta;

  const fixed = layout.fixedColumns;
  const headerTotalHeight = layout.header.month + layout.header.metric;
  drawBox(page, pageHeightMm, left, top, fixed.serial, headerTotalHeight, { borderWidth: 0.9 });
  drawTextInBox(page, pageHeightMm, "SL.NO", { xMm: left, topMm: top, widthMm: fixed.serial, heightMm: headerTotalHeight }, {
    font: fonts.bold,
    size: 6.3,
  });

  drawBox(page, pageHeightMm, left + fixed.serial, top, fixed.name, headerTotalHeight, { borderWidth: 0.9 });
  drawTextInBox(
    page,
    pageHeightMm,
    "NAME OF TRAINEE",
    { xMm: left + fixed.serial, topMm: top, widthMm: fixed.name, heightMm: headerTotalHeight },
    { font: fonts.bold, size: 8.8 },
  );

  drawBox(page, pageHeightMm, left + fixed.serial + fixed.name, top, fixed.admission, headerTotalHeight, { borderWidth: 0.9 });
  drawTextInBox(
    page,
    pageHeightMm,
    "AD NO.",
    { xMm: left + fixed.serial + fixed.name, topMm: top, widthMm: fixed.admission, heightMm: headerTotalHeight },
    { font: fonts.bold, size: 7.6 },
  );

  let metricsStartX = left + fixed.serial + fixed.name + fixed.admission;
  months.forEach((month, monthIndex) => {
    const monthWidth = layout.metricColumnWidth * METRICS.length;
    drawBox(page, pageHeightMm, metricsStartX, top, monthWidth, layout.header.month, {
      fillColor: MONTH_FILL(),
      borderWidth: 0.9,
    });
    drawTextInBox(
      page,
      pageHeightMm,
      formatDisplayMonth(month.label),
      { xMm: metricsStartX, topMm: top, widthMm: monthWidth, heightMm: layout.header.month },
      { font: fonts.bold, size: 7.8 },
    );

    METRICS.forEach((metric, metricIndex) => {
      const cellX = metricsStartX + metricIndex * layout.metricColumnWidth;
      drawBox(page, pageHeightMm, cellX, top + layout.header.month, layout.metricColumnWidth, layout.header.metric, {
        borderWidth: 0.8,
      });
      drawTextInBox(
        page,
        pageHeightMm,
        metric.short,
        { xMm: cellX, topMm: top + layout.header.month, widthMm: layout.metricColumnWidth, heightMm: layout.header.metric },
        { font: fonts.bold, size: 6.5 },
      );
    });

    metricsStartX += monthWidth;
    if (monthIndex < months.length - 1) {
      drawLine(page, pageHeightMm, metricsStartX, top, metricsStartX, top + headerTotalHeight + state.students.length * layout.rowHeight, 1.15);
    }
  });

  const bodyTop = top + headerTotalHeight;
  state.students.forEach((student, studentIndex) => {
    const rowTop = bodyTop + studentIndex * layout.rowHeight;
    drawBox(page, pageHeightMm, left, rowTop, fixed.serial, layout.rowHeight, { borderWidth: 0.8 });
    drawBox(page, pageHeightMm, left + fixed.serial, rowTop, fixed.name, layout.rowHeight, { borderWidth: 0.8 });
    drawBox(page, pageHeightMm, left + fixed.serial + fixed.name, rowTop, fixed.admission, layout.rowHeight, { borderWidth: 0.8 });

    drawTextInBox(
      page,
      pageHeightMm,
      String(studentIndex + 1),
      { xMm: left, topMm: rowTop, widthMm: fixed.serial, heightMm: layout.rowHeight },
      { font: fonts.bold, size: 8.3 },
    );
    drawTextInBox(
      page,
      pageHeightMm,
      student.name.toUpperCase(),
      { xMm: left + fixed.serial, topMm: rowTop, widthMm: fixed.name, heightMm: layout.rowHeight },
      { font: fonts.bold, size: 7.4, paddingMm: 1.8 },
    );
    drawTextInBox(
      page,
      pageHeightMm,
      student.admission,
      { xMm: left + fixed.serial + fixed.name, topMm: rowTop, widthMm: fixed.admission, heightMm: layout.rowHeight },
      { font: fonts.bold, size: 7.1 },
    );

    METRICS.forEach((metric, metricIndex) => {
      months.forEach((_, monthSlot) => {
        const absoluteMonthIndex = monthOffset + monthSlot;
        const record = state.records?.[absoluteMonthIndex]?.[studentIndex];
        const cellX =
          left +
          fixed.serial +
          fixed.name +
          fixed.admission +
          monthSlot * METRICS.length * layout.metricColumnWidth +
          metricIndex * layout.metricColumnWidth;

        drawBox(page, pageHeightMm, cellX, rowTop, layout.metricColumnWidth, layout.rowHeight, { borderWidth: 0.65 });

        const color = options.withColors === false ? "empty" : getMetricColor(metric.key, record?.[metric.key], state.rules);
        const radius = Math.min(layout.metricColumnWidth, layout.rowHeight) * 0.31;
        drawCircle(page, pageHeightMm, cellX + layout.metricColumnWidth / 2, rowTop + layout.rowHeight / 2, radius, color);
      });
    });
  });

  const legendTop = bodyTop + state.students.length * layout.rowHeight + layout.bodyGap;
  const leftLegendWidth = 120;
  const legendGap = 6;
  const legendRowHeight = 7.4;
  const definitions = [
    "PS : PRACTICAL SKILL",
    "PK : PRACTICAL KNOWLEDGE",
    "ES : EMPLOYABILITY SKILLS",
    "WCS : WORKSHOP CALCULATION & SCIENCE",
    "AT : ATTENDANCE PERCENTAGE",
  ];

  definitions.forEach((text, index) => {
    drawBox(page, pageHeightMm, left, legendTop + index * legendRowHeight, leftLegendWidth, legendRowHeight, { borderWidth: 0.8 });
    drawTextInBox(
      page,
      pageHeightMm,
      text,
      { xMm: left, topMm: legendTop + index * legendRowHeight, widthMm: leftLegendWidth, heightMm: legendRowHeight },
      { font: fonts.bold, size: 6.6, align: "left", paddingMm: 2 },
    );
  });

  const legendX = left + leftLegendWidth + legendGap;
  const legendWidth = right - legendX - 1;
  const colorColumn = 40;
  const practicalColumn = 61;
  const theoryColumn = 74;
  const attendanceColumn = legendWidth - colorColumn - practicalColumn - theoryColumn;
  const legendRows = getLegendData(state.rules);

  legendRows.forEach((row, index) => {
    const rowTop = legendTop + index * legendRowHeight;
    drawBox(page, pageHeightMm, legendX, rowTop, colorColumn, legendRowHeight, {
      fillColor: colorFromHex(COLOR_STYLES[row.color].fill),
      borderWidth: 0.8,
    });
    drawTextInBox(
      page,
      pageHeightMm,
      row.color.toUpperCase(),
      { xMm: legendX, topMm: rowTop, widthMm: colorColumn, heightMm: legendRowHeight },
      { font: fonts.bold, size: 8.6, color: row.color === "yellow" ? GRID() : colorFromHex("#ffffff") },
    );

    const practicalX = legendX + colorColumn;
    const theoryX = practicalX + practicalColumn;
    const attendanceX = theoryX + theoryColumn;

    drawBox(page, pageHeightMm, practicalX, rowTop, practicalColumn, legendRowHeight, { borderWidth: 0.8 });
    drawBox(page, pageHeightMm, theoryX, rowTop, theoryColumn, legendRowHeight, { borderWidth: 0.8 });
    drawBox(page, pageHeightMm, attendanceX, rowTop, attendanceColumn, legendRowHeight, { borderWidth: 0.8 });

    drawTextInBox(
      page,
      pageHeightMm,
      legendLabel("practical", row.practical),
      { xMm: practicalX, topMm: rowTop, widthMm: practicalColumn, heightMm: legendRowHeight },
      { font: fonts.bold, size: 6.9 },
    );
    drawTextInBox(
      page,
      pageHeightMm,
      legendLabel("theory", row.theory),
      { xMm: theoryX, topMm: rowTop, widthMm: theoryColumn, heightMm: legendRowHeight },
      { font: fonts.bold, size: 6.7 },
    );
    drawTextInBox(
      page,
      pageHeightMm,
      legendLabel("attendance", row.attendance),
      { xMm: attendanceX, topMm: rowTop, widthMm: attendanceColumn, heightMm: legendRowHeight },
      { font: fonts.bold, size: 6.7 },
    );
  });
}

function drawMonthPanel(page, fonts, state, monthIndex, xMm, topMm, options = {}) {
  const panel = getMonthPanelLayout(state.students.length);
  const pageHeightMm = PAGE_SIZES.monthly.heightMm;
  const monthLabel = state.months[monthIndex]?.label ?? `Month ${monthIndex + 1}`;

  const monthWidth = panel.metricColumnWidth * METRICS.length;
  drawBox(page, pageHeightMm, xMm, topMm, monthWidth, panel.header.month, {
    fillColor: MONTH_FILL(),
    borderWidth: 0.95,
  });
  drawTextInBox(
    page,
    pageHeightMm,
    formatDisplayMonth(monthLabel),
    { xMm, topMm, widthMm: monthWidth, heightMm: panel.header.month },
    { font: fonts.bold, size: 7.8 },
  );

  METRICS.forEach((metric, metricIndex) => {
    const cellX = xMm + metricIndex * panel.metricColumnWidth;
    drawBox(page, pageHeightMm, cellX, topMm + panel.header.month, panel.metricColumnWidth, panel.header.metric, {
      borderWidth: 0.85,
    });
    drawTextInBox(
      page,
      pageHeightMm,
      metric.short,
      { xMm: cellX, topMm: topMm + panel.header.month, widthMm: panel.metricColumnWidth, heightMm: panel.header.metric },
      { font: fonts.bold, size: 6.5 },
    );
  });

  const bodyTop = topMm + panel.header.month + panel.header.metric;
  state.students.forEach((student, studentIndex) => {
    const rowTop = bodyTop + studentIndex * panel.rowHeight;
    const record = state.records?.[monthIndex]?.[studentIndex];
    METRICS.forEach((metric, metricIndex) => {
      const cellX = xMm + metricIndex * panel.metricColumnWidth;
      const color = options.withColors === false ? "empty" : getMetricColor(metric.key, record?.[metric.key], state.rules);
      drawBox(page, pageHeightMm, cellX, rowTop, panel.metricColumnWidth, panel.rowHeight, {
        borderWidth: 0.85,
      });
      const radius = Math.min(panel.metricColumnWidth, panel.rowHeight) * 0.31;
      drawCircle(page, pageHeightMm, cellX + panel.metricColumnWidth / 2, rowTop + panel.rowHeight / 2, radius, color);
    });
  });
}

function drawMonthlyPage(page, fonts, state, monthIndex, options = {}) {
  const layout = getMonthlyLayout(state.students.length);
  const pageHeightMm = PAGE_SIZES.monthly.heightMm;
  drawCropMarks(page, pageHeightMm, layout.offsetX, layout.offsetY, layout.panel.widthMm, layout.panel.heightMm);
  drawMonthPanel(page, fonts, state, monthIndex, layout.offsetX, layout.offsetY, options);
}

async function prepareDocument() {
  const { PDFDocument, StandardFonts } = getPdfLib();
  const doc = await PDFDocument.create();
  const fonts = {
    regular: await doc.embedFont(StandardFonts.Helvetica),
    bold: await doc.embedFont(StandardFonts.HelveticaBold),
  };
  return { doc, fonts };
}

async function createMainPdfBytes(rawState, halfIndex = 0, options = {}) {
  const state = ensureState(rawState);
  const { doc, fonts } = await prepareDocument();
  const page = doc.addPage([PAGE_SIZES.main.widthPt, PAGE_SIZES.main.heightPt]);
  drawMainPage(page, fonts, state, halfIndex, options);
  return await doc.save();
}

async function createAllMainPdfBytes(rawState, options = {}) {
  const state = ensureState(rawState);
  const { doc, fonts } = await prepareDocument();
  for (let halfIndex = 0; halfIndex < 2; halfIndex += 1) {
    const page = doc.addPage([PAGE_SIZES.main.widthPt, PAGE_SIZES.main.heightPt]);
    drawMainPage(page, fonts, state, halfIndex, options);
  }
  return await doc.save();
}

async function createMonthlyPdfBytes(rawState, monthIndex = 0, options = {}) {
  const state = ensureState(rawState);
  const { doc, fonts } = await prepareDocument();
  const page = doc.addPage([PAGE_SIZES.monthly.widthPt, PAGE_SIZES.monthly.heightPt]);
  drawMonthlyPage(page, fonts, state, monthIndex, options);
  return await doc.save();
}

function buildDownloadName(type, state, index = 0) {
  if (type === "main-half") return `progress-chart-half-${index + 1}.pdf`;
  if (type === "main-half-blank") return `progress-chart-half-${index + 1}-blank.pdf`;
  if (type === "main-all") return "progress-chart-main-sheets.pdf";
  if (type === "main-all-blank") return "progress-chart-main-sheets-blank.pdf";
  const label = state.months[index]?.label ?? `month-${index + 1}`;
  const safeLabel = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  return `progress-chart-${safeLabel || `month-${index + 1}`}.pdf`;
}

function downloadPdfBytes(bytes, filename) {
  const blob = new Blob([bytes], { type: "application/pdf" });
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = objectUrl;
  anchor.download = filename;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(objectUrl);
}

function exportSummary(state) {
  return {
    months: state.months.map((month) => month.label),
    students: state.students.length,
    practicalLegend: getLegendData(state.rules).map((row) => formatBandText(row.practical)),
  };
}

globalThis.ProgressChartPdf = {
  createMainPdfBytes,
  createAllMainPdfBytes,
  createMonthlyPdfBytes,
  buildDownloadName,
  downloadPdfBytes,
  exportSummary,
  getMetricDescription,
};
})();
