const STORAGE_KEY = "iti-progress-card-state-v2";
const PORTAL_APP_NAME = "progressCard";
const NIMMI_RANKLIST_STORAGE_KEY = "iti-miscellaneous-ranklist-v1";
const ANNEXURE_STORAGE_KEY = "annex-ii-site-state-v2";
const { downloadWordDocument } = window.OfficeExport;
const ATTENDANCE_STORAGE_KEYS = [
  "attendance-tracker-state-v4",
  "attendance-tracker-state-v3",
  "attendance-tracker-state-v2",
  "attendance-tracker-state-v1",
];
const A4_PORTRAIT_POINTS = Object.freeze([595.28, 841.89]);
const PROGRESS_WORD_EXPORT_STYLES = `
  @page {
    size: A4 portrait !important;
    margin: 0 !important;
  }

  body.office-export {
    padding: 0 !important;
  }

  .office-export section {
    margin: 0 !important;
    padding: 0 !important;
  }

  .office-export .progress-page {
    box-shadow: none !important;
    margin: 0 auto !important;
    background: #ffffff !important;
    overflow: hidden !important;
  }
`;

document.documentElement.classList.toggle("is-embedded", window.parent !== window);
document.body.classList.toggle("is-embedded", window.parent !== window);

const COLUMN_WIDTHS = [
  525, 745, 612, 522, 660, 747, 617, 615, 631, 522, 523, 607, 607, 616, 667,
  732, 833,
];

const STUDENT_FIELDS = [
  { key: "instituteName", label: "Institute Name" },
  { key: "name", label: "Name of Trainee" },
  { key: "trade", label: "Trade" },
  { key: "admissionNo", label: "Admn. No." },
  { key: "admissionDate", label: "Date of admission" },
  { key: "aadhaarNo", label: "Aadhaar No" },
  { key: "misRegNo", label: "MIS Reg. No." },
  { key: "qualification", label: "Educational Qualification" },
  { key: "traineePhone", label: "Trainee's Phone No" },
  { key: "guardianName", label: "Name of Guardian" },
  { key: "guardianPhone", label: "Guardian's Phone No" },
  { key: "address", label: "Address", multiline: true, full: true },
];

const MONTHLY_COLUMNS = [
  { key: "possible", label: "Possible" },
  { key: "present", label: "Present" },
  { key: "cumPossible", label: "Cum. Possible" },
  { key: "cumPresent", label: "Cum. Present" },
  { key: "percentage", label: "Percentage" },
  { key: "profSkill", label: "Prof. skill" },
  { key: "profKnowledge", label: "Prof. knowledge" },
  { key: "enggDrg", label: "Engg. Drg." },
  { key: "wcs", label: "WCS" },
  { key: "es", label: "ES" },
  { key: "total", label: "Total" },
  { key: "instructorInitials", label: "Initials of instructor" },
  { key: "giInitials", label: "Initials of GI" },
  { key: "vpPrlInitials", label: "Initials of VP/PRL" },
  { key: "guardianSignature", label: "Signature of Guardian" },
];
const MONTHLY_ATTENDANCE_KEYS = new Set([
  "possible",
  "present",
  "cumPossible",
  "cumPresent",
  "percentage",
]);
const MONTHLY_SIGNATURE_KEYS = new Set([
  "instructorInitials",
  "giInitials",
  "vpPrlInitials",
  "guardianSignature",
]);
const MONTHLY_EDITOR_HIDDEN_KEYS = new Set([
  ...MONTHLY_ATTENDANCE_KEYS,
  ...MONTHLY_SIGNATURE_KEYS,
  "enggDrg",
]);
const MONTHLY_EDITOR_COLUMNS = MONTHLY_COLUMNS.filter(
  (column) => !MONTHLY_EDITOR_HIDDEN_KEYS.has(column.key),
);

const HALF_YEARLY_COLUMNS = [
  { key: "possible", label: "Poss." },
  { key: "present", label: "Pre." },
  { key: "percentage", label: "%" },
  { key: "formative", label: "Formative Assessment (100)" },
  { key: "conduct", label: "Conduct" },
  { key: "traineeSignature", label: "Sig. of Trainee" },
  { key: "instructorSignature", label: "Sig. of Instr." },
  { key: "giSignature", label: "Sig. of GI" },
  { key: "vpPrlSignature", label: "Sig. of VP/PRL" },
];
const HALF_YEARLY_ATTENDANCE_KEYS = new Set(["possible", "present", "percentage"]);

const MONTH_LAYOUT = [
  { term: "H1", month: "Aug." },
  { term: "H1", month: "Sept." },
  { term: "H1", month: "Oct." },
  { term: "H1", month: "Nov." },
  { term: "H1", month: "Dec." },
  { term: "H1", month: "Jan." },
  { term: "H2", month: "Feb." },
  { term: "H2", month: "Mar" },
  { term: "H2", month: "April" },
  { term: "H2", month: "May" },
  { term: "H2", month: "June" },
  { term: "H2", month: "July" },
];
const DEFAULT_MARKS_WORKSPACE = Object.freeze({
  selectedMonth: MONTH_LAYOUT[0].month,
  nimmiExamIdByMonth: {},
  annexOutcomeKeyByMonth: {},
});
const MONTHLY_MARK_ENTRY_KEYS = ["profSkill", "profKnowledge", "wcs", "es"];

const DEFAULT_STUDENT = {
  instituteName: "GOVT ITI PANNIYANNORE",
  name: "",
  trade: "",
  admissionNo: "",
  admissionDate: "",
  aadhaarNo: "",
  misRegNo: "",
  qualification: "",
  traineePhone: "",
  guardianName: "",
  guardianPhone: "",
  address: "",
};

const DEFAULT_PHOTO = {
  src: "",
  scale: 1,
  x: 50,
  y: 50,
};

const TEMPLATE_HEADERS = [
  "Name of Trainee",
  "Trade",
  "Admn. No.",
  "Date of admission",
  "Aadhaar No.",
  "MIS Reg. No.",
  "Educational Qualification",
  "Trainee's Phone No.",
  "Name of Guardian",
  "Guardian's Phone No.",
  "Address",
];

const FIELD_ALIASES = new Map(
  [
    ["institutename", "instituteName"],
    ["institute", "instituteName"],
    ["nameoftrainee", "name"],
    ["traineename", "name"],
    ["studentname", "name"],
    ["name", "name"],
    ["trade", "trade"],
    ["admnno", "admissionNo"],
    ["admissionno", "admissionNo"],
    ["admn", "admissionNo"],
    ["dateofadmission", "admissionDate"],
    ["admissiondate", "admissionDate"],
    ["aadhaarno", "aadhaarNo"],
    ["aadhaar", "aadhaarNo"],
    ["aadharno", "aadhaarNo"],
    ["misregno", "misRegNo"],
    ["misregistrationno", "misRegNo"],
    ["educationalqualification", "qualification"],
    ["qualification", "qualification"],
    ["traineesphoneno", "traineePhone"],
    ["traineephone", "traineePhone"],
    ["phoneno", "traineePhone"],
    ["nameofguardian", "guardianName"],
    ["guardianname", "guardianName"],
    ["guardiansphoneno", "guardianPhone"],
    ["guardianphone", "guardianPhone"],
    ["address", "address"],
  ]
);

const MONTH_ALIASES = new Map(
  [
    ["aug", "Aug."],
    ["august", "Aug."],
    ["sept", "Sept."],
    ["sep", "Sept."],
    ["september", "Sept."],
    ["oct", "Oct."],
    ["october", "Oct."],
    ["nov", "Nov."],
    ["november", "Nov."],
    ["dec", "Dec."],
    ["december", "Dec."],
    ["jan", "Jan."],
    ["january", "Jan."],
    ["feb", "Feb."],
    ["february", "Feb."],
    ["mar", "Mar"],
    ["march", "Mar"],
    ["apr", "April"],
    ["april", "April"],
    ["may", "May"],
    ["jun", "June"],
    ["june", "June"],
    ["jul", "July"],
    ["july", "July"],
  ]
);

const MONTH_SEARCH_GROUPS = [
  { month: "Aug.", aliases: ["aug", "august"] },
  { month: "Sept.", aliases: ["sept", "sep", "september"] },
  { month: "Oct.", aliases: ["oct", "october"] },
  { month: "Nov.", aliases: ["nov", "november"] },
  { month: "Dec.", aliases: ["dec", "december"] },
  { month: "Jan.", aliases: ["jan", "january"] },
  { month: "Feb.", aliases: ["feb", "february"] },
  { month: "Mar", aliases: ["mar", "march"] },
  { month: "April", aliases: ["apr", "april"] },
  { month: "May", aliases: ["may"] },
  { month: "June", aliases: ["jun", "june"] },
  { month: "July", aliases: ["jul", "july"] },
];

const MONTHLY_IMPORT_PATTERNS = [
  {
    key: "cumPossible",
    aliases: ["cum possible", "cum poss", "cumulative possible"],
  },
  {
    key: "cumPresent",
    aliases: ["cum present", "cum pre", "cumulative present"],
  },
  { key: "percentage", aliases: ["percentage", "percent"] },
  { key: "profKnowledge", aliases: ["prof knowledge", "professional knowledge"] },
  { key: "profSkill", aliases: ["prof skill", "professional skill"] },
  { key: "enggDrg", aliases: ["engg drg", "engg drawing", "engineering drawing"] },
  { key: "wcs", aliases: ["wcs"] },
  { key: "es", aliases: ["es"] },
  { key: "total", aliases: ["total"] },
  { key: "instructorInitials", aliases: ["initials of instructor", "instructor initials"] },
  { key: "giInitials", aliases: ["initials of gi", "gi initials"] },
  { key: "vpPrlInitials", aliases: ["initials of vp prl", "initials of vp/prl", "vp prl initials", "vp/prl initials"] },
  { key: "guardianSignature", aliases: ["signature of guardian", "guardian signature"] },
  { key: "possible", aliases: ["possible", "poss"] },
  { key: "present", aliases: ["present", "pre"] },
];

const HALF_YEARLY_IMPORT_PATTERNS = [
  { key: "possible", aliases: ["possible", "poss"] },
  { key: "present", aliases: ["present", "pre"] },
  { key: "percentage", aliases: ["percentage", "percent"] },
  { key: "formative", aliases: ["formative", "formative assessment", "formative assessment 100"] },
  { key: "conduct", aliases: ["conduct"] },
  { key: "traineeSignature", aliases: ["sig of trainee", "signature of trainee", "trainee signature"] },
  { key: "instructorSignature", aliases: ["sig of instr", "sig of instructor", "signature of instructor", "instructor signature"] },
  { key: "giSignature", aliases: ["sig of gi", "signature of gi", "gi signature"] },
  { key: "vpPrlSignature", aliases: ["sig of vp prl", "sig of vp/prl", "signature of vp prl", "signature of vp/prl", "vp prl signature", "vp/prl signature"] },
];

const DETAIL_IMPORT_LABELS = [
  { key: "name", pattern: /name\s+of\s+trainee\s*:\s*/gi },
  { key: "trade", pattern: /trade\s*:\s*/gi },
  { key: "admissionNo", pattern: /admn\.?\s*no\.?\s*:?\s*/gi },
  { key: "admissionDate", pattern: /date\s+of\s+admission\s*:\s*/gi },
  { key: "aadhaarNo", pattern: /aadhaar\s+no\s*:\s*/gi },
  { key: "misRegNo", pattern: /mis\s+reg\.?\s*no\.?\s*:?\s*/gi },
  { key: "qualification", pattern: /educational\s+qualification\s*:\s*/gi },
  { key: "traineePhone", pattern: /trainee'?s\s+phone\s+no\.?\s*:?\s*/gi },
  { key: "guardianName", pattern: /name\s+of\s+guardian\s*:\s*/gi },
  { key: "guardianPhone", pattern: /guardian'?s\s+phone\s+no\.?\s*:?\s*/gi },
  { key: "address", pattern: /address\s*:\s*/gi },
];

const CRC32_TABLE = createCrc32Table();

const state = loadState();
let activeTab = "marks";
let portalSharedState = null;

const studentFieldsEl = document.getElementById("studentFields");
const studentSelectEl = document.getElementById("studentSelect");
const photoStudentSelectEl = document.getElementById("photoStudentSelect");
const studentListEl = document.getElementById("studentList");
const studentCountBadgeEl = document.getElementById("studentCountBadge");
const monthlyEditorEl = document.getElementById("monthlyEditor");
const marksStatusEl = document.getElementById("marksStatus");
const halfYearlyEditorEl = document.getElementById("halfYearlyEditor");
const singlePreviewMountEl = document.getElementById("singlePreviewMount");
const combinedPrintMountEl = document.getElementById("combinedPrintMount");
const portalStudentMasterNoticeEl = document.getElementById("portalStudentMasterNotice");
const excelFileInputEl = document.getElementById("excelFileInput");
const pasteStatusEl = document.getElementById("pasteStatus");
const previewMetaEl = document.getElementById("previewMeta");
const photoUploadEl = document.getElementById("photoUpload");
const photoScaleEl = document.getElementById("photoScale");
const photoXEl = document.getElementById("photoX");
const photoYEl = document.getElementById("photoY");
const tabButtons = Array.from(document.querySelectorAll("[data-tab-target]"));
const tabPanels = Array.from(document.querySelectorAll("[data-tab-panel]"));

if (portalStudentMasterNoticeEl) {
  portalStudentMasterNoticeEl.hidden = window.parent === window;
}

ensureStateIntegrity();
bindEvents();
renderAll();

function bindEvents() {
  tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      activeTab = button.dataset.tabTarget;
      renderTabs();
      reportPortalHeight();
    });
  });

  studentFieldsEl.addEventListener("input", (event) => {
    const field = event.target.dataset.studentField;
    if (!field) {
      return;
    }
    const selected = getSelectedStudent();
    selected.student[field] = event.target.value;
    if (field === "trade") {
      selected.monthly = selected.monthly.map((row) =>
        normalizeMonthlyRow(row, selected.student)
      );
      renderMonthlyEditor();
    }
    saveState();
    renderStudentSelectors();
    renderStudentList();
    renderPreviews();
  });

  monthlyEditorEl.addEventListener("input", handleMonthlyMarksEditorInput);
  monthlyEditorEl.addEventListener("change", handleMonthlyMarksEditorChange);
  monthlyEditorEl.addEventListener("click", handleMonthlyMarksEditorClick);

  halfYearlyEditorEl.addEventListener("input", (event) => {
    const key = event.target.dataset.halfField;
    const rowIndex = Number(event.target.dataset.halfRow);
    if (!key || Number.isNaN(rowIndex)) {
      return;
    }
    const selected = getSelectedStudent();
    selected.halfYearly[rowIndex][key] = event.target.value;
    saveState();
    renderPreviews();
  });

  halfYearlyEditorEl.addEventListener("change", (event) => {
    if (event.target.dataset.halfStudentSelect === undefined) {
      return;
    }
    setSelectedStudent(event.target.value, true);
    saveState();
    renderAll();
  });

  studentSelectEl.addEventListener("change", () => {
    setSelectedStudent(studentSelectEl.value, true);
    persistAndRender();
  });

  photoStudentSelectEl.addEventListener("change", () => {
    setSelectedStudent(photoStudentSelectEl.value, true);
    persistAndRender();
  });

  studentListEl.addEventListener("click", (event) => {
    const removeTarget = event.target.closest("[data-remove-student]");
    if (removeTarget) {
      removeStudent(removeTarget.dataset.removeStudent);
      return;
    }

    const target = event.target.closest("[data-select-student]");
    if (!target) {
      return;
    }
    setSelectedStudent(target.dataset.selectStudent, true);
    persistAndRender();
  });

  document.getElementById("addStudent").addEventListener("click", () => {
    addManualStudent();
  });

  document.getElementById("importFile").addEventListener("click", async () => {
    const file = excelFileInputEl.files?.[0];
    const result = await importStudentsFromWorkbookFile(file);
    if (!result.ok) {
      setStatus(result.message, "warning");
      return;
    }
    setStatus(result.message, "success");
    persistAndRender();
  });

  document.getElementById("loadDemo").addEventListener("click", () => {
    overwriteState(createDemoState());
    excelFileInputEl.value = "";
    setStatus("Loaded demo batch with multiple students.", "success");
  });

  document.getElementById("downloadTemplate").addEventListener("click", () => {
    downloadTemplateWorkbook();
  });

  document.getElementById("clearAll").addEventListener("click", () => {
    if (!window.confirm("Clear the imported students and reset the page?")) {
      return;
    }
    overwriteState(createEmptyState());
    excelFileInputEl.value = "";
    photoUploadEl.value = "";
    setStatus("All students cleared.", "success");
  });

  document.getElementById("downloadSinglePdf").addEventListener("click", () => {
    downloadSelectedPdf();
  });

  document.getElementById("downloadCombinedPdf").addEventListener("click", () => {
    downloadCombinedPdf();
  });

  document.getElementById("downloadSingleWord").addEventListener("click", () => {
    downloadSelectedWord();
  });

  document.getElementById("downloadCombinedWord").addEventListener("click", () => {
    downloadCombinedWord();
  });

  document.getElementById("resetCrop").addEventListener("click", () => {
    const target = getPhotoTargetStudent();
    target.photo.scale = 1;
    target.photo.x = 50;
    target.photo.y = 50;
    syncPhotoControls();
    saveState();
    renderStudentList();
    renderPreviews();
  });

  document.getElementById("removePhoto").addEventListener("click", () => {
    const target = getPhotoTargetStudent();
    target.photo.src = "";
    target.photo.scale = 1;
    target.photo.x = 50;
    target.photo.y = 50;
    photoUploadEl.value = "";
    syncPhotoControls();
    saveState();
    renderStudentList();
    renderPreviews();
  });

  photoScaleEl.addEventListener("input", () => {
    const target = getPhotoTargetStudent();
    target.photo.scale = Number(photoScaleEl.value);
    saveState();
    renderPreviews();
  });

  photoXEl.addEventListener("input", () => {
    const target = getPhotoTargetStudent();
    target.photo.x = Number(photoXEl.value);
    saveState();
    renderPreviews();
  });

  photoYEl.addEventListener("input", () => {
    const target = getPhotoTargetStudent();
    target.photo.y = Number(photoYEl.value);
    saveState();
    renderPreviews();
  });

  photoUploadEl.addEventListener("change", () => {
    const [file] = photoUploadEl.files || [];
    if (!file) {
      return;
    }

    const target = getPhotoTargetStudent();
    const reader = new FileReader();
    reader.onload = () => {
      target.photo.src = reader.result;
      target.photo.scale = 1;
      target.photo.x = 50;
      target.photo.y = 50;
      syncPhotoControls();
      saveState();
      renderStudentList();
      renderPreviews();
    };
    reader.readAsDataURL(file);
  });

  window.addEventListener("afterprint", () => {
    delete document.body.dataset.printMode;
    combinedPrintMountEl.innerHTML = "";
  });
}

function renderAll() {
  ensureStateIntegrity();
  if (syncAttendanceFromAttendanceState()) {
    saveState();
  }
  renderTabs();
  renderStudentSelectors();
  renderStudentList();
  renderSelectedStudentFields();
  renderMonthlyEditor();
  renderHalfYearlyEditor();
  renderPreviews();
  syncPhotoControls();
  reportPortalHeight();
}

function renderTabs() {
  tabButtons.forEach((button) => {
    const isActive = button.dataset.tabTarget === activeTab;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-selected", isActive ? "true" : "false");
  });

  tabPanels.forEach((panel) => {
    const isActive = panel.dataset.tabPanel === activeTab;
    panel.classList.toggle("active", isActive);
    panel.hidden = !isActive;
  });
}

function applyPortalSharedData(payload) {
  if (!payload || typeof payload !== "object") {
    return;
  }

  portalSharedState = payload;
  const institution = String(payload.itiName ?? payload.institution ?? "").trim();
  const trade = String(payload.tradeNameShort ?? payload.tradeName ?? "").trim();
  const studentRecords = Array.isArray(payload.studentRecords)
    ? payload.studentRecords
        .map((record) => ({
          instituteName: String(
            record?.instituteName || record?.institution || payload.itiName || payload.institution || ""
          ).trim(),
          name: String(record?.name || "").trim(),
          trade: String(record?.trade || record?.tradeName || "").trim(),
          admissionNo: String(record?.admissionNo || record?.admNo || "").trim(),
          admissionDate: String(record?.admissionDate || "").trim(),
          aadhaarNo: String(record?.aadhaarNo || "").trim(),
          misRegNo: String(record?.misRegNo || "").trim(),
          qualification: String(record?.qualification || "").trim(),
          traineePhone: String(record?.traineePhone || "").trim(),
          guardianName: String(record?.guardianName || record?.fatherName || "").trim(),
          guardianPhone: String(record?.guardianPhone || "").trim(),
          address: String(record?.address || "").trim(),
        }))
        .filter(
          (record) =>
            record.name ||
            record.admissionNo ||
            record.guardianName ||
            record.aadhaarNo ||
            record.misRegNo
        )
    : [];
  const rosterEntries = Array.isArray(payload.rosterEntries)
    ? payload.rosterEntries
      .map((entry) => ({
        admNo: String(entry?.admNo || "").trim(),
        name: String(entry?.name || "").trim(),
        fatherName: String(entry?.fatherName || "").trim(),
      }))
      .filter((entry) => entry.admNo || entry.name || entry.fatherName)
    : [];

  if (studentRecords.length) {
    syncStudentsFromPortalStudentRecords(studentRecords, institution, trade);
  } else if (rosterEntries.length) {
    syncStudentsFromPortalRoster(rosterEntries, institution, trade);
  } else {
    syncStudentsFromPortalDefaults(institution, trade);
  }

  saveState();
  renderAll();
  setStatus("Common details synced from the portal.", "success");
  notifyPortalApplied();
}

function syncStudentsFromPortalStudentRecords(studentRecords, institution, trade) {
  const admissionMatches = new Map();
  const nameMatches = new Map();

  state.students.forEach((record) => {
    const admissionKey = normalizePortalMatchToken(record.student.admissionNo);
    const nameKey = normalizePortalMatchToken(record.student.name);
    if (admissionKey && !admissionMatches.has(admissionKey)) {
      admissionMatches.set(admissionKey, record);
    }
    if (nameKey && !nameMatches.has(nameKey)) {
      nameMatches.set(nameKey, record);
    }
  });

  const usedIds = new Set();
  const nextStudents = studentRecords.map((entry) => {
    const admissionKey = normalizePortalMatchToken(entry.admissionNo);
    const nameKey = normalizePortalMatchToken(entry.name);
    const matchingRecord =
      (admissionKey ? admissionMatches.get(admissionKey) : null)
      || (nameKey ? nameMatches.get(nameKey) : null)
      || state.students.find(
        (record) =>
          !usedIds.has(record.id) &&
          !String(record.student.name || "").trim() &&
          !String(record.student.admissionNo || "").trim()
      )
      || createStudentRecord();

    usedIds.add(matchingRecord.id);

    return createStudentRecord({
      id: matchingRecord.id,
      student: {
        ...matchingRecord.student,
        instituteName:
          institution || entry.instituteName || matchingRecord.student.instituteName,
        trade: entry.trade || trade || matchingRecord.student.trade,
        name: entry.name || matchingRecord.student.name,
        admissionNo: entry.admissionNo || matchingRecord.student.admissionNo,
        admissionDate: entry.admissionDate || matchingRecord.student.admissionDate,
        aadhaarNo: entry.aadhaarNo || matchingRecord.student.aadhaarNo,
        misRegNo: entry.misRegNo || matchingRecord.student.misRegNo,
        qualification: entry.qualification || matchingRecord.student.qualification,
        traineePhone: entry.traineePhone || matchingRecord.student.traineePhone,
        guardianName: entry.guardianName || matchingRecord.student.guardianName,
        guardianPhone: entry.guardianPhone || matchingRecord.student.guardianPhone,
        address: entry.address || matchingRecord.student.address,
      },
      photo: matchingRecord.photo,
      monthly: matchingRecord.monthly,
      halfYearly: matchingRecord.halfYearly,
    });
  });

  if (nextStudents.length) {
    state.students = nextStudents;
  }

  syncPortalSelection();
}

function syncStudentsFromPortalRoster(rosterEntries, institution, trade) {
  const admissionMatches = new Map();
  const nameMatches = new Map();

  state.students.forEach((record) => {
    const admissionKey = normalizePortalMatchToken(record.student.admissionNo);
    const nameKey = normalizePortalMatchToken(record.student.name);
    if (admissionKey && !admissionMatches.has(admissionKey)) {
      admissionMatches.set(admissionKey, record);
    }
    if (nameKey && !nameMatches.has(nameKey)) {
      nameMatches.set(nameKey, record);
    }
  });

  const usedIds = new Set();
  const nextStudents = rosterEntries.map((entry) => {
    const admissionKey = normalizePortalMatchToken(entry.admNo);
    const nameKey = normalizePortalMatchToken(entry.name);
    const matchingRecord =
      (admissionKey ? admissionMatches.get(admissionKey) : null)
      || (nameKey ? nameMatches.get(nameKey) : null)
      || state.students.find(
        (record) =>
          !usedIds.has(record.id)
          && !String(record.student.name || "").trim()
          && !String(record.student.admissionNo || "").trim()
      )
      || createStudentRecord();

    usedIds.add(matchingRecord.id);

    return createStudentRecord({
      id: matchingRecord.id,
      student: {
        ...matchingRecord.student,
        instituteName: institution || matchingRecord.student.instituteName,
        trade: trade || matchingRecord.student.trade,
        name: entry.name || matchingRecord.student.name,
        admissionNo: entry.admNo || matchingRecord.student.admissionNo,
        guardianName: entry.fatherName || matchingRecord.student.guardianName,
      },
      photo: matchingRecord.photo,
      monthly: matchingRecord.monthly,
      halfYearly: matchingRecord.halfYearly,
    });
  });

  if (nextStudents.length) {
    state.students = nextStudents;
  }

  syncPortalSelection();
}

function syncStudentsFromPortalDefaults(institution, trade) {
  state.students = state.students.map((record) =>
    createStudentRecord({
      id: record.id,
      student: {
        ...record.student,
        instituteName: institution || record.student.instituteName,
        trade: trade || record.student.trade,
      },
      photo: record.photo,
      monthly: record.monthly,
      halfYearly: record.halfYearly,
    })
  );

  syncPortalSelection();
}

function syncPortalSelection() {
  if (!state.students.length) {
    const fallback = createEmptyState();
    state.students = fallback.students;
    state.selectedStudentId = fallback.selectedStudentId;
    state.photoTargetId = fallback.photoTargetId;
    return;
  }

  if (!state.students.some((record) => record.id === state.selectedStudentId)) {
    state.selectedStudentId = state.students[0].id;
  }

  if (!state.students.some((record) => record.id === state.photoTargetId)) {
    state.photoTargetId = state.selectedStudentId;
  }
}

function getPortalManagedStudentFields() {
  const managedFields = new Set();

  if (!portalSharedState || typeof portalSharedState !== "object") {
    return managedFields;
  }

  const hasStudentRecords = Array.isArray(portalSharedState.studentRecords)
    && portalSharedState.studentRecords.some(
      (record) =>
        record?.name ||
        record?.admissionNo ||
        record?.admNo ||
        record?.guardianName ||
        record?.fatherName
    );

  if (hasStudentRecords) {
    STUDENT_FIELDS.forEach((field) => {
      managedFields.add(field.key);
    });
    return managedFields;
  }

  if (String(portalSharedState.itiName ?? portalSharedState.institution ?? "").trim()) {
    managedFields.add("instituteName");
  }

  if (String(portalSharedState.tradeName || "").trim()) {
    managedFields.add("trade");
  }

  const hasRosterEntries = Array.isArray(portalSharedState.rosterEntries)
    && portalSharedState.rosterEntries.some(
      (entry) => entry?.admNo || entry?.name || entry?.fatherName
    );

  if (hasRosterEntries) {
    managedFields.add("name");
    managedFields.add("admissionNo");
    managedFields.add("guardianName");
  }

  return managedFields;
}

function lockPortalManagedFields() {
  const managedFields = getPortalManagedStudentFields();
  studentFieldsEl.querySelectorAll("[data-student-field]").forEach((field) => {
    const isManaged = managedFields.has(field.dataset.studentField);
    field.readOnly = isManaged;
    field.title = isManaged ? "Managed from the Common Details tab" : "";
  });
}

function notifyPortalReady() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage({ type: "portal:ready", app: PORTAL_APP_NAME }, "*");
  reportPortalHeight();
}

function notifyPortalApplied() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:applied", app: PORTAL_APP_NAME, height: getPortalHeight() },
    "*",
  );
}

function reportPortalHeight() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:height", app: PORTAL_APP_NAME, height: getPortalHeight() },
    "*",
  );
}

function getPortalHeight() {
  const shell = document.querySelector(".app-shell");
  const bodyStyles = window.getComputedStyle(document.body);
  const bodyMargins =
    (Number.parseFloat(bodyStyles.marginTop) || 0)
    + (Number.parseFloat(bodyStyles.marginBottom) || 0);
  const contentHeight = shell
    ? Math.max(shell.scrollHeight || 0, shell.offsetHeight || 0)
    : Math.max(
      document.documentElement?.scrollHeight || 0,
      document.body?.scrollHeight || 0,
      document.documentElement?.offsetHeight || 0,
      document.body?.offsetHeight || 0,
    );

  return contentHeight + bodyMargins;
}

function renderStudentSelectors() {
  const options = state.students
    .map(
      (record, index) => `
        <option value="${escapeAttribute(record.id)}">
          ${escapeHtml(getStudentOptionLabel(record, index))}
        </option>
      `
    )
    .join("");

  studentSelectEl.innerHTML = options;
  photoStudentSelectEl.innerHTML = options;
  studentSelectEl.value = state.selectedStudentId;
  photoStudentSelectEl.value = state.photoTargetId;
  studentCountBadgeEl.textContent = `${state.students.length} student${
    state.students.length === 1 ? "" : "s"
  }`;
}

function renderStudentList() {
  studentListEl.innerHTML = state.students
    .map(
      (record, index) => `
        <div class="student-list-item">
          <button
            type="button"
            class="student-card ${record.id === state.selectedStudentId ? "active" : ""}"
            data-select-student="${escapeAttribute(record.id)}"
          >
            <span class="student-card-title">${escapeHtml(
              getStudentOptionLabel(record, index)
            )}</span>
            <span class="student-card-meta">${escapeHtml(
              [
                record.student.trade || "Trade not set",
                record.photo.src ? "Photo ready" : "No photo",
              ].join(" | ")
            )}</span>
          </button>
          <button
            type="button"
            class="student-remove"
            data-remove-student="${escapeAttribute(record.id)}"
            aria-label="Remove ${escapeAttribute(getStudentOptionLabel(record, index))}"
          >
            Remove
          </button>
        </div>
      `
    )
    .join("");
  return;

  studentListEl.innerHTML = state.students
    .map(
      (record, index) => `
        <button
          type="button"
          class="student-card ${record.id === state.selectedStudentId ? "active" : ""}"
          data-select-student="${escapeAttribute(record.id)}"
        >
          <span class="student-card-title">${escapeHtml(
            getStudentOptionLabel(record, index)
          )}</span>
          <span class="student-card-meta">${escapeHtml(
            [
              record.student.trade || "Trade not set",
              record.photo.src ? "Photo ready" : "No photo",
            ].join(" · ")
          )}</span>
        </button>
      `
    )
    .join("");
}

function renderSelectedStudentFields() {
  const selected = getSelectedStudent();
  studentFieldsEl.innerHTML = STUDENT_FIELDS.map(
    (field) => `
      <div class="field ${field.full ? "full" : ""}">
        <label for="student-${field.key}">${field.label}</label>
        ${
          field.multiline
            ? `<textarea id="student-${field.key}" data-student-field="${field.key}">${escapeHtml(
                selected.student[field.key] || ""
              )}</textarea>`
            : `<input id="student-${field.key}" type="text" data-student-field="${field.key}" value="${escapeAttribute(
                selected.student[field.key] || ""
              )}" />`
        }
      </div>
    `
  ).join("");
  lockPortalManagedFields();
}

function handleMonthlyMarksEditorInput(event) {
  const target = event.target;
  const key = target?.dataset?.monthEntryKey;
  const studentId = target?.dataset?.monthEntryStudentId;
  if (!key || !studentId) {
    return;
  }

  const record = state.students.find((item) => item.id === studentId);
  if (!record) {
    return;
  }

  const month = getSelectedMarksMonth();
  const row = getMonthlyRowForRecord(record, month);
  if (!row) {
    return;
  }

  row[key] = target.value;
  const normalizedRow = normalizeMonthlyRow(row, record.student);
  setMonthlyRowForRecord(record, month, normalizedRow);
  if (record.id !== state.selectedStudentId) {
    setSelectedStudent(record.id, true);
    syncMonthlyMarksSelectionUi();
    renderStudentSelectors();
    renderStudentList();
    renderSelectedStudentFields();
    renderHalfYearlyEditor();
    syncPhotoControls();
  }
  saveState();
  syncMonthlyMarksRowDisplay(target.closest("tr"), normalizedRow);
  renderPreviews();
}

function handleMonthlyMarksEditorChange(event) {
  const target = event.target;
  if (!target) {
    return;
  }

  if (target.dataset.marksMonthSelect !== undefined) {
    const nextMonth = matchMonth(target.value) || MONTH_LAYOUT[0].month;
    state.marksWorkspace.selectedMonth = nextMonth;
    saveState();
    renderMonthlyEditor();
    renderHalfYearlyEditor();
    reportPortalHeight();
    return;
  }

  if (target.dataset.nimmiExamSelect !== undefined) {
    state.marksWorkspace.nimmiExamIdByMonth[getSelectedMarksMonth()] = String(target.value || "");
    saveState();
    renderMonthlyEditor();
    return;
  }

  if (target.dataset.annexOutcomeSelect !== undefined) {
    state.marksWorkspace.annexOutcomeKeyByMonth[getSelectedMarksMonth()] = String(target.value || "");
    saveState();
    renderMonthlyEditor();
    return;
  }
}

function handleMonthlyMarksEditorClick(event) {
  const previewButton = event.target.closest("[data-preview-student]");
  if (previewButton) {
    setSelectedStudent(previewButton.dataset.previewStudent, true);
    saveState();
    renderAll();
    return;
  }

  const nimmiImportButton = event.target.closest("[data-import-nimmi]");
  if (nimmiImportButton) {
    importNimmiMarksForSelectedMonth();
    return;
  }

  const annexImportButton = event.target.closest("[data-import-annex]");
  if (annexImportButton) {
    importAnnexOutcomeMarksForSelectedMonth();
  }
}

function renderMonthlyEditor() {
  const month = getSelectedMarksMonth();
  const term = getTermForMonth(month);
  const nimmiExams = readSavedNimmiExamLibrary();
  const annexOutcomes = readSavedAnnexOutcomeLibrary();
  const selectedNimmiId = nimmiExams.some(
    (exam) => exam.id === state.marksWorkspace.nimmiExamIdByMonth[month]
  )
    ? state.marksWorkspace.nimmiExamIdByMonth[month]
    : "";
  const selectedAnnexKey = annexOutcomes.some(
    (outcome) => outcome.key === state.marksWorkspace.annexOutcomeKeyByMonth[month]
  )
    ? state.marksWorkspace.annexOutcomeKeyByMonth[month]
    : "";

  monthlyEditorEl.innerHTML = `
    <div class="marks-month-shell">
      <div class="marks-month-toolbar">
        <div class="field-group">
          <label for="marksMonthSelect">Month</label>
          <select id="marksMonthSelect" data-marks-month-select>
            ${MONTH_LAYOUT.map(
              (entry) => `
                <option value="${escapeAttribute(entry.month)}"${entry.month === month ? " selected" : ""}>
                  ${escapeHtml(entry.month)}
                </option>
              `
            ).join("")}
          </select>
        </div>
        <div class="marks-month-summary">
          <span class="marks-month-chip">Term ${escapeHtml(term)}</span>
          <span class="marks-month-chip">${state.students.length} trainee${state.students.length === 1 ? "" : "s"}</span>
          <span class="marks-month-chip">Attendance synced from Attendance tab</span>
        </div>
      </div>

      <div class="marks-import-grid">
        <section class="marks-import-card">
          <div class="marks-import-head">
            <h3>NIMI Rank List</h3>
            <span class="marks-import-target">Into Prof. Knowledge</span>
          </div>
          <label class="field">
            <span>Saved exam</span>
            <select data-nimmi-exam-select>
              <option value="">Select saved exam</option>
              ${nimmiExams.map(
                (exam) => `
                  <option value="${escapeAttribute(exam.id)}"${exam.id === selectedNimmiId ? " selected" : ""}>
                    ${escapeHtml(formatNimmiExamOptionLabel(exam))}
                  </option>
                `
              ).join("")}
            </select>
          </label>
          <button
            type="button"
            class="button secondary import-button"
            data-import-nimmi
            ${selectedNimmiId ? "" : "disabled"}
          >
            Import to Prof. Knowledge
          </button>
          <p class="hint">Uses the saved exams from Miscellaneous and matches trainees by admission number or name.</p>
        </section>

        <section class="marks-import-card">
          <div class="marks-import-head">
            <h3>Annexure 2 Learning Outcome</h3>
            <span class="marks-import-target">Into Prof. Skill</span>
          </div>
          <label class="field">
            <span>Saved learning outcome</span>
            <select data-annex-outcome-select>
              <option value="">Select learning outcome</option>
              ${annexOutcomes.map(
                (outcome) => `
                  <option value="${escapeAttribute(outcome.key)}"${outcome.key === selectedAnnexKey ? " selected" : ""}>
                    ${escapeHtml(formatAnnexOutcomeOptionLabel(outcome))}
                  </option>
                `
              ).join("")}
            </select>
          </label>
          <button
            type="button"
            class="button secondary import-button"
            data-import-annex
            ${selectedAnnexKey ? "" : "disabled"}
          >
            Import to Prof. Skill
          </button>
          <p class="hint">Uses the total mark saved under the selected Annexure 2 learning outcome.</p>
        </section>
      </div>

      <table class="editor-table monthly-marks-table">
        <thead>
          <tr>
            <th>Trainee</th>
            <th>Attendance</th>
            <th>%</th>
            <th>Prof. skill</th>
            <th>Prof. knowledge</th>
            <th>WCS</th>
            <th>ES</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          ${state.students.map((record, index) => renderMonthlyMarksEntryRow(record, index, month)).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderHalfYearlyEditor() {
  const selected = getSelectedStudent();
  halfYearlyEditorEl.innerHTML = `
    <div class="half-yearly-toolbar">
      <label class="field half-yearly-select">
        <span>Preview student</span>
        <select data-half-student-select>
          ${state.students.map(
            (record, index) => `
              <option value="${escapeAttribute(record.id)}"${record.id === selected.id ? " selected" : ""}>
                ${escapeHtml(getStudentOptionLabel(record, index))}
              </option>
            `
          ).join("")}
        </select>
      </label>
      <p class="hint">Attendance fields are synced from the Attendance tab.</p>
    </div>
    <table class="editor-table">
      <thead>
        <tr>
          <th>Term</th>
          ${HALF_YEARLY_COLUMNS.map((column) => `<th>${column.label}</th>`).join("")}
        </tr>
      </thead>
      <tbody>
        ${selected.halfYearly
          .map(
            (row, rowIndex) => `
              <tr>
                <td class="month-label">${escapeHtml(row.term)}</td>
                ${HALF_YEARLY_COLUMNS.map(
                  (column) => `
                    <td>
                      <input
                        type="text"
                        value="${escapeAttribute(row[column.key] || "")}"
                        data-half-field="${column.key}"
                        data-half-row="${rowIndex}"
                        ${
                          HALF_YEARLY_ATTENDANCE_KEYS.has(column.key)
                            ? 'readonly title="Synced from Attendance tab"'
                            : ""
                        }
                      />
                    </td>
                  `
                ).join("")}
              </tr>
            `
          )
          .join("")}
      </tbody>
    </table>
  `;
}

function renderPreviews() {
  const selected = getSelectedStudent();
  singlePreviewMountEl.innerHTML = renderProgressPage(selected);
  fitProgressPages(singlePreviewMountEl);

  previewMetaEl.textContent = `${getStudentOptionLabel(
    selected,
    state.students.findIndex((record) => record.id === selected.id)
  )} | ${state.students.length} student${
    state.students.length === 1 ? "" : "s"
  } loaded`;
  return;

  singlePreviewMountEl.innerHTML = renderProgressPage(selected);

  previewMetaEl.textContent = `${getStudentOptionLabel(
    selected,
    state.students.findIndex((record) => record.id === selected.id)
  )} · ${state.students.length} student${
    state.students.length === 1 ? "" : "s"
  } loaded`;
}

function renderCombinedPrintPages() {
  combinedPrintMountEl.innerHTML = state.students
    .map((record) => renderProgressPage(record))
    .join("");
  fitProgressPages(combinedPrintMountEl);
  return;

  combinedPrintMountEl.innerHTML = state.students
    .map((record) => renderProgressPage(record))
    .join("");
}

function renderProgressPage(record) {
  return `
    <section class="progress-page">
      <div class="progress-page-content">
        <img class="watermark" src="assets/iti-watermark.png" alt="" aria-hidden="true" />
        <table class="progress-table">
          <colgroup>
            ${COLUMN_WIDTHS.map(
              (width) => `<col style="width:${(width / 10561) * 100}%">`
            ).join("")}
          </colgroup>
          <tbody>
            ${renderProgressTableRows(record)}
          </tbody>
        </table>
      </div>
    </section>
  `;

  return `
    <section class="progress-page">
      <img class="watermark" src="assets/iti-watermark.png" alt="" aria-hidden="true" />
      <table class="progress-table">
        <colgroup>
          ${COLUMN_WIDTHS.map(
            (width) => `<col style="width:${(width / 10561) * 100}%">`
          ).join("")}
        </colgroup>
        <tbody>
          ${renderProgressTableRows(record)}
        </tbody>
      </table>
    </section>
  `;
}

function renderProgressTableRows(record) {
  const student = record.student;
  const monthlyRows = record.monthly;
  const summaryRows = record.halfYearly;

  return [
    `<tr style="height:4.5mm"><td colspan="17" class="dept-title">INDUSTRIAL TRAINING DEPARTMENT, KERALA</td></tr>`,
    `<tr style="height:8.7mm"><td colspan="17" class="main-title">PROGRESS CARD</td></tr>`,
    `
      <tr style="height:7.4mm">
        <td colspan="14" class="institute">${escapeHtml(
          student.instituteName || DEFAULT_STUDENT.instituteName
        )}</td>
        <td colspan="3" rowspan="7" class="photo-cell">${renderPhoto(record.photo)}</td>
      </tr>
    `,
    `<tr style="height:5.2mm">${renderLabeledCell("Name of Trainee:", student.name, 7)}${renderLabeledCell("Trade:", student.trade, 7)}</tr>`,
    `<tr style="height:5.2mm">${renderLabeledCell("Admn. No.", student.admissionNo, 7)}${renderLabeledCell("Date of admission:", student.admissionDate, 7)}</tr>`,
    `<tr style="height:5.2mm">${renderLabeledCell("Aadhaar No:", student.aadhaarNo, 7)}${renderLabeledCell("MIS Reg. No.", student.misRegNo, 7)}</tr>`,
    `<tr style="height:5.2mm">${renderLabeledCell("Educational Qualification:", student.qualification, 7)}${renderLabeledCell("Trainee's Phone No:", student.traineePhone, 7)}</tr>`,
    `<tr style="height:5.2mm">${renderLabeledCell("Name of Guardian:", student.guardianName, 7)}${renderLabeledCell("Guardian's Phone No:", student.guardianPhone, 7)}</tr>`,
    `<tr style="height:14.5mm">${renderLabeledCell("Address:", student.address, 14)}</tr>`,
    `<tr style="height:5.1mm"><td colspan="17" class="year-title">FIRST YEAR</td></tr>`,
    `
      <tr style="height:4.2mm">
        <td rowspan="2" class="header-cell tight"></td>
        ${renderVerticalHeader("Month", "month-head", 2)}
        <td colspan="5" class="header-cell tight">Attendance</td>
        <td colspan="6" class="header-cell tight">Monthly Tests</td>
        ${renderVerticalHeader("Initials of instructor", "signature-head", 2)}
        ${renderVerticalHeader("Initials of GI", "signature-head", 2)}
        ${renderVerticalHeader("Initials of VP/PRL", "signature-head", 2)}
        ${renderVerticalHeader("Signature of Guardian", "signature-head", 2)}
      </tr>
    `,
    `
      <tr style="height:22.2mm">
        ${renderVerticalHeader("Possible", "subheader-cell")}
        ${renderVerticalHeader("Present", "subheader-cell")}
        ${renderVerticalHeader("Cum. Possible", "subheader-cell")}
        ${renderVerticalHeader("Cum. Present", "subheader-cell")}
        ${renderVerticalHeader("Percentage", "subheader-cell")}
        ${renderVerticalHeader("Prof. skill", "subheader-cell")}
        ${renderVerticalHeader("Prof. knowledge", "subheader-cell")}
        ${renderVerticalHeader("Engg. Drg.", "subheader-cell")}
        ${renderVerticalHeader("WCS", "subheader-cell")}
        ${renderVerticalHeader("ES", "subheader-cell")}
        ${renderVerticalHeader("Total", "subheader-cell")}
      </tr>
    `,
    ...renderMonthlyRows(monthlyRows),
    `<tr style="height:5.2mm"><td colspan="17" class="section-title">HALF YEARLY ASSESSMENT</td></tr>`,
    `
      <tr style="height:6.1mm">
        <td rowspan="2" class="header-cell tight"></td>
        <td colspan="3" class="header-cell tight">Attendance</td>
        <td colspan="3" rowspan="2" class="header-cell tight">Formative Assessment (100)</td>
        <td colspan="2" rowspan="2" class="header-cell tight">Conduct (V.good, Good, Average)</td>
        <td colspan="2" rowspan="2" class="header-cell tight">Sig. of Trainee</td>
        <td colspan="2" rowspan="2" class="header-cell tight">Sig. of Instr.</td>
        <td colspan="2" rowspan="2" class="header-cell tight">Sig. of GI</td>
        <td colspan="2" rowspan="2" class="header-cell tight">Sig. of VP/PRL</td>
      </tr>
    `,
    `
      <tr style="height:5.4mm">
        <td class="header-cell">Poss.</td>
        <td class="header-cell">Pre.</td>
        <td class="header-cell">%</td>
      </tr>
    `,
    ...summaryRows.map(
      (row) => `
        <tr style="height:10.5mm">
          <td class="term-cell">${escapeHtml(row.term)}</td>
          <td class="score-cell">${escapeHtml(row.possible)}</td>
          <td class="score-cell">${escapeHtml(row.present)}</td>
          <td class="score-cell">${escapeHtml(row.percentage)}</td>
          <td colspan="3" class="score-cell">${escapeHtml(row.formative)}</td>
          <td colspan="2" class="score-cell">${escapeHtml(row.conduct)}</td>
          <td colspan="2" class="sign-cell">${escapeHtml(row.traineeSignature)}</td>
          <td colspan="2" class="sign-cell">${escapeHtml(row.instructorSignature)}</td>
          <td colspan="2" class="sign-cell">${escapeHtml(row.giSignature)}</td>
          <td colspan="2" class="sign-cell">${escapeHtml(row.vpPrlSignature)}</td>
        </tr>
      `
    ),
  ].join("");
}

function renderMonthlyRows(rows) {
  return rows.map((row, index) => {
    const startOfGroup = index === 0 || rows[index - 1].term !== row.term;
    const rowspan = startOfGroup ? countTermRows(rows, index) : 0;
    return `
      <tr style="height:9.4mm">
        ${
          startOfGroup
            ? `<td rowspan="${rowspan}" class="term-cell">${escapeHtml(row.term)}</td>`
            : ""
        }
        <td class="month-cell">${escapeHtml(row.month)}</td>
        ${MONTHLY_COLUMNS.map(
          (column) => `
            <td class="${
              column.key.includes("Initials") || column.key.includes("Signature")
                ? "sign-cell"
                : "score-cell"
            }">${escapeHtml(row[column.key] || "")}</td>
          `
        ).join("")}
      </tr>
    `;
  });
}

function renderVerticalHeader(text, extraClass = "", rowspan = 1) {
  const rowSpanAttr = rowspan > 1 ? ` rowspan="${rowspan}"` : "";
  return `
    <td${rowSpanAttr} class="header-cell vertical-cell ${extraClass}">
      <div class="vertical-wrap">
        <span class="vertical-text">${escapeHtml(text)}</span>
      </div>
    </td>
  `;
}

function renderLabeledCell(label, value, colspan) {
  return `
    <td colspan="${colspan}" class="label-row">
      <strong>${escapeHtml(label)}</strong> ${escapeHtml(value || "")}
    </td>
  `;
}

function renderPhoto(photo) {
  if (!photo.src) {
    return `
      <div class="photo-box">
        <div class="photo-placeholder">Photo</div>
      </div>
    `;
  }

  return `
    <div class="photo-box has-image">
      <img
        src="${photo.src}"
        alt="Trainee photo"
        style="object-position:${photo.x}% ${photo.y}%; transform:scale(${photo.scale});"
      />
    </div>
  `;
}

async function importStudentsFromWorkbookFile(file) {
  if (!file) {
    return { ok: false, message: "Select an Excel file first." };
  }

  const lowerName = file.name.toLowerCase();

  try {
    let rows = [];

    if (lowerName.endsWith(".csv")) {
      rows = parseCsvRows(await file.text());
    } else if (lowerName.endsWith(".xlsx")) {
      rows = await readXlsxRows(await file.arrayBuffer());
    } else {
      return {
        ok: false,
        message: "Please import a `.xlsx` file or a `.csv` file.",
      };
    }

    const tableImport = parseTableRows(rows);
    if (!tableImport.students.length) {
      return {
        ok: false,
        message:
          "No student rows were found in that file. Use the downloaded template and keep one student per row.",
      };
    }

    state.students = tableImport.students;
    setSelectedStudent(state.students[0].id, true);
    return {
      ok: true,
      message: `Imported ${tableImport.students.length} student${
        tableImport.students.length === 1 ? "" : "s"
      } from ${file.name}.`,
    };
  } catch (error) {
    return {
      ok: false,
      message:
        "Could not read that Excel file. Use the downloaded template `.xlsx` or save the same sheet as `.csv` and import it.",
    };
  }
}

function importStudentsFromPaste(raw) {
  const trimmed = raw.trim();
  if (!trimmed) {
    return { ok: false, message: "Paste some Excel data first." };
  }

  const detailBlockImport = parseStudentDetailBlocks(trimmed);
  if (detailBlockImport.students.length) {
    state.students = detailBlockImport.students;
    setSelectedStudent(state.students[0].id, true);
    return {
      ok: true,
      message: `Imported ${detailBlockImport.students.length} student detail block${
        detailBlockImport.students.length === 1 ? "" : "s"
      }.`,
    };
  }

  const tableImport = parseTableImport(trimmed);
  if (tableImport.students.length) {
    state.students = tableImport.students;
    setSelectedStudent(state.students[0].id, true);
    return {
      ok: true,
      message: `Imported ${tableImport.students.length} student${
        tableImport.students.length === 1 ? "" : "s"
      } from the Excel table.`,
    };
  }

  const multiBlockImport = parseBlockImport(trimmed);
  if (multiBlockImport.students.length > 1) {
    state.students = multiBlockImport.students;
    setSelectedStudent(state.students[0].id, true);
    return {
      ok: true,
      message: `Imported ${multiBlockImport.students.length} student blocks from the pasted text.`,
    };
  }

  const singleResult = applyLegacyBlockToRecord(trimmed, getSelectedStudent());
  if (singleResult.applied > 0) {
    return {
      ok: true,
      message: `Updated the selected student with ${singleResult.applied} imported value${
        singleResult.applied === 1 ? "" : "s"
      }.`,
    };
  }

  return {
    ok: false,
    message:
      "No student details were detected. Paste the labeled student detail lines from Excel.",
  };
}

function parseStudentDetailBlocks(raw) {
  const lines = raw
    .split(/\r?\n/)
    .map((line) => line.replace(/\u00a0/g, " ").trim());

  const blocks = [];
  let currentBlock = [];

  lines.forEach((line) => {
    const isStartLine = /name\s+of\s+trainee\s*:/i.test(line);
    if (!line) {
      if (currentBlock.length) {
        blocks.push(currentBlock.join("\n"));
        currentBlock = [];
      }
      return;
    }

    if (isStartLine && currentBlock.length) {
      blocks.push(currentBlock.join("\n"));
      currentBlock = [line];
      return;
    }

    currentBlock.push(line);
  });

  if (currentBlock.length) {
    blocks.push(currentBlock.join("\n"));
  }

  const existingByKey = buildExistingStudentMap();
  const students = blocks
    .map((block) => {
      const values = extractStudentDetailValues(block);
      if (Object.keys(values).length < 2) {
        return null;
      }
      const record = createStudentRecord({ student: values });
      preserveExistingPhoto(record, existingByKey);
      return record;
    })
    .filter(Boolean);

  return { students };
}

function extractStudentDetailValues(text) {
  const matches = [];

  DETAIL_IMPORT_LABELS.forEach((label) => {
    const regex = new RegExp(label.pattern.source, "gi");
    let match;
    while ((match = regex.exec(text)) !== null) {
      matches.push({
        key: label.key,
        start: match.index,
        end: regex.lastIndex,
      });
    }
  });

  matches.sort((a, b) => a.start - b.start);

  const values = {};
  matches.forEach((match, index) => {
    const next = matches[index + 1];
    const rawValue = text.slice(match.end, next ? next.start : text.length);
    const cleanedValue = rawValue.replace(/\s+/g, " ").trim();
    if (cleanedValue) {
      values[match.key] = cleanedValue;
    }
  });

  return values;
}

function parseTableImport(raw) {
  const rows = raw
    .split(/\r?\n/)
    .map((line) => line.replace(/\u00a0/g, " ").trim())
    .filter(Boolean)
    .map(splitRow);

  return parseTableRows(rows);
}

function parseTableRows(rows) {
  if (rows.length < 2) {
    return { students: [] };
  }

  const mappings = rows[0].map(resolveColumnMapping);
  const recognizedCount = mappings.filter(Boolean).length;
  const hasStudentField = mappings.some((mapping) => mapping?.type === "student");
  if (recognizedCount < 2 || !hasStudentField) {
    return { students: [] };
  }

  const existingByKey = buildExistingStudentMap();
  const students = [];

  rows.slice(1).forEach((cells) => {
    if (!cells.some((cell) => cell && cell.trim())) {
      return;
    }

    const record = createStudentRecord();
    mappings.forEach((mapping, cellIndex) => {
      if (!mapping) {
        return;
      }
      const value = (cells[cellIndex] || "").trim();
      applyMappingToRecord(record, mapping, value);
    });

    if (!studentHasMeaningfulContent(record)) {
      return;
    }

    preserveExistingPhoto(record, existingByKey);
    students.push(record);
  });

  return { students };
}

function parseCsvRows(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let inQuotes = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        cell += '"';
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === "," && !inQuotes) {
      row.push(cell.trim());
      cell = "";
      continue;
    }

    if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && next === "\n") {
        index += 1;
      }
      row.push(cell.trim());
      if (row.some((value) => value !== "")) {
        rows.push(row);
      }
      row = [];
      cell = "";
      continue;
    }

    cell += char;
  }

  if (cell.length || row.length) {
    row.push(cell.trim());
    if (row.some((value) => value !== "")) {
      rows.push(row);
    }
  }

  return rows;
}

async function readXlsxRows(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  const archive = readZipDirectory(bytes);
  const sheetPath = await getPrimaryWorksheetPath(bytes, archive);
  const sharedStrings = archive.has("xl/sharedStrings.xml")
    ? parseSharedStrings(
        await readZipEntryText(bytes, archive.get("xl/sharedStrings.xml"))
      )
    : [];
  const worksheetXml = await readZipEntryText(bytes, archive.get(sheetPath));
  return parseWorksheetRows(worksheetXml, sharedStrings);
}

function readZipDirectory(bytes) {
  const eocdOffset = findZipEndOfCentralDirectory(bytes);
  if (eocdOffset < 0) {
    throw new Error("ZIP end record not found");
  }

  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const entryCount = view.getUint16(eocdOffset + 10, true);
  const centralOffset = view.getUint32(eocdOffset + 16, true);
  const archive = new Map();
  let cursor = centralOffset;

  for (let index = 0; index < entryCount; index += 1) {
    if (view.getUint32(cursor, true) !== 0x02014b50) {
      break;
    }

    const compressionMethod = view.getUint16(cursor + 10, true);
    const compressedSize = view.getUint32(cursor + 20, true);
    const fileNameLength = view.getUint16(cursor + 28, true);
    const extraLength = view.getUint16(cursor + 30, true);
    const commentLength = view.getUint16(cursor + 32, true);
    const localHeaderOffset = view.getUint32(cursor + 42, true);
    const fileNameBytes = bytes.slice(
      cursor + 46,
      cursor + 46 + fileNameLength
    );
    const fileName = decodeUtf8(fileNameBytes);

    archive.set(fileName, {
      fileName,
      compressionMethod,
      compressedSize,
      localHeaderOffset,
    });

    cursor += 46 + fileNameLength + extraLength + commentLength;
  }

  return archive;
}

function findZipEndOfCentralDirectory(bytes) {
  for (
    let index = Math.max(0, bytes.length - 22);
    index >= Math.max(0, bytes.length - 65557);
    index -= 1
  ) {
    if (
      bytes[index] === 0x50 &&
      bytes[index + 1] === 0x4b &&
      bytes[index + 2] === 0x05 &&
      bytes[index + 3] === 0x06
    ) {
      return index;
    }
  }
  return -1;
}

async function getPrimaryWorksheetPath(bytes, archive) {
  if (!archive.has("xl/workbook.xml")) {
    const firstSheet = Array.from(archive.keys()).find((name) =>
      name.startsWith("xl/worksheets/")
    );
    if (firstSheet) {
      return firstSheet;
    }
    throw new Error("Workbook XML missing");
  }

  const workbookXml = await readZipEntryText(bytes, archive.get("xl/workbook.xml"));
  const relsXml = archive.has("xl/_rels/workbook.xml.rels")
    ? await readZipEntryText(bytes, archive.get("xl/_rels/workbook.xml.rels"))
    : "";

  const workbookDoc = parseXml(workbookXml);
  const relsDoc = relsXml ? parseXml(relsXml) : null;
  const firstSheet = getElementsByLocalName(workbookDoc, "sheet")[0];

  if (!firstSheet) {
    const fallbackSheet = Array.from(archive.keys()).find((name) =>
      name.startsWith("xl/worksheets/")
    );
    if (fallbackSheet) {
      return fallbackSheet;
    }
    throw new Error("Worksheet not found");
  }

  const relationshipId =
    firstSheet.getAttribute("r:id") ||
    firstSheet.getAttributeNS(
      "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "id"
    );

  if (relationshipId && relsDoc) {
    const relationship = getElementsByLocalName(relsDoc, "Relationship").find(
      (node) => node.getAttribute("Id") === relationshipId
    );
    if (relationship) {
      return normalizeWorksheetPath(relationship.getAttribute("Target"));
    }
  }

  return "xl/worksheets/sheet1.xml";
}

function normalizeWorksheetPath(target) {
  const cleaned = String(target || "").replace(/^\/+/, "");
  return cleaned.startsWith("xl/") ? cleaned : `xl/${cleaned}`;
}

async function readZipEntryText(bytes, entry) {
  const data = await extractZipEntry(bytes, entry);
  return decodeUtf8(data);
}

async function extractZipEntry(bytes, entry) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const localOffset = entry.localHeaderOffset;
  if (view.getUint32(localOffset, true) !== 0x04034b50) {
    throw new Error("Invalid local ZIP header");
  }

  const fileNameLength = view.getUint16(localOffset + 26, true);
  const extraLength = view.getUint16(localOffset + 28, true);
  const dataStart = localOffset + 30 + fileNameLength + extraLength;
  const compressed = bytes.slice(dataStart, dataStart + entry.compressedSize);

  if (entry.compressionMethod === 0) {
    return compressed;
  }

  if (entry.compressionMethod === 8) {
    if (typeof DecompressionStream === "undefined") {
      throw new Error("DecompressionStream not supported");
    }
    const stream = new Blob([compressed])
      .stream()
      .pipeThrough(new DecompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  throw new Error(`Unsupported ZIP compression method: ${entry.compressionMethod}`);
}

function parseSharedStrings(xmlText) {
  const doc = parseXml(xmlText);
  return getElementsByLocalName(doc, "si").map((node) =>
    getNodeText(node).replace(/\r?\n/g, " ").trim()
  );
}

function parseWorksheetRows(xmlText, sharedStrings) {
  const doc = parseXml(xmlText);
  return getElementsByLocalName(doc, "row")
    .map((rowNode) => {
      const row = [];
      getElementsByLocalName(rowNode, "c").forEach((cellNode) => {
        const ref = cellNode.getAttribute("r") || "";
        const columnIndex = cellRefToColumnIndex(ref);
        row[columnIndex] = parseWorksheetCellValue(cellNode, sharedStrings);
      });
      while (row.length && row[row.length - 1] === "") {
        row.pop();
      }
      return row.map((value) => String(value || "").trim());
    })
    .filter((row) => row.length);
}

function parseWorksheetCellValue(cellNode, sharedStrings) {
  const type = cellNode.getAttribute("t") || "";

  if (type === "inlineStr") {
    return getNodeText(cellNode);
  }

  if (type === "s") {
    const valueNode = getElementsByLocalName(cellNode, "v")[0];
    const index = Number(valueNode?.textContent || 0);
    return sharedStrings[index] || "";
  }

  if (type === "b") {
    const valueNode = getElementsByLocalName(cellNode, "v")[0];
    return valueNode?.textContent === "1" ? "TRUE" : "FALSE";
  }

  const valueNode = getElementsByLocalName(cellNode, "v")[0];
  return valueNode?.textContent || "";
}

function cellRefToColumnIndex(reference) {
  const letters = (reference.match(/[A-Z]+/i) || ["A"])[0].toUpperCase();
  let index = 0;
  for (let pointer = 0; pointer < letters.length; pointer += 1) {
    index = index * 26 + (letters.charCodeAt(pointer) - 64);
  }
  return Math.max(0, index - 1);
}

function parseXml(text) {
  return new DOMParser().parseFromString(text, "application/xml");
}

function getElementsByLocalName(root, name) {
  return Array.from(root.getElementsByTagNameNS("*", name));
}

function getNodeText(node) {
  return getElementsByLocalName(node, "t")
    .map((textNode) => textNode.textContent || "")
    .join("");
}

function decodeUtf8(bytes) {
  return new TextDecoder("utf-8").decode(bytes);
}

function parseBlockImport(raw) {
  const blocks = raw
    .split(/\r?\n\s*\r?\n+/)
    .map((block) => block.trim())
    .filter(Boolean);

  if (blocks.length < 2) {
    return { students: [] };
  }

  const existingByKey = buildExistingStudentMap();
  const students = [];

  blocks.forEach((block) => {
    const record = createStudentRecord();
    const result = applyLegacyBlockToRecord(block, record);
    if (result.applied > 0 && studentHasMeaningfulContent(record)) {
      preserveExistingPhoto(record, existingByKey);
      students.push(record);
    }
  });

  return { students };
}

function applyLegacyBlockToRecord(raw, record) {
  const lines = raw
    .split(/\r?\n/)
    .map((line) => line.replace(/\u00a0/g, " ").trim())
    .filter(Boolean);

  let applied = 0;
  const unparsed = [];

  for (let index = 0; index < lines.length; index += 1) {
    const cells = splitRow(lines[index]);
    if (!cells.length) {
      continue;
    }

    const headerMatches = cells.map((cell) => matchField(cell));
    const headerCount = headerMatches.filter(Boolean).length;
    if (headerCount >= 2 && index + 1 < lines.length) {
      const valueRow = splitRow(lines[index + 1]);
      headerMatches.forEach((field, cellIndex) => {
        if (field && valueRow[cellIndex]) {
          record.student[field] = valueRow[cellIndex];
          applied += 1;
        }
      });
      index += 1;
      continue;
    }

    const firstCell = cells[0];
    const directField = matchField(firstCell);
    if (directField) {
      record.student[directField] = collectValue(cells.slice(1));
      applied += 1;
      continue;
    }

    if (cells.length === 1 && firstCell.includes(":")) {
      const [label, ...rest] = firstCell.split(":");
      const field = matchField(label);
      if (field) {
        record.student[field] = rest.join(":").trim();
        applied += 1;
        continue;
      }
    }

    if (cells.length > 1 && firstCell.includes(":")) {
      const [label] = firstCell.split(":");
      const field = matchField(label);
      if (field) {
        record.student[field] = collectValue([
          firstCell.slice(firstCell.indexOf(":") + 1),
          ...cells.slice(1),
        ]);
        applied += 1;
        continue;
      }
    }

    const monthlyHit = tryApplyMonthlyRow(cells, record);
    if (monthlyHit) {
      applied += monthlyHit;
      continue;
    }

    const halfYearlyHit = tryApplyHalfYearlyRow(cells, record);
    if (halfYearlyHit) {
      applied += halfYearlyHit;
      continue;
    }

    if (!looksLikeHeaderNoise(cells)) {
      unparsed.push(lines[index]);
    }
  }

  return { applied, unparsed };
}

function tryApplyMonthlyRow(cells, record) {
  let term = normalizeText(cells[0]).toUpperCase();
  let monthCell = cells[1];
  let startIndex = 2;

  if (!["H1", "H2"].includes(term)) {
    term = monthTermFromLabel(cells[0]);
    monthCell = cells[0];
    startIndex = 1;
  }

  const canonicalMonth = matchMonth(monthCell);
  if (!canonicalMonth) {
    return 0;
  }

  const row = record.monthly.find((entry) => entry.month === canonicalMonth);
  if (!row) {
    return 0;
  }

  row.term = term || row.term;
  let applied = 1;

  MONTHLY_COLUMNS.forEach((column, columnIndex) => {
    row[column.key] = cells[startIndex + columnIndex] || "";
    if (row[column.key]) {
      applied += 1;
    }
  });
  Object.assign(row, normalizeMonthlyRow(row, record.student));

  return applied;
}

function tryApplyHalfYearlyRow(cells, record) {
  const term = normalizeText(cells[0]).toUpperCase();
  if (!["H1", "H2"].includes(term)) {
    return 0;
  }

  if (matchMonth(cells[1])) {
    return 0;
  }

  const row = record.halfYearly.find((entry) => entry.term === term);
  if (!row) {
    return 0;
  }

  let applied = 1;
  HALF_YEARLY_COLUMNS.forEach((column, columnIndex) => {
    row[column.key] = cells[columnIndex + 1] || "";
    if (row[column.key]) {
      applied += 1;
    }
  });

  return applied;
}

function resolveColumnMapping(header) {
  const directField = matchField(header);
  if (directField) {
    return { type: "student", key: directField };
  }

  const monthlyMapping = parseMonthlyColumnHeader(header);
  if (monthlyMapping) {
    return { type: "monthly", ...monthlyMapping };
  }

  const halfYearlyMapping = parseHalfYearlyColumnHeader(header);
  if (halfYearlyMapping) {
    return { type: "halfYearly", ...halfYearlyMapping };
  }

  return null;
}

function parseMonthlyColumnHeader(header) {
  const normalized = normalizeHeaderWords(header);
  const monthMatch = findMonthInHeader(normalized);
  if (!monthMatch) {
    return null;
  }

  const remainder = cleanupImportHeader(
    normalized.replace(monthMatch.alias, " ").replace(/\bh1\b|\bh2\b/g, " ")
  );
  const key = matchPatternKey(remainder, MONTHLY_IMPORT_PATTERNS);
  if (!key) {
    return null;
  }

  return { month: monthMatch.month, key };
}

function parseHalfYearlyColumnHeader(header) {
  const normalized = normalizeHeaderWords(header);
  const termMatch = normalized.match(/\bh[12]\b/);
  if (!termMatch) {
    return null;
  }

  const remainder = cleanupImportHeader(
    normalized
      .replace(/\bh[12]\b/g, " ")
      .replace(/\bhalf yearly\b/g, " ")
      .replace(/\bassessment\b/g, " ")
  );
  const key = matchPatternKey(remainder, HALF_YEARLY_IMPORT_PATTERNS);
  if (!key) {
    return null;
  }

  return { term: termMatch[0].toUpperCase(), key };
}

function findMonthInHeader(header) {
  for (const group of MONTH_SEARCH_GROUPS) {
    for (const alias of group.aliases) {
      const regex = new RegExp(`\\b${alias}\\b`);
      if (regex.test(header)) {
        return { month: group.month, alias: alias };
      }
    }
  }
  return null;
}

function matchPatternKey(value, patterns) {
  for (const pattern of patterns) {
    for (const alias of pattern.aliases) {
      if (value === alias || value.includes(alias) || alias.includes(value)) {
        return pattern.key;
      }
    }
  }
  return null;
}

function applyMappingToRecord(record, mapping, value) {
  if (mapping.type === "student") {
    record.student[mapping.key] = value;
    return;
  }

  if (mapping.type === "monthly") {
    const row = record.monthly.find((entry) => entry.month === mapping.month);
    if (row) {
      row[mapping.key] = value;
    }
    return;
  }

  if (mapping.type === "halfYearly") {
    const row = record.halfYearly.find((entry) => entry.term === mapping.term);
    if (row) {
      row[mapping.key] = value;
    }
  }
}

function preserveExistingPhoto(record, existingByKey) {
  const key = getStudentIdentity(record);
  if (!key || !existingByKey.has(key)) {
    return;
  }
  record.photo = cloneData(existingByKey.get(key).photo);
}

function buildExistingStudentMap() {
  const map = new Map();
  state.students.forEach((record) => {
    const key = getStudentIdentity(record);
    if (key) {
      map.set(key, record);
    }
  });
  return map;
}

function getStudentIdentity(record) {
  const identitySource =
    record.student.admissionNo ||
    record.student.aadhaarNo ||
    record.student.misRegNo ||
    record.student.name;
  return normalizeText(identitySource);
}

function studentHasMeaningfulContent(record) {
  const coreFieldKeys = Object.keys(record.student).filter(
    (key) => key !== "instituteName"
  );
  const hasStudentDetails = coreFieldKeys.some((key) =>
    String(record.student[key] || "").trim()
  );
  const hasMonthlyData = record.monthly.some((row) =>
    MONTHLY_COLUMNS.some((column) => String(row[column.key] || "").trim())
  );
  const hasHalfYearlyData = record.halfYearly.some((row) =>
    HALF_YEARLY_COLUMNS.some((column) => String(row[column.key] || "").trim())
  );
  return hasStudentDetails || hasMonthlyData || hasHalfYearlyData;
}

async function downloadSelectedPdf() {
  const selected = getSelectedStudent();
  if (!selected) {
    return;
  }

  try {
    await exportProgressPagesToPdf({
      filename: `progress-card-${sanitizeFilename(
        selected.student.admissionNo || selected.student.name || "selected"
      )}.pdf`,
      records: [selected],
    });
  } catch (error) {
    console.error("Progress Card PDF export failed.", error);
    setStatus("Could not download the selected PDF right now.", "warning");
  }
}

async function downloadCombinedPdf() {
  if (!state.students.length) {
    return;
  }

  try {
    await exportProgressPagesToPdf({
      filename: "progress-card-combined.pdf",
      records: state.students,
    });
  } catch (error) {
    console.error("Progress Card combined PDF export failed.", error);
    setStatus("Could not download the combined PDF right now.", "warning");
  }
}

async function exportProgressPagesToPdf({ filename, records }) {
  if (!window.PDFLib?.PDFDocument) {
    throw new Error("PDF export library is unavailable.");
  }

  const pdfDoc = await window.PDFLib.PDFDocument.create();
  await withPreparedProgressExportPages(records, async (pages) => {
    for (const pageNode of pages) {
      await addProgressPdfPage(pdfDoc, pageNode);
    }
  });

  const pdfBytes = await pdfDoc.save();
  downloadFileBlob(new Blob([pdfBytes], { type: "application/pdf" }), filename);
}

async function downloadSelectedWord() {
  const selected = getSelectedStudent();
  if (!selected) {
    return;
  }

  try {
    await withPreparedProgressExportPages([selected], (pages) => {
      downloadWordDocument({
        filename: `progress-card-${sanitizeFilename(
          selected.student.admissionNo || selected.student.name || "selected"
        )}.doc`,
        title: "Progress Card",
        pageOrientation: "portrait",
        sources: pages,
        extraStyles: PROGRESS_WORD_EXPORT_STYLES,
      });
    });
  } catch (error) {
    console.error("Progress Card Word export failed.", error);
    setStatus("Could not download the selected Word file right now.", "warning");
  }
}

async function downloadCombinedWord() {
  if (!state.students.length) {
    return;
  }

  try {
    await withPreparedProgressExportPages(state.students, (pages) => {
      downloadWordDocument({
        filename: "progress-card-combined.doc",
        title: "Progress Card Combined",
        pageOrientation: "portrait",
        sources: pages,
        extraStyles: PROGRESS_WORD_EXPORT_STYLES,
      });
    });
  } catch (error) {
    console.error("Progress Card combined Word export failed.", error);
    setStatus("Could not download the combined Word file right now.", "warning");
  }
}

async function withPreparedProgressExportPages(records, task) {
  const sourceHost = document.createElement("div");
  sourceHost.setAttribute("aria-hidden", "true");
  sourceHost.style.position = "fixed";
  sourceHost.style.left = "-100000px";
  sourceHost.style.top = "0";
  sourceHost.style.width = "230mm";
  sourceHost.style.visibility = "hidden";
  sourceHost.style.pointerEvents = "none";
  sourceHost.innerHTML = records.map((record) => renderProgressPage(record)).join("");
  document.body.appendChild(sourceHost);

  const exportHost = document.createElement("div");
  exportHost.setAttribute("aria-hidden", "true");
  exportHost.style.position = "fixed";
  exportHost.style.left = "-100000px";
  exportHost.style.top = "0";
  exportHost.style.visibility = "hidden";
  exportHost.style.pointerEvents = "none";
  exportHost.style.background = "#ffffff";
  document.body.appendChild(exportHost);

  try {
    await waitForFontsReady();
    await waitForImagesReady(sourceHost);
    fitProgressPages(sourceHost);
    await waitForNextFrame();

    const preparedPages = [];
    for (const sourcePage of sourceHost.querySelectorAll(".progress-page")) {
      const clone = await cloneProgressNodeForExport(sourcePage);
      if (!clone) {
        continue;
      }
      exportHost.appendChild(clone);
      preparedPages.push(clone);
    }

    await waitForImagesReady(exportHost);
    await waitForNextFrame();
    return await task(preparedPages);
  } finally {
    exportHost.remove();
    sourceHost.remove();
  }
}

async function addProgressPdfPage(pdfDoc, pageNode) {
  const page = pdfDoc.addPage(A4_PORTRAIT_POINTS);
  const pngDataUrl = await renderNodeToPngDataUrl(pageNode, 2);
  const image = await pdfDoc.embedPng(pngDataUrl);
  page.drawImage(image, {
    x: 0,
    y: 0,
    width: page.getWidth(),
    height: page.getHeight(),
  });
}

async function renderNodeToPngDataUrl(node, scaleFactor = 2) {
  const rect = node.getBoundingClientRect();
  const width = Math.max(1, Math.ceil(rect.width));
  const height = Math.max(1, Math.ceil(rect.height));
  const svgMarkup = buildNodeSnapshotSvg(node, width, height);
  const svgUrl = URL.createObjectURL(
    new Blob([svgMarkup], { type: "image/svg+xml;charset=utf-8" })
  );

  try {
    const image = await loadImageElement(svgUrl);
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.ceil(width * scaleFactor));
    canvas.height = Math.max(1, Math.ceil(height * scaleFactor));
    const context = canvas.getContext("2d");
    if (!context) {
      throw new Error("Canvas context is unavailable.");
    }

    context.scale(scaleFactor, scaleFactor);
    context.drawImage(image, 0, 0, width, height);
    return canvas.toDataURL("image/png");
  } finally {
    URL.revokeObjectURL(svgUrl);
  }
}

function buildNodeSnapshotSvg(node, width, height) {
  const wrapper = document.createElement("div");
  wrapper.setAttribute("xmlns", "http://www.w3.org/1999/xhtml");
  wrapper.style.width = `${width}px`;
  wrapper.style.height = `${height}px`;
  wrapper.style.margin = "0";
  wrapper.style.padding = "0";
  wrapper.style.background = "#ffffff";
  wrapper.appendChild(node.cloneNode(true));

  const xhtml = new XMLSerializer().serializeToString(wrapper);
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <foreignObject width="100%" height="100%">
    ${xhtml}
  </foreignObject>
</svg>`;
}

function loadImageElement(url) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = "sync";
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Could not load export image."));
    image.src = url;
  });
}

async function cloneProgressNodeForExport(node) {
  if (node.nodeType === Node.TEXT_NODE) {
    return node.cloneNode(false);
  }

  if (node.nodeType !== Node.ELEMENT_NODE) {
    return null;
  }

  if (
    node instanceof HTMLInputElement
    || node instanceof HTMLTextAreaElement
    || node instanceof HTMLSelectElement
  ) {
    return createProgressExportFieldNode(node);
  }

  if (node.tagName === "SCRIPT") {
    return null;
  }

  const clone = node.cloneNode(false);
  copyProgressComputedStyles(node, clone);

  if (node instanceof HTMLImageElement) {
    const exportSrc = await getProgressExportImageSrc(node);
    if (exportSrc) {
      clone.setAttribute("src", exportSrc);
    }
    clone.removeAttribute("srcset");
  }

  for (const child of node.childNodes) {
    const childClone = await cloneProgressNodeForExport(child);
    if (childClone) {
      clone.appendChild(childClone);
    }
  }

  return clone;
}

function createProgressExportFieldNode(field) {
  const replacement = document.createElement(
    field instanceof HTMLTextAreaElement ? "div" : "span"
  );
  copyProgressComputedStyles(field, replacement);
  replacement.textContent = getProgressExportFieldValue(field) || " ";
  replacement.style.display = "inline-block";
  replacement.style.whiteSpace =
    field instanceof HTMLTextAreaElement ? "pre-wrap" : "nowrap";
  replacement.style.background = "transparent";
  replacement.style.border = "none";
  return replacement;
}

function getProgressExportFieldValue(field) {
  if (field instanceof HTMLSelectElement) {
    return field.selectedOptions[0]?.textContent?.trim() || field.value || "";
  }

  if (
    field instanceof HTMLInputElement
    && (field.type === "checkbox" || field.type === "radio")
  ) {
    return field.checked ? "Y" : "";
  }

  return field.value || field.getAttribute("value") || "";
}

function copyProgressComputedStyles(source, target) {
  const computed = window.getComputedStyle(source);
  for (let index = 0; index < computed.length; index += 1) {
    const property = computed[index];
    target.style.setProperty(
      property,
      computed.getPropertyValue(property),
      computed.getPropertyPriority(property)
    );
  }
}

async function getProgressExportImageSrc(image) {
  const source = image.currentSrc || image.src || image.getAttribute("src") || "";
  if (!source) {
    return "";
  }

  if (/^data:/i.test(source)) {
    return source;
  }

  if (!image.complete || !image.naturalWidth || !image.naturalHeight) {
    return source;
  }

  try {
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const context = canvas.getContext("2d");
    if (!context) {
      return source;
    }
    context.drawImage(image, 0, 0);
    return canvas.toDataURL("image/png");
  } catch (error) {
    try {
      const response = await fetch(source);
      const blob = await response.blob();
      return await readBlobAsDataUrl(blob);
    } catch (fallbackError) {
      return source;
    }
  }
}

function readBlobAsDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error || new Error("Could not read blob."));
    reader.readAsDataURL(blob);
  });
}

function downloadFileBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function waitForNextFrame() {
  return new Promise((resolve) => {
    window.requestAnimationFrame(() => resolve());
  });
}

async function waitForFontsReady() {
  if (!document.fonts?.ready) {
    return;
  }

  try {
    await document.fonts.ready;
  } catch (error) {
    console.warn(
      "Continuing Progress Card export before all fonts finished loading.",
      error
    );
  }
}

async function waitForImagesReady(root) {
  const pendingImages = Array.from(root.querySelectorAll("img")).filter(
    (image) => !image.complete || !image.naturalWidth || !image.naturalHeight
  );

  if (!pendingImages.length) {
    return;
  }

  await Promise.all(
    pendingImages.map(
      (image) =>
        new Promise((resolve) => {
          image.addEventListener("load", resolve, { once: true });
          image.addEventListener("error", resolve, { once: true });
        })
    )
  );
}

function setSelectedStudent(studentId, syncPhotoTarget = false) {
  if (!state.students.some((record) => record.id === studentId)) {
    return;
  }
  state.selectedStudentId = studentId;
  if (syncPhotoTarget) {
    state.photoTargetId = studentId;
  }
}

function getSelectedStudent() {
  ensureStateIntegrity();
  return (
    state.students.find((record) => record.id === state.selectedStudentId) ||
    state.students[0]
  );
}

function getPhotoTargetStudent() {
  ensureStateIntegrity();
  return (
    state.students.find((record) => record.id === state.photoTargetId) ||
    getSelectedStudent()
  );
}

function ensureStateIntegrity() {
  if (!Array.isArray(state.students) || !state.students.length) {
    const fallback = createEmptyState();
    state.students = fallback.students;
    state.selectedStudentId = fallback.selectedStudentId;
    state.photoTargetId = fallback.photoTargetId;
    state.marksWorkspace = fallback.marksWorkspace;
  }

  if (!state.marksWorkspace || typeof state.marksWorkspace !== "object") {
    state.marksWorkspace = createDefaultMarksWorkspace();
  }

  if (!state.students.some((record) => record.id === state.selectedStudentId)) {
    state.selectedStudentId = state.students[0].id;
  }

  if (!state.students.some((record) => record.id === state.photoTargetId)) {
    state.photoTargetId = state.selectedStudentId;
  }
}

function overwriteState(nextState) {
  const normalized = normalizeState(nextState);
  state.students = normalized.students;
  state.selectedStudentId = normalized.selectedStudentId;
  state.photoTargetId = normalized.photoTargetId;
  state.marksWorkspace = normalized.marksWorkspace;
  saveState();
  renderAll();
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return createDemoState();
    }
    return normalizeState(JSON.parse(raw));
  } catch (error) {
    return createDemoState();
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function createDefaultMarksWorkspace() {
  return {
    selectedMonth: DEFAULT_MARKS_WORKSPACE.selectedMonth,
    nimmiExamIdByMonth: {},
    annexOutcomeKeyByMonth: {},
  };
}

function normalizeMarksWorkspace(rawWorkspace) {
  const next = createDefaultMarksWorkspace();

  const selectedMonth = matchMonth(rawWorkspace?.selectedMonth);
  if (selectedMonth) {
    next.selectedMonth = selectedMonth;
  }

  Object.entries(rawWorkspace?.nimmiExamIdByMonth || {}).forEach(([month, examId]) => {
    const canonicalMonth = matchMonth(month);
    if (!canonicalMonth) {
      return;
    }
    next.nimmiExamIdByMonth[canonicalMonth] = String(examId || "");
  });

  Object.entries(rawWorkspace?.annexOutcomeKeyByMonth || {}).forEach(([month, outcomeKey]) => {
    const canonicalMonth = matchMonth(month);
    if (!canonicalMonth) {
      return;
    }
    next.annexOutcomeKeyByMonth[canonicalMonth] = String(outcomeKey || "");
  });

  return next;
}

function normalizeState(raw) {
  if (raw?.students && Array.isArray(raw.students)) {
    const students = raw.students.map((record) => normalizeStudentRecord(record));
    return {
      students: students.length ? students : createEmptyState().students,
      selectedStudentId: raw.selectedStudentId,
      photoTargetId: raw.photoTargetId,
      marksWorkspace: normalizeMarksWorkspace(raw.marksWorkspace),
    };
  }

  if (raw?.student) {
    const migratedRecord = createStudentRecord({
      student: raw.student,
      photo: raw.photo || DEFAULT_PHOTO,
      monthly: raw.monthly || [],
      halfYearly: raw.halfYearly || [],
    });
    return {
      students: [migratedRecord],
      selectedStudentId: migratedRecord.id,
      photoTargetId: migratedRecord.id,
      marksWorkspace: createDefaultMarksWorkspace(),
    };
  }

  return createDemoState();
}

function normalizeStudentRecord(record) {
  return createStudentRecord({
    id: record.id,
    student: { ...DEFAULT_STUDENT, ...(record.student || {}) },
    photo: { ...DEFAULT_PHOTO, ...(record.photo || {}) },
    monthly: Array.isArray(record.monthly) ? record.monthly : [],
    halfYearly: Array.isArray(record.halfYearly) ? record.halfYearly : [],
  });
}

function createEmptyState() {
  const student = createStudentRecord();
  return {
    students: [student],
    selectedStudentId: student.id,
    photoTargetId: student.id,
    marksWorkspace: createDefaultMarksWorkspace(),
  };
}

function createDemoState() {
  const first = createStudentRecord({
    student: {
      instituteName: "GOVT ITI PANNIYANNORE",
      name: "ANJALI K",
      trade: "D/Civil",
      admissionNo: "813",
      admissionDate: "16-07-2025",
      aadhaarNo: "1234 5678 9012",
      misRegNo: "ITI-2025-0813",
      qualification: "PLUS TWO",
      traineePhone: "9876543210",
      guardianName: "PRAKASHAN K",
      guardianPhone: "9847001122",
      address: "MUTHEDATH HOUSE, ANIYARAM, KANNUR, KERALA - 670672",
    },
    monthly: [
      {
        month: "Aug.",
        term: "H1",
        possible: "22",
        present: "22",
        cumPossible: "22",
        cumPresent: "22",
        percentage: "100",
        profSkill: "88",
        profKnowledge: "84",
        enggDrg: "81",
        wcs: "90",
        es: "86",
        total: "429",
      },
      {
        month: "Sept.",
        term: "H1",
        possible: "18",
        present: "18",
        cumPossible: "40",
        cumPresent: "40",
        percentage: "100",
        profSkill: "84",
        profKnowledge: "82",
        enggDrg: "78",
        wcs: "85",
        es: "83",
        total: "412",
      },
    ],
    halfYearly: [
      {
        term: "H1",
        possible: "120",
        present: "120",
        percentage: "100",
        formative: "84",
        conduct: "V.Good",
      },
    ],
  });

  const second = createStudentRecord({
    student: {
      instituteName: "GOVT ITI PANNIYANNORE",
      name: "RESHMA P",
      trade: "D/Civil",
      admissionNo: "814",
      admissionDate: "16-07-2025",
      aadhaarNo: "5678 1234 9012",
      misRegNo: "ITI-2025-0814",
      qualification: "SSLC",
      traineePhone: "9895003344",
      guardianName: "SURESH P",
      guardianPhone: "9847557788",
      address: "PONNAMBATH HOUSE, PANNIYANNORE, KANNUR, KERALA - 670671",
    },
    monthly: [
      {
        month: "Aug.",
        term: "H1",
        possible: "22",
        present: "21",
        cumPossible: "22",
        cumPresent: "21",
        percentage: "95",
        profSkill: "82",
        profKnowledge: "80",
        enggDrg: "75",
        wcs: "84",
        es: "82",
        total: "403",
      },
      {
        month: "Sept.",
        term: "H1",
        possible: "18",
        present: "17",
        cumPossible: "40",
        cumPresent: "38",
        percentage: "95",
        profSkill: "79",
        profKnowledge: "77",
        enggDrg: "73",
        wcs: "80",
        es: "81",
        total: "390",
      },
    ],
    halfYearly: [
      {
        term: "H1",
        possible: "120",
        present: "115",
        percentage: "96",
        formative: "79",
        conduct: "Good",
      },
    ],
  });

  return {
    students: [first, second],
    selectedStudentId: first.id,
    photoTargetId: first.id,
    marksWorkspace: createDefaultMarksWorkspace(),
  };
}

function createStudentRecord(overrides = {}) {
  const student = { ...DEFAULT_STUDENT, ...(overrides.student || {}) };
  const photo = { ...DEFAULT_PHOTO, ...(overrides.photo || {}) };
  const monthly = createMonthlyRows(overrides.monthly || [], student);
  const halfYearly = createHalfYearlyRows(overrides.halfYearly || []);

  return {
    id: overrides.id || createStudentId(),
    student,
    photo,
    monthly,
    halfYearly,
  };
}

function createMonthlyRows(sourceRows, student) {
  return MONTH_LAYOUT.map((layout) => {
    const source =
      sourceRows.find((row) => row.month === layout.month) ||
      sourceRows[MONTH_LAYOUT.findIndex((item) => item.month === layout.month)] ||
      {};
    const row = { ...layout };
    MONTHLY_COLUMNS.forEach((column) => {
      row[column.key] = source[column.key] || "";
    });
    row.term = source.term || layout.term;
    return normalizeMonthlyRow(row, student);
  });
}

function normalizeMonthlyRow(row, student) {
  const nextRow = { ...row };
  if (shouldHideEngineeringDrawing(student)) {
    nextRow.enggDrg = "-";
  }

  const nextTotal = computeMonthlyTotal(nextRow, student);
  nextRow.total = nextTotal;
  return nextRow;
}

function computeMonthlyTotal(row, student) {
  const keys = shouldHideEngineeringDrawing(student)
    ? ["profSkill", "profKnowledge", "wcs", "es"]
    : ["profSkill", "profKnowledge", "enggDrg", "wcs", "es"];
  const values = keys
    .map((key) => parseMonthlyMarkValue(row[key]))
    .filter((value) => value != null);

  if (!values.length) {
    return "";
  }

  const total = values.reduce((sum, value) => sum + value, 0);
  return Number.isInteger(total) ? String(total) : String(Number(total.toFixed(2)));
}

function parseMonthlyMarkValue(value) {
  if (value == null) {
    return null;
  }
  const text = String(value).trim();
  if (!text || text === "-") {
    return null;
  }
  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed : null;
}

function shouldHideEngineeringDrawing(student) {
  const tradeToken = normalizeText(student?.trade || "");
  return tradeToken.includes("civil");
}

function getSelectedMarksMonth() {
  const month = state?.marksWorkspace?.selectedMonth;
  return matchMonth(month) || MONTH_LAYOUT[0].month;
}

function getTermForMonth(month) {
  return MONTH_LAYOUT.find((entry) => entry.month === month)?.term || "";
}

function getMonthlyRowIndexByMonth(month) {
  return MONTH_LAYOUT.findIndex((entry) => entry.month === month);
}

function getMonthlyRowForRecord(record, month) {
  const rowIndex = getMonthlyRowIndexByMonth(month);
  return rowIndex >= 0 ? record.monthly[rowIndex] : null;
}

function setMonthlyRowForRecord(record, month, row) {
  const rowIndex = getMonthlyRowIndexByMonth(month);
  if (rowIndex < 0) {
    return;
  }
  record.monthly[rowIndex] = {
    ...record.monthly[rowIndex],
    ...row,
  };
}

function renderMonthlyMarksEntryRow(record, index, month) {
  const row = getMonthlyRowForRecord(record, month) || {};
  const isSelected = record.id === state.selectedStudentId;
  const attendanceLabel = formatAttendancePair(row.present, row.possible);
  const percentageLabel = String(row.percentage || "").trim() || "-";

  return `
    <tr class="${isSelected ? "is-preview-student" : ""}">
      <td class="marks-trainee-cell">
        <button
          type="button"
          class="marks-student-link ${isSelected ? "active" : ""}"
          data-preview-student="${escapeAttribute(record.id)}"
        >
          ${escapeHtml(record.student.name || `Trainee ${index + 1}`)}
        </button>
        <small>${escapeHtml(record.student.admissionNo || "Admission no not set")}</small>
      </td>
      <td class="month-readonly-cell">${escapeHtml(attendanceLabel)}</td>
      <td class="month-readonly-cell">${escapeHtml(percentageLabel)}</td>
      ${MONTHLY_MARK_ENTRY_KEYS.map(
        (key) => `
          <td>
            <input
              class="month-mark-input"
              type="number"
              min="0"
              max="100"
              step="0.01"
              inputmode="decimal"
              value="${escapeAttribute(row[key] || "")}"
              data-month-entry-key="${key}"
              data-month-entry-student-id="${escapeAttribute(record.id)}"
            />
          </td>
        `
      ).join("")}
      <td>
        <input
          class="month-mark-input total-input"
          type="text"
          readonly
          value="${escapeAttribute(row.total || "")}"
          data-month-entry-key="total"
          data-month-entry-student-id="${escapeAttribute(record.id)}"
          title="Auto-calculated from the monthly marks"
        />
      </td>
    </tr>
  `;
}

function syncMonthlyMarksRowDisplay(rowElement, row) {
  if (!rowElement) {
    return;
  }

  const totalField = rowElement.querySelector('[data-month-entry-key="total"]');
  if (totalField) {
    totalField.value = row.total || "";
  }
}

function syncMonthlyMarksSelectionUi() {
  monthlyEditorEl
    .querySelectorAll(".monthly-marks-table tbody tr")
    .forEach((rowElement) => {
      const previewButton = rowElement.querySelector("[data-preview-student]");
      const isSelected =
        previewButton?.dataset?.previewStudent === state.selectedStudentId;
      rowElement.classList.toggle("is-preview-student", Boolean(isSelected));
      if (previewButton) {
        previewButton.classList.toggle("active", Boolean(isSelected));
      }
    });
}

function formatAttendancePair(present, possible) {
  const presentText = String(present || "").trim();
  const possibleText = String(possible || "").trim();
  if (!presentText && !possibleText) {
    return "-";
  }
  if (!presentText) {
    return `- / ${possibleText}`;
  }
  if (!possibleText) {
    return presentText;
  }
  return `${presentText} / ${possibleText}`;
}

function importNimmiMarksForSelectedMonth() {
  const month = getSelectedMarksMonth();
  const examId = String(state.marksWorkspace.nimmiExamIdByMonth[month] || "").trim();
  if (!examId) {
    setMarksStatus("Select a saved NIMI exam first.", "warning");
    return;
  }

  const exam = readSavedNimmiExamLibrary().find((item) => item.id === examId);
  if (!exam) {
    setMarksStatus("That saved NIMI exam is no longer available.", "warning");
    return;
  }

  const imported = applyImportedMarksToMonth({
    month,
    sourceEntries: exam.students,
    targetKey: "profKnowledge",
    valueGetter: (entry) => entry.status === "absent" ? null : entry.markOutOf100,
  });

  state.marksWorkspace.nimmiExamIdByMonth[month] = examId;
  saveState();
  renderMonthlyEditor();
  renderPreviews();
  setMarksStatus(
    imported.matched
      ? `Imported Prof. Knowledge marks for ${imported.matched} trainee${imported.matched === 1 ? "" : "s"} from "${exam.title}".`
      : `No trainee marks could be matched from "${exam.title}".`,
    imported.matched ? "success" : "warning",
  );
}

function importAnnexOutcomeMarksForSelectedMonth() {
  const month = getSelectedMarksMonth();
  const outcomeKey = String(state.marksWorkspace.annexOutcomeKeyByMonth[month] || "").trim();
  if (!outcomeKey) {
    setMarksStatus("Select a saved Annexure learning outcome first.", "warning");
    return;
  }

  const outcome = readSavedAnnexOutcomeLibrary().find((item) => item.key === outcomeKey);
  if (!outcome) {
    setMarksStatus("That saved Annexure learning outcome is no longer available.", "warning");
    return;
  }

  const imported = applyImportedMarksToMonth({
    month,
    sourceEntries: outcome.trainees,
    targetKey: "profSkill",
    valueGetter: (entry) => entry.total,
  });

  state.marksWorkspace.annexOutcomeKeyByMonth[month] = outcomeKey;
  saveState();
  renderMonthlyEditor();
  renderPreviews();
  setMarksStatus(
    imported.matched
      ? `Imported Prof. Skill marks for ${imported.matched} trainee${imported.matched === 1 ? "" : "s"} from "${outcome.label}".`
      : `No trainee marks could be matched from "${outcome.label}".`,
    imported.matched ? "success" : "warning",
  );
}

function applyImportedMarksToMonth({ month, sourceEntries, targetKey, valueGetter }) {
  const matches = matchProgressStudentsWithSourceEntries(sourceEntries);
  let matched = 0;

  state.students.forEach((record) => {
    const source = matches.get(record.id);
    if (!source) {
      return;
    }

    const rawValue = valueGetter(source);
    if (rawValue == null || rawValue === "") {
      return;
    }

    const row = getMonthlyRowForRecord(record, month);
    if (!row) {
      return;
    }

    row[targetKey] = formatImportedMarkValue(rawValue);
    setMonthlyRowForRecord(record, month, normalizeMonthlyRow(row, record.student));
    matched += 1;
  });

  return { matched };
}

function formatImportedMarkValue(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) {
    return String(value || "").trim();
  }

  if (Number.isInteger(numeric)) {
    return String(numeric);
  }

  return numeric.toFixed(2).replace(/\.00$/, "").replace(/(\.\d)0$/, "$1");
}

function readSavedNimmiExamLibrary() {
  try {
    const raw = JSON.parse(window.localStorage.getItem(NIMMI_RANKLIST_STORAGE_KEY) || "null");
    const exams = Array.isArray(raw?.savedExams)
      ? raw.savedExams.map((exam) => normalizeNimmiExamSummary(exam)).filter(Boolean)
      : [];

    return exams.sort(
      (left, right) =>
        compareIsoDateTimes(right.scheduledDate || right.updatedAt || right.savedAt || right.createdAt, left.scheduledDate || left.updatedAt || left.savedAt || left.createdAt)
        || left.title.localeCompare(right.title),
    );
  } catch {
    return [];
  }
}

function normalizeNimmiExamSummary(rawExam) {
  if (!rawExam || typeof rawExam !== "object") {
    return null;
  }

  const totalQuestions = Math.max(0, Number.parseInt(String(rawExam.totalQuestions || "0"), 10) || 0);
  const students = Array.isArray(rawExam.students)
    ? rawExam.students.map((student, index) => normalizeNimmiExamStudent(student, totalQuestions, index)).filter(Boolean)
    : [];

  return {
    id: String(rawExam.id || ""),
    title: String(rawExam.title || rawExam.examLabel || "NIMI Rank List").trim(),
    scheduledDate: String(rawExam.scheduledDate || ""),
    updatedAt: String(rawExam.updatedAt || ""),
    savedAt: String(rawExam.savedAt || ""),
    createdAt: String(rawExam.createdAt || ""),
    students,
  };
}

function normalizeNimmiExamStudent(rawStudent, totalQuestions, index) {
  if (!rawStudent || typeof rawStudent !== "object") {
    return null;
  }

  const status = String(rawStudent.status || "present").toLowerCase() === "absent" ? "absent" : "present";
  const correctAnswers = parseImportNumber(rawStudent.correctAnswers);
  const markOutOf100 =
    status === "absent"
      ? null
      : parseImportNumber(rawStudent.markOutOf100)
        ?? (totalQuestions > 0 && correctAnswers != null
          ? Number(((correctAnswers / totalQuestions) * 100).toFixed(2))
          : null);

  return {
    id: String(rawStudent.id || `nimmi-${index}`),
    recordId: String(rawStudent.recordId || ""),
    admissionNo: String(rawStudent.admissionNo || "").trim(),
    name: String(rawStudent.name || "").trim(),
    status,
    markOutOf100,
  };
}

function readSavedAnnexOutcomeLibrary() {
  try {
    const raw = JSON.parse(window.localStorage.getItem(ANNEXURE_STORAGE_KEY) || "null");
    const outcomeRecords =
      raw?.outcomeRecords && typeof raw.outcomeRecords === "object"
        ? raw.outcomeRecords
        : {};

    return Object.entries(outcomeRecords)
      .map(([key, record]) => normalizeAnnexOutcomeSummary(key, record))
      .filter(Boolean)
      .sort((left, right) => left.label.localeCompare(right.label));
  } catch {
    return [];
  }
}

function normalizeAnnexOutcomeSummary(key, record) {
  if (!record || typeof record !== "object") {
    return null;
  }

  return {
    key: String(key || ""),
    label: String(record.learningOutcome || "Learning Outcome").trim(),
    dateOfAssessment: String(record.dateOfAssessment || "").trim(),
    trainees: Array.isArray(record.trainees)
      ? record.trainees.map((trainee, index) => normalizeAnnexOutcomeTrainee(trainee, index)).filter(Boolean)
      : [],
  };
}

function normalizeAnnexOutcomeTrainee(rawTrainee, index) {
  if (!rawTrainee || typeof rawTrainee !== "object") {
    return null;
  }

  const totalFromMarks = Array.isArray(rawTrainee.marks)
    ? rawTrainee.marks.reduce((sum, mark) => sum + (Number(mark) || 0), 0)
    : Number(rawTrainee.total || 0);

  return {
    id: `annex-${index}-${normalizePortalMatchToken(rawTrainee.admNo || rawTrainee.name || "trainee")}`,
    admissionNo: String(rawTrainee.admNo || "").trim(),
    name: String(rawTrainee.name || "").trim(),
    total: Math.max(0, Number(totalFromMarks || 0)),
  };
}

function formatNimmiExamOptionLabel(exam) {
  const dateLabel = formatShortDateLabel(exam.scheduledDate || exam.updatedAt || exam.savedAt || exam.createdAt);
  return [exam.title, dateLabel].filter(Boolean).join(" | ");
}

function formatAnnexOutcomeOptionLabel(outcome) {
  const dateLabel = formatShortDateLabel(outcome.dateOfAssessment);
  return [outcome.label, dateLabel].filter(Boolean).join(" | ");
}

function formatShortDateLabel(value) {
  const text = String(value || "").trim();
  if (!text) {
    return "";
  }

  const isoMatch = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (isoMatch) {
    return `${isoMatch[3]}-${isoMatch[2]}-${isoMatch[1]}`;
  }

  return text;
}

function compareIsoDateTimes(left, right) {
  const leftTime = Date.parse(String(left || "")) || 0;
  const rightTime = Date.parse(String(right || "")) || 0;
  return leftTime - rightTime;
}

function parseImportNumber(value) {
  if (value === "" || value == null) {
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function matchProgressStudentsWithSourceEntries(sourceEntries) {
  const normalizedSources = sourceEntries
    .map((entry, index) => normalizeImportSourceEntry(entry, index))
    .filter(Boolean);

  const lookup = buildImportSourceLookup(normalizedSources);
  const usedSourceIds = new Set();
  const matches = new Map();
  const unmatchedStudents = [];

  state.students.forEach((record) => {
    const directMatch = resolveImportSourceMatch(record.student, lookup, usedSourceIds);
    if (directMatch) {
      usedSourceIds.add(directMatch.id);
      matches.set(record.id, directMatch);
      return;
    }
    unmatchedStudents.push(record);
  });

  const remainingSources = normalizedSources.filter((entry) => !usedSourceIds.has(entry.id));
  const fuzzyAssignments = assignImportSimilarityMatches(
    unmatchedStudents,
    remainingSources,
    remainingSources.length === unmatchedStudents.length,
  );

  fuzzyAssignments.forEach((source, studentId) => {
    matches.set(studentId, source);
  });

  return matches;
}

function normalizeImportSourceEntry(entry, index) {
  if (!entry || typeof entry !== "object") {
    return null;
  }

  const name = String(entry.name || "").trim();
  const admissionNo = String(entry.admissionNo || entry.admNo || "").trim();
  if (!name && !admissionNo) {
    return null;
  }

  return {
    ...entry,
    id: String(entry.id || entry.recordId || `source-${index}`),
    name,
    admissionNo,
    nameProfile: buildImportNameProfile(name),
  };
}

function buildImportSourceLookup(records) {
  const byId = new Map();
  const byAdmission = new Map();
  const byExactName = new Map();
  const byAlias = new Map();
  const byFirstToken = new Map();

  records.forEach((record) => {
    byId.set(record.id, record);
    pushImportLookupValue(byAdmission, normalizePortalMatchToken(record.admissionNo), record);
    pushImportLookupValue(byExactName, normalizePortalMatchToken(record.name), record);
    pushImportLookupValue(byAlias, record.nameProfile.alias, record);
    pushImportLookupValue(byFirstToken, record.nameProfile.first, record);
  });

  return { byId, byAdmission, byExactName, byAlias, byFirstToken };
}

function pushImportLookupValue(map, key, value) {
  if (!key) {
    return;
  }
  const list = map.get(key) || [];
  list.push(value);
  map.set(key, list);
}

function resolveImportSourceMatch(student, lookup, usedSourceIds) {
  const admissionMatch = pickUniqueImportRecord(
    lookup.byAdmission.get(normalizePortalMatchToken(student.admissionNo)) || [],
    usedSourceIds,
  );
  if (admissionMatch) {
    return admissionMatch;
  }

  const exactNameMatch = pickUniqueImportRecord(
    lookup.byExactName.get(normalizePortalMatchToken(student.name)) || [],
    usedSourceIds,
  );
  if (exactNameMatch) {
    return exactNameMatch;
  }

  const profile = buildImportNameProfile(student.name);
  const aliasMatch = pickUniqueImportRecord(lookup.byAlias.get(profile.alias) || [], usedSourceIds);
  if (aliasMatch) {
    return aliasMatch;
  }

  const firstTokenCandidates = (lookup.byFirstToken.get(profile.first) || []).filter(
    (record) => !usedSourceIds.has(record.id),
  );
  if (firstTokenCandidates.length === 1) {
    return firstTokenCandidates[0];
  }

  const fuzzyCandidates = firstTokenCandidates.filter((record) => {
    const targetProfile = record.nameProfile;
    if (!profile.first || !targetProfile.first || profile.first !== targetProfile.first) {
      return false;
    }

    if (profile.joined && targetProfile.joined) {
      if (targetProfile.joined.includes(profile.joined) || profile.joined.includes(targetProfile.joined)) {
        return true;
      }
    }

    if (profile.initials && targetProfile.initials) {
      if (
        targetProfile.initials === profile.initials
        || targetProfile.initials.endsWith(profile.initials)
        || profile.initials.endsWith(targetProfile.initials)
      ) {
        return true;
      }
    }

    return false;
  });

  return fuzzyCandidates.length === 1 ? fuzzyCandidates[0] : null;
}

function pickUniqueImportRecord(records, usedSourceIds) {
  const available = records.filter((record) => !usedSourceIds.has(record.id));
  return available.length === 1 ? available[0] : null;
}

function assignImportSimilarityMatches(students, records, mustResolveRosterCount) {
  if (!students.length || !records.length) {
    return new Map();
  }

  const assignments = new Map();
  const usedStudentIds = new Set();
  const usedRecordIds = new Set();
  const primaryThreshold = mustResolveRosterCount ? 0.52 : 0.72;

  greedyAssignImportSimilarityMatches({
    students,
    records,
    threshold: primaryThreshold,
    assignments,
    usedStudentIds,
    usedRecordIds,
  });

  if (!mustResolveRosterCount) {
    return assignments;
  }

  const remainingStudents = students.filter((student) => !usedStudentIds.has(student.id));
  const remainingRecords = records.filter((record) => !usedRecordIds.has(record.id));
  if (!remainingStudents.length || remainingStudents.length !== remainingRecords.length) {
    return assignments;
  }

  greedyAssignImportSimilarityMatches({
    students: remainingStudents,
    records: remainingRecords,
    threshold: 0.36,
    assignments,
    usedStudentIds,
    usedRecordIds,
    allowLooseFallback: true,
  });

  return assignments;
}

function greedyAssignImportSimilarityMatches({
  students,
  records,
  threshold,
  assignments,
  usedStudentIds,
  usedRecordIds,
  allowLooseFallback = false,
}) {
  const recordById = new Map(records.map((record) => [record.id, record]));
  const pairs = [];

  students.forEach((student) => {
    records.forEach((record) => {
      const score = scoreImportRosterMatch(student, record);
      const compatible = isImportSimilarityMatchCompatible(student, record, score, allowLooseFallback);
      if (!compatible || score < threshold) {
        return;
      }

      pairs.push({
        studentId: student.id,
        recordId: record.id,
        score,
      });
    });
  });

  pairs
    .sort(
      (left, right) =>
        right.score - left.score
        || left.studentId.localeCompare(right.studentId)
        || left.recordId.localeCompare(right.recordId),
    )
    .forEach((pair) => {
      if (usedStudentIds.has(pair.studentId) || usedRecordIds.has(pair.recordId)) {
        return;
      }

      const record = recordById.get(pair.recordId);
      if (!record) {
        return;
      }

      assignments.set(pair.studentId, record);
      usedStudentIds.add(pair.studentId);
      usedRecordIds.add(pair.recordId);
    });
}

function scoreImportRosterMatch(studentRecord, sourceRecord) {
  const studentProfile = buildImportNameProfile(studentRecord.student.name);
  const recordProfile = sourceRecord.nameProfile;

  if (!studentProfile.joined || !recordProfile.joined) {
    return 0;
  }

  if (studentProfile.joined === recordProfile.joined) {
    return 1;
  }

  const fullSimilarity = calculateImportStringSimilarity(studentProfile.joined, recordProfile.joined);
  const firstSimilarity = calculateImportStringSimilarity(studentProfile.first, recordProfile.first);
  let score = Math.max(fullSimilarity, firstSimilarity * 0.96);

  if (
    studentProfile.first
    && recordProfile.first
    && (studentProfile.first.startsWith(recordProfile.first) || recordProfile.first.startsWith(studentProfile.first))
  ) {
    score = Math.max(score, 0.9);
  }

  if (
    studentProfile.joined.includes(recordProfile.joined)
    || recordProfile.joined.includes(studentProfile.joined)
  ) {
    score = Math.max(score, 0.9);
  }

  if (studentProfile.initials && recordProfile.initials) {
    if (
      studentProfile.initials === recordProfile.initials
      || studentProfile.initials.endsWith(recordProfile.initials)
      || recordProfile.initials.endsWith(studentProfile.initials)
    ) {
      score += 0.07;
    }
  }

  if (
    studentProfile.first
    && recordProfile.first
    && studentProfile.first.charAt(0) === recordProfile.first.charAt(0)
  ) {
    score += 0.02;
  }

  return Math.min(score, 1);
}

function isImportSimilarityMatchCompatible(studentRecord, sourceRecord, score, allowLooseFallback) {
  const studentProfile = buildImportNameProfile(studentRecord.student.name);
  const recordProfile = sourceRecord.nameProfile;
  const firstSimilarity = calculateImportStringSimilarity(studentProfile.first, recordProfile.first);
  const fullSimilarity = calculateImportStringSimilarity(studentProfile.joined, recordProfile.joined);

  if (score >= 0.72 && firstSimilarity >= 0.55) {
    return true;
  }

  if (
    studentProfile.first
    && recordProfile.first
    && (studentProfile.first.startsWith(recordProfile.first) || recordProfile.first.startsWith(studentProfile.first))
  ) {
    return true;
  }

  if (allowLooseFallback) {
    return fullSimilarity >= 0.36 && firstSimilarity >= 0.32;
  }

  return fullSimilarity >= 0.5 && firstSimilarity >= 0.42;
}

function buildImportNameProfile(name) {
  const tokens = String(name || "")
    .toLowerCase()
    .replaceAll(".", " ")
    .replace(/[^a-z0-9\s]+/g, " ")
    .split(/\s+/)
    .filter(Boolean);

  const first = tokens[0] || "";
  const initials = tokens.slice(1).map((token) => token.charAt(0)).join("");

  return {
    tokens,
    first,
    initials,
    joined: tokens.join(""),
    alias: first ? `${first}|${initials}` : "",
  };
}

function calculateImportStringSimilarity(left, right) {
  const source = String(left || "");
  const target = String(right || "");
  if (!source && !target) {
    return 1;
  }
  if (!source || !target) {
    return 0;
  }
  if (source === target) {
    return 1;
  }

  const maxLength = Math.max(source.length, target.length);
  if (!maxLength) {
    return 1;
  }

  return 1 - calculateImportLevenshteinDistance(source, target) / maxLength;
}

function calculateImportLevenshteinDistance(left, right) {
  const source = String(left || "");
  const target = String(right || "");
  const rows = source.length + 1;
  const cols = target.length + 1;
  const matrix = Array.from({ length: rows }, () => new Array(cols).fill(0));

  for (let row = 0; row < rows; row += 1) {
    matrix[row][0] = row;
  }

  for (let col = 0; col < cols; col += 1) {
    matrix[0][col] = col;
  }

  for (let row = 1; row < rows; row += 1) {
    for (let col = 1; col < cols; col += 1) {
      const cost = source[row - 1] === target[col - 1] ? 0 : 1;
      matrix[row][col] = Math.min(
        matrix[row - 1][col] + 1,
        matrix[row][col - 1] + 1,
        matrix[row - 1][col - 1] + cost,
      );
    }
  }

  return matrix[rows - 1][cols - 1];
}

function setMarksStatus(message, type = "") {
  if (!marksStatusEl) {
    return;
  }
  marksStatusEl.textContent = message || "";
  marksStatusEl.className = `status${type ? ` ${type}` : ""}`;
}

function createHalfYearlyRows(sourceRows) {
  return ["H1", "H2"].map((term, index) => {
    const source =
      sourceRows.find((row) => row.term === term) || sourceRows[index] || {};
    const row = { term };
    HALF_YEARLY_COLUMNS.forEach((column) => {
      row[column.key] = source[column.key] || "";
    });
    return row;
  });
}

function createStudentId() {
  return `student-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function sanitizeFilename(value) {
  return String(value || "")
    .trim()
    .replace(/[<>:"/\\|?*]+/g, "-")
    .replace(/\s+/g, "-")
    .toLowerCase();
}

function downloadTemplateWorkbook() {
  const blob = buildTemplateWorkbook();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "progress-card-template.xlsx";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function buildTemplateWorkbook() {
  const nowIso = new Date().toISOString();
  const worksheetXml = createWorksheetXml(TEMPLATE_HEADERS);
  const entries = [
    {
      name: "[Content_Types].xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>`,
    },
    {
      name: "_rels/.rels",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`,
    },
    {
      name: "docProps/app.xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>Codex</Application>
  <TitlesOfParts>
    <vt:vector size="1" baseType="lpstr">
      <vt:lpstr>Student Details</vt:lpstr>
    </vt:vector>
  </TitlesOfParts>
  <HeadingPairs>
    <vt:vector size="2" baseType="variant">
      <vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant>
      <vt:variant><vt:i4>1</vt:i4></vt:variant>
    </vt:vector>
  </HeadingPairs>
</Properties>`,
    },
    {
      name: "docProps/core.xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:creator>Codex</dc:creator>
  <cp:lastModifiedBy>Codex</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">${escapeXml(nowIso)}</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">${escapeXml(nowIso)}</dcterms:modified>
</cp:coreProperties>`,
    },
    {
      name: "xl/workbook.xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Student Details" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>`,
    },
    {
      name: "xl/_rels/workbook.xml.rels",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`,
    },
    {
      name: "xl/styles.xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><name val="Calibri"/></font>
  </fonts>
  <fills count="2">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
  </fills>
  <borders count="1">
    <border><left/><right/><top/><bottom/><diagonal/></border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="3">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
    <xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
  </cellXfs>
  <cellStyles count="1">
    <cellStyle name="Normal" xfId="0" builtinId="0"/>
  </cellStyles>
</styleSheet>`,
    },
    {
      name: "xl/worksheets/sheet1.xml",
      text: worksheetXml,
    },
  ];

  return createZipBlob(entries);
}

function createWorksheetXml(headers) {
  const colsXml = headers
    .map(
      (_, index) =>
        `<col min="${index + 1}" max="${index + 1}" width="24" customWidth="1" style="2"/>`
    )
    .join("");
  const headerRow = headers
    .map(
      (header, index) =>
        `<c r="${columnLabel(index + 1)}1" t="inlineStr" s="1"><is><t>${escapeXml(
          header
        )}</t></is></c>`
    )
    .join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheetViews>
    <sheetView workbookViewId="0">
      <pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>
      <selection pane="bottomLeft" activeCell="A2" sqref="A2"/>
    </sheetView>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="18"/>
  <cols>${colsXml}</cols>
  <sheetData>
    <row r="1">${headerRow}</row>
  </sheetData>
</worksheet>`;
}

function createZipBlob(entries) {
  const encoder = new TextEncoder();
  const encodedEntries = entries.map((entry) => ({
    nameBytes: encoder.encode(entry.name),
    data: encoder.encode(entry.text),
  }));
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  encodedEntries.forEach((entry) => {
    const crc = crc32(entry.data);
    const localHeader = new Uint8Array(30 + entry.nameBytes.length);
    const localView = new DataView(localHeader.buffer);
    localView.setUint32(0, 0x04034b50, true);
    localView.setUint16(4, 20, true);
    localView.setUint16(6, 0, true);
    localView.setUint16(8, 0, true);
    localView.setUint16(10, 0, true);
    localView.setUint16(12, 0, true);
    localView.setUint32(14, crc >>> 0, true);
    localView.setUint32(18, entry.data.length, true);
    localView.setUint32(22, entry.data.length, true);
    localView.setUint16(26, entry.nameBytes.length, true);
    localView.setUint16(28, 0, true);
    localHeader.set(entry.nameBytes, 30);
    localParts.push(localHeader, entry.data);

    const centralHeader = new Uint8Array(46 + entry.nameBytes.length);
    const centralView = new DataView(centralHeader.buffer);
    centralView.setUint32(0, 0x02014b50, true);
    centralView.setUint16(4, 20, true);
    centralView.setUint16(6, 20, true);
    centralView.setUint16(8, 0, true);
    centralView.setUint16(10, 0, true);
    centralView.setUint16(12, 0, true);
    centralView.setUint16(14, 0, true);
    centralView.setUint32(16, crc >>> 0, true);
    centralView.setUint32(20, entry.data.length, true);
    centralView.setUint32(24, entry.data.length, true);
    centralView.setUint16(28, entry.nameBytes.length, true);
    centralView.setUint16(30, 0, true);
    centralView.setUint16(32, 0, true);
    centralView.setUint16(34, 0, true);
    centralView.setUint16(36, 0, true);
    centralView.setUint32(38, 0, true);
    centralView.setUint32(42, offset, true);
    centralHeader.set(entry.nameBytes, 46);
    centralParts.push(centralHeader);

    offset += localHeader.length + entry.data.length;
  });

  const centralSize = centralParts.reduce(
    (total, chunk) => total + chunk.length,
    0
  );
  const endRecord = new Uint8Array(22);
  const endView = new DataView(endRecord.buffer);
  endView.setUint32(0, 0x06054b50, true);
  endView.setUint16(4, 0, true);
  endView.setUint16(6, 0, true);
  endView.setUint16(8, encodedEntries.length, true);
  endView.setUint16(10, encodedEntries.length, true);
  endView.setUint32(12, centralSize, true);
  endView.setUint32(16, offset, true);
  endView.setUint16(20, 0, true);

  return new Blob([...localParts, ...centralParts, endRecord], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}

function columnLabel(index) {
  let value = index;
  let label = "";
  while (value > 0) {
    const remainder = (value - 1) % 26;
    label = String.fromCharCode(65 + remainder) + label;
    value = Math.floor((value - 1) / 26);
  }
  return label;
}

function createCrc32Table() {
  const table = new Uint32Array(256);
  for (let index = 0; index < 256; index += 1) {
    let crc = index;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = crc & 1 ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1;
    }
    table[index] = crc >>> 0;
  }
  return table;
}

function crc32(bytes) {
  let crc = 0 ^ -1;
  for (let index = 0; index < bytes.length; index += 1) {
    crc = (crc >>> 8) ^ CRC32_TABLE[(crc ^ bytes[index]) & 0xff];
  }
  return (crc ^ -1) >>> 0;
}

function countTermRows(rows, startIndex) {
  const currentTerm = rows[startIndex].term;
  let count = 0;
  for (let index = startIndex; index < rows.length; index += 1) {
    if (rows[index].term !== currentTerm) {
      break;
    }
    count += 1;
  }
  return count;
}

function getStudentOptionLabel(record, index) {
  const primary = record.student.name || `Student ${index + 1}`;
  const secondary = record.student.admissionNo
    ? `Admn ${record.student.admissionNo}`
    : record.student.trade || "No admission no";
  return `${primary} - ${secondary}`;
}

function matchField(label) {
  return FIELD_ALIASES.get(normalizeText(label)) || null;
}

function matchMonth(label) {
  return MONTH_ALIASES.get(normalizeText(label)) || null;
}

function monthTermFromLabel(label) {
  const month = matchMonth(label);
  if (!month) {
    return "";
  }
  return ["Aug.", "Sept.", "Oct.", "Nov.", "Dec.", "Jan."].includes(month)
    ? "H1"
    : "H2";
}

function looksLikeHeaderNoise(cells) {
  const normalized = cells.map((cell) => normalizeText(cell));
  return normalized.some((value) =>
    [
      "month",
      "attendance",
      "possible",
      "present",
      "cumpossible",
      "cumpresent",
      "percentage",
      "monthlytests",
      "halfyearlyassessment",
      "formativeassessment100",
    ].includes(value)
  );
}

function collectValue(values) {
  return values
    .map((value) => value.trim())
    .filter(Boolean)
    .join(" ");
}

function splitRow(line) {
  if (line.includes("\t")) {
    return line.split("\t").map((cell) => cell.trim());
  }
  return line
    .split(/\s{2,}/)
    .map((cell) => cell.trim())
    .filter(Boolean);
}

function syncPhotoControls() {
  const target = getPhotoTargetStudent();
  photoScaleEl.value = target.photo.scale;
  photoXEl.value = target.photo.x;
  photoYEl.value = target.photo.y;
}

function addManualStudent() {
  const selected = getSelectedStudent();
  const record = createStudentRecord({
    student: {
      instituteName:
        selected.student.instituteName || DEFAULT_STUDENT.instituteName,
      trade: selected.student.trade || "",
      admissionDate: selected.student.admissionDate || "",
    },
  });

  state.students.push(record);
  setSelectedStudent(record.id, true);
  setStatus("Added a blank student to the imported list.", "success");
  persistAndRender();
}

function removeStudent(studentId) {
  const recordIndex = state.students.findIndex((record) => record.id === studentId);
  if (recordIndex === -1) {
    return;
  }

  const record = state.students[recordIndex];
  if (
    !window.confirm(
      `Remove ${getStudentOptionLabel(record, recordIndex)} from the student list?`
    )
  ) {
    return;
  }

  if (state.students.length === 1) {
    overwriteState(createEmptyState());
    setStatus("Removed the last student and reset the form to a blank card.", "success");
    return;
  }

  state.students = state.students.filter((item) => item.id !== studentId);
  const fallbackIndex = Math.max(0, recordIndex - 1);
  const fallback = state.students[fallbackIndex] || state.students[0];
  setSelectedStudent(fallback.id, true);
  setStatus(
    `Removed ${getStudentOptionLabel(record, recordIndex)} from the student list.`,
    "success"
  );
  persistAndRender();
}

function fitProgressPages(rootEl) {
  if (!rootEl) {
    return;
  }

  rootEl.querySelectorAll(".progress-page").forEach((page) => {
    page.classList.remove("compact", "tight");
    const content = page.querySelector(".progress-page-content");
    const table = page.querySelector(".progress-table");

    if (!content || !table) {
      return;
    }

    if (pageFits(content, table)) {
      return;
    }

    page.classList.add("compact");
    if (pageFits(content, table)) {
      return;
    }

    page.classList.add("tight");
  });
}

function pageFits(content, table) {
  const availableHeight = content.clientHeight;
  const tableHeight = table.getBoundingClientRect().height;
  return tableHeight <= availableHeight + 1;
}

function persistAndRender() {
  saveState();
  renderAll();
}

function syncAttendanceFromAttendanceState() {
  const attendanceData = loadAttendanceStateForProgressCard();
  if (!attendanceData?.months?.length) {
    return false;
  }

  const computedMonths = computeAttendanceSummariesForProgressCard(attendanceData.months);
  const assignedMonths = assignAttendanceMonthsToProgressLayout(computedMonths);
  let changed = false;

  state.students = state.students.map((record) => {
    let monthlyChanged = false;
    const nextMonthly = record.monthly.map((row, rowIndex) => {
      const attendanceMonth = assignedMonths[rowIndex] || null;
      const attendanceRow = attendanceMonth
        ? findAttendanceSummaryRowForStudent(attendanceMonth, record.student)
        : null;
      const nextValues = attendanceRow
        ? {
            possible: formatAttendanceCardValue(attendanceRow.possible),
            present: formatAttendanceCardValue(
              attendanceRow.displayPresentWithSf ?? attendanceRow.present,
            ),
            cumPossible: formatAttendanceCardValue(attendanceRow.cumulativePossible),
            cumPresent: formatAttendanceCardValue(attendanceRow.cumulativePresent),
            percentage: formatAttendanceCardPercentage(attendanceRow.monthlyPercentage),
          }
        : {
            possible: "",
            present: "",
            cumPossible: "",
            cumPresent: "",
            percentage: "",
          };

      return applyAttendanceValuesToRow(row, nextValues, () => {
        changed = true;
        monthlyChanged = true;
      });
    });

    let halfYearlyChanged = false;
    const nextHalfYearly = record.halfYearly.map((row, rowIndex) => {
      const attendanceMonth = rowIndex === 0 ? assignedMonths[5] : assignedMonths[11];
      const attendanceRow = attendanceMonth
        ? findAttendanceSummaryRowForStudent(attendanceMonth, record.student)
        : null;
      const nextValues = attendanceRow
        ? {
            possible: formatAttendanceCardValue(attendanceRow.cumulativePossible),
            present: formatAttendanceCardValue(attendanceRow.cumulativePresent),
            percentage: formatAttendanceCardPercentage(attendanceRow.cumulativePercentage),
          }
        : {
            possible: "",
            present: "",
            percentage: "",
          };

      return applyAttendanceValuesToRow(row, nextValues, () => {
        changed = true;
        halfYearlyChanged = true;
      });
    });

    if (!monthlyChanged && !halfYearlyChanged) {
      return record;
    }

    return {
      ...record,
      monthly: nextMonthly,
      halfYearly: nextHalfYearly,
    };
  });

  return changed;
}

function applyAttendanceValuesToRow(row, nextValues, onChange) {
  let rowChanged = false;
  const nextRow = { ...row };

  Object.entries(nextValues).forEach(([key, value]) => {
    const nextText = String(value || "");
    if (String(nextRow[key] || "") === nextText) {
      return;
    }

    nextRow[key] = nextText;
    rowChanged = true;
  });

  if (rowChanged) {
    onChange();
    return nextRow;
  }

  return row;
}

function loadAttendanceStateForProgressCard() {
  for (const key of ATTENDANCE_STORAGE_KEYS) {
    const raw = window.localStorage.getItem(key);
    if (!raw) {
      continue;
    }

    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed?.months)) {
        return parsed;
      }
    } catch (error) {
      console.warn(`Could not read attendance data from ${key}.`, error);
    }
  }

  return null;
}

function computeAttendanceSummariesForProgressCard(months) {
  const runningTotals = new Map();

  return [...months]
    .map((month) => normalizeAttendanceMonthForProgressCard(month))
    .filter((month) => month)
    .sort((left, right) => left.key.localeCompare(right.key))
    .map((month) => {
      const rows = month.records.map((record) => {
        const previous = runningTotals.get(record.admissionNo) ?? {
          cumulativePresent: 0,
          cumulativePossible: 0,
        };

        const present = toAttendanceNumberOrNull(record.present);
        const possible = toAttendanceNumberOrNull(record.possible);
        const sfDays = toAttendanceNumberOrNull(record.sfDays);
        const hasMonthlyInput = present != null && possible != null;
        const creditedPresent = hasMonthlyInput ? roundAttendanceHalf(present + (sfDays ?? 0)) : null;
        const cumulativePresent = hasMonthlyInput
          ? roundAttendanceHalf(previous.cumulativePresent + (creditedPresent ?? 0))
          : previous.cumulativePresent;
        const cumulativePossible = hasMonthlyInput
          ? roundAttendanceHalf(previous.cumulativePossible + possible)
          : previous.cumulativePossible;
        const monthlyPercentage = hasMonthlyInput && possible > 0
          ? roundAttendanceTwo((present / possible) * 100)
          : null;
        const cumulativePercentage = cumulativePossible > 0
          ? roundAttendanceTwo((cumulativePresent / cumulativePossible) * 100)
          : null;

        runningTotals.set(record.admissionNo, {
          cumulativePresent,
          cumulativePossible,
        });

        return {
          admissionNo: record.admissionNo,
          name: record.name,
          present,
          possible,
          sfDays,
          displayPresentWithSf:
            hasMonthlyInput && (sfDays ?? 0) > 0 ? creditedPresent : present,
          monthlyPercentage,
          cumulativePresent,
          cumulativePossible,
          cumulativePercentage,
        };
      });

      return {
        ...month,
        rows,
      };
    });
}

function normalizeAttendanceMonthForProgressCard(month) {
  const key = String(
    month?.key
      || `${String(month?.year || "").padStart(4, "0")}-${String(month?.month || "").padStart(2, "0")}`,
  ).trim();
  const [yearText, monthText] = key.split("-");
  const monthNumber = Number(month?.month ?? monthText);
  const year = Number(month?.year ?? yearText);
  if (!key || !Number.isFinite(monthNumber) || !Number.isFinite(year)) {
    return null;
  }

  const records = Array.isArray(month?.records)
    ? month.records
        .map((record) => ({
          admissionNo: String(record?.admissionNo || "").trim(),
          name: String(record?.name || "").trim(),
          present: record?.present,
          possible: record?.possible,
          sfDays: record?.sfDays,
        }))
        .filter((record) => record.admissionNo || record.name)
    : [];

  return {
    key,
    year,
    month: monthNumber,
    records,
  };
}

function assignAttendanceMonthsToProgressLayout(months) {
  const remaining = [...months];
  return MONTH_LAYOUT.map((layout) => {
    const targetToken = normalizeProgressMonthToken(layout.month);
    const matchIndex = remaining.findIndex(
      (month) => normalizeProgressMonthToken(getMonthNameForNumber(month.month)) === targetToken,
    );
    if (matchIndex === -1) {
      return null;
    }

    return remaining.splice(matchIndex, 1)[0];
  });
}

function findAttendanceSummaryRowForStudent(attendanceMonth, student) {
  const admissionKey = normalizePortalMatchToken(student.admissionNo);
  const nameKey = normalizePortalMatchToken(student.name);
  const byAdmission = new Map(
    attendanceMonth.rows.map((row) => [normalizePortalMatchToken(row.admissionNo), row]),
  );
  const byName = new Map(
    attendanceMonth.rows.map((row) => [normalizePortalMatchToken(row.name), row]),
  );

  return (
    (admissionKey ? byAdmission.get(admissionKey) : null)
    || (nameKey ? byName.get(nameKey) : null)
    || null
  );
}

function normalizeProgressMonthToken(value) {
  const normalized = String(value || "").toLowerCase().replace(/[^a-z]+/g, "");
  if (normalized.startsWith("sept")) {
    return "sep";
  }
  if (normalized.startsWith("jul")) {
    return "jul";
  }
  if (normalized.startsWith("jun")) {
    return "jun";
  }
  if (normalized.startsWith("apr")) {
    return "apr";
  }
  if (normalized.startsWith("mar")) {
    return "mar";
  }
  if (normalized.startsWith("aug")) {
    return "aug";
  }
  if (normalized.startsWith("jan")) {
    return "jan";
  }
  if (normalized.startsWith("feb")) {
    return "feb";
  }
  if (normalized.startsWith("oct")) {
    return "oct";
  }
  if (normalized.startsWith("nov")) {
    return "nov";
  }
  if (normalized.startsWith("dec")) {
    return "dec";
  }
  if (normalized.startsWith("may")) {
    return "may";
  }
  return normalized;
}

function getMonthNameForNumber(monthNumber) {
  return [
    "",
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ][Number(monthNumber) || 0] || "";
}

function toAttendanceNumberOrNull(value) {
  if (value === "" || value == null) {
    return null;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function roundAttendanceHalf(value) {
  return Math.round(Number(value || 0) * 2) / 2;
}

function roundAttendanceTwo(value) {
  return Math.round(Number(value || 0) * 100) / 100;
}

function formatAttendanceCardValue(value) {
  if (value == null || Number.isNaN(value)) {
    return "";
  }

  return Number.isInteger(value) ? String(value) : Number(value).toFixed(1).replace(/\.0$/, "");
}

function formatAttendanceCardPercentage(value) {
  if (value == null || Number.isNaN(value)) {
    return "";
  }

  return String(Math.round(value));
}

function normalizePortalMatchToken(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function setStatus(message, type) {
  pasteStatusEl.textContent = message;
  pasteStatusEl.className = `status ${type}`;
}

window.addEventListener("message", (event) => {
  if (event.data?.type !== "portal-shared-update" || event.data?.app !== PORTAL_APP_NAME) {
    return;
  }

  applyPortalSharedData(event.data.payload);
});

window.addEventListener("storage", (event) => {
  if (event.key && ATTENDANCE_STORAGE_KEYS.includes(event.key)) {
    if (!syncAttendanceFromAttendanceState()) {
      return;
    }

    saveState();
    renderAll();
    return;
  }

  if (
    event.key === NIMMI_RANKLIST_STORAGE_KEY
    || event.key === ANNEXURE_STORAGE_KEY
  ) {
    renderMonthlyEditor();
    reportPortalHeight();
    return;
  }
});

window.addEventListener("load", () => {
  if (window.parent !== window) {
    notifyPortalReady();
  }
});

window.addEventListener("resize", reportPortalHeight);

if (typeof ResizeObserver === "function") {
  const portalObserver = new ResizeObserver(() => {
    reportPortalHeight();
  });
  portalObserver.observe(document.querySelector(".app-shell") || document.body);
}

function normalizeText(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function normalizeHeaderWords(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/%/g, " percent ")
    .replace(/[._/()-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function cleanupImportHeader(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function escapeXml(value) {
  return escapeHtml(value).replaceAll("'", "&apos;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("'", "&#39;");
}

function cloneData(value) {
  return JSON.parse(JSON.stringify(value));
}
