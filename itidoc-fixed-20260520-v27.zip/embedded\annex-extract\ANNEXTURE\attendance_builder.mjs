import fs from "node:fs/promises";
import path from "node:path";
import { Workbook, SpreadsheetFile } from "@oai/artifact-tool";

const outputDir = path.resolve("outputs", "attendance-template");
const outputPath = path.join(outputDir, "attendance_percentage_template.xlsx");

const students = [
  [1, 663, "DEVANANDHA C", 0, null, null, 110, 120, null, ""],
  [2, 666, "ANAYA V K", 0, null, null, 112, 120, null, ""],
  [3, 667, "THEJA M", 0, null, null, 114, 120, null, ""],
  [4, 668, "NIYUKTHA P", 0, null, null, 105, 120, null, ""],
  [5, 669, "ALEESHA V", 0, null, null, 89.5, 120, null, ""],
  [6, 670, "SANIYA M P", 0, null, null, 101, 120, null, ""],
  [7, 672, "ABHINAND MOHANAN M", 0, null, null, 102, 120, null, ""],
  [8, 688, "RADHUL N K", 0, null, null, 118, 120, null, ""],
  [9, 699, "AMAYA T P", 0, null, null, 115, 120, null, ""],
  [10, 701, "SHYAM RAJ P", 0, null, null, 98.25, 120, null, ""],
  [11, 716, "SHARON N", 0, null, null, 98, 120, null, ""],
  [12, 717, "SACHIN M", 0, null, null, 99, 120, null, ""],
  [13, 736, "RWETHISHEK K", 0, null, null, 84, 120, null, ""],
  [14, 769, "DEVADHARSH M", 0, null, null, 118, 120, null, ""],
  [15, 770, "AKASH A P", 0, null, null, 99, 120, null, ""],
  [16, 785, "SREENANDU N", 0, null, null, 105.5, 120, null, ""],
  [17, 791, "AYUSH BABU", 0, null, null, 110, 120, null, ""],
  [18, 792, "SURYA THEJ A K", 0, null, null, 108.5, 120, null, ""],
];

const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Attendance");

sheet.getRange("A1:J1").merge();
sheet.getRange("A1").values = [["ATTENDANCE PERCENTAGE REGISTER"]];
sheet.getRange("A2:J2").merge();
sheet.getRange("A2").values = [[
  "Fill SF, Present, Possible, Cumulative Present and Cumulative Possible. Percentage and red highlighting update automatically.",
]];

sheet.getRange("A4:J4").values = [[
  "SL",
  "ADM NO",
  "NAME",
  "SF (DAYS)",
  "PRESENT",
  "POSSIBLE",
  "CUMULATIVE PRESENT",
  "CUMULATIVE POSSIBLE",
  "PERCENTAGE",
  "REMARKS",
]];

sheet.getRange(`A5:J${4 + students.length}`).values = students;

for (let row = 5; row < 5 + students.length; row += 1) {
  sheet.getRange(`I${row}`).formulas = [[`=IF(OR(G${row}="",H${row}="",H${row}=0),"",G${row}/H${row})`]];
  sheet.getRange(`J${row}`).formulas = [[`=IF(I${row}="","",IF(I${row}<0.8,"Below 80%","80% and above"))`]];
}

sheet.getRange("A1:J1").format = {
  font: { bold: true, size: 16, color: "#FFFFFF" },
  fill: "#1F4E78",
  horizontalAlignment: "center",
  verticalAlignment: "center",
};

sheet.getRange("A2:J2").format = {
  font: { italic: true, color: "#404040", size: 10 },
  fill: "#EAF3F8",
  horizontalAlignment: "center",
  verticalAlignment: "center",
  wrapText: true,
};

sheet.getRange("A4:J4").format = {
  font: { bold: true, color: "#FFFFFF" },
  fill: "#2F75B5",
  horizontalAlignment: "center",
  verticalAlignment: "center",
  wrapText: true,
};

sheet.getRange(`A5:J${4 + students.length}`).format = {
  verticalAlignment: "center",
  borders: { preset: "outside", style: "thin", color: "#A6A6A6" },
};
sheet.getRange(`A5:J${4 + students.length}`).format.borders = {
  preset: "insideHorizontal",
  style: "thin",
  color: "#D9D9D9",
};
sheet.getRange(`A5:J${4 + students.length}`).format.borders.getItem("EdgeLeft").style = "thin";
sheet.getRange(`A5:J${4 + students.length}`).format.borders.getItem("EdgeLeft").color = "#A6A6A6";
sheet.getRange(`A5:J${4 + students.length}`).format.borders.getItem("EdgeRight").style = "thin";
sheet.getRange(`A5:J${4 + students.length}`).format.borders.getItem("EdgeRight").color = "#A6A6A6";
sheet.getRange(`A5:J${4 + students.length}`).format.borders.getItem("EdgeTop").style = "thin";
sheet.getRange(`A5:J${4 + students.length}`).format.borders.getItem("EdgeTop").color = "#A6A6A6";
sheet.getRange(`A5:J${4 + students.length}`).format.borders.getItem("EdgeBottom").style = "thin";
sheet.getRange(`A5:J${4 + students.length}`).format.borders.getItem("EdgeBottom").color = "#A6A6A6";

sheet.getRange(`A5:B${4 + students.length}`).format = {
  horizontalAlignment: "center",
  verticalAlignment: "center",
};

sheet.getRange(`D5:I${4 + students.length}`).format.numberFormat = "0.00";
sheet.getRange(`I5:I${4 + students.length}`).format.numberFormat = "0.00%";

sheet
  .getRange(`A5:J${4 + students.length}`)
  .conditionalFormats.addExpression('=AND($I5<>"",$I5<0.8)', {
    fill: "#FFC7CE",
    font: { color: "#9C0006", bold: true },
  });

sheet
  .getRange(`I5:I${4 + students.length}`)
  .conditionalFormats.addExpression('=AND(I5<>"",I5>=0.8)', {
    fill: "#C6EFCE",
    font: { color: "#006100", bold: true },
  });

sheet.getRange("A1:J22").format.autofitColumns();
sheet.getRange("A1:J22").format.autofitRows();
sheet.freezePanes.freezeRows(4);

await fs.mkdir(outputDir, { recursive: true });
const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(outputPath);

const inspection = await workbook.inspect({
  kind: "table",
  range: "Attendance!A4:J12",
  include: "values,formulas",
  tableMaxRows: 9,
  tableMaxCols: 10,
});

console.log(JSON.stringify({ outputPath, inspection: inspection.ndjson }, null, 2));
