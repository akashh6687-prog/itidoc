const STORAGE_KEY = "iti-planner-workspace-v1";
const PORTAL_APP_NAME = "planner";
const DEFAULT_TRADE_VALUE = "D/CIVIL  2025-27    ( JUNIORS )  (II nd Shift)";
const DEFAULT_MONTH_VALUE = "2026-02";
const DEFAULT_HOST_TAB = "monthly";
const EMPTY_DIARY_ENTRY = Object.freeze({
  skillText: "",
  knowledgeFirstText: "",
  knowledgeSecondText: "",
  isLeave: false,
  isSaturdayWorking: false,
  leaveType: "full",
  leaveReason: "",
});

document.documentElement.classList.toggle("is-embedded", window.parent !== window);
document.body.classList.toggle("is-embedded", window.parent !== window);

function createEmptyMonthRecord() {
  return {
    skillData: "",
    knowledgeData: "",
    overrides: [],
    diaryEntries: {},
  };
}

function createEmptyPortalMeta() {
  return {
    institution: "",
    tradeNameLong: "",
    tradeNameShort: "",
    session: "",
    shift: "",
    unit: "",
  };
}

function normalizePortalMeta(value) {
  return {
    institution: String(value?.institution || "").trim(),
    tradeNameLong: String(value?.tradeNameLong || "").trim(),
    tradeNameShort: String(value?.tradeNameShort || "").trim(),
    session: String(value?.session || "").trim(),
    shift: String(value?.shift || "").trim(),
    unit: String(value?.unit || "").trim(),
  };
}

function buildPortalTradeValue(payload, fallbackValue = DEFAULT_TRADE_VALUE) {
  return String(
    payload?.tradeNameLong
    ?? payload?.tradeLong
    ?? payload?.tradeName
    ?? payload?.tradeValue
    ?? fallbackValue
  ).trim();
}

function createInitialState() {
  return {
    tradeValue: DEFAULT_TRADE_VALUE,
    monthValue: DEFAULT_MONTH_VALUE,
    hostTab: DEFAULT_HOST_TAB,
    portalMeta: createEmptyPortalMeta(),
    monthRecords: {
      [DEFAULT_MONTH_VALUE]: createEmptyMonthRecord(),
    },
  };
}

const elements = {
  monthInput: document.getElementById("monthInput"),
  diaryMonthInput: document.getElementById("diaryMonthInput"),
  overrideDate: document.getElementById("overrideDate"),
  overrideType: document.getElementById("overrideType"),
  overrideLabel: document.getElementById("overrideLabel"),
  addOverrideButton: document.getElementById("addOverrideButton"),
  overrideList: document.getElementById("overrideList"),
  skillDataInput: document.getElementById("skillDataInput"),
  knowledgeDataInput: document.getElementById("knowledgeDataInput"),
  renderButton: document.getElementById("renderButton"),
  downloadExcelButton: document.getElementById("downloadExcelButton"),
  printButton: document.getElementById("printButton"),
  resetButton: document.getElementById("resetButton"),
  statsPanel: document.getElementById("statsPanel"),
  tradeHeadingText: document.getElementById("tradeHeadingText"),
  monthHeadingText: document.getElementById("monthHeadingText"),
  planBody: document.getElementById("planBody"),
  planPage: document.getElementById("planPage"),
  planSheet: document.querySelector(".plan-sheet"),
  planTable: document.querySelector(".plan-table"),
  tradeBand: document.querySelector(".plan-band--trade"),
  monthBand: document.querySelector(".plan-band--month"),
  signatureStrip: document.querySelector(".signature-strip"),
  exportStatus: document.getElementById("exportStatus"),
  monthlyHostPanel: document.getElementById("monthlyHostPanel"),
  diaryHostPanel: document.getElementById("diaryHostPanel"),
  coachingHostPanel: document.getElementById("coachingHostPanel"),
  programPlannerFrame: document.getElementById("programPlannerFrame"),
  diaryBody: document.getElementById("diaryBody"),
  diarySkillOptions: document.getElementById("diarySkillOptions"),
  diaryKnowledgeOptions: document.getElementById("diaryKnowledgeOptions"),
  hostTabs: [...document.querySelectorAll("[data-host-tab]")],
};

let state = loadState();
let currentPlan = null;
const CRC32_TABLE = createCrc32Table();
const XLSX_STYLE_IDS = {
  trade: 1,
  month: 2,
  header: 3,
  date: 4,
  job: 5,
  skill: 6,
  lesson: 7,
  knowledge: 8,
  leave: 9,
  exam: 10,
  noteBlue: 11,
  noteDark: 12,
  blank: 13,
  signature: 14,
};

bootstrap();

function bootstrap() {
  getCurrentMonthRecord();
  syncFormWithState();
  bindEvents();
  bindHostEvents();
  bindPrintEvents();
  syncOverrideDateOptions();
  updateHostPanels();
  renderEverything();
}

function bindEvents() {
  [
    elements.skillDataInput,
    elements.knowledgeDataInput,
  ].filter(Boolean).forEach((field) => {
    field.addEventListener("input", handleFormChange);
  });

  [elements.monthInput, elements.diaryMonthInput]
    .filter(Boolean)
    .forEach((field) => {
      field.addEventListener("change", () => {
        handleMonthChange(field.value);
        syncOverrideDateOptions();
        renderOverrideList();
      });
    });

  elements.diaryBody?.addEventListener("input", (event) => {
    const target = event.target;
    if (
      !(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement)
      || !target.dataset.diaryField
      || !target.dataset.diaryDate
    ) {
      return;
    }

    updateDiaryEntry(target.dataset.diaryDate, {
      [target.dataset.diaryField]: target.value,
    });
    persistState();
    if (target.dataset.diaryField === "leaveReason") {
      syncDiaryLeaveReasonTitle(target);
      return;
    }
    syncPlannerWithMonthlyPlan();
  });

  elements.diaryBody?.addEventListener("change", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement) || !target.dataset.diaryDate) {
      return;
    }

    if (target instanceof HTMLInputElement && target.dataset.diaryLeave === "true") {
      updateDiaryEntry(target.dataset.diaryDate, { isLeave: target.checked });
      persistState();
      renderEverything();
      return;
    }

    if (target instanceof HTMLSelectElement && target.dataset.diaryField) {
      updateDiaryEntry(target.dataset.diaryDate, {
        [target.dataset.diaryField]: target.value,
      });
      persistState();
      renderEverything();
    }
  });

  elements.renderButton.addEventListener("click", renderEverything);
  elements.downloadExcelButton.addEventListener("click", downloadExcelWorkbook);
  elements.printButton.addEventListener("click", () => {
    renderEverything();
    setStatus("Browser print opened with print-color styling enabled.");
    window.print();
  });

  elements.resetButton.addEventListener("click", () => {
    const confirmed = window.confirm("Reset all inputs and remove saved data for this planner?");
    if (!confirmed) {
      return;
    }

    state = createInitialState();
    persistState();
    syncFormWithState();
    syncOverrideDateOptions();
    clearStatus();
    renderEverything();
  });

  elements.addOverrideButton.addEventListener("click", addOrUpdateOverride);

  elements.overrideList.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-date]");
    if (!button) {
      return;
    }

    const monthRecord = getCurrentMonthRecord();
    monthRecord.overrides = monthRecord.overrides.filter((override) => override.date !== button.dataset.date);
    persistState();
    renderEverything();
  });

}

function bindHostEvents() {
  elements.hostTabs.forEach((button) => {
    button.addEventListener("click", () => {
      setActiveHostTab(button.dataset.hostTab);
    });
  });

  if (elements.programPlannerFrame) {
    elements.programPlannerFrame.addEventListener("load", () => {
      syncPlannerWithMonthlyPlan();
    });
  }
}

function bindPrintEvents() {
  const syncPrintLayout = (isPrinting) => {
    document.body.classList.toggle("is-print-preview", isPrinting);
    renderEverything();
  };

  window.addEventListener("beforeprint", () => {
    syncPrintLayout(true);
    window.requestAnimationFrame(() => renderEverything());
  });

  window.addEventListener("afterprint", () => {
    syncPrintLayout(false);
  });

  if (!window.matchMedia) {
    return;
  }

  const printMedia = window.matchMedia("print");
  const handlePrintMediaChange = (event) => {
    syncPrintLayout(event.matches);
  };

  if (typeof printMedia.addEventListener === "function") {
    printMedia.addEventListener("change", handlePrintMediaChange);
  } else if (typeof printMedia.addListener === "function") {
    printMedia.addListener(handlePrintMediaChange);
  }
}

function handleFormChange() {
  syncCurrentFormIntoMonthRecord();

  persistState();
  renderEverything();
}

function handleMonthChange(nextMonthValue = elements.monthInput.value) {
  syncCurrentFormIntoMonthRecord(state.monthValue);
  state.monthValue = nextMonthValue || DEFAULT_MONTH_VALUE;
  getCurrentMonthRecord();
  persistState();
  syncFormWithState();
  clearStatus();
  renderEverything();
}

function syncFormWithState() {
  const monthRecord = getCurrentMonthRecord();
  elements.monthInput.value = state.monthValue;
  if (elements.diaryMonthInput) {
    elements.diaryMonthInput.value = state.monthValue;
  }
  elements.skillDataInput.value = monthRecord.skillData;
  elements.knowledgeDataInput.value = monthRecord.knowledgeData;
}

function syncOverrideDateOptions() {
  const dates = getMonthDates(state.monthValue);
  const selectedValue = elements.overrideDate.value;
  elements.overrideDate.replaceChildren();

  dates.forEach((date) => {
    const option = document.createElement("option");
    option.value = formatIsoDate(date);
    option.textContent = formatDisplayDate(date);
    elements.overrideDate.append(option);
  });

  if (!dates.length) {
    return;
  }

  const fallback = formatIsoDate(dates[0]);
  elements.overrideDate.value = dates.some((date) => formatIsoDate(date) === selectedValue)
    ? selectedValue
    : fallback;
}

function addOrUpdateOverride() {
  const monthRecord = getCurrentMonthRecord();
  const date = elements.overrideDate.value;
  const type = elements.overrideType.value;
  const label = elements.overrideLabel.value.trim();

  if (!date || !label) {
    window.alert("Choose a date and enter the row text first.");
    return;
  }

  const nextOverride = { date, type, label };
  const existingIndex = monthRecord.overrides.findIndex((override) => override.date === date);

  if (existingIndex >= 0) {
    monthRecord.overrides.splice(existingIndex, 1, nextOverride);
  } else {
    monthRecord.overrides.push(nextOverride);
  }

  monthRecord.overrides.sort((left, right) => left.date.localeCompare(right.date));
  elements.overrideLabel.value = "";

  persistState();
  renderEverything();
}

function renderEverything() {
  const schedule = buildSchedule();
  currentPlan = buildViewModel(schedule);
  renderHeadings(currentPlan);
  renderPlanRows(currentPlan.rows);
  renderDiaryPanel(currentPlan.rows);
  renderStats(currentPlan.meta);
  renderOverrideList();
  applySizing(currentPlan.meta.totalDays);
  syncPlannerWithMonthlyPlan();
}

function buildViewModel(schedule) {
  const tradeValue = (state.tradeValue || DEFAULT_TRADE_VALUE).trim();
  return {
    tradeValue,
    monthValue: state.monthValue,
    tradeHeadingText: `TRADE : ${tradeValue}`,
    monthHeadingText: formatMonthHeading(state.monthValue),
    rows: schedule.rows,
    meta: schedule.meta,
  };
}

function renderHeadings(viewModel) {
  elements.tradeHeadingText.textContent = viewModel.tradeHeadingText;
  elements.monthHeadingText.textContent = viewModel.monthHeadingText;
  document.title = viewModel.monthHeadingText;
}

function renderPlanRows(rows) {
  elements.planBody.replaceChildren();

  rows.forEach((row) => {
    const tr = document.createElement("tr");
    tr.append(createCell(row.dateLabel, "date-cell"));

    if (row.type === "work") {
      tr.append(createCell(row.jobNo));
      tr.append(createCell(row.professionalSkill));
      tr.append(createCell(row.lessonNo));
      tr.append(createCell(row.professionalKnowledge));
    } else if (row.type === "blank") {
      tr.append(createCell(""));
      tr.append(createCell(""));
      tr.append(createCell(""));
      tr.append(createCell(""));
    } else {
      tr.append(createCell(row.label, `merged-cell merged-cell--${row.type}`, 4));
    }

    elements.planBody.append(tr);
  });
}

function renderStats(meta) {
  elements.statsPanel.replaceChildren();

  const chips = [
    { text: `${meta.totalDays} calendar days` },
    { text: `${meta.weekendDays} weekend rows` },
    { text: `${meta.overrideCount} custom day rows` },
    { text: `${meta.importedItems} imported lesson rows` },
    { text: `${meta.scheduledItems} lesson rows placed` },
    { text: `${meta.examRows} exam rows` },
    { text: "Using Excel paste" },
  ];

  if (meta.unscheduledItems > 0) {
    chips.push({
      text: `${meta.unscheduledItems} lesson rows left outside the month`,
      className: "stat-chip--warning",
    });
  }

  if (meta.unplacedExamGroup) {
    chips.push({
      text: `EXAM LO ${meta.unplacedExamGroup} could not be placed`,
      className: "stat-chip--warning",
    });
  }

  if (meta.importedItems === 0) {
    chips.push({
      text: "Paste Excel data to fill working days",
      className: "stat-chip--warning",
    });
  }

  chips.forEach((chip) => {
    const item = document.createElement("div");
    item.className = ["stat-chip", chip.className].filter(Boolean).join(" ");
    item.textContent = chip.text;
    elements.statsPanel.append(item);
  });
}

function renderOverrideList() {
  const currentMonthOverrides = getCurrentMonthRecord().overrides;
  elements.overrideList.replaceChildren();

  if (!currentMonthOverrides.length) {
    const empty = document.createElement("div");
    empty.className = "stat-chip";
    empty.textContent = "No custom overrides added for this month.";
    elements.overrideList.append(empty);
    return;
  }

  currentMonthOverrides.forEach((override) => {
    const chip = document.createElement("div");
    chip.className = "override-chip";

    const typeLabel = {
      leave: "Leave",
      "note-blue": "Blue",
      "note-dark": "Dark blue",
    }[override.type];

    const label = document.createElement("span");
    label.textContent = `${formatDisplayDate(parseIsoDate(override.date))} | ${typeLabel} | ${override.label}`;

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.dataset.date = override.date;
    removeButton.setAttribute("aria-label", `Remove override for ${override.date}`);
    removeButton.textContent = "x";

    chip.append(label, removeButton);
    elements.overrideList.append(chip);
  });
}

function renderDiaryPanel(rows) {
  if (!elements.diaryBody) {
    return;
  }

  renderDiaryOptionLists(rows);
  const monthRecord = getCurrentMonthRecord();
  elements.diaryBody.innerHTML = rows
    .map((row) => renderDiaryRow(row, getDiaryEntry(row.isoDate, monthRecord)))
    .join("");
}

function renderDiaryRow(row, entry) {
  const dayText = getDayLabel(row.isoDate);
  const leaveContext = getDiaryLeaveContext(row, entry);

  if (leaveContext.mode === "off") {
    return `
      <tr class="diary-row is-off">
        <td><div class="diary-date-text">${escapeHtml(row.dateLabel)}</div></td>
        <td class="diary-state-cell" colspan="3">
          <div class="diary-state-banner">
            <div>
              <div class="diary-state-title">${escapeHtml(leaveContext.title)}</div>
              ${leaveContext.note ? `<div class="diary-state-note">${escapeHtml(leaveContext.note)}</div>` : ""}
            </div>
          </div>
        </td>
        <td><div class="diary-day-text">${escapeHtml(dayText)}</div></td>
        <td><div class="diary-auto-tag">${escapeHtml(dayText)}</div></td>
      </tr>
    `;
  }

  if (leaveContext.mode === "planned-leave") {
    return `
      <tr class="diary-row is-leave is-auto-leave">
        <td><div class="diary-date-text">${escapeHtml(row.dateLabel)}</div></td>
        <td class="diary-state-cell" colspan="3">
          <div class="diary-state-banner">
            <div>
              <div class="diary-state-title ${leaveContext.isReasonTitle ? "diary-state-title--reason" : ""}">${escapeHtml(leaveContext.title)}</div>
              ${leaveContext.note ? `<div class="diary-state-note">${escapeHtml(leaveContext.note)}</div>` : ""}
            </div>
            <div class="diary-auto-tag">From Monthly Plan</div>
          </div>
        </td>
        <td><div class="diary-day-text">${escapeHtml(dayText)}</div></td>
        <td><div class="diary-auto-tag">Auto</div></td>
      </tr>
    `;
  }

  if (leaveContext.mode === "manual-leave") {
    return `
      <tr class="diary-row is-leave">
        <td><div class="diary-date-text">${escapeHtml(row.dateLabel)}</div></td>
        <td class="diary-state-cell" colspan="3">
          <div class="diary-state-banner diary-state-banner--stack">
            <div>
              <div class="diary-state-title ${leaveContext.isReasonTitle ? "diary-state-title--reason" : ""}">${escapeHtml(leaveContext.title)}</div>
              ${leaveContext.note ? `<div class="diary-state-note">${escapeHtml(leaveContext.note)}</div>` : ""}
            </div>
            <div class="diary-leave-form">
              <label class="diary-reason-field">
                <span>Reason</span>
                <input
                  type="text"
                  value="${escapeHtml(entry.leaveReason)}"
                  placeholder="Enter reason for leave"
                  data-diary-date="${escapeHtml(row.isoDate)}"
                  data-diary-field="leaveReason"
                >
              </label>
              <label class="diary-reason-field diary-reason-field--type">
                <span>Type</span>
                <select data-diary-date="${escapeHtml(row.isoDate)}" data-diary-field="leaveType">
                  <option value="full" ${entry.leaveType === "half" ? "" : "selected"}>Full day leave</option>
                  <option value="half" ${entry.leaveType === "half" ? "selected" : ""}>Half day leave</option>
                </select>
              </label>
            </div>
          </div>
        </td>
        <td><div class="diary-day-text">${escapeHtml(dayText)}</div></td>
        <td>
          <label class="diary-toggle-label diary-toggle-label--compact">
            <input
              type="checkbox"
              checked
              data-diary-date="${escapeHtml(row.isoDate)}"
              data-diary-leave="true"
            >
            <span>Leave</span>
          </label>
        </td>
      </tr>
    `;
  }

  return `
    <tr class="diary-row">
      <td><div class="diary-date-text">${escapeHtml(row.dateLabel)}</div></td>
      <td>
        <div class="diary-entry-cell">
          <input
            class="diary-entry-input"
            type="text"
            list="diarySkillOptions"
            value="${escapeHtml(entry.skillText)}"
            placeholder="Select or type skill taken"
            data-diary-date="${escapeHtml(row.isoDate)}"
            data-diary-field="skillText"
          >
        </div>
      </td>
      <td>
        <div class="diary-entry-cell">
          <input
            class="diary-entry-input"
            type="text"
            list="diaryKnowledgeOptions"
            value="${escapeHtml(entry.knowledgeFirstText)}"
            placeholder="Select or type 1st period topic"
            data-diary-date="${escapeHtml(row.isoDate)}"
            data-diary-field="knowledgeFirstText"
          >
        </div>
      </td>
      <td>
        <div class="diary-entry-cell">
          <input
            class="diary-entry-input"
            type="text"
            list="diaryKnowledgeOptions"
            value="${escapeHtml(entry.knowledgeSecondText)}"
            placeholder="Select or type 2nd period topic"
            data-diary-date="${escapeHtml(row.isoDate)}"
            data-diary-field="knowledgeSecondText"
          >
        </div>
      </td>
      <td><div class="diary-day-text">${escapeHtml(dayText)}</div></td>
      <td>
        <label class="diary-toggle-label diary-toggle-label--compact">
          <input
            type="checkbox"
            data-diary-date="${escapeHtml(row.isoDate)}"
            data-diary-leave="true"
          >
          <span>Leave</span>
        </label>
      </td>
    </tr>
  `;
}

function renderDiaryOptionLists(rows) {
  const optionLists = buildDiaryOptionLists(rows);
  if (elements.diarySkillOptions) {
    elements.diarySkillOptions.innerHTML = optionLists.skillOptions
      .map((value) => `<option value="${escapeHtml(value)}"></option>`)
      .join("");
  }
  if (elements.diaryKnowledgeOptions) {
    elements.diaryKnowledgeOptions.innerHTML = optionLists.knowledgeOptions
      .map((value) => `<option value="${escapeHtml(value)}"></option>`)
      .join("");
  }
}

function buildDiaryOptionLists(rows) {
  const skillOptions = [];
  const knowledgeOptions = [];
  const skillSeen = new Set();
  const knowledgeSeen = new Set();

  rows.forEach((row) => {
    if (row.type !== "work") {
      return;
    }

    pushDiaryOption(skillOptions, skillSeen, row.jobNo, row.professionalSkill);
    pushDiaryOption(knowledgeOptions, knowledgeSeen, row.lessonNo, row.professionalKnowledge);
  });

  appendExtraDiaryOptions(skillOptions, skillSeen, "skill", 4);
  appendExtraDiaryOptions(knowledgeOptions, knowledgeSeen, "knowledge", 4);

  return { skillOptions, knowledgeOptions };
}

function appendExtraDiaryOptions(options, seen, sectionKey, limit = 4) {
  let extraCount = 0;
  const pushExtra = (code, label) => {
    if (extraCount >= limit) {
      return;
    }
    const added = pushDiaryOption(options, seen, code, label);
    if (added) {
      extraCount += 1;
    }
  };

  getImportedItems(getCurrentMonthRecord()).items.forEach((item) => {
    if (sectionKey === "skill") {
      pushExtra(item.jobNo, item.professionalSkill);
      return;
    }
    pushExtra(item.lessonNo, item.professionalKnowledge);
  });

  if (extraCount >= limit) {
    return;
  }

  Object.keys(state.monthRecords || {})
    .sort()
    .filter((monthValue) => monthValue > state.monthValue)
    .forEach((monthValue) => {
      if (extraCount >= limit) {
        return;
      }

      getImportedItems(getMonthRecord(monthValue)).items.forEach((item) => {
        if (extraCount >= limit) {
          return;
        }

        if (sectionKey === "skill") {
          pushExtra(item.jobNo, item.professionalSkill);
          return;
        }
        pushExtra(item.lessonNo, item.professionalKnowledge);
      });
    });
}

function pushDiaryOption(options, seen, code, label) {
  const value = formatDiaryOptionValue(code, label);
  if (!value || seen.has(value)) {
    return false;
  }

  seen.add(value);
  options.push(value);
  return true;
}

function formatDiaryOptionValue(code, label) {
  const safeCode = String(code || "").trim();
  const safeLabel = String(label || "").trim();
  return [safeCode, safeLabel].filter(Boolean).join(" ").trim();
}

function getDiaryLeaveContext(row, entry) {
  if (isWeekendDate(row.isoDate)) {
    const dayLabel = getDayLabel(row.isoDate);
    return {
      mode: "off",
      title: dayLabel,
      note: "",
      isReasonTitle: false,
    };
  }

  if (row.type === "leave") {
    return {
      mode: "planned-leave",
      title: String(row.label || "LEAVE").trim() || "LEAVE",
      note: "This leave comes from the Monthly Plan tab.",
      isReasonTitle: false,
    };
  }

  if (entry.isLeave) {
    const leaveReason = String(entry.leaveReason || "").trim();
    const leaveType = getDiaryLeaveTypeLabel(entry.leaveType);
    return {
      mode: "manual-leave",
      title: leaveReason || `${leaveType} leave`,
      note: leaveReason ? `${leaveType} leave marked in the diary.` : "",
      isReasonTitle: Boolean(leaveReason),
    };
  }

  return { mode: "normal", isReasonTitle: false };
}

function syncDiaryLeaveReasonTitle(target) {
  const row = target.closest(".diary-row");
  const title = row?.querySelector(".diary-state-title");
  if (!(title instanceof HTMLElement)) {
    return;
  }

  const text = String(target.value || "").trim();
  const leaveTypeField = row?.querySelector('select[data-diary-field="leaveType"]');
  const leaveType = getDiaryLeaveTypeLabel(leaveTypeField instanceof HTMLSelectElement ? leaveTypeField.value : "full");
  title.textContent = text || `${leaveType} leave`;
  title.classList.toggle("diary-state-title--reason", Boolean(text));
}

function getDiaryLeaveTypeLabel(value) {
  return String(value || "").trim().toLowerCase() === "half" ? "Half day" : "Full day";
}

function getDiaryPlannedNote(row, sectionKey) {
  if (row.type === "work") {
    if (sectionKey === "skill") {
      return buildDiaryPlannedText(row.jobNo, row.professionalSkill);
    }
    return buildDiaryPlannedText(row.lessonNo, row.professionalKnowledge);
  }

  if (row.type === "blank") {
    return "";
  }

  return row.label || "";
}

function buildDiaryPlannedText(code, label) {
  const left = String(code || "").trim();
  const right = String(label || "").trim();
  if (left && right) {
    return `Planned: ${left} | ${right}`;
  }
  if (left) {
    return `Planned: ${left}`;
  }
  if (right) {
    return `Planned: ${right}`;
  }
  return "";
}

function getDayLabel(isoDate) {
  const date = parseIsoDate(isoDate);
  return date.toLocaleString("en-US", { weekday: "long", timeZone: "UTC" });
}

function isWeekendDate(isoDate) {
  return Boolean(getWeekendLabel(parseIsoDate(isoDate)));
}

function getDiaryEntry(isoDate, monthRecord = getCurrentMonthRecord()) {
  return monthRecord.diaryEntries[isoDate] || EMPTY_DIARY_ENTRY;
}

function applySizing(totalDays) {
  const sizing = getBaseSizing(totalDays);
  applySizingValues(sizing);
  fitPlanToPage(sizing);
}

function setStatus(message, type = "") {
  elements.exportStatus.className = `export-status ${type === "error" ? "is-error" : ""} ${type === "success" ? "is-success" : ""}`.trim();
  elements.exportStatus.textContent = message;
}

function clearStatus() {
  elements.exportStatus.className = "export-status";
  elements.exportStatus.textContent = "";
}

function getBaseSizing(totalDays) {
  return {
    rowHeightMm: 209 / Math.max(totalDays, 1),
    cellFontSize:
      totalDays >= 31 ? 11.35 :
      totalDays >= 30 ? 11.7 :
      totalDays >= 29 ? 12.3 : 13.1,
    bandFontSize:
      totalDays >= 31 ? 12.9 :
      totalDays >= 30 ? 13.2 : 13.8,
    bodyLineHeight:
      totalDays >= 31 ? 1.04 :
      totalDays >= 30 ? 1.06 :
      totalDays >= 29 ? 1.08 : 1.1,
    bodyPaddingRem:
      totalDays >= 31 ? 0.08 :
      totalDays >= 30 ? 0.095 :
      totalDays >= 29 ? 0.11 : 0.125,
    signatureHeightMm:
      totalDays >= 31 ? 24.2 :
      totalDays >= 30 ? 24.8 : 25.7,
  };
}

function applySizingValues(sizing) {
  elements.planPage.style.setProperty("--body-row-height", `${sizing.rowHeightMm.toFixed(3)}mm`);
  elements.planPage.style.setProperty("--cell-font-size", `${sizing.cellFontSize.toFixed(2)}px`);
  elements.planPage.style.setProperty("--band-font-size", `${sizing.bandFontSize.toFixed(2)}px`);
  elements.planPage.style.setProperty("--body-line-height", sizing.bodyLineHeight.toFixed(3));
  elements.planPage.style.setProperty("--body-cell-padding-y", `${sizing.bodyPaddingRem.toFixed(3)}rem`);
  elements.planPage.style.setProperty("--signature-height", `${sizing.signatureHeightMm.toFixed(3)}mm`);
}

function fitPlanToPage(baseSizing) {
  if (!elements.planSheet || !elements.planTable || !elements.tradeBand || !elements.monthBand || !elements.signatureStrip) {
    return;
  }

  const availableHeight = elements.planSheet.clientHeight;

  if (!Number.isFinite(availableHeight) || availableHeight <= 0) {
    return;
  }

  const sizing = { ...baseSizing };
  const isPrintMode = isPrintPreviewActive();
  const printSafetyPx = isPrintMode ? 22 : 0.5;
  const maxIterations = isPrintMode ? 52 : 28;
  const lockedSignatureHeight = baseSizing.signatureHeightMm;

  for (let iteration = 0; iteration < maxIterations; iteration += 1) {
    const contentHeight =
      elements.tradeBand.getBoundingClientRect().height
      + elements.monthBand.getBoundingClientRect().height
      + elements.planTable.getBoundingClientRect().height
      + elements.signatureStrip.getBoundingClientRect().height;

    if (contentHeight <= availableHeight - printSafetyPx) {
      return;
    }

    sizing.rowHeightMm = Math.max(sizing.rowHeightMm - (isPrintMode ? 0.16 : 0.14), 5.2);
    sizing.cellFontSize = Math.max(sizing.cellFontSize - (isPrintMode ? 0.1 : 0.09), 9.45);
    sizing.bandFontSize = Math.max(sizing.bandFontSize - 0.05, 11.75);
    sizing.bodyLineHeight = Math.max(sizing.bodyLineHeight - (isPrintMode ? 0.02 : 0.018), 0.93);
    sizing.bodyPaddingRem = Math.max(sizing.bodyPaddingRem - (isPrintMode ? 0.009 : 0.008), 0.015);
    sizing.signatureHeightMm = isPrintMode
      ? lockedSignatureHeight
      : Math.max(sizing.signatureHeightMm - 0.26, 20.5);

    applySizingValues(sizing);
  }
}

function isPrintPreviewActive() {
  return document.body.classList.contains("is-print-preview")
    || (typeof window.matchMedia === "function" && window.matchMedia("print").matches);
}

function downloadExcelWorkbook() {
  renderEverything();

  try {
    const workbookBlob = buildMonthlyPlanWorkbookBlob(currentPlan);
    const fileName = `${sanitizeFileName(currentPlan?.monthHeadingText || "MONTHLY PLAN")}.xlsx`;
    downloadBlob(workbookBlob, fileName);
    setStatus(`Excel file downloaded as ${fileName}.`, "success");
  } catch (error) {
    console.error(error);
    setStatus("Excel download failed in the browser. Please try again.", "error");
  }
}

function buildMonthlyPlanWorkbookBlob(viewModel) {
  const files = [
    { name: "[Content_Types].xml", data: createContentTypesXml() },
    { name: "_rels/.rels", data: createRootRelationshipsXml() },
    { name: "xl/workbook.xml", data: createWorkbookXml() },
    { name: "xl/_rels/workbook.xml.rels", data: createWorkbookRelationshipsXml() },
    { name: "xl/styles.xml", data: createStylesXml() },
    { name: "xl/worksheets/sheet1.xml", data: createWorksheetXml(viewModel) },
  ];

  return createZipBlob(
    files,
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  );
}

function createWorksheetXml(viewModel) {
  const rowsXml = [];
  const mergeRefs = ["A1:E1", "A2:E2"];
  const totalDays = Math.max(viewModel?.meta?.totalDays || 0, 1);
  const bodyRowHeightPt = clampNumber((209 / totalDays) * 2.834645669, 17, 22);

  rowsXml.push(createRowXml(1, 23, [
    createInlineStringCell("A1", viewModel.tradeHeadingText, XLSX_STYLE_IDS.trade),
  ]));

  rowsXml.push(createRowXml(2, 27, [
    createInlineStringCell("A2", viewModel.monthHeadingText, XLSX_STYLE_IDS.month),
  ]));

  rowsXml.push(createRowXml(3, 26, [
    createInlineStringCell("A3", "DATE", XLSX_STYLE_IDS.header),
    createInlineStringCell("B3", "JOB\nNO.", XLSX_STYLE_IDS.header),
    createInlineStringCell("C3", "PROFESSIONAL SKILL", XLSX_STYLE_IDS.header),
    createInlineStringCell("D3", "LESSON\nNO.", XLSX_STYLE_IDS.header),
    createInlineStringCell("E3", "PROFESSIONAL KNOWLEDGE", XLSX_STYLE_IDS.header),
  ]));

  let rowIndex = 4;

  viewModel.rows.forEach((row) => {
    if (row.type === "work") {
      rowsXml.push(createRowXml(rowIndex, bodyRowHeightPt, [
        createInlineStringCell(`A${rowIndex}`, row.dateLabel, XLSX_STYLE_IDS.date),
        createInlineStringCell(`B${rowIndex}`, row.jobNo, XLSX_STYLE_IDS.job),
        createInlineStringCell(`C${rowIndex}`, row.professionalSkill, XLSX_STYLE_IDS.skill),
        createInlineStringCell(`D${rowIndex}`, row.lessonNo, XLSX_STYLE_IDS.lesson),
        createInlineStringCell(`E${rowIndex}`, row.professionalKnowledge, XLSX_STYLE_IDS.knowledge),
      ]));
    } else if (row.type === "blank") {
      rowsXml.push(createRowXml(rowIndex, bodyRowHeightPt, [
        createInlineStringCell(`A${rowIndex}`, row.dateLabel, XLSX_STYLE_IDS.date),
        createEmptyCell(`B${rowIndex}`, XLSX_STYLE_IDS.blank),
        createEmptyCell(`C${rowIndex}`, XLSX_STYLE_IDS.blank),
        createEmptyCell(`D${rowIndex}`, XLSX_STYLE_IDS.blank),
        createEmptyCell(`E${rowIndex}`, XLSX_STYLE_IDS.blank),
      ]));
    } else {
      mergeRefs.push(`B${rowIndex}:E${rowIndex}`);
      rowsXml.push(createRowXml(rowIndex, bodyRowHeightPt, [
        createInlineStringCell(`A${rowIndex}`, row.dateLabel, XLSX_STYLE_IDS.date),
        createInlineStringCell(`B${rowIndex}`, row.label, getMergedRowStyleId(row.type)),
      ]));
    }

    rowIndex += 1;
  });

  rowsXml.push(createRowXml(rowIndex, 14, [
    createEmptyCell(`A${rowIndex}`, XLSX_STYLE_IDS.blank),
    createEmptyCell(`B${rowIndex}`, XLSX_STYLE_IDS.blank),
    createEmptyCell(`C${rowIndex}`, XLSX_STYLE_IDS.blank),
    createEmptyCell(`D${rowIndex}`, XLSX_STYLE_IDS.blank),
    createEmptyCell(`E${rowIndex}`, XLSX_STYLE_IDS.blank),
  ]));
  rowIndex += 1;

  mergeRefs.push(`A${rowIndex}:B${rowIndex}`, `C${rowIndex}:D${rowIndex}`);
  rowsXml.push(createRowXml(rowIndex, 26, [
    createInlineStringCell(`A${rowIndex}`, "INSTRUCTOR", XLSX_STYLE_IDS.signature),
    createInlineStringCell(`C${rowIndex}`, "GROUP INSTRUCTOR", XLSX_STYLE_IDS.signature),
    createInlineStringCell(`E${rowIndex}`, "PRINCIPAL", XLSX_STYLE_IDS.signature),
  ]));

  const lastRow = rowIndex;
  const mergesXml = mergeRefs.length
    ? `<mergeCells count="${mergeRefs.length}">${mergeRefs.map((ref) => `<mergeCell ref="${ref}"/>`).join("")}</mergeCells>`
    : "";

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <dimension ref="A1:E${lastRow}"/>
  <sheetViews>
    <sheetView workbookViewId="0">
      <pane ySplit="3" topLeftCell="A4" activePane="bottomLeft" state="frozen"/>
      <selection pane="bottomLeft" activeCell="A4" sqref="A4"/>
    </sheetView>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="15"/>
  <cols>
    <col min="1" max="1" width="12.5" customWidth="1"/>
    <col min="2" max="2" width="9.5" customWidth="1"/>
    <col min="3" max="3" width="34" customWidth="1"/>
    <col min="4" max="4" width="10.5" customWidth="1"/>
    <col min="5" max="5" width="36" customWidth="1"/>
  </cols>
  <sheetData>${rowsXml.join("")}</sheetData>
  ${mergesXml}
  <pageMargins left="0.25" right="0.25" top="0.35" bottom="0.35" header="0.2" footer="0.2"/>
  <pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="0"/>
</worksheet>`;
}

function createContentTypesXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`;
}

function createRootRelationshipsXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;
}

function createWorkbookXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <bookViews>
    <workbookView xWindow="0" yWindow="0" windowWidth="24000" windowHeight="12840"/>
  </bookViews>
  <sheets>
    <sheet name="Monthly Plan" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>`;
}

function createWorkbookRelationshipsXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;
}

function createStylesXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font>
      <sz val="11"/>
      <name val="Arial"/>
      <family val="2"/>
    </font>
    <font>
      <b/>
      <sz val="11"/>
      <name val="Arial"/>
      <family val="2"/>
    </font>
  </fonts>
  <fills count="8">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFDCE8F5"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFF7C9A7"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFD8E7D0"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFF9FA4"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFB7C9EA"/><bgColor indexed="64"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF92B6DB"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border>
      <left/>
      <right/>
      <top/>
      <bottom/>
      <diagonal/>
    </border>
    <border>
      <left style="thin"><color rgb="FF303030"/></left>
      <right style="thin"><color rgb="FF303030"/></right>
      <top style="thin"><color rgb="FF303030"/></top>
      <bottom style="thin"><color rgb="FF303030"/></bottom>
      <diagonal/>
    </border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="15">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="1" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
  </cellXfs>
  <cellStyles count="1">
    <cellStyle name="Normal" xfId="0" builtinId="0"/>
  </cellStyles>
</styleSheet>`;
}

function createZipBlob(files, mimeType) {
  const encoder = new TextEncoder();
  const zipParts = [];
  const centralDirectoryParts = [];
  let offset = 0;

  files.forEach((file) => {
    const nameBytes = encoder.encode(file.name);
    const dataBytes = typeof file.data === "string" ? encoder.encode(file.data) : file.data;
    const checksum = crc32(dataBytes);
    const { dosDate, dosTime } = getZipDateParts(new Date());

    const localHeader = new Uint8Array(30 + nameBytes.length);
    const localView = new DataView(localHeader.buffer);
    localView.setUint32(0, 0x04034b50, true);
    localView.setUint16(4, 20, true);
    localView.setUint16(6, 0, true);
    localView.setUint16(8, 0, true);
    localView.setUint16(10, dosTime, true);
    localView.setUint16(12, dosDate, true);
    localView.setUint32(14, checksum, true);
    localView.setUint32(18, dataBytes.length, true);
    localView.setUint32(22, dataBytes.length, true);
    localView.setUint16(26, nameBytes.length, true);
    localView.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const centralView = new DataView(centralHeader.buffer);
    centralView.setUint32(0, 0x02014b50, true);
    centralView.setUint16(4, 20, true);
    centralView.setUint16(6, 20, true);
    centralView.setUint16(8, 0, true);
    centralView.setUint16(10, 0, true);
    centralView.setUint16(12, dosTime, true);
    centralView.setUint16(14, dosDate, true);
    centralView.setUint32(16, checksum, true);
    centralView.setUint32(20, dataBytes.length, true);
    centralView.setUint32(24, dataBytes.length, true);
    centralView.setUint16(28, nameBytes.length, true);
    centralView.setUint16(30, 0, true);
    centralView.setUint16(32, 0, true);
    centralView.setUint16(34, 0, true);
    centralView.setUint16(36, 0, true);
    centralView.setUint32(38, 0, true);
    centralView.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    zipParts.push(localHeader, dataBytes);
    centralDirectoryParts.push(centralHeader);
    offset += localHeader.length + dataBytes.length;
  });

  const centralDirectorySize = centralDirectoryParts.reduce((total, part) => total + part.length, 0);
  const endRecord = new Uint8Array(22);
  const endView = new DataView(endRecord.buffer);
  endView.setUint32(0, 0x06054b50, true);
  endView.setUint16(4, 0, true);
  endView.setUint16(6, 0, true);
  endView.setUint16(8, files.length, true);
  endView.setUint16(10, files.length, true);
  endView.setUint32(12, centralDirectorySize, true);
  endView.setUint32(16, offset, true);
  endView.setUint16(20, 0, true);

  return new Blob([...zipParts, ...centralDirectoryParts, endRecord], { type: mimeType });
}

function createRowXml(rowNumber, heightPt, cells) {
  const height = Number.isFinite(heightPt) ? ` ht="${heightPt.toFixed(2)}" customHeight="1"` : "";
  return `<row r="${rowNumber}"${height}>${cells.join("")}</row>`;
}

function createInlineStringCell(cellRef, text, styleId) {
  return `<c r="${cellRef}" s="${styleId}" t="inlineStr"><is><t xml:space="preserve">${escapeXml(text || "")}</t></is></c>`;
}

function createEmptyCell(cellRef, styleId) {
  return `<c r="${cellRef}" s="${styleId}"/>`;
}

function getMergedRowStyleId(type) {
  if (type === "leave") {
    return XLSX_STYLE_IDS.leave;
  }
  if (type === "exam") {
    return XLSX_STYLE_IDS.exam;
  }
  if (type === "note-dark") {
    return XLSX_STYLE_IDS.noteDark;
  }
  return XLSX_STYLE_IDS.noteBlue;
}

function sanitizeFileName(value) {
  const cleaned = String(value || "MONTHLY PLAN")
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);

  return cleaned || "MONTHLY PLAN";
}

function downloadBlob(blob, fileName) {
  const link = document.createElement("a");
  const objectUrl = URL.createObjectURL(blob);

  link.href = objectUrl;
  link.download = fileName;
  link.style.display = "none";
  document.body.append(link);
  link.click();

  window.setTimeout(() => {
    link.remove();
    URL.revokeObjectURL(objectUrl);
  }, 1200);
}

function escapeXml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function clampNumber(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function getZipDateParts(date) {
  const safeYear = Math.max(date.getFullYear(), 1980);
  const dosTime =
    (date.getHours() << 11)
    | (date.getMinutes() << 5)
    | Math.floor(date.getSeconds() / 2);
  const dosDate =
    ((safeYear - 1980) << 9)
    | ((date.getMonth() + 1) << 5)
    | date.getDate();

  return { dosDate, dosTime };
}

function createCrc32Table() {
  const table = new Uint32Array(256);

  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) {
      value = (value & 1) ? (0xedb88320 ^ (value >>> 1)) : (value >>> 1);
    }
    table[index] = value >>> 0;
  }

  return table;
}

function crc32(bytes) {
  let crc = 0xffffffff;

  for (let index = 0; index < bytes.length; index += 1) {
    crc = CRC32_TABLE[(crc ^ bytes[index]) & 0xff] ^ (crc >>> 8);
  }

  return (crc ^ 0xffffffff) >>> 0;
}

function buildSchedule(monthValue = state.monthValue, monthRecord = getMonthRecord(monthValue)) {
  const dates = getMonthDates(monthValue);
  const overrideMap = new Map(
    monthRecord.overrides
      .filter((override) => override.date.startsWith(`${monthValue}-`))
      .map((override) => [override.date, override]),
  );

  const imported = getImportedItems(monthRecord);
  const rows = [];
  let dataIndex = 0;
  let pendingExamGroup = "";
  let examRows = 0;
  let weekendDays = 0;

  dates.forEach((date) => {
    const isoDate = formatIsoDate(date);
    const override = overrideMap.get(isoDate);
    const weekendLabel = getWeekendLabel(date);

    if (override) {
      rows.push({
        type: override.type,
        isoDate,
        dateLabel: formatDisplayDate(date),
        label: override.type === "leave" ? override.label.toUpperCase() : override.label,
      });
      return;
    }

    if (weekendLabel) {
      weekendDays += 1;
      rows.push({
        type: "leave",
        isoDate,
        dateLabel: formatDisplayDate(date),
        label: weekendLabel,
      });
      return;
    }

    if (pendingExamGroup) {
      examRows += 1;
      rows.push({
        type: "exam",
        isoDate,
        dateLabel: formatDisplayDate(date),
        label: `EXAM LO ${pendingExamGroup}`,
      });
      pendingExamGroup = "";
      return;
    }

    const item = imported.items[dataIndex];

    if (!item) {
      rows.push({
        type: "blank",
        isoDate,
        dateLabel: formatDisplayDate(date),
      });
      return;
    }

    rows.push({
      type: "work",
      isoDate,
      dateLabel: formatDisplayDate(date),
      jobNo: item.jobNo,
      professionalSkill: item.professionalSkill,
      lessonNo: item.lessonNo,
      professionalKnowledge: item.professionalKnowledge,
    });

    const currentGroup = extractJobGroup(item.jobNo);
    const nextItem = imported.items[dataIndex + 1];
    const nextGroup = nextItem ? extractJobGroup(nextItem.jobNo) : "";

    if (currentGroup && nextGroup && currentGroup !== nextGroup) {
      pendingExamGroup = currentGroup;
    }

    dataIndex += 1;
  });

  return {
    rows,
    meta: {
      totalDays: dates.length,
      weekendDays,
      overrideCount: overrideMap.size,
      importedItems: imported.items.length,
      scheduledItems: dataIndex,
      unscheduledItems: Math.max(imported.items.length - dataIndex, 0),
      examRows,
      unplacedExamGroup: pendingExamGroup,
      dataSource: imported.source,
    },
  };
}

function getImportedItems(monthRecord = getCurrentMonthRecord()) {
  const skillRows = parseTwoColumnRows(monthRecord.skillData, "JOB NO", "PROFESSIONAL SKILL");
  const knowledgeRows = parseTwoColumnRows(monthRecord.knowledgeData, "LESSON NO", "PROFESSIONAL KNOWLEDGE");
  const length = Math.max(skillRows.length, knowledgeRows.length);

  const items = Array.from({ length }, (_, index) => ({
    jobNo: skillRows[index]?.left ?? "",
    professionalSkill: skillRows[index]?.right ?? "",
    lessonNo: knowledgeRows[index]?.left ?? "",
    professionalKnowledge: knowledgeRows[index]?.right ?? "",
  })).filter((row) => Object.values(row).some((value) => value.trim() !== ""));

  return { source: "split", items };
}

function parseTwoColumnRows(text, firstHeader, secondHeader) {
  const lines = toUsefulLines(text);
  const rows = [];

  lines.forEach((line) => {
    const parts = splitColumns(line);
    if (parts.length < 2) {
      return;
    }

    const left = cleanCell(parts[0]);
    const right = cleanCell(parts.slice(1).join(" "));

    if (looksLikeHeader(`${left} ${right}`, firstHeader, secondHeader)) {
      return;
    }

    rows.push({ left, right });
  });

  return rows;
}

function splitColumns(line) {
  if (line.includes("\t")) {
    return line.split("\t");
  }

  return line.split(/\s{2,}/);
}

function looksLikeHeader(text, firstHeader, secondHeader) {
  const normalized = text.replace(/\./g, "").replace(/\s+/g, " ").trim().toUpperCase();
  return normalized.includes(firstHeader.replace(/\./g, "").toUpperCase())
    && normalized.includes(secondHeader.replace(/\./g, "").toUpperCase());
}

function toUsefulLines(text) {
  return text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function cleanCell(value) {
  return value.replace(/^"(.*)"$/, "$1").replace(/\s+/g, " ").trim();
}

function getMonthDates(monthValue) {
  const [yearText, monthText] = monthValue.split("-");
  const year = Number(yearText);
  const monthIndex = Number(monthText) - 1;

  if (!Number.isFinite(year) || !Number.isFinite(monthIndex)) {
    return [];
  }

  const dayCount = new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
  return Array.from({ length: dayCount }, (_, index) => new Date(Date.UTC(year, monthIndex, index + 1)));
}

function formatMonthHeading(monthValue) {
  const dates = getMonthDates(monthValue);
  if (!dates.length) {
    return "MONTHLY PLAN";
  }

  const date = dates[0];
  const monthName = date.toLocaleString("en-US", { month: "long", timeZone: "UTC" }).toUpperCase();
  const year = date.getUTCFullYear();
  return `MONTHLY PLAN - ${monthName} -${year}`;
}

function formatDisplayDate(date) {
  const day = String(date.getUTCDate()).padStart(2, "0");
  const month = String(date.getUTCMonth() + 1).padStart(2, "0");
  const year = date.getUTCFullYear();
  return `${day}-${month}-${year}`;
}

function formatIsoDate(date) {
  return [
    date.getUTCFullYear(),
    String(date.getUTCMonth() + 1).padStart(2, "0"),
    String(date.getUTCDate()).padStart(2, "0"),
  ].join("-");
}

function parseIsoDate(value) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day));
}

function getWeekendLabel(date) {
  const day = date.getUTCDay();
  if (day === 0) {
    return "SUNDAY";
  }
  if (day === 6) {
    return "SATURDAY";
  }
  return "";
}

function extractJobGroup(jobNo) {
  const match = String(jobNo || "").trim().match(/^([0-9]+)/);
  return match ? match[1] : "";
}

function createCell(text, className = "", colSpan = 1) {
  const td = document.createElement("td");
  td.textContent = text || "";
  if (className) {
    td.className = className;
  }
  if (colSpan > 1) {
    td.colSpan = colSpan;
  }
  return td;
}

function persistState() {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function loadState() {
  try {
    const saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || "null");
    if (!saved || typeof saved !== "object") {
      return createInitialState();
    }

    const next = {
      ...createInitialState(),
      tradeValue: String(saved.tradeValue || DEFAULT_TRADE_VALUE),
      monthValue: String(saved.monthValue || DEFAULT_MONTH_VALUE),
      hostTab: ["monthly", "diary", "coaching"].includes(saved.hostTab) ? saved.hostTab : DEFAULT_HOST_TAB,
      portalMeta: normalizePortalMeta(saved.portalMeta),
      monthRecords: {},
    };

    if (saved.monthRecords && typeof saved.monthRecords === "object") {
      Object.entries(saved.monthRecords).forEach(([monthValue, monthRecord]) => {
        next.monthRecords[monthValue] = normalizeMonthRecord(monthRecord);
      });
    }

    if (
      typeof saved.skillData === "string"
      || typeof saved.knowledgeData === "string"
      || Array.isArray(saved.overrides)
    ) {
      next.monthRecords[next.monthValue] = normalizeMonthRecord({
        ...next.monthRecords[next.monthValue],
        skillData: saved.skillData ?? next.monthRecords[next.monthValue]?.skillData,
        knowledgeData: saved.knowledgeData ?? next.monthRecords[next.monthValue]?.knowledgeData,
        overrides: Array.isArray(saved.overrides)
          ? saved.overrides
          : next.monthRecords[next.monthValue]?.overrides,
      });
    }

    if (!next.monthRecords[next.monthValue]) {
      next.monthRecords[next.monthValue] = createEmptyMonthRecord();
    }

    return next;
  } catch {
    return createInitialState();
  }
}

function applyPortalSharedData(payload) {
  if (!payload || typeof payload !== "object") {
    return;
  }

  state.tradeValue = buildPortalTradeValue(payload, state.tradeValue);
  state.portalMeta = normalizePortalMeta({
    institution: payload.itiName ?? payload.institution,
    tradeNameLong: payload.tradeNameLong ?? payload.tradeLong ?? payload.tradeName,
    tradeNameShort: payload.tradeNameShort ?? payload.tradeShort ?? payload.tradeName,
    session: payload.session ?? payload.academicSpan,
    shift: payload.shift ?? payload.shiftLabel,
    unit: payload.unit,
  });

  persistState();
  syncFormWithState();
  syncOverrideDateOptions();
  renderEverything();
  lockPortalManagedFields();
  notifyPortalApplied();
}

function lockPortalManagedFields() {
}

function notifyPortalReady() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage({ type: "portal:ready", app: PORTAL_APP_NAME }, "*");
  reportPortalHeight();
}

function notifyPortalApplied() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:applied", app: PORTAL_APP_NAME, height: getPortalHeight() },
    "*",
  );
}

function reportPortalHeight() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:height", app: PORTAL_APP_NAME, height: getPortalHeight() },
    "*",
  );
}

function getPortalHeight() {
  const shell = document.querySelector(".portal-shell");
  const bodyStyles = window.getComputedStyle(document.body);
  const bodyMargins =
    (Number.parseFloat(bodyStyles.marginTop) || 0)
    + (Number.parseFloat(bodyStyles.marginBottom) || 0);
  const contentHeight = shell
    ? Math.max(shell.scrollHeight || 0, shell.offsetHeight || 0)
    : Math.max(
      document.documentElement?.scrollHeight || 0,
      document.body?.scrollHeight || 0,
      document.documentElement?.offsetHeight || 0,
      document.body?.offsetHeight || 0,
    );

  return contentHeight + bodyMargins;
}

window.addEventListener("message", (event) => {
  if (event.data?.type === "program-planner:ready") {
    setPlannerFrameHeight(event.data.height);
    syncPlannerWithMonthlyPlan();
    return;
  }

  if (event.data?.type === "program-planner:height") {
    setPlannerFrameHeight(event.data.height);
    return;
  }

  if (event.data?.type !== "portal-shared-update" || event.data?.app !== PORTAL_APP_NAME) {
    return;
  }

  applyPortalSharedData(event.data.payload);
});

window.addEventListener("load", () => {
  if (window.parent !== window) {
    lockPortalManagedFields();
    notifyPortalReady();
  }
});

window.addEventListener("resize", reportPortalHeight);

if (typeof ResizeObserver === "function") {
  const portalObserver = new ResizeObserver(() => {
    reportPortalHeight();
  });
  portalObserver.observe(document.querySelector(".portal-shell") || document.body);
}

function normalizeMonthRecord(monthRecord) {
  const next = monthRecord && typeof monthRecord === "object"
    ? monthRecord
    : createEmptyMonthRecord();

  next.skillData = String(next.skillData || "");
  next.knowledgeData = String(next.knowledgeData || "");
  next.overrides = Array.isArray(next.overrides)
    ? next.overrides
      .filter((override) => override && typeof override === "object")
      .map((override) => ({
        date: String(override.date || ""),
        type: String(override.type || "leave"),
        label: String(override.label || ""),
      }))
      .filter((override) => override.date && override.label)
      .sort((left, right) => left.date.localeCompare(right.date))
    : [];
  next.diaryEntries = normalizeDiaryEntries(next.diaryEntries);

  return next;
}

function normalizeDiaryEntries(entries) {
  if (!entries || typeof entries !== "object") {
    return {};
  }

  const next = {};
  Object.entries(entries).forEach(([isoDate, entry]) => {
    if (!isoDate || !entry || typeof entry !== "object") {
      return;
    }

    const normalizedEntry = {
      skillText: String(entry.skillText || "").trim(),
      knowledgeFirstText: String(entry.knowledgeFirstText || entry.knowledgeText || "").trim(),
      knowledgeSecondText: String(entry.knowledgeSecondText || "").trim(),
      isLeave: Boolean(entry.isLeave),
      leaveType: String(entry.leaveType || "full").trim().toLowerCase() === "half" ? "half" : "full",
      leaveReason: String(entry.leaveReason || "").trim(),
    };

    if (
      !normalizedEntry.skillText
      && !normalizedEntry.knowledgeFirstText
      && !normalizedEntry.knowledgeSecondText
      && !normalizedEntry.isLeave
    ) {
      return;
    }

    next[String(isoDate)] = normalizedEntry;
  });

  return next;
}

function updateDiaryEntry(isoDate, patch) {
  const monthRecord = getCurrentMonthRecord();
  const current = {
    ...EMPTY_DIARY_ENTRY,
    ...(monthRecord.diaryEntries[isoDate] || {}),
  };
  const next = {
    ...current,
    ...patch,
  };

  next.skillText = String(next.skillText || "").trim();
  next.knowledgeFirstText = String(next.knowledgeFirstText || next.knowledgeText || "").trim();
  next.knowledgeSecondText = String(next.knowledgeSecondText || "").trim();
  next.isLeave = Boolean(next.isLeave);
  next.leaveType = String(next.leaveType || "full").trim().toLowerCase() === "half" ? "half" : "full";
  next.leaveReason = String(next.leaveReason || "").trim();

  if (next.isLeave) {
    next.skillText = "";
    next.knowledgeFirstText = "";
    next.knowledgeSecondText = "";
  } else {
    next.leaveType = "full";
    next.leaveReason = "";
  }

  delete next.knowledgeText;

  if (!next.skillText && !next.knowledgeFirstText && !next.knowledgeSecondText && !next.isLeave) {
    delete monthRecord.diaryEntries[isoDate];
    return;
  }

  monthRecord.diaryEntries[isoDate] = next;
}

function getMonthRecord(monthValue = state.monthValue) {
  const safeMonthValue = monthValue || DEFAULT_MONTH_VALUE;
  if (!state.monthRecords || typeof state.monthRecords !== "object") {
    state.monthRecords = {};
  }

  if (!state.monthRecords[safeMonthValue]) {
    state.monthRecords[safeMonthValue] = createEmptyMonthRecord();
  }

  state.monthRecords[safeMonthValue] = normalizeMonthRecord(state.monthRecords[safeMonthValue]);
  return state.monthRecords[safeMonthValue];
}

function getCurrentMonthRecord() {
  return getMonthRecord(state.monthValue);
}

function syncCurrentFormIntoMonthRecord(monthValue = state.monthValue) {
  const monthRecord = getMonthRecord(monthValue);
  monthRecord.skillData = elements.skillDataInput.value;
  monthRecord.knowledgeData = elements.knowledgeDataInput.value;
  return monthRecord;
}

function setActiveHostTab(hostTab) {
  state.hostTab = ["monthly", "diary", "coaching"].includes(hostTab) ? hostTab : DEFAULT_HOST_TAB;
  persistState();
  updateHostPanels();

  if (state.hostTab === "coaching") {
    syncPlannerWithMonthlyPlan();
  }
}

function updateHostPanels() {
  const activeHostTab = ["monthly", "diary", "coaching"].includes(state.hostTab) ? state.hostTab : DEFAULT_HOST_TAB;

  elements.monthlyHostPanel?.classList.toggle("is-hidden", activeHostTab !== "monthly");
  elements.diaryHostPanel?.classList.toggle("is-hidden", activeHostTab !== "diary");
  elements.coachingHostPanel?.classList.toggle("is-hidden", activeHostTab !== "coaching");
  elements.hostTabs.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.hostTab === activeHostTab);
  });
}

function syncPlannerWithMonthlyPlan() {
  if (!elements.programPlannerFrame?.contentWindow) {
    return;
  }

  elements.programPlannerFrame.contentWindow.postMessage(
    {
      type: "monthly-plan-sync",
      app: "program-planner",
      payload: buildPlannerSyncPayload(),
    },
    "*",
  );
}

function buildPlannerSyncPayload() {
  const months = {};

  Object.entries(state.monthRecords || {})
    .sort(([leftMonth], [rightMonth]) => leftMonth.localeCompare(rightMonth))
    .forEach(([monthValue, monthRecord]) => {
      const monthKey = getPreviewMonthKeyFromMonthValue(monthValue);
      if (!monthKey) {
        return;
      }

      const schedule = buildSchedule(monthValue, normalizeMonthRecord(monthRecord));
      const proposedDates = collectProposedDates(schedule.rows);
      const conductedDates = collectDiaryConductedDates(monthRecord.diaryEntries, schedule.rows);
      const hasData =
        Object.values(proposedDates).some((section) => Object.keys(section).length > 0)
        || Object.values(conductedDates).some((section) => Object.keys(section).length > 0);

      if (!hasData && monthValue !== state.monthValue) {
        return;
      }

      months[monthValue] = {
        monthKey,
        proposedDates,
        conductedDates,
      };
    });

  return {
    currentMonthValue: state.monthValue,
    currentMonthKey: getPreviewMonthKeyFromMonthValue(state.monthValue),
    monthHeadingText: formatMonthHeading(state.monthValue),
    tradeValue: String(state.tradeValue || DEFAULT_TRADE_VALUE).trim(),
    institution: String(state.portalMeta?.institution || "").trim(),
    tradeNameShort: String(state.portalMeta?.tradeNameShort || "").trim(),
    session: String(state.portalMeta?.session || "").trim(),
    shift: String(state.portalMeta?.shift || "").trim(),
    unit: String(state.portalMeta?.unit || "").trim(),
    months,
  };
}

function collectProposedDates(rows) {
  const proposedDates = {
    skill: {},
    theory: {},
    skillAssessments: {},
  };

  rows.forEach((row) => {
    if (!row?.isoDate) {
      return;
    }

    if (row.type === "work") {
      const skillCode = normalizePlannerCode(row.jobNo);
      const theoryCode = normalizePlannerCode(row.lessonNo);

      if (skillCode && !proposedDates.skill[skillCode]) {
        proposedDates.skill[skillCode] = row.isoDate;
      }
      if (theoryCode && !proposedDates.theory[theoryCode]) {
        proposedDates.theory[theoryCode] = row.isoDate;
      }
      return;
    }

    if (row.type === "exam") {
      const assessmentCode = extractAssessmentCode(row.label);
      if (assessmentCode && !proposedDates.skillAssessments[assessmentCode]) {
        proposedDates.skillAssessments[assessmentCode] = row.isoDate;
      }
    }
  });

  return proposedDates;
}

function collectDiaryConductedDates(diaryEntries, scheduleRows = []) {
  const conductedDates = {
    skill: {},
    theory: {},
  };
  const blockedDates = new Set(
    scheduleRows
      .filter((row) => row && (isWeekendDate(row.isoDate) || row.type === "leave"))
      .map((row) => row.isoDate),
  );

  Object.entries(normalizeDiaryEntries(diaryEntries))
    .sort(([leftDate], [rightDate]) => leftDate.localeCompare(rightDate))
    .forEach(([isoDate, entry]) => {
      if (entry.isLeave || blockedDates.has(isoDate)) {
        return;
      }

      extractSkillDiaryCodes(entry.skillText).forEach((code) => {
        assignFirstConductedDate(conductedDates.skill, code, isoDate);
      });

      [entry.knowledgeFirstText, entry.knowledgeSecondText].forEach((knowledgeText) => {
        extractTheoryDiaryCodes(knowledgeText).forEach((code) => {
          assignFirstConductedDate(conductedDates.theory, code, isoDate);
        });
      });
    });

  return conductedDates;
}

function assignFirstConductedDate(bucket, code, isoDate) {
  if (!code || bucket[code]) {
    return;
  }

  bucket[code] = isoDate;
}

function normalizePlannerCode(value) {
  return String(value || "").trim();
}

function extractAssessmentCode(label) {
  const match = String(label || "").match(/EXAM LO\s+(.+)$/i);
  return match ? match[1].trim() : "";
}

function extractSkillDiaryCodes(text) {
  const codes = extractDiaryCodes(text);
  const normalized = new Set();

  codes.forEach((code) => {
    normalized.add(code);

    const parts = code.split(".");
    if (parts.length > 2) {
      normalized.add(parts.slice(0, 2).join("."));
    }
  });

  return [...normalized];
}

function extractTheoryDiaryCodes(text) {
  return extractDiaryCodes(text);
}

function extractDiaryCodes(text) {
  const matches = String(text || "").match(/\b\d+(?:\.\d+)+\b/g);
  return matches ? [...new Set(matches.map((value) => value.trim()))] : [];
}

function getPreviewMonthKeyFromMonthValue(monthValue) {
  const dates = getMonthDates(monthValue);
  if (!dates.length) {
    return "";
  }

  return dates[0].toLocaleString("en-US", { month: "long", timeZone: "UTC" }).toUpperCase();
}

function setPlannerFrameHeight(height) {
  if (!elements.programPlannerFrame) {
    return;
  }

  const safeHeight = Math.max(Number(height) || 0, 420);
  elements.programPlannerFrame.style.height = `${safeHeight}px`;
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
