const STORAGE_KEY = "iti-unified-portal-shared-v1";
const TAB_KEY = "iti-unified-portal-active-tab-v1";
const DEFAULT_PROGRESS_CHART_TITLE = "TRAINEES PROGRESS & ATTENDANCE CHART";
const PROGRESS_CARD_STORAGE_KEY = "iti-progress-card-state-v2";
const BACKUP_FORMAT = "iti-doc-portal-backup";
const BACKUP_VERSION = 1;
const BACKUP_KEY_PREFIXES = [
  "iti-unified-portal-",
  "pc-progress-chart-",
  "iti-progress-card-",
  "attendance-tracker-",
  "annex-ii-site-",
  "iti-planner-",
  "iti-miscellaneous-",
  "program-of-coaching-entry-",
  "program-of-coaching-planner-",
];

const DEFAULT_ROSTER_LINES = [
  "837/25 | ABHIJITH K J | JANEESH K M",
  "822/25 | ADISH U P | PAVITHRAN U P",
  "797/25 | ANUNANDANA C V | SURESH BABU C V",
  "853/25 | DEVANANDA.K.V | ANILKUMAR K V",
  "833/25 | DEVAPRIYA M K | AJITH KUMAR.M.K",
  "794/25 | DEVIKA M | SMIJITH M",
  "809/25 | DHARSANA P | VIJESH P",
  "813/25 | DIYA RAJEEVAN M T K | RAJEEVAN M T K",
  "795/25 | GOPIKA C M | RADHAKRISHNAN",
  "814/25 | GOPIKA.T.P | SREENIVASAN T P",
  "897/25 | MOHAMMED MISHAL K P | BASHEER M",
  "801/25 | NAJAH ABOOBACKER V K | ABOOBACKER.V.K",
  "851/25 | NAVATHEJ.K.P | SUKUMARAN.K.P",
  "796/25 | NIDHIYA T M | SUDHEER T M",
  "887/25 | RITHIN CHANDRAN | CHANDRAN P",
  "831/25 | SHARON P K | P K PRASHOB",
  "808/25 | SIVAPRIYA E | CHANDRAN E",
  "857/25 | SRAVAN MANU | MANOHARAN K V",
  "810/25 | SREE LAKSHMI K P | ANILKUMAR A P",
  "805/25 | VISHNU C K | UTHAMAN C K",
  "811/25 | VISMAYA T | SURESH BABU T",
];

const SHARED_STUDENT_FIELDS = [
  { key: "instituteName", label: "Institute Name" },
  { key: "trade", label: "Trade" },
  { key: "admissionNo", label: "Admission No" },
  { key: "admissionDate", label: "Date of Admission" },
  { key: "aadhaarNo", label: "Aadhaar No" },
  { key: "misRegNo", label: "MIS Reg. No." },
  { key: "qualification", label: "Educational Qualification" },
  { key: "traineePhone", label: "Trainee Phone" },
  { key: "guardianName", label: "Guardian Name" },
  { key: "guardianPhone", label: "Guardian Phone" },
  { key: "address", label: "Address", wide: true },
];

const STUDENT_TEMPLATE_HEADERS = [
  "Name of Trainee",
  "Trade",
  "Admn. No.",
  "Date of admission",
  "Aadhaar No.",
  "MIS Reg. No.",
  "Educational Qualification",
  "Trainee's Phone No.",
  "Name of Guardian",
  "Guardian's Phone No.",
  "Address",
];

const STUDENT_FIELD_ALIASES = new Map(
  [
    ["institutename", "instituteName"],
    ["institute", "instituteName"],
    ["nameoftrainee", "name"],
    ["traineename", "name"],
    ["studentname", "name"],
    ["name", "name"],
    ["trade", "trade"],
    ["admnno", "admissionNo"],
    ["admissionno", "admissionNo"],
    ["admn", "admissionNo"],
    ["dateofadmission", "admissionDate"],
    ["admissiondate", "admissionDate"],
    ["aadhaarno", "aadhaarNo"],
    ["aadhaar", "aadhaarNo"],
    ["aadharno", "aadhaarNo"],
    ["misregno", "misRegNo"],
    ["misregistrationno", "misRegNo"],
    ["educationalqualification", "qualification"],
    ["qualification", "qualification"],
    ["traineesphoneno", "traineePhone"],
    ["traineephone", "traineePhone"],
    ["phoneno", "traineePhone"],
    ["nameofguardian", "guardianName"],
    ["guardianname", "guardianName"],
    ["guardiansphoneno", "guardianPhone"],
    ["guardianphone", "guardianPhone"],
    ["address", "address"],
  ]
);

const BASE_DEFAULT_SHARED_STATE = {
  instructorName: "AKASH B",
  itiName: "GOVT ITI PANNIYANNORE",
  tradeNameShort: "D/CIVIL",
  tradeNameLong: "D/CIVIL",
  session: "2025-2027",
  unit: "1",
  shift: "II nd Shift",
  durationOfCourse: "TWO YEARS",
  rosterText: DEFAULT_ROSTER_LINES.join("\n"),
  studentRecords: [],
  selectedStudentRecordId: "",
};

const CRC32_TABLE = createCrc32Table();

const FRAME_CONFIG = {
  planner: { frameId: "plannerFrame", statusId: "plannerStatus" },
  progress: { frameId: "progressFrame", statusId: "progressStatus" },
  progressCard: { frameId: "progressCardFrame", statusId: "progressCardStatus" },
  attendance: { frameId: "attendanceFrame", statusId: "attendanceStatus" },
  annex: { frameId: "annexFrame", statusId: "annexStatus" },
  miscellaneous: { frameId: "miscellaneousFrame", statusId: "miscellaneousStatus" },
};

const dom = {
  fields: [...document.querySelectorAll("[data-shared-key]")],
  tabButtons: [...document.querySelectorAll(".tab-button[data-tab]")],
  tabPanels: [...document.querySelectorAll(".tab-panel[data-panel]")],
  syncNowButton: document.getElementById("syncNowButton"),
  resetSharedButton: document.getElementById("resetSharedButton"),
  studentImportFile: document.getElementById("studentImportFile"),
  downloadStudentTemplateButton: document.getElementById("downloadStudentTemplateButton"),
  importStudentsButton: document.getElementById("importStudentsButton"),
  clearStudentMasterButton: document.getElementById("clearStudentMasterButton"),
  studentImportStatus: document.getElementById("studentImportStatus"),
  studentRecordCount: document.getElementById("studentRecordCount"),
  studentPreviewSelect: document.getElementById("studentPreviewSelect"),
  studentPreviewPanel: document.getElementById("studentPreviewPanel"),
  downloadBackupButton: document.getElementById("downloadBackupButton"),
  chooseBackupButton: document.getElementById("chooseBackupButton"),
  restoreBackupButton: document.getElementById("restoreBackupButton"),
  backupFileInput: document.getElementById("backupFileInput"),
  backupStatus: document.getElementById("backupStatus"),
};

let sharedState = loadSharedState();
let activeTab = loadActiveTab();
let syncTimer = 0;

initialize();

function initialize() {
  syncFormWithState();
  ensureSelectedStudentRecord();
  renderStudentMaster();
  setActiveTab(activeTab);
  bindEvents();
  updateSummary();
  if (dom.studentImportStatus && !dom.studentImportStatus.textContent.trim()) {
    setStudentImportStatus("Student details are managed centrally here.", "muted");
  }
  if (dom.backupStatus && !dom.backupStatus.textContent.trim()) {
    setBackupStatus("Backup file covers HOME and all embedded tab data.", "muted");
  }
  queueBroadcast("initial");
}

function bindEvents() {
  dom.tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setActiveTab(button.dataset.tab);
    });
  });

  dom.fields.forEach((field) => {
    field.addEventListener("input", handleFieldInput);
    if (field.type === "month" || field.type === "date") {
      field.addEventListener("change", handleFieldInput);
    }
  });

  dom.syncNowButton.addEventListener("click", () => {
    broadcastSharedState("manual");
  });

  dom.resetSharedButton.addEventListener("click", () => {
    const confirmed = window.confirm("Reset the HOME details for all tabs?");
    if (!confirmed) {
      return;
    }

    sharedState = createDefaultSharedState();
    saveSharedState();
    syncFormWithState();
    renderStudentMaster();
    updateSummary();
    setStudentImportStatus("HOME details and the central student master were reset.", "muted");
    broadcastSharedState("reset");
  });

  if (dom.studentPreviewSelect) {
    dom.studentPreviewSelect.addEventListener("change", (event) => {
      sharedState.selectedStudentRecordId = String(event.target.value || "");
      saveSharedState();
      renderStudentMaster();
    });
  }

  if (dom.studentImportFile) {
    dom.studentImportFile.addEventListener("change", () => {
      const file = dom.studentImportFile.files?.[0];
      if (!file) {
        setStudentImportStatus("Select an Excel or CSV file to import student details.", "muted");
        return;
      }
      setStudentImportStatus(`${file.name} is ready to import.`, "muted");
    });
  }

  if (dom.downloadStudentTemplateButton) {
    dom.downloadStudentTemplateButton.addEventListener("click", () => {
      downloadStudentTemplateWorkbook();
    });
  }

  if (dom.importStudentsButton) {
    dom.importStudentsButton.addEventListener("click", async () => {
      await handleStudentImport();
    });
  }

  if (dom.clearStudentMasterButton) {
    dom.clearStudentMasterButton.addEventListener("click", () => {
      const confirmed = window.confirm("Clear the central student data and roster?");
      if (!confirmed) {
        return;
      }

      sharedState.studentRecords = [];
      sharedState.selectedStudentRecordId = "";
      sharedState.rosterText = "";
      saveSharedState();
      syncFormWithState();
      renderStudentMaster();
      updateSummary();
      queueBroadcast("clear-student-master");
      if (dom.studentImportFile) {
        dom.studentImportFile.value = "";
      }
      setStudentImportStatus("Cleared the central student data.", "muted");
    });
  }

  if (dom.downloadBackupButton) {
    dom.downloadBackupButton.addEventListener("click", () => {
      downloadPortalBackup();
    });
  }

  if (dom.chooseBackupButton && dom.backupFileInput) {
    dom.chooseBackupButton.addEventListener("click", () => {
      dom.backupFileInput.click();
    });

    dom.backupFileInput.addEventListener("change", () => {
      const file = dom.backupFileInput.files?.[0];
      if (!file) {
        setBackupStatus("Choose a backup file to restore the full portal later.", "muted");
        return;
      }
      setBackupStatus(`${file.name} is ready to restore.`, "muted");
    });
  }

  if (dom.restoreBackupButton) {
    dom.restoreBackupButton.addEventListener("click", async () => {
      await restorePortalBackup();
    });
  }

  Object.entries(FRAME_CONFIG).forEach(([appName, config]) => {
    const frame = document.getElementById(config.frameId);
    if (!frame) {
      return;
    }

    frame.addEventListener("load", () => {
      setStatus(appName, "Waiting", "waiting");
      queueBroadcast(`load-${appName}`);
    });
  });

  window.addEventListener("message", handleEmbeddedMessage);
}

function handleFieldInput(event) {
  const key = event.target.dataset.sharedKey;
  sharedState[key] = event.target.value;

  if (key === "rosterText") {
    syncStudentRecordsFromRosterText();
  }

  saveSharedState();
  renderStudentMaster();
  updateSummary();
  queueBroadcast(`field-${key}`);
}

async function handleStudentImport() {
  const file = dom.studentImportFile?.files?.[0];
  const result = await importStudentRecordsFromWorkbookFile(file);

  if (!result.ok) {
    setStudentImportStatus(result.message, "warning");
    return;
  }

  sharedState.studentRecords = result.records;
  sharedState.selectedStudentRecordId = resolveSelectedStudentRecordId(
    sharedState.selectedStudentRecordId,
    sharedState.studentRecords
  );
  sharedState.rosterText = serializeStudentRecordsToRosterText(sharedState.studentRecords);
  saveSharedState();
  syncFormWithState();
  renderStudentMaster();
  updateSummary();
  queueBroadcast("student-import");
  setStudentImportStatus(result.message, "success");
}

function createDefaultSharedState() {
  const defaults = structuredClone(BASE_DEFAULT_SHARED_STATE);
  defaults.studentRecords = createStudentRecordsFromRosterText(defaults.rosterText, defaults);
  defaults.selectedStudentRecordId = resolveSelectedStudentRecordId(
    defaults.selectedStudentRecordId,
    defaults.studentRecords
  );
  return defaults;
}

function loadSharedState() {
  const defaults = createDefaultSharedState();

  try {
    const saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || "null");
    if (!saved || typeof saved !== "object") {
      return defaults;
    }

    const merged = migrateLegacySharedState(saved, defaults);

    merged.rosterText = String(merged.rosterText ?? defaults.rosterText);
    merged.studentRecords = normalizeSharedStudentRecords(saved.studentRecords, merged);

    if (!merged.studentRecords.length && merged.rosterText.trim()) {
      merged.studentRecords = createStudentRecordsFromRosterText(merged.rosterText, merged);
    }

    if (!merged.rosterText.trim() && merged.studentRecords.length) {
      merged.rosterText = serializeStudentRecordsToRosterText(merged.studentRecords);
    }

    merged.selectedStudentRecordId = resolveSelectedStudentRecordId(
      saved.selectedStudentRecordId,
      merged.studentRecords
    );

    return merged;
  } catch {
    return defaults;
  }
}

function saveSharedState() {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(sharedState));
}

function migrateLegacySharedState(saved, defaults) {
  const merged = {
    ...defaults,
    ...saved,
  };

  merged.instructorName = coalesceSharedText(saved.instructorName, defaults.instructorName);
  merged.itiName = coalesceSharedText(saved.itiName, saved.institution, defaults.itiName);
  merged.tradeNameShort = coalesceSharedText(
    saved.tradeNameShort,
    saved.tradeShort,
    saved.tradeName,
    defaults.tradeNameShort
  );
  merged.tradeNameLong = coalesceSharedText(
    saved.tradeNameLong,
    saved.tradeLong,
    saved.tradeName,
    merged.tradeNameShort,
    defaults.tradeNameLong
  );
  merged.session = coalesceSharedText(saved.session, saved.academicSpan, defaults.session);
  merged.unit = coalesceSharedText(saved.unit, defaults.unit);
  merged.shift = coalesceSharedText(saved.shift, saved.shiftLabel, saved.shiftShort, defaults.shift);
  merged.durationOfCourse = coalesceSharedText(
    saved.durationOfCourse,
    saved.duration,
    defaults.durationOfCourse
  );

  return merged;
}

function coalesceSharedText(...values) {
  for (const value of values) {
    if (value === undefined || value === null) {
      continue;
    }

    const text = String(value).trim();
    if (text) {
      return text;
    }
  }

  return "";
}

function loadActiveTab() {
  const hashTab = window.location.hash.replace(/^#/, "").trim();
  if (hashTab) {
    return hashTab;
  }

  const saved = window.localStorage.getItem(TAB_KEY);
  return saved || "common";
}

function setActiveTab(tabName) {
  activeTab =
    Object.prototype.hasOwnProperty.call(FRAME_CONFIG, tabName) || tabName === "common"
      ? tabName
      : "common";
  window.localStorage.setItem(TAB_KEY, activeTab);
  window.history.replaceState(null, "", `#${activeTab}`);

  dom.tabButtons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.tab === activeTab);
  });

  dom.tabPanels.forEach((panel) => {
    panel.classList.toggle("is-active", panel.dataset.panel === activeTab);
  });

  if (activeTab === "common") {
    renderStudentMaster();
  }
}

function syncFormWithState() {
  dom.fields.forEach((field) => {
    const key = field.dataset.sharedKey;
    field.value = sharedState[key] ?? "";
  });
}

function renderStudentMaster() {
  const records = getResolvedSharedStudentRecords();
  ensureSelectedStudentRecord(records);

  if (dom.studentRecordCount) {
    dom.studentRecordCount.textContent = `${records.length} student${
      records.length === 1 ? "" : "s"
    }`;
  }

  if (dom.studentPreviewSelect) {
    if (records.length) {
      dom.studentPreviewSelect.innerHTML = records
        .map(
          (record, index) => `
            <option value="${escapeAttribute(record.id)}">
              ${escapeHtml(getStudentRecordOptionLabel(record, index))}
            </option>
          `
        )
        .join("");
      dom.studentPreviewSelect.value = sharedState.selectedStudentRecordId;
      dom.studentPreviewSelect.disabled = false;
    } else {
      dom.studentPreviewSelect.innerHTML = '<option value="">No students loaded</option>';
      dom.studentPreviewSelect.disabled = true;
    }
  }

  if (!dom.studentPreviewPanel) {
    return;
  }

  if (!records.length) {
    dom.studentPreviewPanel.innerHTML = `
      <p class="student-preview-empty">
        No central student records are loaded yet. Import the student sheet here or type roster lines below.
      </p>
    `;
    return;
  }

  const selectedIndex = records.findIndex(
    (record) => record.id === sharedState.selectedStudentRecordId
  );
  const selectedRecord = records[selectedIndex] || records[0];

  dom.studentPreviewPanel.innerHTML = renderStudentPreview(
    selectedRecord,
    selectedIndex >= 0 ? selectedIndex : 0,
    records.length
  );
}

function renderStudentPreview(record, index, total) {
  const name = record.name || `Student ${index + 1}`;
  const admissionText = record.admissionNo
    ? `Admission No: ${record.admissionNo}`
    : "Admission number not set";
  const photo = getProgressCardPhotoForStudent(record);

  return `
    <div class="student-preview-header">
      <div>
        <h4>${escapeHtml(name)}</h4>
        <p>${escapeHtml(admissionText)}</p>
      </div>
      <span class="student-record-badge">Student ${index + 1} of ${total}</span>
    </div>
    <div class="student-preview-grid">
      ${renderStudentPhotoCard(photo)}
      ${SHARED_STUDENT_FIELDS.map((field) =>
        renderStudentPreviewCard(record, field)
      ).join("")}
    </div>
  `;
}

function renderStudentPreviewCard(record, field) {
  const value = String(record[field.key] || "").trim() || "-";
  return `
    <div class="student-preview-card${field.wide ? " is-wide" : ""}">
      <span>${escapeHtml(field.label)}</span>
      <strong>${escapeHtml(value)}</strong>
    </div>
  `;
}

function renderStudentPhotoCard(photo) {
  if (photo?.src) {
    return `
      <div class="student-preview-card student-preview-card--photo">
        <div class="student-preview-photo-frame">
          <img
            src="${escapeAttribute(photo.src)}"
            alt="Trainee photo"
            style="object-position:${Number(photo.x) || 50}% ${Number(photo.y) || 50}%; transform:scale(${Number(photo.scale) || 1});"
          >
        </div>
      </div>
    `;
  }

  return `
    <div class="student-preview-card student-preview-card--photo">
      <div class="student-preview-photo-frame">
        <div class="student-preview-photo-placeholder">No Photo</div>
      </div>
    </div>
  `;
}

function ensureSelectedStudentRecord(records = getResolvedSharedStudentRecords()) {
  sharedState.selectedStudentRecordId = resolveSelectedStudentRecordId(
    sharedState.selectedStudentRecordId,
    records
  );
}

function resolveSelectedStudentRecordId(selectedId, records) {
  const normalizedId = String(selectedId || "");
  if (normalizedId && records.some((record) => record.id === normalizedId)) {
    return normalizedId;
  }

  return records[0]?.id || "";
}

function getResolvedSharedStudentRecords() {
  const sourceRecords = Array.isArray(sharedState.studentRecords)
    ? sharedState.studentRecords
    : [];
  const normalizedRecords = sourceRecords
    .map((record) => normalizeSharedStudentRecord(record, sharedState))
    .filter(studentRecordHasMeaningfulContent);

  if (normalizedRecords.length) {
    return normalizedRecords;
  }

  return createStudentRecordsFromRosterText(sharedState.rosterText, sharedState);
}

function syncStudentRecordsFromRosterText() {
  const rosterEntries = parseRoster(sharedState.rosterText);

  if (!rosterEntries.length) {
    sharedState.studentRecords = [];
    sharedState.selectedStudentRecordId = "";
    return;
  }

  sharedState.studentRecords = mergeStudentRecordsFromRosterEntries(
    sharedState.studentRecords,
    rosterEntries,
    sharedState
  );
  sharedState.selectedStudentRecordId = resolveSelectedStudentRecordId(
    sharedState.selectedStudentRecordId,
    sharedState.studentRecords
  );
}

function mergeStudentRecordsFromRosterEntries(existingRecords, rosterEntries, baseState) {
  const admissionMatches = new Map();
  const nameMatches = new Map();
  const normalizedExisting = normalizeSharedStudentRecords(existingRecords, baseState);

  normalizedExisting.forEach((record) => {
    const admissionKey = normalizeMatchToken(record.admissionNo);
    const nameKey = normalizeMatchToken(record.name);
    if (admissionKey && !admissionMatches.has(admissionKey)) {
      admissionMatches.set(admissionKey, record);
    }
    if (nameKey && !nameMatches.has(nameKey)) {
      nameMatches.set(nameKey, record);
    }
  });

  const usedIds = new Set();

  return rosterEntries.map((entry) => {
    const admissionKey = normalizeMatchToken(entry.admNo);
    const nameKey = normalizeMatchToken(entry.name);
    const matchingRecord =
      (admissionKey ? admissionMatches.get(admissionKey) : null) ||
      (nameKey ? nameMatches.get(nameKey) : null) ||
      createSharedStudentRecord({}, baseState);

    usedIds.add(matchingRecord.id);

    return normalizeSharedStudentRecord(
      {
        ...matchingRecord,
        id: matchingRecord.id,
        instituteName:
          matchingRecord.instituteName || String(baseState.itiName || baseState.institution || ""),
        trade:
          matchingRecord.trade
          || String(baseState.tradeNameShort || baseState.tradeName || ""),
        name: entry.name || matchingRecord.name,
        admissionNo: entry.admNo || matchingRecord.admissionNo,
        guardianName: entry.fatherName || matchingRecord.guardianName,
      },
      baseState
    );
  });
}

function createStudentRecordsFromRosterText(rosterText, baseState) {
  const rosterEntries = parseRoster(rosterText);
  return mergeStudentRecordsFromRosterEntries([], rosterEntries, baseState);
}

function normalizeSharedStudentRecords(rawRecords, baseState) {
  if (!Array.isArray(rawRecords)) {
    return [];
  }

  return rawRecords
    .map((record) => normalizeSharedStudentRecord(record, baseState))
    .filter(studentRecordHasMeaningfulContent);
}

function createSharedStudentRecord(overrides = {}, baseState = null) {
  return normalizeSharedStudentRecord(
    {
      id: overrides.id || createStudentRecordId(),
      instituteName: overrides.instituteName || "",
      name: overrides.name || "",
      trade: overrides.trade || "",
      admissionNo: overrides.admissionNo || "",
      admissionDate: overrides.admissionDate || "",
      aadhaarNo: overrides.aadhaarNo || "",
      misRegNo: overrides.misRegNo || "",
      qualification: overrides.qualification || "",
      traineePhone: overrides.traineePhone || "",
      guardianName: overrides.guardianName || "",
      guardianPhone: overrides.guardianPhone || "",
      address: overrides.address || "",
    },
    baseState
  );
}

function normalizeSharedStudentRecord(rawRecord, baseState = null) {
  const context = baseState || sharedState || BASE_DEFAULT_SHARED_STATE;

  return {
    id: String(rawRecord?.id || createStudentRecordId()),
    instituteName: String(
      rawRecord?.instituteName || rawRecord?.institution || context.itiName || context.institution || ""
    ).trim(),
    name: String(rawRecord?.name || "").trim(),
    trade: String(
      rawRecord?.trade
      || rawRecord?.tradeName
      || rawRecord?.tradeShort
      || context.tradeNameShort
      || context.tradeName
      || ""
    ).trim(),
    admissionNo: String(rawRecord?.admissionNo || rawRecord?.admNo || "").trim(),
    admissionDate: String(rawRecord?.admissionDate || "").trim(),
    aadhaarNo: String(rawRecord?.aadhaarNo || "").trim(),
    misRegNo: String(rawRecord?.misRegNo || "").trim(),
    qualification: String(rawRecord?.qualification || "").trim(),
    traineePhone: String(rawRecord?.traineePhone || "").trim(),
    guardianName: String(rawRecord?.guardianName || rawRecord?.fatherName || "").trim(),
    guardianPhone: String(rawRecord?.guardianPhone || "").trim(),
    address: String(rawRecord?.address || "").trim(),
  };
}

function createStudentRecordId() {
  return `portal-student-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function studentRecordHasMeaningfulContent(record) {
  return [
    record.name,
    record.admissionNo,
    record.admissionDate,
    record.aadhaarNo,
    record.misRegNo,
    record.qualification,
    record.traineePhone,
    record.guardianName,
    record.guardianPhone,
    record.address,
  ].some((value) => String(value || "").trim());
}

function serializeStudentRecordsToRosterText(records) {
  return records
    .map((record) => {
      const parts = [record.admissionNo, record.name, record.guardianName]
        .map((part) => String(part || "").trim())
        .filter(Boolean);
      return parts.join(" | ");
    })
    .filter(Boolean)
    .join("\n");
}

function getStudentRecordOptionLabel(record, index) {
  const primary = record.name || `Student ${index + 1}`;
  const secondary = record.admissionNo
    ? `Admn ${record.admissionNo}`
    : record.trade || "No admission no";
  return `${primary} - ${secondary}`;
}

function getProgressCardPhotoForStudent(record) {
  const photoMap = readProgressCardPhotoMap();
  const matchKey = [
    record.admissionNo,
    record.aadhaarNo,
    record.misRegNo,
    record.name,
  ]
    .map((value) => normalizeMatchToken(value))
    .find((value) => value && photoMap.has(value));

  return matchKey ? photoMap.get(matchKey) : null;
}

function readProgressCardPhotoMap() {
  const photoMap = new Map();

  try {
    const raw = JSON.parse(window.localStorage.getItem(PROGRESS_CARD_STORAGE_KEY) || "null");
    const students = Array.isArray(raw?.students)
      ? raw.students
      : raw?.student
        ? [raw]
        : [];

    students.forEach((record) => {
      const student = record?.student || {};
      const photo = record?.photo || {};
      if (!photo.src) {
        return;
      }

      [
        student.admissionNo,
        student.aadhaarNo,
        student.misRegNo,
        student.name,
      ]
        .map((value) => normalizeMatchToken(value))
        .filter(Boolean)
        .forEach((key) => {
          if (!photoMap.has(key)) {
            photoMap.set(key, {
              src: String(photo.src || ""),
              scale: Number(photo.scale) || 1,
              x: Number(photo.x) || 50,
              y: Number(photo.y) || 50,
            });
          }
        });
    });
  } catch {
    return photoMap;
  }

  return photoMap;
}

function setStudentImportStatus(message, tone = "muted") {
  if (!dom.studentImportStatus) {
    return;
  }

  dom.studentImportStatus.textContent = message;
  dom.studentImportStatus.classList.remove("is-success", "is-warning", "is-muted");
  if (tone === "success") {
    dom.studentImportStatus.classList.add("is-success");
  } else if (tone === "warning") {
    dom.studentImportStatus.classList.add("is-warning");
  } else {
    dom.studentImportStatus.classList.add("is-muted");
  }
}

function setBackupStatus(message, tone = "muted") {
  if (!dom.backupStatus) {
    return;
  }

  dom.backupStatus.textContent = message;
  dom.backupStatus.classList.remove("is-success", "is-warning", "is-muted");
  if (tone === "success") {
    dom.backupStatus.classList.add("is-success");
  } else if (tone === "warning") {
    dom.backupStatus.classList.add("is-warning");
  } else {
    dom.backupStatus.classList.add("is-muted");
  }
}

function updateSummary() {
  document.title = sharedState.tradeNameShort?.trim()
    ? `ITI DOC - ${sharedState.tradeNameShort.trim()}`
    : "ITI DOC";
}

function downloadPortalBackup() {
  try {
    const backup = buildPortalBackupSnapshot();
    const timestamp = new Date()
      .toISOString()
      .replace(/[:.]/g, "-")
      .replace("T", "_")
      .replace("Z", "");
    const blob = new Blob([JSON.stringify(backup, null, 2)], {
      type: "application/json",
    });

    downloadBlob(blob, `iti-doc-backup-${timestamp}.json`);
    setBackupStatus(
      `Backup downloaded with ${Object.keys(backup.storage).length} saved portal entries.`,
      "success"
    );
  } catch (error) {
    setBackupStatus(
      error instanceof Error ? error.message : "Backup export failed.",
      "warning"
    );
  }
}

async function restorePortalBackup() {
  const file = dom.backupFileInput?.files?.[0];
  if (!file) {
    setBackupStatus("Choose a backup file first.", "warning");
    return;
  }

  try {
    const text = await file.text();
    const snapshot = parsePortalBackupSnapshot(text);
    applyPortalBackupSnapshot(snapshot);
    if (dom.backupFileInput) {
      dom.backupFileInput.value = "";
    }
    setBackupStatus(
      `Restored backup from ${formatBackupTimestamp(snapshot.createdAt)}.`,
      "success"
    );
  } catch (error) {
    setBackupStatus(
      error instanceof Error ? error.message : "Backup restore failed.",
      "warning"
    );
  }
}

function buildPortalBackupSnapshot() {
  const storage = {};

  getRelevantPortalStorageKeys().forEach((key) => {
    const value = window.localStorage.getItem(key);
    if (value !== null) {
      storage[key] = value;
    }
  });

  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    createdAt: new Date().toISOString(),
    appTitle: "ITI DOC",
    storage,
  };
}

function parsePortalBackupSnapshot(text) {
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error("That backup file is not valid JSON.");
  }

  if (!parsed || typeof parsed !== "object") {
    throw new Error("That backup file is empty or invalid.");
  }

  const storage = parsed.storage;
  if (parsed.format !== BACKUP_FORMAT || !storage || typeof storage !== "object") {
    throw new Error("This file is not an ITI DOC portal backup.");
  }

  const sanitizedStorage = {};
  Object.entries(storage).forEach(([key, value]) => {
    if (shouldIncludeBackupStorageKey(key) && typeof value === "string") {
      sanitizedStorage[key] = value;
    }
  });

  if (!Object.keys(sanitizedStorage).length) {
    throw new Error("The backup file does not contain any restorable portal data.");
  }

  return {
    format: parsed.format,
    version: Number(parsed.version) || BACKUP_VERSION,
    createdAt: String(parsed.createdAt || ""),
    storage: sanitizedStorage,
  };
}

function applyPortalBackupSnapshot(snapshot) {
  clearRelevantPortalStorage();

  Object.entries(snapshot.storage).forEach(([key, value]) => {
    window.localStorage.setItem(key, value);
  });

  sharedState = loadSharedState();
  activeTab = "common";
  saveSharedState();
  syncFormWithState();
  ensureSelectedStudentRecord();
  renderStudentMaster();
  updateSummary();
  setActiveTab("common");

  if (dom.studentImportFile) {
    dom.studentImportFile.value = "";
  }

  reloadEmbeddedFrames();
  queueBroadcast("backup-restore");
}

function getRelevantPortalStorageKeys() {
  const keys = [];
  for (let index = 0; index < window.localStorage.length; index += 1) {
    const key = window.localStorage.key(index);
    if (key && shouldIncludeBackupStorageKey(key)) {
      keys.push(key);
    }
  }
  return keys.sort();
}

function shouldIncludeBackupStorageKey(key) {
  return BACKUP_KEY_PREFIXES.some((prefix) => key.startsWith(prefix));
}

function clearRelevantPortalStorage() {
  getRelevantPortalStorageKeys().forEach((key) => {
    window.localStorage.removeItem(key);
  });
}

function reloadEmbeddedFrames() {
  Object.entries(FRAME_CONFIG).forEach(([appName, config]) => {
    const frame = document.getElementById(config.frameId);
    if (!frame) {
      return;
    }

    setStatus(appName, "Loading", "waiting");

    try {
      if (frame.contentWindow?.location) {
        frame.contentWindow.location.reload();
        return;
      }
    } catch {
      // Fall back to resetting the src attribute.
    }

    const source = frame.getAttribute("src");
    if (source) {
      frame.setAttribute("src", source);
    }
  });
}

function formatBackupTimestamp(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "the selected file" : date.toLocaleString();
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function queueBroadcast(reason) {
  window.clearTimeout(syncTimer);
  Object.keys(FRAME_CONFIG).forEach((appName) => {
    setStatus(appName, "Queued", "waiting");
  });
  syncTimer = window.setTimeout(() => {
    broadcastSharedState(reason);
  }, 180);
}

function broadcastSharedState(reason = "manual") {
  const payload = buildSharedPayload();
  Object.entries(FRAME_CONFIG).forEach(([appName, config]) => {
    const frame = document.getElementById(config.frameId);
    if (!frame?.contentWindow) {
      setStatus(appName, "Loading", "waiting");
      return;
    }

    setStatus(appName, "Syncing", "waiting");
    frame.contentWindow.postMessage(
      {
        type: "portal-shared-update",
        app: appName,
        reason,
        payload,
      },
      "*"
    );
  });
}

function buildSharedPayload() {
  const studentRecords = getResolvedSharedStudentRecords();
  const rosterText = studentRecords.length
    ? serializeStudentRecordsToRosterText(studentRecords)
    : String(sharedState.rosterText || "");
  const rosterEntries = studentRecords.length
    ? studentRecords.map((record) => ({
        admNo: record.admissionNo,
        name: record.name,
        fatherName: record.guardianName,
      }))
    : parseRoster(rosterText);

  const instructorName = String(sharedState.instructorName || "");
  const itiName = String(sharedState.itiName || "");
  const tradeNameShort = String(sharedState.tradeNameShort || "");
  const tradeNameLong = String(sharedState.tradeNameLong || tradeNameShort);
  const session = String(sharedState.session || "");
  const unit = String(sharedState.unit || "");
  const shift = String(sharedState.shift || "");
  const durationOfCourse = String(sharedState.durationOfCourse || "");

  return {
    instructorName,
    itiName,
    tradeNameShort,
    tradeNameLong,
    tradeShort: tradeNameShort,
    tradeLong: tradeNameLong,
    session,
    unit,
    shift,
    durationOfCourse,
    institution: itiName,
    tradeName: tradeNameShort,
    progressChartTitle: DEFAULT_PROGRESS_CHART_TITLE,
    monthlyPlanHeading: buildMonthlyPlanHeading({
      tradeNameShort,
      session,
      shift,
      unit,
    }),
    academicSpan: session,
    progressAcademicYear: session,
    shiftLabel: shift,
    shiftShort: deriveShiftShort(shift),
    rosterText,
    rosterEntries,
    studentRecords,
    progressTrade: normaliseTradeForProgress(tradeNameShort),
    annexTradeName: normaliseTradeForAnnex(tradeNameShort),
  };
}

function buildMonthlyPlanHeading({
  tradeNameShort = "",
  session = "",
  shift = "",
  unit = "",
} = {}) {
  const pieces = [
    String(tradeNameShort || "").trim(),
    String(session || "").trim(),
    unit ? `Unit ${String(unit).trim()}` : "",
    shift ? `(${String(shift).trim()})` : "",
  ].filter(Boolean);
  return pieces.join("  ");
}

function deriveShiftShort(value) {
  const shiftValue = String(value || "").trim();
  if (!shiftValue) {
    return "";
  }

  const romanMatch = shiftValue.match(/\b([IVX]+)\b/i);
  if (romanMatch?.[1]) {
    return romanMatch[1].toUpperCase();
  }

  const numberMatch = shiftValue.match(/\b([0-9]+)(?:st|nd|rd|th)?\b/i);
  if (numberMatch?.[1]) {
    return numberMatch[1];
  }

  return shiftValue.split(/\s+/)[0].replace(/[^A-Za-z0-9]/g, "").toUpperCase();
}

function handleEmbeddedMessage(event) {
  const data = event.data;
  if (!data || typeof data !== "object" || !data.type || !data.app) {
    return;
  }

  if (!Object.prototype.hasOwnProperty.call(FRAME_CONFIG, data.app)) {
    return;
  }

  if (data.type === "portal:ready") {
    setStatus(data.app, "Ready", "waiting");
    const frame = document.getElementById(FRAME_CONFIG[data.app].frameId);
    if (frame?.contentWindow) {
      frame.contentWindow.postMessage(
        {
          type: "portal-shared-update",
          app: data.app,
          reason: "ready",
          payload: buildSharedPayload(),
        },
        "*"
      );
    }
    return;
  }

  if (data.type === "portal:applied") {
    setStatus(data.app, "Synced", "ready");
    if (Number.isFinite(data.height)) {
      setFrameHeight(data.app, data.height);
    }
    return;
  }

  if (data.type === "portal:height" && Number.isFinite(data.height)) {
    setFrameHeight(data.app, data.height);
  }
}

function setFrameHeight(appName, height) {
  const frame = document.getElementById(FRAME_CONFIG[appName].frameId);
  if (!frame) {
    return;
  }

  const safeHeight = Math.max(280, Math.min(6000, Math.ceil(height) + 8));
  frame.style.height = `${safeHeight}px`;
}

function setStatus(appName, label, tone = "") {
  const config = FRAME_CONFIG[appName];
  const node = config ? document.getElementById(config.statusId) : null;
  if (!node) {
    return;
  }

  node.textContent = label;
  node.classList.remove("is-ready", "is-waiting", "is-error");
  if (tone === "ready") {
    node.classList.add("is-ready");
  } else if (tone === "waiting") {
    node.classList.add("is-waiting");
  } else if (tone === "error") {
    node.classList.add("is-error");
  }
}

function parseRoster(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map(parseRosterLine)
    .filter((entry) => entry.name || entry.admNo || entry.fatherName);
}

function parseRosterLine(line) {
  const parts = line
    .split("|")
    .map((part) => part.trim())
    .filter(Boolean);

  if (!parts.length) {
    return { admNo: "", name: "", fatherName: "" };
  }

  if (parts.length === 1) {
    return { admNo: "", name: parts[0], fatherName: "" };
  }

  if (parts.length === 2) {
    if (looksLikeAdmission(parts[0])) {
      return { admNo: parts[0], name: parts[1], fatherName: "" };
    }

    if (looksLikeAdmission(parts[1])) {
      return { admNo: parts[1], name: parts[0], fatherName: "" };
    }

    return { admNo: "", name: parts[0], fatherName: parts[1] };
  }

  if (looksLikeAdmission(parts[0])) {
    return { admNo: parts[0], name: parts[1], fatherName: parts.slice(2).join(" | ") };
  }

  if (looksLikeAdmission(parts[1])) {
    return { admNo: parts[1], name: parts[0], fatherName: parts.slice(2).join(" | ") };
  }

  return { admNo: "", name: parts[0], fatherName: parts.slice(1).join(" | ") };
}

function looksLikeAdmission(value) {
  return /[0-9]/.test(value) && (value.includes("/") || value.includes("-") || value.length <= 12);
}

function normaliseTradeForProgress(value) {
  return String(value || "")
    .trim()
    .replace(/\s+/g, " ");
}

function normaliseTradeForAnnex(value) {
  return String(value || "")
    .trim()
    .replace(/\s+/g, " ");
}

async function importStudentRecordsFromWorkbookFile(file) {
  if (!file) {
    return {
      ok: false,
      message: "Select an Excel or CSV file first.",
      records: [],
    };
  }

  const lowerName = file.name.toLowerCase();

  try {
    let rows = [];

    if (lowerName.endsWith(".csv")) {
      rows = parseCsvRows(await file.text());
    } else if (lowerName.endsWith(".xlsx")) {
      rows = await readXlsxRows(await file.arrayBuffer());
    } else {
      return {
        ok: false,
        message: "Please import a `.xlsx` file or a `.csv` file.",
        records: [],
      };
    }

    const records = parseStudentTableRows(rows);
    if (!records.length) {
      return {
        ok: false,
        message:
          "No student rows were found in that file. Use the template and keep one student per row.",
        records: [],
      };
    }

    return {
      ok: true,
      message: `Imported ${records.length} student${records.length === 1 ? "" : "s"} from ${file.name}.`,
      records,
    };
  } catch (error) {
    return {
      ok: false,
      message: error instanceof Error ? error.message : "Student import failed.",
      records: [],
    };
  }
}

function parseStudentTableRows(rows) {
  if (rows.length < 2) {
    return [];
  }

  const mappings = rows[0].map((header) => matchStudentField(header));
  const recognizedCount = mappings.filter(Boolean).length;
  const hasCoreField = mappings.some(
    (field) => field === "name" || field === "admissionNo" || field === "guardianName"
  );

  if (recognizedCount < 2 || !hasCoreField) {
    return [];
  }

  const existingByKey = buildSharedStudentIdentityMap(sharedState.studentRecords);
  const students = [];

  rows.slice(1).forEach((cells) => {
    if (!cells.some((cell) => String(cell || "").trim())) {
      return;
    }

    const record = createSharedStudentRecord({}, sharedState);
    mappings.forEach((field, cellIndex) => {
      if (!field) {
        return;
      }
      record[field] = String(cells[cellIndex] || "").trim();
    });

    const normalizedRecord = normalizeSharedStudentRecord(record, sharedState);
    if (!studentRecordHasMeaningfulContent(normalizedRecord)) {
      return;
    }

    const identity = getSharedStudentIdentity(normalizedRecord);
    if (identity && existingByKey.has(identity)) {
      const existingRecord = existingByKey.get(identity);
      students.push(
        normalizeSharedStudentRecord(
          {
            ...existingRecord,
            ...normalizedRecord,
            id: existingRecord.id,
          },
          sharedState
        )
      );
      return;
    }

    students.push(normalizedRecord);
  });

  return students;
}

function buildSharedStudentIdentityMap(records) {
  const map = new Map();
  normalizeSharedStudentRecords(records, sharedState).forEach((record) => {
    const identity = getSharedStudentIdentity(record);
    if (identity && !map.has(identity)) {
      map.set(identity, record);
    }
  });
  return map;
}

function getSharedStudentIdentity(record) {
  return normalizeMatchToken(
    record.admissionNo || record.aadhaarNo || record.misRegNo || record.name
  );
}

function normalizeMatchToken(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function matchStudentField(header) {
  return STUDENT_FIELD_ALIASES.get(normalizeText(header)) || null;
}

function parseCsvRows(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let inQuotes = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        cell += '"';
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === "," && !inQuotes) {
      row.push(cell.trim());
      cell = "";
      continue;
    }

    if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && next === "\n") {
        index += 1;
      }
      row.push(cell.trim());
      if (row.some((value) => value !== "")) {
        rows.push(row);
      }
      row = [];
      cell = "";
      continue;
    }

    cell += char;
  }

  if (cell.length || row.length) {
    row.push(cell.trim());
    if (row.some((value) => value !== "")) {
      rows.push(row);
    }
  }

  return rows;
}

async function readXlsxRows(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  const archive = readZipDirectory(bytes);
  const sheetPath = await getPrimaryWorksheetPath(bytes, archive);
  const sharedStrings = archive.has("xl/sharedStrings.xml")
    ? parseSharedStrings(await readZipEntryText(bytes, archive.get("xl/sharedStrings.xml")))
    : [];
  const worksheetXml = await readZipEntryText(bytes, archive.get(sheetPath));
  return parseWorksheetRows(worksheetXml, sharedStrings);
}

function readZipDirectory(bytes) {
  const eocdOffset = findZipEndOfCentralDirectory(bytes);
  if (eocdOffset < 0) {
    throw new Error("ZIP end record not found.");
  }

  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const entryCount = view.getUint16(eocdOffset + 10, true);
  const centralOffset = view.getUint32(eocdOffset + 16, true);
  const archive = new Map();
  let cursor = centralOffset;

  for (let index = 0; index < entryCount; index += 1) {
    if (view.getUint32(cursor, true) !== 0x02014b50) {
      break;
    }

    const compressionMethod = view.getUint16(cursor + 10, true);
    const compressedSize = view.getUint32(cursor + 20, true);
    const fileNameLength = view.getUint16(cursor + 28, true);
    const extraLength = view.getUint16(cursor + 30, true);
    const commentLength = view.getUint16(cursor + 32, true);
    const localHeaderOffset = view.getUint32(cursor + 42, true);
    const fileNameBytes = bytes.slice(cursor + 46, cursor + 46 + fileNameLength);
    const fileName = decodeUtf8(fileNameBytes);

    archive.set(fileName, {
      fileName,
      compressionMethod,
      compressedSize,
      localHeaderOffset,
    });

    cursor += 46 + fileNameLength + extraLength + commentLength;
  }

  return archive;
}

function findZipEndOfCentralDirectory(bytes) {
  for (
    let index = Math.max(0, bytes.length - 22);
    index >= Math.max(0, bytes.length - 65557);
    index -= 1
  ) {
    if (
      bytes[index] === 0x50 &&
      bytes[index + 1] === 0x4b &&
      bytes[index + 2] === 0x05 &&
      bytes[index + 3] === 0x06
    ) {
      return index;
    }
  }
  return -1;
}

async function getPrimaryWorksheetPath(bytes, archive) {
  if (!archive.has("xl/workbook.xml")) {
    const firstSheet = Array.from(archive.keys()).find((name) =>
      name.startsWith("xl/worksheets/")
    );
    if (firstSheet) {
      return firstSheet;
    }
    throw new Error("Workbook XML is missing.");
  }

  const workbookXml = await readZipEntryText(bytes, archive.get("xl/workbook.xml"));
  const relsXml = archive.has("xl/_rels/workbook.xml.rels")
    ? await readZipEntryText(bytes, archive.get("xl/_rels/workbook.xml.rels"))
    : "";

  const workbookDoc = parseXml(workbookXml);
  const relsDoc = relsXml ? parseXml(relsXml) : null;
  const firstSheet = getElementsByLocalName(workbookDoc, "sheet")[0];

  if (!firstSheet) {
    const fallbackSheet = Array.from(archive.keys()).find((name) =>
      name.startsWith("xl/worksheets/")
    );
    if (fallbackSheet) {
      return fallbackSheet;
    }
    throw new Error("Worksheet not found.");
  }

  const relationshipId =
    firstSheet.getAttribute("r:id") ||
    firstSheet.getAttributeNS(
      "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "id"
    );

  if (relationshipId && relsDoc) {
    const relationship = getElementsByLocalName(relsDoc, "Relationship").find(
      (node) => node.getAttribute("Id") === relationshipId
    );
    if (relationship) {
      return normalizeWorksheetPath(relationship.getAttribute("Target"));
    }
  }

  return "xl/worksheets/sheet1.xml";
}

function normalizeWorksheetPath(target) {
  const cleaned = String(target || "").replace(/^\/+/, "");
  return cleaned.startsWith("xl/") ? cleaned : `xl/${cleaned}`;
}

async function readZipEntryText(bytes, entry) {
  const data = await extractZipEntry(bytes, entry);
  return decodeUtf8(data);
}

async function extractZipEntry(bytes, entry) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const localOffset = entry.localHeaderOffset;
  if (view.getUint32(localOffset, true) !== 0x04034b50) {
    throw new Error("Invalid ZIP header.");
  }

  const fileNameLength = view.getUint16(localOffset + 26, true);
  const extraLength = view.getUint16(localOffset + 28, true);
  const dataStart = localOffset + 30 + fileNameLength + extraLength;
  const compressed = bytes.slice(dataStart, dataStart + entry.compressedSize);

  if (entry.compressionMethod === 0) {
    return compressed;
  }

  if (entry.compressionMethod === 8) {
    if (typeof DecompressionStream === "undefined") {
      throw new Error("This browser cannot unzip the workbook.");
    }
    const stream = new Blob([compressed])
      .stream()
      .pipeThrough(new DecompressionStream("deflate-raw"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }

  throw new Error(`Unsupported ZIP compression method: ${entry.compressionMethod}`);
}

function parseSharedStrings(xmlText) {
  const doc = parseXml(xmlText);
  return getElementsByLocalName(doc, "si").map((node) =>
    getNodeText(node).replace(/\r?\n/g, " ").trim()
  );
}

function parseWorksheetRows(xmlText, sharedStrings) {
  const doc = parseXml(xmlText);
  return getElementsByLocalName(doc, "row")
    .map((rowNode) => {
      const row = [];
      getElementsByLocalName(rowNode, "c").forEach((cellNode) => {
        const ref = cellNode.getAttribute("r") || "";
        const columnIndex = cellRefToColumnIndex(ref);
        row[columnIndex] = parseWorksheetCellValue(cellNode, sharedStrings);
      });
      while (row.length && row[row.length - 1] === "") {
        row.pop();
      }
      return row.map((value) => String(value || "").trim());
    })
    .filter((row) => row.length);
}

function parseWorksheetCellValue(cellNode, sharedStrings) {
  const type = cellNode.getAttribute("t") || "";

  if (type === "inlineStr") {
    return getNodeText(cellNode);
  }

  if (type === "s") {
    const valueNode = getElementsByLocalName(cellNode, "v")[0];
    const index = Number(valueNode?.textContent || 0);
    return sharedStrings[index] || "";
  }

  if (type === "b") {
    const valueNode = getElementsByLocalName(cellNode, "v")[0];
    return valueNode?.textContent === "1" ? "TRUE" : "FALSE";
  }

  const valueNode = getElementsByLocalName(cellNode, "v")[0];
  return valueNode?.textContent || "";
}

function cellRefToColumnIndex(reference) {
  const letters = (reference.match(/[A-Z]+/i) || ["A"])[0].toUpperCase();
  let index = 0;
  for (let pointer = 0; pointer < letters.length; pointer += 1) {
    index = index * 26 + (letters.charCodeAt(pointer) - 64);
  }
  return Math.max(0, index - 1);
}

function parseXml(text) {
  return new DOMParser().parseFromString(text, "application/xml");
}

function getElementsByLocalName(root, name) {
  return Array.from(root.getElementsByTagNameNS("*", name));
}

function getNodeText(node) {
  return getElementsByLocalName(node, "t")
    .map((textNode) => textNode.textContent || "")
    .join("");
}

function decodeUtf8(bytes) {
  return new TextDecoder("utf-8").decode(bytes);
}

function downloadStudentTemplateWorkbook() {
  const blob = buildStudentTemplateWorkbook();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "student-master-template.xlsx";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function buildStudentTemplateWorkbook() {
  const nowIso = new Date().toISOString();
  const worksheetXml = createWorksheetXml(STUDENT_TEMPLATE_HEADERS);
  const entries = [
    {
      name: "[Content_Types].xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>`,
    },
    {
      name: "_rels/.rels",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`,
    },
    {
      name: "docProps/app.xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>Codex</Application>
  <TitlesOfParts>
    <vt:vector size="1" baseType="lpstr">
      <vt:lpstr>Student Details</vt:lpstr>
    </vt:vector>
  </TitlesOfParts>
  <HeadingPairs>
    <vt:vector size="2" baseType="variant">
      <vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant>
      <vt:variant><vt:i4>1</vt:i4></vt:variant>
    </vt:vector>
  </HeadingPairs>
</Properties>`,
    },
    {
      name: "docProps/core.xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:creator>Codex</dc:creator>
  <cp:lastModifiedBy>Codex</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">${escapeXml(nowIso)}</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">${escapeXml(nowIso)}</dcterms:modified>
</cp:coreProperties>`,
    },
    {
      name: "xl/workbook.xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Student Details" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>`,
    },
    {
      name: "xl/_rels/workbook.xml.rels",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`,
    },
    {
      name: "xl/styles.xml",
      text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><name val="Calibri"/></font>
  </fonts>
  <fills count="2">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
  </fills>
  <borders count="1">
    <border><left/><right/><top/><bottom/><diagonal/></border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="3">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
    <xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
  </cellXfs>
  <cellStyles count="1">
    <cellStyle name="Normal" xfId="0" builtinId="0"/>
  </cellStyles>
</styleSheet>`,
    },
    {
      name: "xl/worksheets/sheet1.xml",
      text: worksheetXml,
    },
  ];

  return createZipBlob(entries);
}

function createWorksheetXml(headers) {
  const colsXml = headers
    .map(
      (_, index) =>
        `<col min="${index + 1}" max="${index + 1}" width="24" customWidth="1" style="2"/>`
    )
    .join("");
  const headerRow = headers
    .map(
      (header, index) =>
        `<c r="${columnLabel(index + 1)}1" t="inlineStr" s="1"><is><t>${escapeXml(
          header
        )}</t></is></c>`
    )
    .join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheetViews>
    <sheetView workbookViewId="0">
      <pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>
      <selection pane="bottomLeft" activeCell="A2" sqref="A2"/>
    </sheetView>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="18"/>
  <cols>${colsXml}</cols>
  <sheetData>
    <row r="1">${headerRow}</row>
  </sheetData>
</worksheet>`;
}

function createZipBlob(entries) {
  const encoder = new TextEncoder();
  const encodedEntries = entries.map((entry) => ({
    nameBytes: encoder.encode(entry.name),
    data: encoder.encode(entry.text),
  }));
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  encodedEntries.forEach((entry) => {
    const crc = crc32(entry.data);
    const localHeader = new Uint8Array(30 + entry.nameBytes.length);
    const localView = new DataView(localHeader.buffer);
    localView.setUint32(0, 0x04034b50, true);
    localView.setUint16(4, 20, true);
    localView.setUint16(6, 0, true);
    localView.setUint16(8, 0, true);
    localView.setUint16(10, 0, true);
    localView.setUint16(12, 0, true);
    localView.setUint32(14, crc >>> 0, true);
    localView.setUint32(18, entry.data.length, true);
    localView.setUint32(22, entry.data.length, true);
    localView.setUint16(26, entry.nameBytes.length, true);
    localView.setUint16(28, 0, true);
    localHeader.set(entry.nameBytes, 30);
    localParts.push(localHeader, entry.data);

    const centralHeader = new Uint8Array(46 + entry.nameBytes.length);
    const centralView = new DataView(centralHeader.buffer);
    centralView.setUint32(0, 0x02014b50, true);
    centralView.setUint16(4, 20, true);
    centralView.setUint16(6, 20, true);
    centralView.setUint16(8, 0, true);
    centralView.setUint16(10, 0, true);
    centralView.setUint16(12, 0, true);
    centralView.setUint16(14, 0, true);
    centralView.setUint32(16, crc >>> 0, true);
    centralView.setUint32(20, entry.data.length, true);
    centralView.setUint32(24, entry.data.length, true);
    centralView.setUint16(28, entry.nameBytes.length, true);
    centralView.setUint16(30, 0, true);
    centralView.setUint16(32, 0, true);
    centralView.setUint16(34, 0, true);
    centralView.setUint16(36, 0, true);
    centralView.setUint32(38, 0, true);
    centralView.setUint32(42, offset, true);
    centralHeader.set(entry.nameBytes, 46);
    centralParts.push(centralHeader);

    offset += localHeader.length + entry.data.length;
  });

  const centralSize = centralParts.reduce((total, chunk) => total + chunk.length, 0);
  const endRecord = new Uint8Array(22);
  const endView = new DataView(endRecord.buffer);
  endView.setUint32(0, 0x06054b50, true);
  endView.setUint16(4, 0, true);
  endView.setUint16(6, 0, true);
  endView.setUint16(8, encodedEntries.length, true);
  endView.setUint16(10, encodedEntries.length, true);
  endView.setUint32(12, centralSize, true);
  endView.setUint32(16, offset, true);
  endView.setUint16(20, 0, true);

  return new Blob([...localParts, ...centralParts, endRecord], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}

function columnLabel(index) {
  let value = index;
  let label = "";
  while (value > 0) {
    const remainder = (value - 1) % 26;
    label = String.fromCharCode(65 + remainder) + label;
    value = Math.floor((value - 1) / 26);
  }
  return label;
}

function createCrc32Table() {
  const table = new Uint32Array(256);
  for (let index = 0; index < 256; index += 1) {
    let crc = index;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = crc & 1 ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1;
    }
    table[index] = crc >>> 0;
  }
  return table;
}

function crc32(bytes) {
  let crc = 0 ^ -1;
  for (let index = 0; index < bytes.length; index += 1) {
    crc = (crc >>> 8) ^ CRC32_TABLE[(crc ^ bytes[index]) & 0xff];
  }
  return (crc ^ -1) >>> 0;
}

function normalizeText(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function escapeXml(value) {
  return escapeHtml(value).replaceAll("'", "&apos;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("'", "&#39;");
}
