const STORAGE_KEY = "iti-miscellaneous-ranklist-v1";
const PORTAL_APP_NAME = "miscellaneous";
const PREVIEW_WIDTH = 1240;
const PREVIEW_SCALE = 2;
const { downloadExcelDocument } = window.OfficeExport || {};

document.documentElement.classList.toggle("is-embedded", window.parent !== window);
document.body.classList.toggle("is-embedded", window.parent !== window);

const dom = {
  saveStatus: document.getElementById("saveStatus"),
  toolButtons: Array.from(document.querySelectorAll("[data-tool]")),
  toolPanels: Array.from(document.querySelectorAll("[data-tool-panel]")),
  examTitleInput: document.getElementById("examTitleInput"),
  rawDataInput: document.getElementById("rawDataInput"),
  generateButton: document.getElementById("generateButton"),
  saveExamButton: document.getElementById("saveExamButton"),
  clearButton: document.getElementById("clearButton"),
  parseStatus: document.getElementById("parseStatus"),
  statsGrid: document.getElementById("statsGrid"),
  previewCanvas: document.getElementById("previewCanvas"),
  downloadExcelButton: document.getElementById("downloadExcelButton"),
  downloadImageButton: document.getElementById("downloadImageButton"),
  downloadPdfButton: document.getElementById("downloadPdfButton"),
  editorNote: document.getElementById("editorNote"),
  marksTableBody: document.getElementById("marksTableBody"),
  savedExamMonthFilter: document.getElementById("savedExamMonthFilter"),
  clearSavedExamMonthButton: document.getElementById("clearSavedExamMonthButton"),
  savedExamsList: document.getElementById("savedExamsList"),
};

const state = loadState();
let sharedContext = createDefaultSharedContext();
let lastResult = null;

initialize();

function initialize() {
  syncFormWithState();
  renderToolSelection();
  renderSavedExams();
  bindEvents();

  if (state.selectedExamId && !findSavedExamById(state.selectedExamId)) {
    state.selectedExamId = "";
  }

  const draft = normalizeExamRecord(state.draftExam);
  if (draft) {
    loadExamIntoWorkspace(draft, {
      silent: true,
      preserveSelection: true,
      saveMessage: "Saved locally",
    });
    return;
  }

  const selectedSavedExam = findSavedExamById(state.selectedExamId);
  if (selectedSavedExam) {
    loadExamIntoWorkspace(selectedSavedExam, {
      silent: true,
      preserveSelection: true,
      saveMessage: "Saved locally",
    });
    return;
  }

  if (state.rawData.trim()) {
    generateRankList({ silent: true });
    return;
  }

  renderStats(null);
  renderMarksEditor(null);
  renderEmptyPreview();
  updateExportButtons(false);
  updateSaveButton();
  setStatus("Paste the copied data and click Generate Rank List.", "muted");
}

function bindEvents() {
  dom.toolButtons.forEach((button) => {
    button.addEventListener("click", () => {
      state.activeTool = button.dataset.tool || "nimmiRankList";
      saveState("Saved locally");
      renderToolSelection();
    });
  });

  dom.examTitleInput.addEventListener("input", () => {
    state.examTitle = dom.examTitleInput.value;

    if (lastResult) {
      lastResult.title = resolvePreviewTitle(lastResult.examLabel, state.examTitle);
      renderCurrentResult({
        saveMessage: "Saved locally",
      });
      return;
    }

    saveState("Saved locally");
  });

  dom.rawDataInput.addEventListener("input", () => {
    state.rawData = dom.rawDataInput.value;

    if (
      state.selectedExamId
      && lastResult
      && normalizeInputText(state.rawData) !== normalizeInputText(lastResult.rawData)
    ) {
      state.selectedExamId = "";
      if (lastResult) {
        lastResult.id = "";
      }
      renderSavedExams();
      updateSaveButton();
    }

    saveState("Saved locally");

    if (!state.rawData.trim() && !lastResult) {
      setStatus("Paste the copied data and click Generate Rank List.", "muted");
      return;
    }

    setStatus("Source updated. Click Generate Rank List to refresh the preview.", "muted");
  });

  dom.generateButton.addEventListener("click", () => {
    generateRankList();
  });

  dom.saveExamButton.addEventListener("click", () => {
    handleSaveExam();
  });

  dom.clearButton.addEventListener("click", () => {
    clearCurrentWorkspace();
  });

  dom.downloadImageButton.addEventListener("click", () => {
    downloadPreviewImage();
  });

  dom.downloadExcelButton.addEventListener("click", () => {
    downloadPreviewExcel();
  });

  dom.downloadPdfButton.addEventListener("click", async () => {
    await downloadPreviewPdf();
  });

  dom.marksTableBody.addEventListener("change", (event) => {
    handleMarksTableChange(event);
  });

  dom.savedExamMonthFilter.addEventListener("change", () => {
    state.savedExamMonth = String(dom.savedExamMonthFilter.value || "");
    saveState("Saved locally");
    renderSavedExams();
  });

  dom.clearSavedExamMonthButton.addEventListener("click", () => {
    state.savedExamMonth = "";
    dom.savedExamMonthFilter.value = "";
    saveState("Saved locally");
    renderSavedExams();
  });

  dom.savedExamsList.addEventListener("click", (event) => {
    const button = event.target.closest("[data-action][data-exam-id]");
    if (!button) {
      return;
    }

    const examId = String(button.dataset.examId || "");
    const action = String(button.dataset.action || "");
    if (!examId || !action) {
      return;
    }

    if (action === "load") {
      loadSavedExam(examId);
      return;
    }

    if (action === "delete") {
      deleteSavedExam(examId);
    }
  });

  window.addEventListener("message", handlePortalMessage);
  window.addEventListener("resize", reportPortalHeight);
  window.addEventListener("load", notifyPortalReady);

  if (typeof ResizeObserver === "function") {
    const observer = new ResizeObserver(() => {
      reportPortalHeight();
    });
    observer.observe(document.querySelector(".app-shell") || document.body);
  }
}

function loadState() {
  try {
    const raw = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || "null");
    const savedExams = Array.isArray(raw?.savedExams)
      ? raw.savedExams.map((exam) => normalizeExamRecord(exam)).filter(Boolean)
      : [];

    return {
      activeTool: String(raw?.activeTool || "nimmiRankList"),
      examTitle: String(raw?.examTitle || ""),
      rawData: String(raw?.rawData || ""),
      selectedExamId: String(raw?.selectedExamId || ""),
      savedExamMonth: isMonthKey(raw?.savedExamMonth) ? String(raw.savedExamMonth) : "",
      savedExams,
      draftExam: normalizeExamRecord(raw?.draftExam),
    };
  } catch {
    return {
      activeTool: "nimmiRankList",
      examTitle: "",
      rawData: "",
      selectedExamId: "",
      savedExamMonth: "",
      savedExams: [],
      draftExam: null,
    };
  }
}

function saveState(message = "Saved locally") {
  window.localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify({
      activeTool: state.activeTool,
      examTitle: state.examTitle,
      rawData: state.rawData,
      selectedExamId: state.selectedExamId,
      savedExamMonth: state.savedExamMonth,
      savedExams: state.savedExams,
      draftExam: state.draftExam,
    }),
  );

  if (dom.saveStatus) {
    dom.saveStatus.textContent = message;
  }
}

function syncFormWithState() {
  dom.examTitleInput.value = state.examTitle;
  dom.rawDataInput.value = state.rawData;
  dom.savedExamMonthFilter.value = state.savedExamMonth;
}

function renderToolSelection() {
  dom.toolButtons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.tool === state.activeTool);
  });

  dom.toolPanels.forEach((panel) => {
    panel.hidden = panel.dataset.toolPanel !== state.activeTool;
  });
}

function generateRankList({ silent = false } = {}) {
  try {
    const result = parseRankListSource(state.rawData, state.examTitle, sharedContext.studentRecords);
    state.selectedExamId = "";
    lastResult = result;
    renderCurrentResult({
      saveMessage: "Preview updated",
    });

    if (!silent) {
      setStatus(
        `Generated rank list for ${result.registeredCount} trainee${result.registeredCount === 1 ? "" : "s"}.`,
        "success",
      );
    } else {
      setStatus(
        `Loaded ${result.registeredCount} trainee record${result.registeredCount === 1 ? "" : "s"}.`,
        "muted",
      );
    }
  } catch (error) {
    lastResult = null;
    state.draftExam = null;
    renderStats(null);
    renderMarksEditor(null);
    renderEmptyPreview();
    updateExportButtons(false);
    updateSaveButton();
    saveState("Saved locally");
    setStatus(error instanceof Error ? error.message : "Could not parse the pasted data.", "warning");
    notifyPortalApplied();
  }
}

function parseRankListSource(rawSource, titleInput, sharedStudents = []) {
  const raw = String(rawSource || "").replace(/\u00a0/g, " ");
  if (!raw.trim()) {
    throw new Error("Paste the NIMI exam data first.");
  }

  const lines = raw
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  const totalQuestions = extractNumber(raw, /Total Questions\s+(\d+)/i);
  if (!totalQuestions) {
    throw new Error("Total Questions was not found in the pasted data.");
  }

  const examNumber = extractText(raw, /Scheduled Exam No\s+([A-Z0-9]+)/i);
  const trade = extractText(raw, /Trade\s+(.+?)\s+Language\b/i);
  const language = extractText(raw, /Language\s+(.+?)\s+Scheduled Date\b/i);
  const scheduledDate = extractText(raw, /Scheduled Date\s+([0-9-]+)/i);
  const scheduledTiming = extractText(raw, /Scheduled Timing\s+([^\n\r]+)/i);
  const examLabel = findExamLabel(lines);

  const parsedStudents = lines
    .map(parseStudentLine)
    .filter(Boolean)
    .map((student, index) => buildPresentExamStudent(student, index, totalQuestions));

  if (!parsedStudents.length) {
    throw new Error("No student result rows were detected. Paste the full Attend Student List block.");
  }

  return synchronizeExamWithSharedRoster(
    {
      id: "",
      title: resolvePreviewTitle(examLabel, titleInput),
      examLabel,
      examNumber,
      trade,
      language,
      scheduledDate,
      scheduledTiming,
      totalQuestions,
      rawData: rawSource,
      students: parsedStudents,
      allowRosterSync: true,
      createdAt: "",
      updatedAt: "",
      savedAt: "",
    },
    sharedStudents,
  ).result;
}

function buildPresentExamStudent(student, parsedOrder, totalQuestions) {
  return {
    id: createExamStudentId(student.name, parsedOrder),
    recordId: "",
    name: formatDisplayName(student.name),
    admissionNo: "",
    guardianName: "",
    itiCode: String(student.itiCode || "").trim(),
    startLabel: student.startLabel,
    endLabel: student.endLabel,
    durationSeconds: student.durationSeconds,
    durationLabel: formatDuration(student.durationSeconds),
    correctAnswers: student.correctAnswers,
    markOutOf100: calculateMark(student.correctAnswers, totalQuestions),
    status: "present",
    origin: "parsed",
    homeOrder: Number.MAX_SAFE_INTEGER,
    parsedOrder,
    rank: "",
  };
}

function synchronizeExamWithSharedRoster(exam, sharedStudents) {
  const roster = normalizeSharedStudents(sharedStudents);
  const examClone = normalizeExamRecord(exam);

  if (!examClone) {
    return { result: null, changed: false };
  }

  if (!roster.length) {
    return {
      result: recalculateExamResult(examClone),
      changed: false,
    };
  }

  const lookup = buildSharedStudentLookup(roster);
  const usedRecordIds = new Set();
  const initiallyRetainedStudents = examClone.students
    .filter((student) => !(student.origin === "homeRoster" && student.status === "absent"))
    .map((student) => {
      const matchedRecord = resolveStudentRosterMatch(student, lookup, usedRecordIds);
      if (!matchedRecord) {
        return normalizeExamStudent(student, examClone.totalQuestions);
      }

      usedRecordIds.add(matchedRecord.id);
      return enrichStudentWithHomeRecord(student, matchedRecord, examClone.totalQuestions);
    });

  const fuzzyAssignments = assignSimilarityMatches(
    initiallyRetainedStudents.filter((student) => !student.recordId && student.status !== "absent"),
    roster.filter((record) => !usedRecordIds.has(record.id)),
    roster.length === initiallyRetainedStudents.length,
  );

  const retainedStudents = initiallyRetainedStudents.map((student) => {
    const matchedRecord = fuzzyAssignments.get(student.id);
    if (!matchedRecord) {
      return student;
    }

    usedRecordIds.add(matchedRecord.id);
    return enrichStudentWithHomeRecord(student, matchedRecord, examClone.totalQuestions);
  });

  const absentStudents = roster
    .filter((record) => !usedRecordIds.has(record.id))
    .map((record) => createAbsentStudentFromRecord(record, examClone.totalQuestions));

  return {
    result: recalculateExamResult({
      ...examClone,
      students: [...retainedStudents, ...absentStudents],
    }),
    changed:
      absentStudents.length > 0
      || retainedStudents.some((student) => Boolean(student.recordId))
      || fuzzyAssignments.size > 0,
  };
}

function buildSharedStudentLookup(records) {
  const byId = new Map();
  const byAdmission = new Map();
  const byExactName = new Map();
  const byAlias = new Map();
  const byFirstToken = new Map();

  records.forEach((record) => {
    byId.set(record.id, record);
    pushLookupValue(byAdmission, normalizeMatchToken(record.admissionNo), record);
    pushLookupValue(byExactName, normalizeMatchToken(record.name), record);
    pushLookupValue(byAlias, record.nameProfile.alias, record);
    pushLookupValue(byFirstToken, record.nameProfile.first, record);
  });

  return {
    byId,
    byAdmission,
    byExactName,
    byAlias,
    byFirstToken,
  };
}

function pushLookupValue(map, key, value) {
  if (!key) {
    return;
  }

  const list = map.get(key) || [];
  list.push(value);
  map.set(key, list);
}

function resolveStudentRosterMatch(student, lookup, usedRecordIds) {
  if (student.recordId && lookup.byId.has(student.recordId) && !usedRecordIds.has(student.recordId)) {
    return lookup.byId.get(student.recordId);
  }

  const admissionMatch = pickUniqueAvailable(
    lookup.byAdmission.get(normalizeMatchToken(student.admissionNo)) || [],
    usedRecordIds,
  );
  if (admissionMatch) {
    return admissionMatch;
  }

  const nameKey = normalizeMatchToken(student.name);
  const exactNameMatch = pickUniqueAvailable(lookup.byExactName.get(nameKey) || [], usedRecordIds);
  if (exactNameMatch) {
    return exactNameMatch;
  }

  const profile = buildNameProfile(student.name);
  const aliasMatch = pickUniqueAvailable(lookup.byAlias.get(profile.alias) || [], usedRecordIds);
  if (aliasMatch) {
    return aliasMatch;
  }

  const firstTokenCandidates = (lookup.byFirstToken.get(profile.first) || []).filter(
    (record) => !usedRecordIds.has(record.id),
  );
  if (firstTokenCandidates.length === 1) {
    return firstTokenCandidates[0];
  }

  const fuzzyCandidates = firstTokenCandidates.filter((record) => {
    const targetProfile = record.nameProfile;
    if (!profile.first || !targetProfile.first || profile.first !== targetProfile.first) {
      return false;
    }

    if (profile.joined && targetProfile.joined) {
      if (targetProfile.joined.includes(profile.joined) || profile.joined.includes(targetProfile.joined)) {
        return true;
      }
    }

    if (profile.initials && targetProfile.initials) {
      if (
        targetProfile.initials === profile.initials
        || targetProfile.initials.endsWith(profile.initials)
        || profile.initials.endsWith(targetProfile.initials)
      ) {
        return true;
      }
    }

    return false;
  });

  return fuzzyCandidates.length === 1 ? fuzzyCandidates[0] : null;
}

function pickUniqueAvailable(records, usedRecordIds) {
  const available = records.filter((record) => !usedRecordIds.has(record.id));
  return available.length === 1 ? available[0] : null;
}

function assignSimilarityMatches(students, records, mustResolveRosterCount) {
  if (!students.length || !records.length) {
    return new Map();
  }

  const assignments = new Map();
  const usedStudentIds = new Set();
  const usedRecordIds = new Set();
  const primaryThreshold = mustResolveRosterCount ? 0.52 : 0.72;

  greedyAssignSimilarityMatches({
    students,
    records,
    threshold: primaryThreshold,
    assignments,
    usedStudentIds,
    usedRecordIds,
  });

  if (!mustResolveRosterCount) {
    return assignments;
  }

  const remainingStudents = students.filter((student) => !usedStudentIds.has(student.id));
  const remainingRecords = records.filter((record) => !usedRecordIds.has(record.id));
  if (!remainingStudents.length || remainingStudents.length !== remainingRecords.length) {
    return assignments;
  }

  greedyAssignSimilarityMatches({
    students: remainingStudents,
    records: remainingRecords,
    threshold: 0.36,
    assignments,
    usedStudentIds,
    usedRecordIds,
    allowLooseFallback: true,
  });

  return assignments;
}

function greedyAssignSimilarityMatches({
  students,
  records,
  threshold,
  assignments,
  usedStudentIds,
  usedRecordIds,
  allowLooseFallback = false,
}) {
  const recordById = new Map(records.map((record) => [record.id, record]));
  const pairs = [];

  students.forEach((student) => {
    records.forEach((record) => {
      const score = scoreStudentRosterMatch(student, record);
      const compatible = isSimilarityMatchCompatible(student, record, score, allowLooseFallback);
      if (!compatible || score < threshold) {
        return;
      }

      pairs.push({
        studentId: student.id,
        recordId: record.id,
        score,
      });
    });
  });

  pairs
    .sort(
      (left, right) =>
        right.score - left.score
        || left.studentId.localeCompare(right.studentId)
        || left.recordId.localeCompare(right.recordId),
    )
    .forEach((pair) => {
      if (usedStudentIds.has(pair.studentId) || usedRecordIds.has(pair.recordId)) {
        return;
      }

      const record = recordById.get(pair.recordId);
      if (!record) {
        return;
      }

      assignments.set(pair.studentId, record);
      usedStudentIds.add(pair.studentId);
      usedRecordIds.add(pair.recordId);
    });
}

function scoreStudentRosterMatch(student, record) {
  const studentProfile = buildNameProfile(student.name);
  const recordProfile = record.nameProfile;

  if (!studentProfile.joined || !recordProfile.joined) {
    return 0;
  }

  if (studentProfile.joined === recordProfile.joined) {
    return 1;
  }

  const fullSimilarity = calculateStringSimilarity(studentProfile.joined, recordProfile.joined);
  const firstSimilarity = calculateStringSimilarity(studentProfile.first, recordProfile.first);
  let score = Math.max(fullSimilarity, firstSimilarity * 0.96);

  if (
    studentProfile.first
    && recordProfile.first
    && (studentProfile.first.startsWith(recordProfile.first) || recordProfile.first.startsWith(studentProfile.first))
  ) {
    score = Math.max(score, 0.9);
  }

  if (
    studentProfile.joined.includes(recordProfile.joined)
    || recordProfile.joined.includes(studentProfile.joined)
  ) {
    score = Math.max(score, 0.9);
  }

  if (studentProfile.initials && recordProfile.initials) {
    if (
      studentProfile.initials === recordProfile.initials
      || studentProfile.initials.endsWith(recordProfile.initials)
      || recordProfile.initials.endsWith(studentProfile.initials)
    ) {
      score += 0.07;
    }
  }

  if (
    studentProfile.first
    && recordProfile.first
    && studentProfile.first.charAt(0) === recordProfile.first.charAt(0)
  ) {
    score += 0.02;
  }

  return Math.min(score, 1);
}

function isSimilarityMatchCompatible(student, record, score, allowLooseFallback) {
  const studentProfile = buildNameProfile(student.name);
  const recordProfile = record.nameProfile;
  const firstSimilarity = calculateStringSimilarity(studentProfile.first, recordProfile.first);
  const fullSimilarity = calculateStringSimilarity(studentProfile.joined, recordProfile.joined);

  if (score >= 0.72 && firstSimilarity >= 0.55) {
    return true;
  }

  if (
    studentProfile.first
    && recordProfile.first
    && (studentProfile.first.startsWith(recordProfile.first) || recordProfile.first.startsWith(studentProfile.first))
  ) {
    return true;
  }

  if (allowLooseFallback) {
    return fullSimilarity >= 0.36 && firstSimilarity >= 0.32;
  }

  return fullSimilarity >= 0.5 && firstSimilarity >= 0.42;
}

function calculateStringSimilarity(left, right) {
  const source = String(left || "");
  const target = String(right || "");
  if (!source && !target) {
    return 1;
  }
  if (!source || !target) {
    return 0;
  }
  if (source === target) {
    return 1;
  }

  const maxLength = Math.max(source.length, target.length);
  if (!maxLength) {
    return 1;
  }

  return 1 - calculateLevenshteinDistance(source, target) / maxLength;
}

function calculateLevenshteinDistance(left, right) {
  const source = String(left || "");
  const target = String(right || "");
  const rows = source.length + 1;
  const cols = target.length + 1;
  const matrix = Array.from({ length: rows }, () => new Array(cols).fill(0));

  for (let row = 0; row < rows; row += 1) {
    matrix[row][0] = row;
  }

  for (let col = 0; col < cols; col += 1) {
    matrix[0][col] = col;
  }

  for (let row = 1; row < rows; row += 1) {
    for (let col = 1; col < cols; col += 1) {
      const cost = source[row - 1] === target[col - 1] ? 0 : 1;
      matrix[row][col] = Math.min(
        matrix[row - 1][col] + 1,
        matrix[row][col - 1] + 1,
        matrix[row - 1][col - 1] + cost,
      );
    }
  }

  return matrix[rows - 1][cols - 1];
}

function enrichStudentWithHomeRecord(student, record, totalQuestions) {
  return normalizeExamStudent(
    {
      ...student,
      recordId: record.id,
      name: record.name,
      admissionNo: student.admissionNo || record.admissionNo,
      guardianName: student.guardianName || record.guardianName,
      homeOrder: record.rosterOrder,
    },
    totalQuestions,
  );
}

function createAbsentStudentFromRecord(record, totalQuestions) {
  return normalizeExamStudent(
    {
      id: createExamStudentId(record.name || record.admissionNo || "absent", record.rosterOrder),
      recordId: record.id,
      name: record.name,
      admissionNo: record.admissionNo,
      guardianName: record.guardianName,
      itiCode: "",
      startLabel: "",
      endLabel: "",
      durationSeconds: null,
      durationLabel: "-",
      correctAnswers: null,
      markOutOf100: null,
      status: "absent",
      origin: "homeRoster",
      homeOrder: record.rosterOrder,
      parsedOrder: Number.MAX_SAFE_INTEGER,
      rank: "",
    },
    totalQuestions,
  );
}

function recalculateExamResult(exam) {
  const totalQuestions = Math.max(0, Number.parseInt(String(exam.totalQuestions || "0"), 10) || 0);
  const normalizedStudents = Array.isArray(exam.students)
    ? exam.students.map((student) => normalizeExamStudent(student, totalQuestions))
    : [];

  const presentStudents = normalizedStudents
    .filter((student) => student.status !== "absent")
    .sort(
      (left, right) =>
        (right.markOutOf100 ?? 0) - (left.markOutOf100 ?? 0)
        || (right.correctAnswers ?? 0) - (left.correctAnswers ?? 0)
        || (left.durationSeconds ?? Number.MAX_SAFE_INTEGER) - (right.durationSeconds ?? Number.MAX_SAFE_INTEGER)
        || left.name.localeCompare(right.name),
    )
    .map((student, index) => ({
      ...student,
      rank: index + 1,
    }));

  const absentStudents = normalizedStudents
    .filter((student) => student.status === "absent")
    .sort(
      (left, right) =>
        left.homeOrder - right.homeOrder
        || left.parsedOrder - right.parsedOrder
        || left.name.localeCompare(right.name),
    )
    .map((student) => ({
      ...student,
      rank: "",
    }));

  const students = [...presentStudents, ...absentStudents];
  const highestMark = presentStudents[0]?.markOutOf100 ?? 0;
  const averageMark = presentStudents.length
    ? Number(
        (
          presentStudents.reduce((sum, student) => sum + Number(student.markOutOf100 || 0), 0)
          / presentStudents.length
        ).toFixed(2),
      )
    : 0;

  return {
    ...normalizeExamRecord(exam),
    title: resolvePreviewTitle(exam.examLabel, exam.title),
    totalQuestions,
    students,
    highestMark,
    averageMark,
    presentCount: presentStudents.length,
    absentCount: absentStudents.length,
    registeredCount: students.length,
  };
}

function normalizeExamRecord(rawExam) {
  if (!rawExam || typeof rawExam !== "object") {
    return null;
  }

  const totalQuestions = Math.max(0, Number.parseInt(String(rawExam.totalQuestions || "0"), 10) || 0);
  return {
    id: String(rawExam.id || ""),
    title: String(rawExam.title || ""),
    examLabel: String(rawExam.examLabel || "NIMI Mock Test"),
    examNumber: String(rawExam.examNumber || ""),
    trade: String(rawExam.trade || ""),
    language: String(rawExam.language || ""),
    scheduledDate: String(rawExam.scheduledDate || ""),
    scheduledTiming: String(rawExam.scheduledTiming || ""),
    totalQuestions,
    rawData: String(rawExam.rawData || ""),
    students: Array.isArray(rawExam.students)
      ? rawExam.students.map((student) => normalizeExamStudent(student, totalQuestions))
      : [],
    allowRosterSync: Boolean(rawExam.allowRosterSync),
    createdAt: String(rawExam.createdAt || ""),
    updatedAt: String(rawExam.updatedAt || ""),
    savedAt: String(rawExam.savedAt || ""),
    highestMark: Number(rawExam.highestMark || 0),
    averageMark: Number(rawExam.averageMark || 0),
    presentCount: Number(rawExam.presentCount || 0),
    absentCount: Number(rawExam.absentCount || 0),
    registeredCount: Number(rawExam.registeredCount || 0),
  };
}

function normalizeExamStudent(rawStudent, totalQuestions) {
  const safeTotalQuestions = Math.max(0, Number.parseInt(String(totalQuestions || "0"), 10) || 0);
  const status = String(rawStudent?.status || "present").toLowerCase() === "absent" ? "absent" : "present";
  const correctAnswers = parseNumberOrNull(rawStudent?.correctAnswers);
  const clampedCorrectAnswers = Number.isFinite(correctAnswers)
    ? clampNumber(correctAnswers, 0, safeTotalQuestions || correctAnswers)
    : null;
  const durationSeconds = parseIntegerOrNull(rawStudent?.durationSeconds);
  const normalizedDuration = Number.isFinite(durationSeconds) ? Math.max(0, durationSeconds) : null;
  const markOutOf100 = status === "absent"
    ? null
    : calculateMark(clampedCorrectAnswers ?? 0, safeTotalQuestions);

  return {
    id: String(rawStudent?.id || createExamStudentId(rawStudent?.name || "student", 0)),
    recordId: String(rawStudent?.recordId || ""),
    name: formatDisplayName(rawStudent?.name || ""),
    admissionNo: String(rawStudent?.admissionNo || "").trim(),
    guardianName: String(rawStudent?.guardianName || "").trim(),
    itiCode: String(rawStudent?.itiCode || "").trim(),
    startLabel: String(rawStudent?.startLabel || "").trim(),
    endLabel: String(rawStudent?.endLabel || "").trim(),
    durationSeconds: normalizedDuration,
    durationLabel: status === "absent" || !Number.isFinite(normalizedDuration)
      ? "-"
      : formatDuration(normalizedDuration),
    correctAnswers: clampedCorrectAnswers,
    markOutOf100,
    status,
    origin: String(rawStudent?.origin || "parsed"),
    homeOrder: Number.isFinite(Number(rawStudent?.homeOrder))
      ? Number(rawStudent.homeOrder)
      : Number.MAX_SAFE_INTEGER,
    parsedOrder: Number.isFinite(Number(rawStudent?.parsedOrder))
      ? Number(rawStudent.parsedOrder)
      : Number.MAX_SAFE_INTEGER,
    rank: status === "absent" ? "" : rawStudent?.rank || "",
  };
}

function resolvePreviewTitle(examLabel, preferredTitle = "") {
  const title = String(preferredTitle || "").trim();
  return title || `${String(examLabel || "NIMI Mock Test").trim()} Rank List`;
}

function loadExamIntoWorkspace(exam, options = {}) {
  const normalizedExam = normalizeExamRecord(exam);
  if (!normalizedExam) {
    return;
  }

  lastResult = recalculateExamResult(normalizedExam);
  state.examTitle = lastResult.title;
  state.rawData = lastResult.rawData;

  if (!options.preserveSelection) {
    state.selectedExamId = lastResult.id || "";
  }

  syncFormWithState();
  renderCurrentResult({
    saveMessage: options.saveMessage || "Saved locally",
  });

  if (!options.silent) {
    setStatus(
      `Loaded "${lastResult.title}" with ${lastResult.registeredCount} trainee record${
        lastResult.registeredCount === 1 ? "" : "s"
      }.`,
      "success",
    );
  }
}

function renderCurrentResult({ saveMessage = "Saved locally" } = {}) {
  if (!lastResult) {
    renderStats(null);
    renderMarksEditor(null);
    renderEmptyPreview();
    updateExportButtons(false);
    updateSaveButton();
    state.draftExam = null;
    saveState(saveMessage);
    reportPortalHeight();
    notifyPortalApplied();
    return;
  }

  lastResult = recalculateExamResult(lastResult);
  renderStats(lastResult);
  renderMarksEditor(lastResult);
  renderPreview(lastResult);
  updateExportButtons(true);
  updateSaveButton();
  state.draftExam = deepClone(lastResult);
  saveState(saveMessage);
  renderSavedExams();
  reportPortalHeight();
  notifyPortalApplied();
}

function renderStats(result) {
  if (!result) {
    dom.statsGrid.innerHTML = [
      "Total Questions",
      "Present",
      "Absent",
      "Top Score",
      "Average / 100",
      "Exam No",
    ]
      .map(
        (label) => `
          <div class="stat-card">
            <span>${escapeHtml(label)}</span>
            <strong>-</strong>
          </div>
        `,
      )
      .join("");
    return;
  }

  const cards = [
    { label: "Total Questions", value: String(result.totalQuestions) },
    { label: "Present", value: String(result.presentCount) },
    { label: "Absent", value: String(result.absentCount) },
    { label: "Top Score", value: formatMark(result.highestMark) },
    { label: "Average / 100", value: formatMark(result.averageMark) },
    { label: "Exam No", value: result.examNumber || "-" },
  ];

  dom.statsGrid.innerHTML = cards
    .map(
      (card) => `
        <div class="stat-card">
          <span>${escapeHtml(card.label)}</span>
          <strong>${escapeHtml(card.value)}</strong>
        </div>
      `,
    )
    .join("");
}

function renderMarksEditor(result) {
  if (!result) {
    dom.editorNote.textContent = "Generate a rank list to edit trainee scores and mark absentees.";
    dom.marksTableBody.innerHTML = `
      <tr>
        <td colspan="7" class="marks-table__empty">Generate a rank list to start editing marks.</td>
      </tr>
    `;
    return;
  }

  dom.editorNote.textContent = buildEditorNote(result);

  dom.marksTableBody.innerHTML = result.students
    .map((student) => {
      const rowClasses = [
        student.status === "absent" ? "is-absent" : "",
        student.rank === 1 ? "is-top-1" : "",
        student.rank === 2 ? "is-top-2" : "",
        student.rank === 3 ? "is-top-3" : "",
      ]
        .filter(Boolean)
        .join(" ");

      const correctValue = student.status === "absent" ? "" : formatEditableNumber(student.correctAnswers);
      const markValue = student.status === "absent" ? "" : formatEditableNumber(student.markOutOf100);
      const timeText = student.status === "absent" ? "ABSENT" : student.durationLabel || "-";

      return `
        <tr class="${rowClasses}" data-student-id="${escapeAttribute(student.id)}">
          <td class="marks-rank">${student.status === "absent" ? "-" : escapeHtml(String(student.rank || "-"))}</td>
          <td class="marks-name">
            <strong>${escapeHtml(student.name)}</strong>
            <small>${escapeHtml(buildStudentSourceLabel(student))}</small>
          </td>
          <td class="marks-admission">
            ${escapeHtml(student.admissionNo || "-")}
            ${student.itiCode ? `<small>ITI Code: ${escapeHtml(student.itiCode)}</small>` : ""}
          </td>
          <td class="marks-status">
            <select class="marks-input" data-role="status-select">
              <option value="present" ${student.status === "present" ? "selected" : ""}>Present</option>
              <option value="absent" ${student.status === "absent" ? "selected" : ""}>Absent</option>
            </select>
          </td>
          <td>
            <input
              class="marks-input"
              data-role="correct-input"
              type="number"
              min="0"
              max="${escapeAttribute(String(result.totalQuestions || 0))}"
              step="0.01"
              value="${escapeAttribute(correctValue)}"
            />
          </td>
          <td>
            <input
              class="marks-input"
              data-role="mark-input"
              type="number"
              min="0"
              max="100"
              step="0.01"
              value="${escapeAttribute(markValue)}"
            />
          </td>
          <td class="marks-time ${student.status === "absent" ? "is-absent" : ""}">${escapeHtml(timeText)}</td>
        </tr>
      `;
    })
    .join("");
}

function buildEditorNote(result) {
  const autoAbsentCount = result.students.filter(
    (student) => student.origin === "homeRoster" && student.status === "absent",
  ).length;
  const unmatchedCount = result.students.filter(
    (student) => student.origin === "parsed" && !student.recordId,
  ).length;

  const parts = [
    `${result.registeredCount} trainee${result.registeredCount === 1 ? "" : "s"} are in this working exam.`,
    `${result.absentCount} marked ABSENT at the end.`,
    "Edit correct questions below and the mark out of 100 updates automatically.",
  ];

  if (autoAbsentCount > 0) {
    parts.unshift(`${autoAbsentCount} HOME trainee${autoAbsentCount === 1 ? "" : "s"} were added automatically.`);
  } else if (sharedContext.studentRecords.length) {
    parts.unshift("HOME student master is linked to this exam.");
  } else {
    parts.unshift("Paste the result and connect HOME student data to auto-add absentees.");
  }

  if (unmatchedCount > 0) {
    parts.push(
      `${unmatchedCount} pasted trainee result${unmatchedCount === 1 ? "" : "s"} could not be matched to HOME and were kept as separate entries.`,
    );
  }

  return parts.join(" ");
}

function buildStudentSourceLabel(student) {
  if (student.origin === "homeRoster" && student.status === "absent") {
    return "Auto-added from HOME as ABSENT";
  }

  if (student.origin === "homeRoster") {
    return "Added from HOME student master";
  }

  if (student.recordId) {
    return "Matched with HOME student master";
  }

  return "Detected from pasted NIMI data";
}

function updateSaveButton() {
  dom.saveExamButton.disabled = !lastResult;
  dom.saveExamButton.textContent = state.selectedExamId ? "Update Saved Exam" : "Save Exam";
}

function renderSavedExams() {
  const savedExams = [...state.savedExams]
    .map((exam) => normalizeExamRecord(exam))
    .filter(Boolean)
    .sort((left, right) =>
      getExamMonthKey(right).localeCompare(getExamMonthKey(left))
      || String(right.scheduledDate || "").localeCompare(String(left.scheduledDate || ""))
      || String(right.updatedAt || right.savedAt || "").localeCompare(String(left.updatedAt || left.savedAt || ""))
      || left.title.localeCompare(right.title),
    );

  const filteredExams = state.savedExamMonth
    ? savedExams.filter((exam) => getExamMonthKey(exam) === state.savedExamMonth)
    : savedExams;

  if (!filteredExams.length) {
    dom.savedExamsList.innerHTML = `
      <p class="saved-exams-empty">${
        state.savedExamMonth
          ? `No saved exams were found for ${escapeHtml(formatMonthLabel(state.savedExamMonth))}.`
          : "Saved exams will appear here."
      }</p>
    `;
    reportPortalHeight();
    return;
  }

  const groups = new Map();
  filteredExams.forEach((exam) => {
    const monthKey = getExamMonthKey(exam);
    const list = groups.get(monthKey) || [];
    list.push(exam);
    groups.set(monthKey, list);
  });

  dom.savedExamsList.innerHTML = Array.from(groups.entries())
    .map(
      ([monthKey, exams]) => `
        <section class="saved-month-group">
          <h3>${escapeHtml(formatMonthLabel(monthKey))}</h3>
          <div class="saved-month-group__grid">
            ${exams.map((exam) => buildSavedExamCard(exam)).join("")}
          </div>
        </section>
      `,
    )
    .join("");

  reportPortalHeight();
}

function buildSavedExamCard(exam) {
  const isSelected = exam.id && exam.id === state.selectedExamId;
  const scheduledLabel = formatDateLabel(exam.scheduledDate) || "Date not set";
  const savedLabel = formatDateTimeLabel(exam.updatedAt || exam.savedAt || exam.createdAt) || "Saved locally";

  return `
    <article class="saved-exam-card${isSelected ? " is-selected" : ""}">
      <div>
        <div class="saved-exam-title">
          <strong>${escapeHtml(exam.title || "Untitled Exam")}</strong>
          ${isSelected ? '<span class="saved-exam-badge">Current</span>' : ""}
        </div>
        <div class="saved-exam-meta">
          <span>${escapeHtml(scheduledLabel)}</span>
          <span>${escapeHtml(`Present: ${exam.presentCount || 0}`)}</span>
          <span>${escapeHtml(`Absent: ${exam.absentCount || 0}`)}</span>
          <span>${escapeHtml(`Questions: ${exam.totalQuestions || 0}`)}</span>
          <small>${escapeHtml(`Last saved: ${savedLabel}`)}</small>
        </div>
      </div>
      <div class="saved-exam-actions">
        <button class="ghost-button" type="button" data-action="load" data-exam-id="${escapeAttribute(exam.id)}">
          Load
        </button>
        <button class="ghost-button" type="button" data-action="delete" data-exam-id="${escapeAttribute(exam.id)}">
          Delete
        </button>
      </div>
    </article>
  `;
}

function handleMarksTableChange(event) {
  if (!lastResult) {
    return;
  }

  const target = event.target;
  const row = target.closest("[data-student-id]");
  if (!row) {
    return;
  }

  const studentId = String(row.dataset.studentId || "");
  const student = lastResult.students.find((item) => item.id === studentId);
  if (!student) {
    return;
  }

  if (target.dataset.role === "status-select") {
    student.status = target.value === "absent" ? "absent" : "present";
    if (student.status === "absent") {
      student.correctAnswers = null;
    } else if (!Number.isFinite(student.correctAnswers)) {
      student.correctAnswers = 0;
    }
    renderCurrentResult({
      saveMessage: "Saved locally",
    });
    setStatus("Trainee status updated.", "muted");
    return;
  }

  if (target.dataset.role === "correct-input") {
    const nextValue = String(target.value || "").trim();
    const parsedValue = nextValue ? parseNumberOrNull(nextValue) : 0;
    student.correctAnswers = Number.isFinite(parsedValue)
      ? clampNumber(parsedValue, 0, lastResult.totalQuestions)
      : 0;
    student.status = "present";
    renderCurrentResult({
      saveMessage: "Saved locally",
    });
    setStatus("Marks updated.", "muted");
    return;
  }

  if (target.dataset.role === "mark-input") {
    const nextValue = String(target.value || "").trim();
    const parsedValue = nextValue ? parseNumberOrNull(nextValue) : 0;
    const normalizedMark = Number.isFinite(parsedValue)
      ? clampNumber(parsedValue, 0, 100)
      : 0;
    student.correctAnswers = calculateCorrectAnswersFromMark(normalizedMark, lastResult.totalQuestions);
    student.status = "present";
    renderCurrentResult({
      saveMessage: "Saved locally",
    });
    setStatus("Marks updated.", "muted");
  }
}

function handleSaveExam() {
  if (!lastResult) {
    return;
  }

  const timestamp = new Date().toISOString();
  const existingIndex = state.savedExams.findIndex((exam) => exam.id === state.selectedExamId);
  const baseExam = deepClone(lastResult);
  baseExam.title = resolvePreviewTitle(baseExam.examLabel, state.examTitle || baseExam.title);
  baseExam.rawData = state.rawData;
  baseExam.id = state.selectedExamId || createExamId();
  baseExam.updatedAt = timestamp;
  baseExam.savedAt = existingIndex >= 0 ? state.savedExams[existingIndex].savedAt || timestamp : timestamp;
  baseExam.createdAt = existingIndex >= 0 ? state.savedExams[existingIndex].createdAt || timestamp : timestamp;
  baseExam.allowRosterSync = false;

  const normalizedSavedExam = recalculateExamResult(baseExam);

  if (existingIndex >= 0) {
    state.savedExams.splice(existingIndex, 1, normalizedSavedExam);
  } else {
    state.savedExams.push(normalizedSavedExam);
  }

  state.selectedExamId = normalizedSavedExam.id;
  lastResult = deepClone(normalizedSavedExam);
  renderCurrentResult({
    saveMessage: "Saved locally",
  });
  setStatus(`Saved "${normalizedSavedExam.title}" to the exam library.`, "success");
}

function loadSavedExam(examId) {
  const exam = findSavedExamById(examId);
  if (!exam) {
    return;
  }

  state.selectedExamId = exam.id;
  loadExamIntoWorkspace(exam, {
    preserveSelection: true,
    saveMessage: "Saved locally",
  });
  setStatus(`Loaded saved exam "${exam.title}".`, "success");
}

function deleteSavedExam(examId) {
  const exam = findSavedExamById(examId);
  if (!exam) {
    return;
  }

  const confirmed = window.confirm(`Delete "${exam.title}" from the saved exam library?`);
  if (!confirmed) {
    return;
  }

  state.savedExams = state.savedExams.filter((item) => item.id !== examId);

  if (state.selectedExamId === examId) {
    state.selectedExamId = "";
    if (lastResult?.id === examId) {
      lastResult.id = "";
    }
  }

  saveState("Saved locally");
  renderSavedExams();
  updateSaveButton();
  setStatus(`Deleted "${exam.title}" from the exam library.`, "muted");
}

function findSavedExamById(examId) {
  return state.savedExams.find((exam) => exam.id === examId) || null;
}

function clearCurrentWorkspace() {
  state.examTitle = "";
  state.rawData = "";
  state.selectedExamId = "";
  state.draftExam = null;
  lastResult = null;
  syncFormWithState();
  renderStats(null);
  renderMarksEditor(null);
  renderEmptyPreview();
  updateExportButtons(false);
  updateSaveButton();
  renderSavedExams();
  saveState("Cleared");
  setStatus("Cleared the current rank list workspace.", "muted");
  notifyPortalApplied();
}

function parseStudentLine(line) {
  if (
    !/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/.test(line)
    || /correct answer|view result|attend student list|scheduled exam no|trade|scheduled date/i.test(line)
  ) {
    return null;
  }

  const tabParts = line
    .split(/\t+/)
    .map((part) => part.trim())
    .filter(Boolean);

  if (
    tabParts.length >= 5
    && /\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/.test(tabParts[2] || "")
    && /\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/.test(tabParts[3] || "")
  ) {
    return buildStudentRecord(tabParts[0], tabParts[1], tabParts[2], tabParts[3], tabParts[4]);
  }

  const match = line.match(
    /^(.*?)\s+([A-Z0-9]{6,})\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+(\d+)(?:\s+.*)?$/i,
  );

  if (!match) {
    return null;
  }

  return buildStudentRecord(match[1], match[2], match[3], match[4], match[5]);
}

function buildStudentRecord(name, itiCode, startText, endText, correctText) {
  const startTime = new Date(String(startText || "").replace(" ", "T"));
  const endTime = new Date(String(endText || "").replace(" ", "T"));
  const correctAnswers = Number.parseInt(String(correctText || "").trim(), 10);

  if (!Number.isFinite(startTime.getTime()) || !Number.isFinite(endTime.getTime()) || !Number.isFinite(correctAnswers)) {
    return null;
  }

  const durationSeconds = Math.max(0, Math.round((endTime.getTime() - startTime.getTime()) / 1000));
  return {
    name: formatDisplayName(name),
    itiCode: String(itiCode || "").trim(),
    startLabel: String(startText || "").trim(),
    endLabel: String(endText || "").trim(),
    durationSeconds,
    correctAnswers,
  };
}

function findExamLabel(lines) {
  return (
    lines.find((line) =>
      /(mock test|exam)\b/i.test(line)
      && !/scheduled exam|attend scheduled exam list|view questions|dashboard|logout/i.test(line)
    )
    || "NIMI Mock Test"
  );
}

function formatDisplayName(name) {
  return String(name || "")
    .replace(/\s+/g, " ")
    .trim()
    .split(" ")
    .filter(Boolean)
    .map((token) =>
      token
        .split(".")
        .map((segment) => {
          if (!segment) {
            return "";
          }
          const lettersOnly = segment.replace(/[^A-Za-z]/g, "");
          if (lettersOnly && lettersOnly.length <= 2) {
            return segment.toUpperCase();
          }
          return segment.charAt(0).toUpperCase() + segment.slice(1).toLowerCase();
        })
        .join("."),
    )
    .join(" ");
}

function buildNameProfile(name) {
  const tokens = String(name || "")
    .toLowerCase()
    .replaceAll(".", " ")
    .replace(/[^a-z0-9\s]+/g, " ")
    .split(/\s+/)
    .filter(Boolean);

  const first = tokens[0] || "";
  const initials = tokens.slice(1).map((token) => token.charAt(0)).join("");

  return {
    tokens,
    first,
    initials,
    joined: tokens.join(""),
    alias: first ? `${first}|${initials}` : "",
  };
}

function extractText(source, pattern) {
  const match = String(source || "").match(pattern);
  return match?.[1] ? match[1].trim() : "";
}

function extractNumber(source, pattern) {
  const value = Number.parseInt(extractText(source, pattern), 10);
  return Number.isFinite(value) ? value : 0;
}

function renderPreview(result) {
  const logicalHeight = calculateCanvasHeight(result.students.length);
  const canvas = dom.previewCanvas;
  canvas.width = PREVIEW_WIDTH * PREVIEW_SCALE;
  canvas.height = logicalHeight * PREVIEW_SCALE;
  canvas.style.width = "";
  canvas.style.height = "";

  const ctx = canvas.getContext("2d");
  ctx.setTransform(PREVIEW_SCALE, 0, 0, PREVIEW_SCALE, 0, 0);
  ctx.clearRect(0, 0, PREVIEW_WIDTH, logicalHeight);

  drawRankListCanvas(ctx, result, logicalHeight);
  reportPortalHeight();
}

function calculateCanvasHeight(studentCount) {
  return 206 + 52 + 54 + 80 + studentCount * 60 + 32;
}

function drawRankListCanvas(ctx, result, logicalHeight) {
  const margin = 42;
  const sheetX = margin;
  const sheetY = margin;
  const sheetWidth = PREVIEW_WIDTH - margin * 2;
  const sheetHeight = logicalHeight - margin * 2;
  const innerX = sheetX + 48;
  const innerWidth = sheetWidth - 96;
  const columns = [
    { key: "rank", label: "Rank", width: 92, align: "center" },
    { key: "name", label: "Trainee Name", width: 432, align: "left" },
    { key: "correct", label: "Correct Questions", width: 172, align: "center" },
    { key: "mark", label: "Mark / 100", width: 160, align: "center" },
    { key: "duration", label: "Time Taken", width: 160, align: "center" },
  ];
  const rowHeight = 60;
  let cursorY = sheetY + 58;

  ctx.fillStyle = "#eef3f7";
  ctx.fillRect(0, 0, PREVIEW_WIDTH, logicalHeight);
  drawRoundedRect(ctx, sheetX, sheetY, sheetWidth, sheetHeight, 28, "#ffffff", "#000000", 2.5);

  drawWrappedCenteredText(ctx, result.title, PREVIEW_WIDTH / 2, cursorY, innerWidth, 42, 800, "#10212c");

  cursorY += 66;
  ctx.textAlign = "center";
  ctx.font = "700 18px Aptos, Segoe UI, sans-serif";
  ctx.fillStyle = "#5f6f7b";
  const metaLine = [
    result.trade ? `Trade: ${result.trade}` : "",
    result.language ? `Language: ${result.language}` : "",
    result.examNumber ? `Exam No: ${result.examNumber}` : "",
  ]
    .filter(Boolean)
    .join("  |  ");
  if (metaLine) {
    ctx.fillText(metaLine, PREVIEW_WIDTH / 2, cursorY);
    cursorY += 32;
  }

  const scheduleLine = [
    result.scheduledDate ? `Date: ${result.scheduledDate}` : "",
    result.scheduledTiming ? `Timing: ${result.scheduledTiming}` : "",
    `Total Questions: ${result.totalQuestions}`,
  ]
    .filter(Boolean)
    .join("  |  ");
  ctx.fillText(scheduleLine, PREVIEW_WIDTH / 2, cursorY);
  cursorY += 42;

  const chips = [
    { label: "Registered", value: String(result.registeredCount), fill: "#edf5ff", ink: "#214f8a" },
    { label: "Present", value: String(result.presentCount), fill: "#ecf9ef", ink: "#1e6a35" },
    { label: "Absent", value: String(result.absentCount), fill: "#fff5e8", ink: "#a05d10" },
    { label: "Top Score", value: formatMark(result.highestMark), fill: "#f4edff", ink: "#5b3b94" },
  ];
  const chipGap = 12;
  const chipWidth = (innerWidth - chipGap * (chips.length - 1)) / chips.length;
  let chipX = innerX;
  chips.forEach((chip) => {
    drawChip(ctx, chipX, cursorY, chipWidth, 46, chip, chip.fill, chip.ink);
    chipX += chipWidth + chipGap;
  });
  cursorY += 74;

  let columnX = innerX;
  columns.forEach((column) => {
    drawCell(ctx, columnX, cursorY, column.width, rowHeight, {
      fill: "#183f59",
      stroke: "#183f59",
      text: column.label,
      color: "#ffffff",
      fontSize: 20,
      fontWeight: 800,
      align: column.align,
    });
    columnX += column.width;
  });
  cursorY += rowHeight;

  result.students.forEach((student) => {
    const fill =
      student.status === "absent" ? "#fff3e6"
      : student.rank === 1 ? "#dff4e5"
      : student.rank === 2 ? "#e5f0ff"
      : student.rank === 3 ? "#fbe3e3"
      : Number(student.rank || 0) % 2 === 0 ? "#f9fbfd"
      : "#ffffff";
    const fontWeight = student.status === "absent" || Number(student.rank || 0) <= 3 ? 800 : 700;
    const rowValues = [
      student.status === "absent" ? "-" : String(student.rank),
      student.name,
      student.status === "absent"
        ? "ABSENT"
        : `${formatEditableNumber(student.correctAnswers) || "0"}/${result.totalQuestions}`,
      student.status === "absent" ? "ABSENT" : formatEditableNumber(student.markOutOf100),
      student.status === "absent" ? "-" : student.durationLabel,
    ];

    columnX = innerX;
    columns.forEach((column, columnIndex) => {
      drawCell(ctx, columnX, cursorY, column.width, rowHeight, {
        fill,
        stroke: "#d2dde5",
        text: rowValues[columnIndex],
        color: "#10212c",
        fontSize: column.key === "name" ? 20 : 18,
        fontWeight,
        align: column.align,
      });
      columnX += column.width;
    });

    cursorY += rowHeight;
  });

}

function drawChip(ctx, x, y, width, height, chip, fill, ink) {
  drawRoundedRect(ctx, x, y, width, height, 18, fill, fill);
  ctx.textAlign = "left";
  ctx.fillStyle = ink;
  ctx.font = "800 13px Aptos, Segoe UI, sans-serif";
  ctx.fillText(chip.label.toUpperCase(), x + 16, y + 18);
  ctx.font = "800 23px Aptos, Segoe UI, sans-serif";
  ctx.fillText(chip.value, x + 16, y + 37);
}

function drawCell(ctx, x, y, width, height, options) {
  ctx.fillStyle = options.fill;
  ctx.fillRect(x, y, width, height);
  ctx.strokeStyle = options.stroke;
  ctx.lineWidth = 1;
  ctx.strokeRect(x, y, width, height);

  ctx.fillStyle = options.color;
  ctx.font = `${options.fontWeight || 700} ${options.fontSize || 18}px Aptos, Segoe UI, sans-serif`;
  ctx.textAlign = options.align === "left" ? "left" : options.align === "right" ? "right" : "center";
  ctx.textBaseline = "middle";

  const textX =
    options.align === "left" ? x + 16
    : options.align === "right" ? x + width - 16
    : x + width / 2;
  ctx.fillText(String(options.text || ""), textX, y + height / 2 + 1, width - 24);
}

function drawWrappedCenteredText(ctx, text, centerX, topY, maxWidth, fontSize, fontWeight, color) {
  const lines = wrapText(ctx, text, maxWidth, fontSize, fontWeight);
  ctx.textAlign = "center";
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = color;
  ctx.font = `${fontWeight} ${fontSize}px Aptos, Segoe UI, sans-serif`;
  lines.slice(0, 2).forEach((line, index) => {
    ctx.fillText(line, centerX, topY + index * (fontSize + 8));
  });
}

function wrapText(ctx, text, maxWidth, fontSize, fontWeight) {
  ctx.font = `${fontWeight} ${fontSize}px Aptos, Segoe UI, sans-serif`;
  const words = String(text || "").split(/\s+/).filter(Boolean);
  if (!words.length) {
    return [""];
  }

  const lines = [];
  let current = words[0];

  for (let index = 1; index < words.length; index += 1) {
    const next = `${current} ${words[index]}`;
    if (ctx.measureText(next).width <= maxWidth) {
      current = next;
    } else {
      lines.push(current);
      current = words[index];
    }
  }

  lines.push(current);
  return lines;
}

function drawRoundedRect(ctx, x, y, width, height, radius, fill, stroke, strokeWidth = 1) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();

  ctx.fillStyle = fill;
  ctx.fill();
  ctx.strokeStyle = stroke;
  ctx.lineWidth = strokeWidth;
  ctx.stroke();
}

function renderEmptyPreview() {
  const canvas = dom.previewCanvas;
  const logicalHeight = 920;
  canvas.width = PREVIEW_WIDTH * PREVIEW_SCALE;
  canvas.height = logicalHeight * PREVIEW_SCALE;
  canvas.style.width = "";
  canvas.style.height = "";

  const ctx = canvas.getContext("2d");
  ctx.setTransform(PREVIEW_SCALE, 0, 0, PREVIEW_SCALE, 0, 0);
  ctx.clearRect(0, 0, PREVIEW_WIDTH, logicalHeight);

  ctx.fillStyle = "#eef3f7";
  ctx.fillRect(0, 0, PREVIEW_WIDTH, logicalHeight);
  drawRoundedRect(ctx, 36, 36, PREVIEW_WIDTH - 72, logicalHeight - 72, 28, "#ffffff", "#000000", 2.5);

  ctx.textAlign = "center";
  ctx.fillStyle = "#153d58";
  ctx.font = "800 34px Aptos, Segoe UI, sans-serif";
  ctx.fillText("NIMI Rank List Preview", PREVIEW_WIDTH / 2, 180);

  ctx.fillStyle = "#667884";
  ctx.font = "600 20px Aptos, Segoe UI, sans-serif";
  ctx.fillText("Paste the copied exam data, set the title, and generate the ranked preview here.", PREVIEW_WIDTH / 2, 238);

  drawRoundedRect(ctx, 136, 314, PREVIEW_WIDTH - 272, 340, 24, "#f7fafc", "#dde6ec");
  ctx.fillStyle = "#183f59";
  ctx.font = "800 24px Aptos, Segoe UI, sans-serif";
  ctx.fillText("Ready For Editable Marks, ABSENT Detection, Image And PDF Export", PREVIEW_WIDTH / 2, 422);
  ctx.fillStyle = "#6a7882";
  ctx.font = "600 18px Aptos, Segoe UI, sans-serif";
  ctx.fillText("The HOME student master is used to append missing trainees as ABSENT at the end.", PREVIEW_WIDTH / 2, 470);
  ctx.fillText("Edit correct questions below the preview and save each exam into the month-wise library.", PREVIEW_WIDTH / 2, 506);
  ctx.fillText("The same preview layout is used for both the PDF and image downloads.", PREVIEW_WIDTH / 2, 542);

  reportPortalHeight();
}

function updateExportButtons(enabled) {
  dom.downloadExcelButton.disabled = !enabled;
  dom.downloadImageButton.disabled = !enabled;
  dom.downloadPdfButton.disabled = !enabled;
}

function setStatus(message, tone = "muted") {
  dom.parseStatus.textContent = message;
  dom.parseStatus.classList.remove("is-success", "is-warning", "is-muted");
  if (tone === "success") {
    dom.parseStatus.classList.add("is-success");
  } else if (tone === "warning") {
    dom.parseStatus.classList.add("is-warning");
  } else {
    dom.parseStatus.classList.add("is-muted");
  }
}

function formatMark(value) {
  const rounded = Number(value || 0);
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2);
}

function formatEditableNumber(value) {
  if (!Number.isFinite(Number(value))) {
    return "";
  }

  return Number(value)
    .toFixed(2)
    .replace(/\.?0+$/, "");
}

function downloadPreviewImage() {
  if (!lastResult) {
    return;
  }

  dom.previewCanvas.toBlob((blob) => {
    if (!blob) {
      return;
    }
    downloadBlob(blob, buildFilename(lastResult.title, "png"));
  }, "image/png");
}

function downloadPreviewExcel() {
  if (!lastResult || typeof downloadExcelDocument !== "function") {
    return;
  }

  try {
    if (dom.saveStatus) {
      dom.saveStatus.textContent = "Preparing Excel...";
    }

    downloadExcelDocument({
      filename: buildFilename(lastResult.title, "xls"),
      title: lastResult.title || "NIMI Rank List",
      worksheetName: buildWorksheetName(lastResult.title),
      pageOrientation: "landscape",
      sources: buildExcelSourceNode(lastResult),
      extraStyles: `
        .nimmi-excel-sheet {
          width: 100%;
          max-width: 270mm;
          margin: 0 auto;
          border: 2px solid #000000;
          background: #ffffff;
          border-collapse: collapse;
          table-layout: fixed;
          font-family: Aptos, "Segoe UI", sans-serif;
          color: #000000;
        }

        .nimmi-excel-sheet > tbody > tr > td {
          padding: 7mm 8mm 8mm;
        }

        .nimmi-excel-heading-table,
        .nimmi-excel-stats-table,
        .nimmi-excel-rank-table {
          width: 100%;
          border-collapse: collapse;
          table-layout: fixed;
        }

        .nimmi-excel-title {
          padding: 3mm 0 4mm;
          border: none;
          text-align: center;
          font-size: 20pt;
          font-weight: 800;
          letter-spacing: 0.02em;
        }

        .nimmi-excel-meta-line {
          padding: 0 0 2.4mm;
          border: none;
          text-align: center;
          font-size: 10.5pt;
          font-weight: 700;
          color: #5f6f7b;
        }

        .nimmi-excel-stats-table {
          margin: 2mm 0 4mm;
        }

        .nimmi-excel-chip {
          padding: 2.4mm 3mm;
          border: 1px solid #000000;
          vertical-align: top;
        }

        .nimmi-excel-chip-label {
          width: 100%;
          display: block;
          margin-bottom: 1mm;
          font-size: 9pt;
          font-weight: 800;
          text-transform: uppercase;
          letter-spacing: 0.06em;
        }

        .nimmi-excel-chip-value {
          display: block;
          font-size: 15pt;
          font-weight: 800;
        }

        .nimmi-excel-chip--registered {
          background: #edf5ff;
          color: #214f8a;
        }

        .nimmi-excel-chip--present {
          background: #ecf9ef;
          color: #1e6a35;
        }

        .nimmi-excel-chip--absent {
          background: #fff5e8;
          color: #a05d10;
        }

        .nimmi-excel-chip--top {
          background: #f4edff;
          color: #5b3b94;
        }

        .nimmi-excel-rank-table th,
        .nimmi-excel-rank-table td {
          border: 1px solid #000000;
          padding: 2.2mm 2.6mm;
          font-size: 10pt;
          vertical-align: middle;
        }

        .nimmi-excel-rank-table th {
          background: #183f59;
          color: #ffffff;
          text-align: center;
          font-weight: 800;
        }

        .nimmi-excel-rank-table td:nth-child(1),
        .nimmi-excel-rank-table td:nth-child(3),
        .nimmi-excel-rank-table td:nth-child(4),
        .nimmi-excel-rank-table td:nth-child(5) {
          text-align: center;
        }

        .nimmi-excel-row--top-1 td {
          background: #dff4e5;
        }

        .nimmi-excel-row--top-2 td {
          background: #e5f0ff;
        }

        .nimmi-excel-row--top-3 td {
          background: #fbe3e3;
        }

        .nimmi-excel-row--absent td {
          background: #fff3e6;
          font-weight: 800;
        }

        .nimmi-excel-row--band td {
          background: #f9fbfd;
        }
      `,
    });

    if (dom.saveStatus) {
      dom.saveStatus.textContent = "Excel downloaded";
    }
  } catch (error) {
    console.error(error);
    if (dom.saveStatus) {
      dom.saveStatus.textContent = "Could not generate Excel in the browser.";
    }
  }
}

async function downloadPreviewPdf() {
  if (!lastResult) {
    return;
  }

  const pdfDoc = await PDFLib.PDFDocument.create();
  const canvas = dom.previewCanvas;
  const pageWidth = 595.28;
  const pageHeight = 841.89;
  const margin = 24;
  const contentWidth = pageWidth - margin * 2;
  const contentHeight = pageHeight - margin * 2;
  const sliceHeightPx = Math.max(
    1,
    Math.floor((canvas.width / PREVIEW_SCALE) * (contentHeight / contentWidth) * PREVIEW_SCALE),
  );

  for (let offset = 0; offset < canvas.height; offset += sliceHeightPx) {
    const sliceCanvas = document.createElement("canvas");
    const sliceHeight = Math.min(sliceHeightPx, canvas.height - offset);
    sliceCanvas.width = canvas.width;
    sliceCanvas.height = sliceHeight;

    const sliceContext = sliceCanvas.getContext("2d");
    sliceContext.drawImage(
      canvas,
      0,
      offset,
      canvas.width,
      sliceHeight,
      0,
      0,
      canvas.width,
      sliceHeight,
    );

    const image = await pdfDoc.embedPng(sliceCanvas.toDataURL("image/png"));
    const scaledHeight = (sliceHeight / canvas.width) * contentWidth;
    const page = pdfDoc.addPage([pageWidth, pageHeight]);
    page.drawImage(image, {
      x: margin,
      y: pageHeight - margin - scaledHeight,
      width: contentWidth,
      height: scaledHeight,
    });
  }

  const bytes = await pdfDoc.save();
  downloadBlob(new Blob([bytes], { type: "application/pdf" }), buildFilename(lastResult.title, "pdf"));
}

function buildFilename(title, extension) {
  const safeBase = String(title || "nimmi-rank-list")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    || "nimmi-rank-list";
  return `${safeBase}.${extension}`;
}

function buildWorksheetName(title) {
  const text = String(title || "Rank List").trim() || "Rank List";
  return text.slice(0, 31);
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function buildExcelSourceNode(result) {
  const wrapper = document.createElement("div");
  wrapper.className = "nimmi-excel-export-root";
  const metaLine = [
    result.trade ? `Trade: ${result.trade}` : "",
    result.language ? `Language: ${result.language}` : "",
    result.examNumber ? `Exam No: ${result.examNumber}` : "",
  ]
    .filter(Boolean)
    .join("  |  ");
  const scheduleLine = [
    result.scheduledDate ? `Date: ${result.scheduledDate}` : "",
    result.scheduledTiming ? `Timing: ${result.scheduledTiming}` : "",
    `Total Questions: ${result.totalQuestions}`,
  ]
    .filter(Boolean)
    .join("  |  ");

  wrapper.innerHTML = `
    <table class="nimmi-excel-sheet">
      <tbody>
        <tr>
          <td>
            <table class="nimmi-excel-heading-table">
              <tbody>
                <tr>
                  <td class="nimmi-excel-title">${escapeHtml(result.title || "NIMI Rank List")}</td>
                </tr>
                ${
                  metaLine
                    ? `
                      <tr>
                        <td class="nimmi-excel-meta-line">${escapeHtml(metaLine)}</td>
                      </tr>
                    `
                    : ""
                }
                <tr>
                  <td class="nimmi-excel-meta-line">${escapeHtml(scheduleLine)}</td>
                </tr>
              </tbody>
            </table>

            <table class="nimmi-excel-stats-table">
              <tbody>
                <tr>
                  <td class="nimmi-excel-chip nimmi-excel-chip--registered">
                    <span class="nimmi-excel-chip-label">Registered</span>
                    <span class="nimmi-excel-chip-value">${escapeHtml(String(result.registeredCount || 0))}</span>
                  </td>
                  <td class="nimmi-excel-chip nimmi-excel-chip--present">
                    <span class="nimmi-excel-chip-label">Present</span>
                    <span class="nimmi-excel-chip-value">${escapeHtml(String(result.presentCount || 0))}</span>
                  </td>
                  <td class="nimmi-excel-chip nimmi-excel-chip--absent">
                    <span class="nimmi-excel-chip-label">Absent</span>
                    <span class="nimmi-excel-chip-value">${escapeHtml(String(result.absentCount || 0))}</span>
                  </td>
                  <td class="nimmi-excel-chip nimmi-excel-chip--top">
                    <span class="nimmi-excel-chip-label">Top Score</span>
                    <span class="nimmi-excel-chip-value">${escapeHtml(formatEditableNumber(result.highestMark))}</span>
                  </td>
                </tr>
              </tbody>
            </table>

            <table class="nimmi-excel-rank-table">
              <colgroup>
                <col style="width:9.055%;" />
                <col style="width:42.52%;" />
                <col style="width:16.929%;" />
                <col style="width:15.748%;" />
                <col style="width:15.748%;" />
              </colgroup>
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Trainee Name</th>
                  <th>Correct Questions</th>
                  <th>Mark / 100</th>
                  <th>Time Taken</th>
                </tr>
              </thead>
              <tbody>
                ${result.students.map((student, index) => buildExcelStudentRow(student, result.totalQuestions, index)).join("")}
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>
  `;

  return wrapper;
}

function buildExcelStudentRow(student, totalQuestions, index) {
  const rowClasses = [
    student.status === "absent" ? "nimmi-excel-row--absent" : "",
    student.rank === 1 ? "nimmi-excel-row--top-1" : "",
    student.rank === 2 ? "nimmi-excel-row--top-2" : "",
    student.rank === 3 ? "nimmi-excel-row--top-3" : "",
    student.status !== "absent" && Number(student.rank || 0) > 3 && index % 2 === 1
      ? "nimmi-excel-row--band"
      : "",
  ]
    .filter(Boolean)
    .join(" ");

  return `
    <tr class="${rowClasses}">
      <td>${escapeHtml(student.status === "absent" ? "-" : String(student.rank || "-"))}</td>
      <td>${escapeHtml(student.name || "-")}</td>
      <td>${escapeHtml(
        student.status === "absent"
          ? "ABSENT"
          : `${formatEditableNumber(student.correctAnswers) || "0"}/${totalQuestions}`,
      )}</td>
      <td>${escapeHtml(student.status === "absent" ? "ABSENT" : formatEditableNumber(student.markOutOf100))}</td>
      <td>${escapeHtml(student.status === "absent" ? "-" : student.durationLabel || "-")}</td>
    </tr>
  `;
}

function handlePortalMessage(event) {
  if (event.data?.type !== "portal-shared-update" || event.data?.app !== PORTAL_APP_NAME) {
    return;
  }

  sharedContext = normalizeSharedContext(event.data.payload);

  if (lastResult && !state.selectedExamId && lastResult.allowRosterSync) {
    lastResult = synchronizeExamWithSharedRoster(lastResult, sharedContext.studentRecords).result;
    renderCurrentResult({
      saveMessage: "Saved locally",
    });
    setStatus("HOME student master synced into the working exam.", "muted");
    return;
  }

  notifyPortalApplied();
}

function createDefaultSharedContext() {
  return {
    studentRecords: [],
  };
}

function normalizeSharedContext(payload) {
  const studentRecords = Array.isArray(payload?.studentRecords)
    ? payload.studentRecords
        .map((record, index) => normalizeSharedStudent(record, index))
        .filter(Boolean)
    : [];

  return {
    studentRecords,
  };
}

function normalizeSharedStudent(record, index) {
  const name = formatDisplayName(record?.name || "");
  const admissionNo = String(record?.admissionNo || record?.admNo || "").trim();
  const guardianName = String(record?.guardianName || record?.fatherName || "").trim();

  if (!name && !admissionNo) {
    return null;
  }

  return {
    id: String(record?.id || `home-${index}`),
    name,
    admissionNo,
    guardianName,
    rosterOrder: index,
    nameProfile: buildNameProfile(name),
  };
}

function normalizeSharedStudents(records) {
  return Array.isArray(records)
    ? records
        .map((record, index) => normalizeSharedStudent(record, index))
        .filter(Boolean)
    : [];
}

function notifyPortalReady() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage({ type: "portal:ready", app: PORTAL_APP_NAME }, "*");
  reportPortalHeight();
}

function notifyPortalApplied() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:applied", app: PORTAL_APP_NAME, height: getPortalHeight() },
    "*",
  );
}

function reportPortalHeight() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:height", app: PORTAL_APP_NAME, height: getPortalHeight() },
    "*",
  );
}

function getPortalHeight() {
  const shell = document.querySelector(".app-shell");
  const bodyStyles = window.getComputedStyle(document.body);
  const bodyMargins =
    (Number.parseFloat(bodyStyles.marginTop) || 0)
    + (Number.parseFloat(bodyStyles.marginBottom) || 0);
  const contentHeight = shell
    ? Math.max(shell.scrollHeight || 0, shell.offsetHeight || 0)
    : Math.max(
      document.documentElement?.scrollHeight || 0,
      document.body?.scrollHeight || 0,
      document.documentElement?.offsetHeight || 0,
      document.body?.offsetHeight || 0,
    );

  return contentHeight + bodyMargins;
}

function calculateMark(correctAnswers, totalQuestions) {
  const safeTotalQuestions = Number(totalQuestions || 0);
  const safeCorrectAnswers = Number(correctAnswers || 0);
  if (!safeTotalQuestions) {
    return 0;
  }

  return Number(((safeCorrectAnswers / safeTotalQuestions) * 100).toFixed(2));
}

function calculateCorrectAnswersFromMark(markOutOf100, totalQuestions) {
  const safeMark = Number(markOutOf100 || 0);
  const safeTotalQuestions = Number(totalQuestions || 0);
  if (!safeTotalQuestions) {
    return 0;
  }

  return Number(((safeMark / 100) * safeTotalQuestions).toFixed(2));
}

function formatDuration(totalSeconds) {
  const seconds = Math.max(0, Number(totalSeconds || 0));
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;

  if (hours > 0) {
    return `${hours}h ${String(minutes).padStart(2, "0")}m`;
  }

  return `${minutes}m ${String(remainingSeconds).padStart(2, "0")}s`;
}

function parseIntegerOrNull(value) {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  const parsed = Number.parseInt(String(value), 10);
  return Number.isFinite(parsed) ? parsed : null;
}

function parseNumberOrNull(value) {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  const parsed = Number.parseFloat(String(value));
  return Number.isFinite(parsed) ? parsed : null;
}

function clampNumber(value, min, max) {
  if (!Number.isFinite(value)) {
    return min;
  }

  return Math.min(Math.max(value, min), max);
}

function createExamId() {
  return `exam-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function createExamStudentId(name, index) {
  return `student-${normalizeMatchToken(name || "student") || "entry"}-${index}-${Math.random()
    .toString(36)
    .slice(2, 6)}`;
}

function deepClone(value) {
  return value ? JSON.parse(JSON.stringify(value)) : value;
}

function normalizeMatchToken(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function normalizeInputText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function getExamMonthKey(exam) {
  const dateSource = String(exam?.scheduledDate || exam?.updatedAt || exam?.savedAt || exam?.createdAt || "");
  const match = dateSource.match(/^(\d{4})-(\d{2})/);
  return match ? `${match[1]}-${match[2]}` : "unknown";
}

function isMonthKey(value) {
  return /^\d{4}-\d{2}$/.test(String(value || ""));
}

function formatMonthLabel(monthKey) {
  if (!isMonthKey(monthKey)) {
    return "Unknown Month";
  }

  const date = new Date(`${monthKey}-01T00:00:00`);
  return new Intl.DateTimeFormat("en-IN", { month: "long", year: "numeric" }).format(date);
}

function formatDateLabel(dateText) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dateText || ""))) {
    return "";
  }

  const date = new Date(`${dateText}T00:00:00`);
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
}

function formatDateTimeLabel(dateText) {
  const date = new Date(String(dateText || ""));
  if (!Number.isFinite(date.getTime())) {
    return "";
  }

  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#96;");
}
