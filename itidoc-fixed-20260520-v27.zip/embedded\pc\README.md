# Progress Chart Builder

Standalone website for preparing:

- `A3`-style main progress sheets for half-year blocks
- Monthly cut-and-paste sheets that match the uploaded `pc.pdf` page size

## Open

Open [index.html](</F:/CODEX/pc/index.html>) directly in your browser.

## Features

- Editable institution, title, trade, year, shift, and unit
- Editable 12-month list with automatic 6 + 6 half split
- Editable trainee roster
- Month-wise percentage entry for `PS`, `PK`, `ES`, `WCS`, and `AT`
- Auto colour mapping using editable threshold bands
- Tabbed previews for the main sheet and the monthly A4 cut-and-paste print
- Monthly A4 page contains one exact month strip that matches the main sheet month width and height
- PDF downloads for:
  - Current coloured main half
  - Current blank main half
  - Both main halves
  - Selected monthly A4 sheet
- No local server required
