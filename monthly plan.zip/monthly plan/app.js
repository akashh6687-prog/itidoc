const STORAGE_KEY = "iti-unified-portal-shared-v1";
const TAB_KEY = "iti-unified-portal-active-tab-v1";

const DEFAULT_SHARED_STATE = {
  institution: "Govt: Industrial Training Institute panniyannore",
  tradeName: "D/CIVIL",
  progressChartTitle: "TRAINEES PROGRESS & ATTENDANCE CHART",
  monthlyPlanHeading: "D/CIVIL  2025-27    ( JUNIORS )  (II nd Shift)",
  academicSpan: "2025-2027",
  progressAcademicYear: "2025-26",
  shiftLabel: "II nd Shift",
  shiftShort: "II",
  unit: "1",
  trainingYear: "1",
  rosterText: [
    "837/25 | ABHIJITH K J | JANEESH K M",
    "822/25 | ADISH U P | PAVITHRAN U P",
    "797/25 | ANUNANDANA C V | SURESH BABU C V",
    "853/25 | DEVANANDA.K.V | ANILKUMAR K V",
    "833/25 | DEVAPRIYA M K | AJITH KUMAR.M.K",
    "794/25 | DEVIKA M | SMIJITH M",
    "809/25 | DHARSANA P | VIJESH P",
    "813/25 | DIYA RAJEEVAN M T K | RAJEEVAN M T K",
    "795/25 | GOPIKA C M | RADHAKRISHNAN",
    "814/25 | GOPIKA.T.P | SREENIVASAN T P",
    "897/25 | MOHAMMED MISHAL K P | BASHEER M",
    "801/25 | NAJAH ABOOBACKER V K | ABOOBACKER.V.K",
    "851/25 | NAVATHEJ.K.P | SUKUMARAN.K.P",
    "796/25 | NIDHIYA T M | SUDHEER T M",
    "887/25 | RITHIN CHANDRAN | CHANDRAN P",
    "831/25 | SHARON P K | P K PRASHOB",
    "808/25 | SIVAPRIYA E | CHANDRAN E",
    "857/25 | SRAVAN MANU | MANOHARAN K V",
    "810/25 | SREE LAKSHMI K P | ANILKUMAR A P",
    "805/25 | VISHNU C K | UTHAMAN C K",
    "811/25 | VISMAYA T | SURESH BABU T",
  ].join("\n"),
};

const FRAME_CONFIG = {
  monthly: { frameId: "monthlyFrame", statusId: "monthlyStatus" },
  progress: { frameId: "progressFrame", statusId: "progressStatus" },
  annex: { frameId: "annexFrame", statusId: "annexStatus" },
};

const dom = {
  fields: [...document.querySelectorAll("[data-shared-key]")],
  tabButtons: [...document.querySelectorAll(".tab-button[data-tab]")],
  tabPanels: [...document.querySelectorAll(".tab-panel[data-panel]")],
  syncNowButton: document.getElementById("syncNowButton"),
  resetSharedButton: document.getElementById("resetSharedButton"),
};

let sharedState = loadSharedState();
let activeTab = loadActiveTab();
let syncTimer = 0;

initialize();

function initialize() {
  syncFormWithState();
  setActiveTab(activeTab);
  bindEvents();
  updateSummary();
  queueBroadcast("initial");
}

function bindEvents() {
  dom.tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setActiveTab(button.dataset.tab);
    });
  });

  dom.fields.forEach((field) => {
    field.addEventListener("input", handleFieldInput);
    if (field.type === "month" || field.type === "date") {
      field.addEventListener("change", handleFieldInput);
    }
  });

  dom.syncNowButton.addEventListener("click", () => {
    broadcastSharedState("manual");
  });

  dom.resetSharedButton.addEventListener("click", () => {
    const confirmed = window.confirm("Reset the shared common details for all tabs?");
    if (!confirmed) {
      return;
    }

    sharedState = structuredClone(DEFAULT_SHARED_STATE);
    saveSharedState();
    syncFormWithState();
    updateSummary();
    broadcastSharedState("reset");
  });

  Object.entries(FRAME_CONFIG).forEach(([appName, config]) => {
    const frame = document.getElementById(config.frameId);
    if (!frame) {
      return;
    }

    frame.addEventListener("load", () => {
      setStatus(appName, "Waiting", "waiting");
      queueBroadcast(`load-${appName}`);
    });
  });

  window.addEventListener("message", handleEmbeddedMessage);
}

function handleFieldInput(event) {
  const key = event.target.dataset.sharedKey;
  sharedState[key] = event.target.value;
  saveSharedState();
  updateSummary();
  queueBroadcast(`field-${key}`);
}

function loadSharedState() {
  try {
    const saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || "null");
    if (!saved || typeof saved !== "object") {
      return structuredClone(DEFAULT_SHARED_STATE);
    }

    return {
      ...structuredClone(DEFAULT_SHARED_STATE),
      ...saved,
    };
  } catch {
    return structuredClone(DEFAULT_SHARED_STATE);
  }
}

function saveSharedState() {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(sharedState));
}

function loadActiveTab() {
  const hashTab = window.location.hash.replace(/^#/, "").trim();
  if (hashTab) {
    return hashTab;
  }

  const saved = window.localStorage.getItem(TAB_KEY);
  return saved || "common";
}

function setActiveTab(tabName) {
  activeTab = Object.prototype.hasOwnProperty.call(FRAME_CONFIG, tabName) || tabName === "common" ? tabName : "common";
  window.localStorage.setItem(TAB_KEY, activeTab);
  window.history.replaceState(null, "", `#${activeTab}`);

  dom.tabButtons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.tab === activeTab);
  });

  dom.tabPanels.forEach((panel) => {
    panel.classList.toggle("is-active", panel.dataset.panel === activeTab);
  });
}

function syncFormWithState() {
  dom.fields.forEach((field) => {
    const key = field.dataset.sharedKey;
    field.value = sharedState[key] ?? "";
  });
}

function updateSummary() {
  document.title = sharedState.tradeName?.trim()
    ? `ITI DOC - ${sharedState.tradeName.trim()}`
    : "ITI DOC";
}

function queueBroadcast(reason) {
  window.clearTimeout(syncTimer);
  Object.keys(FRAME_CONFIG).forEach((appName) => {
    setStatus(appName, "Queued", "waiting");
  });
  syncTimer = window.setTimeout(() => {
    broadcastSharedState(reason);
  }, 180);
}

function broadcastSharedState(reason = "manual") {
  const payload = buildSharedPayload();
  Object.entries(FRAME_CONFIG).forEach(([appName, config]) => {
    const frame = document.getElementById(config.frameId);
    if (!frame?.contentWindow) {
      setStatus(appName, "Loading", "waiting");
      return;
    }

    setStatus(appName, "Syncing", "waiting");
    frame.contentWindow.postMessage(
      {
        type: "portal-shared-update",
        app: appName,
        reason,
        payload,
      },
      "*",
    );
  });
}

function buildSharedPayload() {
  const rosterEntries = parseRoster(sharedState.rosterText);

  return {
    institution: String(sharedState.institution || ""),
    tradeName: String(sharedState.tradeName || ""),
    progressChartTitle: String(sharedState.progressChartTitle || ""),
    monthlyPlanHeading: String(sharedState.monthlyPlanHeading || ""),
    academicSpan: String(sharedState.academicSpan || ""),
    progressAcademicYear: String(sharedState.progressAcademicYear || ""),
    shiftLabel: String(sharedState.shiftLabel || ""),
    shiftShort: String(sharedState.shiftShort || ""),
    unit: String(sharedState.unit || ""),
    trainingYear: String(sharedState.trainingYear || ""),
    rosterText: String(sharedState.rosterText || ""),
    rosterEntries,
    progressTrade: normaliseTradeForProgress(sharedState.tradeName),
    annexTradeName: normaliseTradeForAnnex(sharedState.tradeName),
  };
}

function handleEmbeddedMessage(event) {
  const data = event.data;
  if (!data || typeof data !== "object" || !data.type || !data.app) {
    return;
  }

  if (!Object.prototype.hasOwnProperty.call(FRAME_CONFIG, data.app)) {
    return;
  }

  if (data.type === "portal:ready") {
    setStatus(data.app, "Ready", "waiting");
    const frame = document.getElementById(FRAME_CONFIG[data.app].frameId);
    if (frame?.contentWindow) {
      frame.contentWindow.postMessage(
        {
          type: "portal-shared-update",
          app: data.app,
          reason: "ready",
          payload: buildSharedPayload(),
        },
        "*",
      );
    }
    return;
  }

  if (data.type === "portal:applied") {
    setStatus(data.app, "Synced", "ready");
    if (Number.isFinite(data.height)) {
      setFrameHeight(data.app, data.height);
    }
    return;
  }

  if (data.type === "portal:height" && Number.isFinite(data.height)) {
    setFrameHeight(data.app, data.height);
  }
}

function setFrameHeight(appName, height) {
  const frame = document.getElementById(FRAME_CONFIG[appName].frameId);
  if (!frame) {
    return;
  }

  const safeHeight = Math.max(760, Math.min(6000, Math.ceil(height) + 12));
  frame.style.height = `${safeHeight}px`;
}

function setStatus(appName, label, tone = "") {
  const config = FRAME_CONFIG[appName];
  const node = config ? document.getElementById(config.statusId) : null;
  if (!node) {
    return;
  }

  node.textContent = label;
  node.classList.remove("is-ready", "is-waiting", "is-error");
  if (tone === "ready") {
    node.classList.add("is-ready");
  } else if (tone === "waiting") {
    node.classList.add("is-waiting");
  } else if (tone === "error") {
    node.classList.add("is-error");
  }
}

function parseRoster(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map(parseRosterLine)
    .filter((entry) => entry.name || entry.admNo || entry.fatherName);
}

function parseRosterLine(line) {
  const parts = line
    .split("|")
    .map((part) => part.trim())
    .filter(Boolean);

  if (!parts.length) {
    return { admNo: "", name: "", fatherName: "" };
  }

  if (parts.length === 1) {
    return { admNo: "", name: parts[0], fatherName: "" };
  }

  if (parts.length === 2) {
    if (looksLikeAdmission(parts[0])) {
      return { admNo: parts[0], name: parts[1], fatherName: "" };
    }

    if (looksLikeAdmission(parts[1])) {
      return { admNo: parts[1], name: parts[0], fatherName: "" };
    }

    return { admNo: "", name: parts[0], fatherName: parts[1] };
  }

  if (looksLikeAdmission(parts[0])) {
    return { admNo: parts[0], name: parts[1], fatherName: parts.slice(2).join(" | ") };
  }

  if (looksLikeAdmission(parts[1])) {
    return { admNo: parts[1], name: parts[0], fatherName: parts.slice(2).join(" | ") };
  }

  return { admNo: "", name: parts[0], fatherName: parts.slice(1).join(" | ") };
}

function looksLikeAdmission(value) {
  return /[0-9]/.test(value) && (value.includes("/") || value.includes("-") || value.length <= 12);
}

function normaliseTradeForProgress(value) {
  return String(value || "")
    .trim()
    .replace(/\s+/g, " ");
}

function normaliseTradeForAnnex(value) {
  return String(value || "")
    .trim()
    .replace(/\s+/g, " ");
}
