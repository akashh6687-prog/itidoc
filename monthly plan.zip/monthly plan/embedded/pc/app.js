const {
  COLOR_STYLES,
  METRICS,
  createDefaultState,
  createEmptyMetricSet,
  formatDisplayMonth,
  getHalfMonths,
  getHalfRangeLabel,
  getLegendData,
  getMainLayout,
  getMonthPanelLayout,
  getMetricColor,
  getMetricDescription,
  parseRoster,
  serializeRoster,
} = globalThis.ProgressChartShared;
const {
  buildDownloadName,
  createAllMainPdfBytes,
  createMainPdfBytes,
  createMonthlyPdfBytes,
  downloadPdfBytes,
} = globalThis.ProgressChartPdf;

const STORAGE_KEY = "pc-progress-chart-state-v1";
const PREVIEW_TAB_STORAGE_KEY = "pc-progress-chart-preview-tab-v1";
const WORKSPACE_TAB_STORAGE_KEY = "pc-progress-chart-workspace-tab-v1";

const dom = {
  workspaceTabs: document.querySelector("#workspaceTabs"),
  detailsWorkspacePanel: document.querySelector("#detailsWorkspacePanel"),
  previewWorkspacePanel: document.querySelector("#previewWorkspacePanel"),
  institutionInput: document.querySelector("#institutionInput"),
  titleInput: document.querySelector("#titleInput"),
  tradeInput: document.querySelector("#tradeInput"),
  yearInput: document.querySelector("#yearInput"),
  shiftInput: document.querySelector("#shiftInput"),
  unitInput: document.querySelector("#unitInput"),
  monthsGrid: document.querySelector("#monthsGrid"),
  rosterTextarea: document.querySelector("#rosterTextarea"),
  applyRosterButton: document.querySelector("#applyRosterButton"),
  resetDefaultsButton: document.querySelector("#resetDefaultsButton"),
  ruleGroups: document.querySelector("#ruleGroups"),
  marksEditor: document.querySelector("#marksEditor"),
  mainSheet: document.querySelector("#mainSheet"),
  monthlySheet: document.querySelector("#monthlySheet"),
  mainPreviewShell: document.querySelector("#mainPreviewShell"),
  monthlyPreviewShell: document.querySelector("#monthlyPreviewShell"),
  mainPreviewStage: document.querySelector("#mainPreviewStage"),
  monthlyPreviewStage: document.querySelector("#monthlyPreviewStage"),
  mainPreviewPanel: document.querySelector("#mainPreviewPanel"),
  monthlyPreviewPanel: document.querySelector("#monthlyPreviewPanel"),
  previewTabs: document.querySelector("#previewTabs"),
  halfToggle: document.querySelector("#halfToggle"),
  downloadHalfButton: document.querySelector("#downloadHalfButton"),
  downloadBlankHalfButton: document.querySelector("#downloadBlankHalfButton"),
  downloadAllMainButton: document.querySelector("#downloadAllMainButton"),
  selectedMonthInput: document.querySelector("#selectedMonthInput"),
  previewMonthSelect: document.querySelector("#previewMonthSelect"),
  downloadMonthlyButton: document.querySelector("#downloadMonthlyButton"),
  saveStatus: document.querySelector("#saveStatus"),
  studentCountStat: document.querySelector("#studentCountStat"),
  selectedMonthStat: document.querySelector("#selectedMonthStat"),
  selectedHalfStat: document.querySelector("#selectedHalfStat"),
};

let state = loadState();
let activePreviewTab = loadPreviewTab();
let activeWorkspaceTab = loadWorkspaceTab();

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultState();
    return ensureState(JSON.parse(raw));
  } catch (error) {
    console.warn("Could not load saved state.", error);
    return createDefaultState();
  }
}

function saveState(message = "Saved locally") {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  dom.saveStatus.textContent = message;
}

function loadPreviewTab() {
  const saved = localStorage.getItem(PREVIEW_TAB_STORAGE_KEY);
  return saved === "monthly" ? "monthly" : "main";
}

function savePreviewTab() {
  localStorage.setItem(PREVIEW_TAB_STORAGE_KEY, activePreviewTab);
}

function loadWorkspaceTab() {
  const saved = localStorage.getItem(WORKSPACE_TAB_STORAGE_KEY);
  return saved === "preview" ? "preview" : "details";
}

function saveWorkspaceTab() {
  localStorage.setItem(WORKSPACE_TAB_STORAGE_KEY, activeWorkspaceTab);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function syncHeaderControls() {
  dom.institutionInput.value = state.header.institution;
  dom.titleInput.value = state.header.title;
  dom.tradeInput.value = state.header.trade;
  dom.yearInput.value = state.header.academicYear;
  dom.shiftInput.value = state.header.shift;
  dom.unitInput.value = state.header.unit;
}

function renderMonthsEditor() {
  dom.monthsGrid.innerHTML = state.months
    .map(
      (month, index) => `
        <label class="field">
          <span>Month ${index + 1}</span>
          <input data-month-index="${index}" type="text" value="${escapeHtml(month.label)}" />
        </label>
      `,
    )
    .join("");
}

function renderMonthSelectors() {
  const options = state.months
    .map(
      (month, index) =>
        `<option value="${index}" ${index === state.selectedMonth ? "selected" : ""}>${escapeHtml(month.label)}</option>`,
    )
    .join("");
  dom.selectedMonthInput.innerHTML = options;
  dom.previewMonthSelect.innerHTML = options;
}

function renderRuleEditors() {
  dom.ruleGroups.innerHTML = Object.entries(state.rules)
    .map(([group, bands]) => {
      const rows = bands
        .map(
          (band, index) => `
            <tr>
              <td>
                <span class="rule-swatch">
                  <span class="rule-dot" style="background:${COLOR_STYLES[band.color].fill}"></span>
                  ${escapeHtml(band.color.toUpperCase())}
                </span>
              </td>
              <td>
                <input data-rule-group="${group}" data-rule-index="${index}" data-rule-field="min" type="number" min="0" max="100" value="${band.min}" />
              </td>
              <td>
                <input data-rule-group="${group}" data-rule-index="${index}" data-rule-field="max" type="number" min="0" max="100" value="${band.max}" />
              </td>
            </tr>
          `,
        )
        .join("");

      return `
        <section class="rule-group">
          <h3>${escapeHtml(group.charAt(0).toUpperCase() + group.slice(1))}</h3>
          <table class="rule-table">
            <thead>
              <tr>
                <th>Band</th>
                <th>Min %</th>
                <th>Max %</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        </section>
      `;
    })
    .join("");
}

function renderRoster() {
  dom.rosterTextarea.value = serializeRoster(state.students);
}

function renderStats() {
  dom.studentCountStat.textContent = String(state.students.length);
  dom.selectedMonthStat.textContent = state.months[state.selectedMonth]?.label ?? "-";
  dom.selectedHalfStat.textContent = state.selectedHalf === 0 ? "Half 1" : "Half 2";
}

function renderToggleButtons() {
  const buttons = dom.halfToggle.querySelectorAll("button");
  buttons.forEach((button) => {
    const active = Number(button.dataset.half) === state.selectedHalf;
    button.classList.toggle("is-active", active);
  });
}

function renderPreviewTabs() {
  const buttons = dom.previewTabs.querySelectorAll("button[data-preview-tab]");
  buttons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.previewTab === activePreviewTab);
  });
  dom.mainPreviewPanel.classList.toggle("is-active", activePreviewTab === "main");
  dom.monthlyPreviewPanel.classList.toggle("is-active", activePreviewTab === "monthly");
}

function renderWorkspaceTabs() {
  const buttons = dom.workspaceTabs.querySelectorAll("button[data-workspace-tab]");
  buttons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.workspaceTab === activeWorkspaceTab);
  });
  dom.detailsWorkspacePanel.classList.toggle("is-active", activeWorkspaceTab === "details");
  dom.previewWorkspacePanel.classList.toggle("is-active", activeWorkspaceTab === "preview");
}

function setActivePreviewTab(tab) {
  activePreviewTab = tab === "monthly" ? "monthly" : "main";
  savePreviewTab();
  renderPreviewTabs();
  requestAnimationFrame(() => {
    fitActivePreview();
  });
}

function setActiveWorkspaceTab(tab) {
  activeWorkspaceTab = tab === "preview" ? "preview" : "details";
  saveWorkspaceTab();
  renderWorkspaceTabs();
  requestAnimationFrame(() => {
    fitActivePreview();
  });
}

function getMainTableMarkup() {
  const layout = getMainLayout(state.students.length);
  const months = getHalfMonths(state.months, state.selectedHalf);
  const monthOffset = state.selectedHalf * 6;
  const rangeLabel = getHalfRangeLabel(state.months, state.selectedHalf);
  const legendRows = getLegendData(state.rules);

  const monthHeaders = months
    .map(
      (month) => `<th class="month-head" colspan="${METRICS.length}" style="height:${layout.header.month}mm">${escapeHtml(
        formatDisplayMonth(month.label),
      )}</th>`,
    )
    .join("");

  const subHeaders = months
    .map(
      () =>
        METRICS.map(
          (metric) =>
            `<th style="height:${layout.header.metric}mm;width:${layout.metricColumnWidth}mm">${escapeHtml(metric.short)}</th>`,
        ).join(""),
    )
    .join("");

  const bodyRows = state.students
    .map((student, studentIndex) => {
      const monthCells = months
        .map((_, monthSlot) =>
          METRICS.map((metric) => {
            const value = state.records?.[monthOffset + monthSlot]?.[studentIndex]?.[metric.key];
            const color = getMetricColor(metric.key, value, state.rules);
            return `
              <td style="width:${layout.metricColumnWidth}mm;height:${layout.rowHeight}mm" title="${escapeHtml(
                `${metric.short}: ${value ?? "blank"} (${getMetricDescription(metric.key)})`,
              )}">
                <div class="cell-center"><span class="score-dot score-dot--${color}"></span></div>
              </td>
            `;
          }).join(""),
        )
        .join("");

      return `
        <tr>
          <td style="width:${layout.fixedColumns.serial}mm;height:${layout.rowHeight}mm"><div class="sheet-row-number">${studentIndex + 1}</div></td>
          <td style="width:${layout.fixedColumns.name}mm;height:${layout.rowHeight}mm"><div class="sheet-name">${escapeHtml(student.name)}</div></td>
          <td style="width:${layout.fixedColumns.admission}mm;height:${layout.rowHeight}mm"><div class="sheet-admission">${escapeHtml(
            student.admission,
          )}</div></td>
          ${monthCells}
        </tr>
      `;
    })
    .join("");

  const definitionRows = [
    "PS : PRACTICAL SKILL",
    "PK : PRACTICAL KNOWLEDGE",
    "ES : EMPLOYABILITY SKILLS",
    "WCS : WORKSHOP CALCULATION & SCIENCE",
    "AT : ATTENDANCE PERCENTAGE",
  ]
    .map((text) => `<tr><td class="align-left">${escapeHtml(text)}</td></tr>`)
    .join("");

  const colorLegendRows = legendRows
    .map(
      (row) => `
        <tr>
          <td class="color-cell color-${row.color}">${escapeHtml(row.color.toUpperCase())}</td>
          <td>${escapeHtml(
            row.practical.min <= 0
              ? `Practical < ${row.practical.max + 1}%`
              : row.practical.max >= 100
                ? `Practical ${row.practical.min}% and above`
                : `Practical ${row.practical.min}% to ${row.practical.max}%`,
          )}</td>
          <td>${escapeHtml(
            row.theory.min <= 0
              ? `ES / WCS / ED < ${row.theory.max + 1}%`
              : row.theory.max >= 100
                ? `ES / WCS / ED ${row.theory.min}% and above`
                : `ES / WCS / ED ${row.theory.min}% to ${row.theory.max}%`,
          )}</td>
          <td>${escapeHtml(
            row.attendance.min <= 0
              ? `Attendance below ${row.attendance.max + 1}%`
              : row.attendance.max >= 100
                ? `Attendance ${row.attendance.min}% to ${row.attendance.max}%`
                : `Attendance ${row.attendance.min}% to ${row.attendance.max}%`,
          )}</td>
        </tr>
      `,
    )
    .join("");

  return `
    <div class="sheet-main-header">
      <div class="sheet-banner sheet-banner--institution">${escapeHtml(state.header.institution.toUpperCase())}</div>
      <div class="sheet-banner sheet-banner--range">${escapeHtml(rangeLabel)}</div>
      <div class="sheet-banner sheet-banner--title">${escapeHtml(state.header.title.toUpperCase())}</div>
    </div>

    <div class="sheet-meta-row">
      <div class="sheet-meta-box sheet-meta-box--trade">TRADE : ${escapeHtml(state.header.trade)}</div>
      <div class="sheet-meta-box sheet-meta-box--year">YEAR : ${escapeHtml(state.header.academicYear)}</div>
      <div class="sheet-meta-box">SHIFT : ${escapeHtml(state.header.shift)}</div>
      <div class="sheet-meta-box">UNIT : ${escapeHtml(state.header.unit)}</div>
    </div>

    <table class="sheet-table main-table">
      <colgroup>
        <col style="width:${layout.fixedColumns.serial}mm" />
        <col style="width:${layout.fixedColumns.name}mm" />
        <col style="width:${layout.fixedColumns.admission}mm" />
        ${Array.from({ length: 6 * METRICS.length })
          .map(() => `<col style="width:${layout.metricColumnWidth}mm" />`)
          .join("")}
      </colgroup>
      <thead>
        <tr>
          <th rowspan="2" style="height:${layout.header.month + layout.header.metric}mm">SL.NO</th>
          <th rowspan="2" style="height:${layout.header.month + layout.header.metric}mm">NAME OF TRAINEE</th>
          <th rowspan="2" style="height:${layout.header.month + layout.header.metric}mm">AD NO.</th>
          ${monthHeaders}
        </tr>
        <tr>${subHeaders}</tr>
      </thead>
      <tbody>${bodyRows}</tbody>
    </table>

    <div class="main-legend">
      <table class="legend-table">
        <tbody>${definitionRows}</tbody>
      </table>
      <table class="legend-table">
        <colgroup>
          <col style="width:40mm" />
          <col style="width:61mm" />
          <col style="width:74mm" />
          <col />
        </colgroup>
        <tbody>${colorLegendRows}</tbody>
      </table>
    </div>
  `;
}

function getMonthlyTableMarkup() {
  const panel = getMonthPanelLayout(state.students.length);
  const monthLabel = state.months[state.selectedMonth]?.label ?? `Month ${state.selectedMonth + 1}`;

  const bodyRows = state.students
    .map((student, studentIndex) => {
      const record = state.records?.[state.selectedMonth]?.[studentIndex] ?? createEmptyMetricSet();
      const metricCells = METRICS.map((metric) => {
        const value = record[metric.key];
        const color = getMetricColor(metric.key, value, state.rules);
        return `
          <td style="width:${panel.metricColumnWidth}mm;height:${panel.rowHeight}mm" title="${escapeHtml(
            `${metric.short}: ${value ?? "blank"} (${getMetricDescription(metric.key)})`,
          )}">
            <div class="cell-center"><span class="score-dot score-dot--${color}"></span></div>
          </td>
        `;
      }).join("");

      return `
        <tr>
          ${metricCells}
        </tr>
      `;
    })
    .join("");

  return `
    <div class="monthly-a4-frame">
      <div class="monthly-cut-panel-wrap" style="width:${panel.widthMm}mm;height:${panel.heightMm}mm">
        <span class="crop-mark crop-mark--h crop-mark--tl-h"></span>
        <span class="crop-mark crop-mark--v crop-mark--tl-v"></span>
        <span class="crop-mark crop-mark--h crop-mark--tr-h"></span>
        <span class="crop-mark crop-mark--v crop-mark--tr-v"></span>
        <span class="crop-mark crop-mark--h crop-mark--bl-h"></span>
        <span class="crop-mark crop-mark--v crop-mark--bl-v"></span>
        <span class="crop-mark crop-mark--h crop-mark--br-h"></span>
        <span class="crop-mark crop-mark--v crop-mark--br-v"></span>

        <table class="sheet-table month-strip-table">
          <colgroup>
            ${METRICS.map(() => `<col style="width:${panel.metricColumnWidth}mm" />`).join("")}
          </colgroup>
          <thead>
            <tr>
              <th class="month-head" colspan="${METRICS.length}" style="height:${panel.header.month}mm">${escapeHtml(
                formatDisplayMonth(monthLabel),
              )}</th>
            </tr>
            <tr>
              ${METRICS.map((metric) => `<th style="height:${panel.header.metric}mm">${escapeHtml(metric.short)}</th>`).join("")}
            </tr>
          </thead>
          <tbody>${bodyRows}</tbody>
        </table>
      </div>
    </div>
  `;
}

function renderMarksEditor() {
  const rows = state.students
    .map((student, studentIndex) => {
      const record = state.records?.[state.selectedMonth]?.[studentIndex] ?? createEmptyMetricSet();
      const inputs = METRICS.map((metric) => {
        const value = record[metric.key];
        const color = getMetricColor(metric.key, value, state.rules);
        return `
          <td class="metric-cell">
            <input
              type="number"
              min="0"
              max="100"
              placeholder="-"
              data-student-index="${studentIndex}"
              data-metric="${metric.key}"
              value="${value ?? ""}"
            />
            <small class="muted-inline">${escapeHtml(COLOR_STYLES[color].name)}</small>
          </td>
        `;
      }).join("");

      return `
        <tr>
          <td>${studentIndex + 1}</td>
          <td>
            <strong>${escapeHtml(student.name)}</strong>
            <small>${escapeHtml(student.admission)}</small>
          </td>
          ${inputs}
        </tr>
      `;
    })
    .join("");

  dom.marksEditor.innerHTML = `
    <table class="marks-table">
      <thead>
        <tr>
          <th>Sl.No</th>
          <th>Trainee</th>
          ${METRICS.map((metric) => `<th>${escapeHtml(metric.short)}</th>`).join("")}
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

function fitSheet(shell, stageElement, pageElement) {
  if (!shell || !stageElement || !pageElement) return;
  const shellStyles = getComputedStyle(shell);
  const horizontalPadding = parseFloat(shellStyles.paddingLeft) + parseFloat(shellStyles.paddingRight);
  const verticalPadding = parseFloat(shellStyles.paddingTop) + parseFloat(shellStyles.paddingBottom);
  const frameWidth = shell.clientWidth - horizontalPadding;
  const frameHeight = shell.clientHeight - verticalPadding;
  const pageWidth = pageElement.offsetWidth;
  const pageHeight = pageElement.offsetHeight;
  const scale = Math.min(1, frameWidth / pageWidth, frameHeight / pageHeight);

  stageElement.style.width = `${pageWidth * scale}px`;
  stageElement.style.height = `${pageHeight * scale}px`;
  pageElement.style.transform = `scale(${scale})`;
}

function fitActivePreview() {
  if (activePreviewTab === "monthly") {
    fitSheet(dom.monthlyPreviewShell, dom.monthlyPreviewStage, dom.monthlySheet);
    return;
  }
  fitSheet(dom.mainPreviewShell, dom.mainPreviewStage, dom.mainSheet);
}

function renderPreviews() {
  dom.mainSheet.innerHTML = getMainTableMarkup();
  dom.monthlySheet.innerHTML = getMonthlyTableMarkup();
  renderPreviewTabs();
  requestAnimationFrame(() => {
    fitActivePreview();
  });
}

function renderAll() {
  syncHeaderControls();
  renderMonthsEditor();
  renderMonthSelectors();
  renderRuleEditors();
  renderRoster();
  renderMarksEditor();
  renderToggleButtons();
  renderWorkspaceTabs();
  renderPreviewTabs();
  renderStats();
  renderPreviews();
}

function updateHeader(key, value) {
  state.header[key] = value.trim();
  saveState();
  renderStats();
  renderPreviews();
}

function resizeRecords(newStudents) {
  const nextRecords = Array.from({ length: state.months.length }, (_, monthIndex) =>
    Array.from({ length: newStudents.length }, (_, studentIndex) => {
      const existing = state.records?.[monthIndex]?.[studentIndex];
      return existing
        ? { ...existing }
        : {
            PS: null,
            PK: null,
            ES: null,
            WCS: null,
            AT: null,
          };
    }),
  );
  state.students = newStudents;
  state.records = nextRecords;
}

async function runPdfDownload(buildPdf, filename) {
  try {
    dom.saveStatus.textContent = "Preparing PDF...";
    const bytes = await buildPdf();
    downloadPdfBytes(bytes, filename);
    dom.saveStatus.textContent = "PDF downloaded";
  } catch (error) {
    console.error(error);
    dom.saveStatus.textContent = "Could not generate PDF in the browser.";
  }
}

function applyRuleChange(input) {
  const group = input.dataset.ruleGroup;
  const index = Number(input.dataset.ruleIndex);
  const field = input.dataset.ruleField;
  const value = Math.max(0, Math.min(100, Number(input.value || 0)));
  const target = state.rules[group][index];
  target[field] = value;
  if (field === "min" && target.min > target.max) target.max = target.min;
  if (field === "max" && target.max < target.min) target.min = target.max;
  saveState();
  renderRuleEditors();
  renderMarksEditor();
  renderPreviews();
}

function onWindowResize() {
  fitActivePreview();
}

syncHeaderControls();
renderAll();

dom.workspaceTabs.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-workspace-tab]");
  if (!button) return;
  setActiveWorkspaceTab(button.dataset.workspaceTab);
});

dom.previewTabs.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-preview-tab]");
  if (!button) return;
  setActivePreviewTab(button.dataset.previewTab);
});

dom.institutionInput.addEventListener("input", (event) => updateHeader("institution", event.target.value));
dom.titleInput.addEventListener("input", (event) => updateHeader("title", event.target.value));
dom.tradeInput.addEventListener("input", (event) => updateHeader("trade", event.target.value));
dom.yearInput.addEventListener("input", (event) => updateHeader("academicYear", event.target.value));
dom.shiftInput.addEventListener("input", (event) => updateHeader("shift", event.target.value));
dom.unitInput.addEventListener("input", (event) => updateHeader("unit", event.target.value));

dom.monthsGrid.addEventListener("input", (event) => {
  const input = event.target.closest("input[data-month-index]");
  if (!input) return;
  const index = Number(input.dataset.monthIndex);
  state.months[index].label = input.value;
  saveState();
  renderMonthSelectors();
  renderStats();
  renderPreviews();
});

dom.applyRosterButton.addEventListener("click", () => {
  const parsed = parseRoster(dom.rosterTextarea.value);
  if (!parsed.length) {
    dom.saveStatus.textContent = "Please add at least one trainee.";
    return;
  }
  resizeRecords(parsed);
  saveState("Roster updated");
  renderAll();
});

dom.resetDefaultsButton.addEventListener("click", () => {
  state = createDefaultState();
  saveState("Sample data restored");
  renderAll();
});

dom.halfToggle.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-half]");
  if (!button) return;
  state.selectedHalf = Number(button.dataset.half);
  saveState();
  renderToggleButtons();
  renderStats();
  renderPreviews();
});

dom.selectedMonthInput.addEventListener("change", (event) => {
  state.selectedMonth = Number(event.target.value);
  saveState();
  renderMonthSelectors();
  renderMarksEditor();
  renderStats();
  renderPreviews();
});

dom.previewMonthSelect.addEventListener("change", (event) => {
  state.selectedMonth = Number(event.target.value);
  saveState();
  renderMonthSelectors();
  renderMarksEditor();
  renderStats();
  renderPreviews();
});

dom.ruleGroups.addEventListener("input", (event) => {
  const input = event.target.closest("input[data-rule-group]");
  if (!input) return;
  const row = input.closest("tr");
  if (!row) return;
  const group = input.dataset.ruleGroup;
  const index = Number(input.dataset.ruleIndex);
  const field = input.dataset.ruleField;
  const value = Math.max(0, Math.min(100, Number(input.value || 0)));
  const target = state.rules[group][index];
  target[field] = value;
  if (field === "min" && target.min > target.max) target.max = target.min;
  if (field === "max" && target.max < target.min) target.min = target.max;
});

dom.ruleGroups.addEventListener("change", (event) => {
  const input = event.target.closest("input[data-rule-group]");
  if (!input) return;
  applyRuleChange(input);
});

dom.marksEditor.addEventListener("input", (event) => {
  const input = event.target.closest("input[data-student-index][data-metric]");
  if (!input) return;
  const studentIndex = Number(input.dataset.studentIndex);
  const metric = input.dataset.metric;
  const value = input.value === "" ? null : Math.max(0, Math.min(100, Number(input.value)));
  state.records[state.selectedMonth][studentIndex][metric] = Number.isFinite(value) ? value : null;
  saveState();
  const color = getMetricColor(metric, state.records[state.selectedMonth][studentIndex][metric], state.rules);
  const hint = input.parentElement?.querySelector("small");
  if (hint) hint.textContent = COLOR_STYLES[color].name;
  renderPreviews();
});

dom.downloadHalfButton.addEventListener("click", () => {
  runPdfDownload(
    () => createMainPdfBytes(state, state.selectedHalf),
    buildDownloadName("main-half", state, state.selectedHalf),
  );
});

dom.downloadBlankHalfButton.addEventListener("click", () => {
  runPdfDownload(
    () => createMainPdfBytes(state, state.selectedHalf, { withColors: false }),
    buildDownloadName("main-half-blank", state, state.selectedHalf),
  );
});

dom.downloadAllMainButton.addEventListener("click", () => {
  runPdfDownload(() => createAllMainPdfBytes(state), buildDownloadName("main-all", state));
});

dom.downloadMonthlyButton.addEventListener("click", () => {
  runPdfDownload(
    () => createMonthlyPdfBytes(state, state.selectedMonth),
    buildDownloadName("monthly", state, state.selectedMonth),
  );
});

window.addEventListener("resize", onWindowResize);

function applyPortalSharedData(payload) {
  if (!payload || typeof payload !== "object") {
    return;
  }

  state.header.institution = String(payload.institution ?? "");
  state.header.title = String(payload.progressChartTitle ?? "");
  state.header.trade = String(payload.progressTrade ?? payload.tradeName ?? "");
  state.header.academicYear = String(payload.progressAcademicYear ?? "");
  state.header.shift = String(payload.shiftLabel ?? "");
  state.header.unit = String(payload.unit ?? "");

  if (Array.isArray(payload.rosterEntries) && payload.rosterEntries.length) {
    const nextStudents = payload.rosterEntries.map((entry, index) => ({
      id: state.students[index]?.id ?? `student-${index + 1}`,
      name: entry.name || `Trainee ${index + 1}`,
      admission: entry.admNo || "",
    }));
    resizeRecords(nextStudents);
  }

  saveState("Synced from Common Details");
  renderAll();
  lockPortalManagedFields();
  notifyPortalApplied();
}

function lockPortalManagedFields() {
  [
    dom.institutionInput,
    dom.titleInput,
    dom.tradeInput,
    dom.yearInput,
    dom.shiftInput,
    dom.unitInput,
    dom.rosterTextarea,
  ].forEach((field) => {
    if (!field) {
      return;
    }
    field.readOnly = true;
    field.title = "Managed from the Common Details tab";
  });

  if (dom.applyRosterButton) {
    dom.applyRosterButton.disabled = true;
    dom.applyRosterButton.title = "Managed from the Common Details tab";
  }
}

function notifyPortalReady() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage({ type: "portal:ready", app: "progress" }, "*");
  reportPortalHeight();
}

function notifyPortalApplied() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:applied", app: "progress", height: getPortalHeight() },
    "*",
  );
}

function reportPortalHeight() {
  if (window.parent === window) {
    return;
  }

  window.parent.postMessage(
    { type: "portal:height", app: "progress", height: getPortalHeight() },
    "*",
  );
}

function getPortalHeight() {
  return Math.max(
    document.documentElement?.scrollHeight || 0,
    document.body?.scrollHeight || 0,
    document.documentElement?.offsetHeight || 0,
    document.body?.offsetHeight || 0,
  );
}

window.addEventListener("message", (event) => {
  if (event.data?.type !== "portal-shared-update" || event.data?.app !== "progress") {
    return;
  }

  applyPortalSharedData(event.data.payload);
});

window.addEventListener("load", () => {
  if (window.parent !== window) {
    lockPortalManagedFields();
    notifyPortalReady();
  }
});

if (typeof ResizeObserver === "function") {
  const portalObserver = new ResizeObserver(() => {
    reportPortalHeight();
  });
  portalObserver.observe(document.body);
}
